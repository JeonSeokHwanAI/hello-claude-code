# NaverBlogWriter

> AI는 펜이고, 당신이 작가입니다.

AI 블로그 작가가 만든 네이버 블로그 스크래핑·분석·글쓰기 플랫폼입니다.
블로그 분석부터 페르소나 기반 글쓰기까지, AI를 파트너로 활용해 나만의 블로그 작가가 되는 도구입니다.

(기존 `Naver Scraping` 프로젝트를 이관한 것입니다. 자세한 이관 내역은 `docs/90.reference/97.guides/마이그레이션_기록_2026-05-20.md` 참조)

## 프로젝트 개요

- 네이버 블로그를 스크래핑하여 `docs/20.working/scraped/{blog_id}/`에 JSON으로 저장 (중간 데이터)
- 수집 데이터를 기반으로 블로그를 분석/리뷰하고, 페르소나를 적용해 글을 작성
- 모든 기능은 `.claude/skills/` 의 Skill(구 슬래시 명령어)로 제공

## 폴더 구조

```
├── config/                      # 설정 파일 (영속, 사용자 관리)
│   ├── blogs.json               # 블로그 목록
│   ├── me.json                  # 나의 블로그 프로필 (레거시)
│   ├── personas/                # 페르소나별 JSON 파일
│   ├── naver_topics.json        # 네이버 주제 카테고리
│   ├── keyword_config.json      # 키워드 API 설정
│   └── trend_config.json        # 트렌드 API 설정 (API 키)
├── docs/                        # 문서 (작업 단계별 구조)
│   ├── 10.input/                # 외부에서 받은 원본 자료 (수정하지 않음)
│   ├── 20.working/              # 작업 중 중간 데이터 (사용자가 직접 볼 일 없음)
│   │   ├── 21.scraped/          # 스크래핑 원본 JSON (블로그 ID별 폴더 + monthly 등)
│   │   └── 22.state/            # 런타임 상태 (.last_search, .favorites, .active_persona 등 숨김)
│   ├── 30.output/               # 최종 결과물 (사용자가 보는 산출물)
│   │   ├── 31.posts/            # writer 스킬로 작성한 블로그 글
│   │   ├── 32.reviews/          # 블로그 리뷰·전체분석
│   │   └── 33.reports/          # 고객용 HTML 리포트 (+ images/)
│   └── 90.reference/            # 참고 문서·링크·캡처
│       ├── 91.archive/          # 보관용 문서 (PRD, 강의자료, 미사용 코드 등)
│       ├── 92.clips/            # 클리핑한 블로그 글
│       ├── 93.context/          # 글쓰기 참조 (페르소나, Naver Blog Writer 가이드)
│       ├── 97.guides/           # 프로젝트 가이드·작업 기록 (getting-started, 마이그레이션 기록)
│       ├── 98.setup/            # 프로젝트 설정 (requirements.txt, setup-prompt.md)
│       └── 99.external-scripts/ # 외부에서 가져온 참조용 스크립트 (구 samples)
└── .claude/skills/              # 기능별 Skill (search, review, write, ...)
    ├── search/scripts/          # 공유 스크래핑 엔진 (main.py + scraper/ + utils/)
    ├── monthly/scripts/         # monthly_blog.py (이달의 블로그 수집)
    └── bloggers/scripts/        # bloggers_cli.py (블로거 목록 빠른 조회)
```

> Python 스크립트는 skill 규칙(`{스킬명}/scripts/`)에 따라 각 skill 폴더로 이동했습니다.
> 공유 엔진은 주 사용 skill인 `search`가 소유하며, `analyze`는 `search/scripts/main.py`를 참조합니다.
> `config/`에는 **영속 설정**(blogs.json, personas, API 설정)만 두어 루트에 유지합니다.
> 사용자가 직접 볼 일 없는 데이터는 `docs/20.working/`에: 스크래핑 원본은 `21.scraped/`, 런타임 상태(숨김 .json)는 `22.state/`.

## 작업 규칙 (Claude가 따라야 할 규칙)

### Skill 구성 규칙
- 사용자가 생성한 Skill은 반드시 `.claude/skills/{스킬명}/SKILL.md` 형태로 만든다.
  (스킬명 폴더를 만들고 그 아래에 `SKILL.md`를 둔다 — `.claude/skills/SKILL.md` 처럼 평탄하게 두지 않는다)
- Skill에서 사용하는 스크립트는 `.claude/skills/{스킬명}/scripts/` 아래에 둔다.
- Skill이 참고하는 문서·예시·데이터 파일은 `.claude/skills/{스킬명}/references/` 아래에 둔다.

### 파일 저장 위치 가이드

> ⚠️ **모든 생성·갱신 파일은 아래 표의 위치에만 저장한다.** 표에 없는 임의 경로나 프로젝트 루트에 파일을 만들지 않는다.
> 각 Skill은 자신의 출력 경로를 `SKILL.md` 상단의 "저장 위치 (필수 준수)" 섹션에 명시한다.
> 저장 위치가 불분명하면 새 파일을 만들기 전에 이 표를 따르고, 그래도 애매하면 사용자에게 확인한다.

| 파일 유형 | 저장 위치 | 예시 |
|-----------|-----------|------|
| 설정 파일 (영속) | `config/` | `blogs.json`, `personas/`, `trend_config.json` |
| 런타임 상태 (숨김 JSON) | `docs/20.working/22.state/` | `.last_search.json`, `.favorites.json` |
| 스크래핑 결과 (중간 데이터) | `docs/20.working/21.scraped/{blog_id}/` | `zeroenter_posts_*.json` |
| 블로그 글 (writer 산출물) | `docs/30.output/31.posts/` | `{제목}_{YYYYMMDD}.md` |
| 블로그 리뷰·전체분석 | `docs/30.output/32.reviews/` | `{blog_id}_전체분석_{날짜}.md` |
| 고객 리포트 | `docs/30.output/33.reports/` | `{blog_id}_report_{날짜}.html` |
| 글쓰기 참조 (페르소나 등) | `docs/90.reference/93.context/` | 페르소나, 톤앤매너 가이드 |
| 클리핑 글 | `docs/90.reference/92.clips/` | `{제목}.md` |
| 보관용 문서 | `docs/90.reference/91.archive/` | 사용하지 않는 문서 |
| 외부 참조 스크립트 | `docs/90.reference/99.external-scripts/` | 외부에서 가져온 참조 코드 |
| 외부 원본 자료 (수정 X) | `docs/10.input/` | 받은 원본 데이터 |
| Skill 전용 스크립트 | `.claude/skills/{스킬명}/scripts/` | `main.py`, `monthly_blog.py`, `bloggers_cli.py` |

**주의사항:**
- root 폴더에는 `CLAUDE.md`만 유지 (그 외 코드/데이터/문서는 `config/`, `docs/`, `.claude/`로 분류)
- 의존성 설치: `pip install -r docs/90.reference/98.setup/requirements.txt`
- 새로운 **설정**은 `config/`에, 자동 생성되는 **런타임 상태**는 `docs/20.working/22.state/`에 저장
- `config/`, `docs/20.working/21.scraped/`, `docs/20.working/22.state/` 경로는 Python 코드와 Skill이 직접 참조하므로 위치를 바꾸지 않는다
- skill 전용 스크립트는 해당 skill의 `scripts/`에 두고, 프로젝트 루트 기준 경로는 `__file__` 기준 상위 경로로 계산한다

## 자주 쓰는 명령

기능은 `.claude/skills/` 의 Skill로 제공됩니다. `/스킬명 인자` 형태로 실행합니다.

### 수집 및 분석
| 명령 | 설명 | 예시 |
|------|------|------|
| `/search` | 블로그 스크래핑 | `/search zeroenter 5`, `/search 리리 --댓글` |
| `/review` | 블로그 분석 리뷰 | `/review 비움 00`, `/review 리리 댓글` |
| `/analyze` | 블로그 성장 분석 (이전 비교) | `/analyze 셀슈머` |
| `/keyword` | 키워드 분석 | `/keyword AI 바이브 코딩` |
| `/trend` | 트렌드 키워드 검색 | `/trend IT` |
| `/monthly` | 이달의 블로그 수집 | `/monthly add` |

### 블로거/페르소나 관리
| 명령 | 설명 | 예시 |
|------|------|------|
| `/bloggers` | 블로거 목록 관리 | `/bloggers *`, `/bloggers add zeroenter` |
| `/persona` | 페르소나 생성/전환/수정 | `/persona list`, `/persona use AI블로그작가` |

### 콘텐츠 생성 및 저장
| 명령 | 설명 | 예시 |
|------|------|------|
| `/write` | 블로그 글 작성 | `/write` 또는 `/write 제목` |
| `/write-photo` | 실제 사진을 비전으로 보고 페르소나 말투로 작업후기 글 작성 + 사진 배치 | `/write-photo`, `/write-photo 20260602` |
| `/autopost upload` | 작성된 마크다운을 네이버 임시저장에 업로드 (발행은 사용자가 직접) | `/autopost upload <md파일>`, `/autopost status` |
| `/bridge` | 브릿지 콘텐츠 아이디어 | `/bridge 다이어트` |
| `/save` | 블로그 리뷰 저장 | `/save` |
| `/clip` | 블로그 글 클리핑 | `/clip list` |
| `/report` | 고객용 HTML 리포트 생성 | `/report 셀슈머` |

각 Skill의 상세 사용법은 해당 `.claude/skills/{스킬명}/SKILL.md`를 참조하세요.

### Skill별 모델 배정

각 Skill은 목적에 맞는 모델을 `SKILL.md` 프론트매터의 `model` 필드로 지정한다 (해당 실행 턴에만 적용, 이후 세션 모델 복귀). 별칭(`opus`/`sonnet`/`haiku`) 사용 — `opus`는 현재 Opus 4.7로 해석됨.

| 모델 | Skill | 기준 |
|------|-------|------|
| `opus` | write, write-photo, persona, review, analyze, bridge, report | 창작·심층 분석·고객 산출물 (품질 중요) |
| `sonnet` | keyword, trend, save | 리서치·기존 분석 구조화 (균형) |
| `haiku` | search, bloggers, monthly, clip | 스크립트 실행·목록·표 출력 (기계적) |

### Skill별 사용 툴 (allowed-tools)

각 Skill은 사용하는 툴을 `SKILL.md` 프론트매터의 `allowed-tools`(YAML 리스트)로 명시한다 — 나열된 툴은 자동 승인되며, 미기재 툴도 동작은 하되 권한을 물어본다. (SKILL.md의 정식 필드는 `allowed-tools`이며, subagent의 `tools`와 다름)

---
이 문서는 Claude가 매 대화 시작 시 자동으로 읽는다.
