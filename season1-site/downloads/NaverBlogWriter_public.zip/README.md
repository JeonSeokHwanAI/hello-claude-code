# NaverBlogWriter

> AI는 펜이고, 당신이 작가입니다.

네이버 블로그를 **스크래핑·분석**하고, **페르소나**를 적용해 글을 쓰고, **네이버 임시저장**까지 자동화하는 Claude Code 기반 플랫폼입니다. 모든 기능은 `.claude/skills/`의 Skill로 제공됩니다.

## 주요 기능 (Skill)

| 명령 | 설명 |
|------|------|
| `/search` | 네이버 블로그 스크래핑 |
| `/review` · `/analyze` | 블로그 분석(12항목)·성장 추이 |
| `/keyword` · `/trend` | 키워드·트렌드 분석 |
| `/persona` | 글쓰기 페르소나 생성·전환 (인터뷰/블로그 분석) |
| `/write` | 페르소나 기반 블로그 글 작성 |
| `/write-photo` | **실제 사진**을 비전으로 보고 작업후기 글 작성 + 사진 배치(콜라주) |
| `/autopost upload` | 작성 글을 네이버 **임시저장**에 업로드 (발행은 사용자가 직접) |
| `/bloggers` · `/monthly` · `/bridge` · `/clip` · `/report` · `/save` | 목록 관리·수집·아이디어·클리핑·리포트·저장 |

각 Skill의 상세 사용법은 `.claude/skills/{스킬명}/SKILL.md` 참조.

## 설치

```bash
pip install -r docs/90.reference/98.setup/requirements.txt
```

## 초기 설정

1. **API 키 등록** — `config/keyword_config.json`, `config/trend_config.json`의 placeholder를 본인 [네이버 데이터랩/검색 API](https://developers.naver.com) 키로 교체
2. **블로그 목록** — `config/blogs.json`에 분석할 블로그 추가 (샘플 구조 참고)
3. **페르소나** — `/persona create <이름>` 또는 `/persona <블로그ID>`로 생성 (`config/personas/샘플페르소나.json`은 구조 예시)
4. **네이버 자동화(선택, /autopost)** — 환경변수 설정:
   ```powershell
   $env:NAVER_ID="아이디"; $env:NAVER_PW="비밀번호"; $env:NAVER_BLOG_ID="블로그아이디"
   ```

## 폴더 구조

```
config/            # 설정 (API키 템플릿, blogs.json, personas/)
docs/
├── 10.input/      # 외부 원본 자료 (사진 등) — 비어 있음
├── 20.working/    # 중간 데이터(스크래핑·런타임 상태) — 비어 있음
├── 30.output/     # 산출물(글·리뷰·리포트) — 비어 있음
└── 90.reference/  # 가이드·설계 문서(PRD)·글쓰기 규칙
.claude/skills/    # 기능별 Skill (코드)
CLAUDE.md          # 프로젝트 규칙 (Claude가 매 세션 읽음)
```

> `docs/10.input`, `20.working`, `30.output`은 개인 데이터 폴더라 빈 구조(.gitkeep)만 포함됩니다. 사용하면서 채워집니다.

## 주의

- `/autopost`는 **임시저장까지만** 합니다. 공개 발행은 항상 사용자가 직접 누릅니다.
- 스크래핑·분석은 본인 블로그 또는 허용된 범위에서만 사용하세요(저작권·개인정보 유의).

## 라이선스

MIT (또는 원하는 라이선스로 교체)
