"""
write 스킬용: 블로그 글 파일 골격 생성 (IO 전용)

파일명 sanitize + frontmatter + 빈 섹션 템플릿을 docs/30.output/31.posts/ 에 생성하고
생성된 경로를 출력한다. 본문/제목/이미지/태그 등 창작 내용은 LLM이 채운다.

사용법:
    python scaffold_post.py "<제목 또는 키워드>" [--keyword "<키워드>"]
    → 생성된 파일 경로를 stdout으로 출력
"""

import os
import re
import argparse
from datetime import datetime

# 이 스크립트는 .claude/skills/write/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
POSTS_DIR = os.path.join(ROOT, "docs", "30.output", "31.posts")

TEMPLATE = '''---
title: "{title}"
created_at: "{created_at}"
status: "draft"
keyword: "{keyword}"
category: ""
---

# {title}

---

## 작성자 원본

> 사용자가 직접 작성한 영역 (AI 영역 아님)


---

## 본문

(작성 예정)

---

## 추천 제목


---

## Image Prompt


---

## Tags


---

## 메모

'''


def sanitize(name):
    name = re.sub(r'[\\/:*?"<>|]', "", name.strip())  # 파일명 금지문자 제거
    name = re.sub(r"\s+", "_", name)
    return name[:50] or "untitled"


def main():
    ap = argparse.ArgumentParser(description="블로그 글 골격 생성")
    ap.add_argument("title", help="제목 또는 키워드")
    ap.add_argument("--keyword", default="", help="frontmatter용 키워드")
    args = ap.parse_args()

    os.makedirs(POSTS_DIR, exist_ok=True)
    fname = f"{sanitize(args.title)}_{datetime.now():%Y%m%d}.md"
    path = os.path.join(POSTS_DIR, fname)

    if not os.path.exists(path):   # 이미 있으면 덮어쓰지 않고 그대로 반환
        with open(path, "w", encoding="utf-8") as f:
            f.write(TEMPLATE.format(
                title=args.title.strip(),
                created_at=f"{datetime.now():%Y-%m-%d %H:%M}",
                keyword=args.keyword,
            ))
    print(path)


if __name__ == "__main__":
    main()
