---
name: write-photo
description: 사용자가 직접 찍은 실제 사진을 비전으로 보고, 활성 페르소나 말투로 작업후기/경험형 블로그 글을 쓰고 사진을 본문에 배치한다. '/write-photo', '사진으로 글쓰기', '사진 블로그' 요청 시 사용.
model: opus
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - AskUserQuestion
---

# 사진 기반 블로그 글쓰기

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- 사진 원본(입력, 수정 X): `docs/10.input/{페르소나명}/{YYYYMMDD}/`
- 사진 분석(중간 상태): `docs/20.working/22.state/.photo_analysis_{페르소나}_{날짜}.json`
- staging 사진(autopost용): `docs/10.input/gemini/{md_stem}__{NN}_{label}.png`
- 블로그 글(산출물): `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md`

## 개요

`/write`는 텍스트 + 생성형 이미지 프롬프트를 만든다. 본 스킬은 **사용자가 직접 찍은 실제 사진**을 활용한다.
Claude가 사진을 **비전으로 보고**, **활성 페르소나** 말투로 글을 쓰고, 사진을 본문 흐름에 맞게 배치한 마크다운까지 만든다.
업로드는 기존 `/autopost`가 담당한다(이 스킬은 마크다운 + 사진 staging까지).

⚠️ **AI 이미지 생성을 하지 않는다. 실제 사진만 사용한다.** 원본 사진은 읽기만 하고 수정/이동하지 않는다.

## 사용법 (인자 적응형)

| 입력 | 동작 |
|------|------|
| `/write-photo` | 활성 페르소나 + **오늘 날짜** 폴더: `docs/10.input/{활성페르소나}/{오늘}/` |
| `/write-photo 20260602` | 활성 페르소나 + 지정 날짜 폴더 |
| `/write-photo <전체경로>` | 폴더 경로 직접 지정 |

---

## 실행 흐름

### 0단계: 페르소나 로딩 (필수 - 가장 먼저)

⚠️ 폴더 경로가 페르소나명에 의존하므로 반드시 먼저 실행한다.

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/persona_context.py"
```

출력에서 **활성 페르소나 `name`**(폴더 경로용), 닉네임·톤·글쓰기 패턴·content_structure·타겟독자·마무리공식을 확보한다.
활성 페르소나가 없으면 안내 후 종료: "먼저 `/persona use <이름>`으로 페르소나를 활성화하세요."

### 1단계: 사진 폴더 해석

- 인자 없음 → `docs/10.input/{활성페르소나명}/{오늘(YYYYMMDD)}/`
- 인자가 `YYYYMMDD` → `docs/10.input/{활성페르소나명}/{그날짜}/`
- 인자가 경로 → 그대로 사용

폴더가 없거나 이미지가 없으면 종료 안내:
```
docs/10.input/{페르소나}/{날짜}/ 에 사진이 없습니다.
이 폴더에 작업 사진을 넣고 다시 실행하세요.
```

### 2단계: 사진 목록·정렬

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write-photo/scripts/list_photos.py" "<폴더>"
```

스크립트가 **EXIF 촬영일시순**(없으면 mtime → 파일명) 정렬된 JSON을 출력한다:
`{count, sort_source_summary, sample_indices, photos:[{idx, filename, taken_at, sort_source}]}`
이 정렬이 **사진 배치 순서**의 기준이다.

### 3단계: 비전 추정 → 사용자 보정 (핵심)

1. **사진 수에 따른 Read 정책:**
   - `count <= 12` → 전체 사진을 순서대로 **Read**(비전).
   - `count >= 13` → AskUserQuestion으로 (a) 전수 분석 (b) **대표 선별(권장)** 선택.
     - 대표 선별 시 `sample_indices`의 사진만 Read하고, 나머지는 파일명·촬영순서로 before/after를 추론한다.

2. **캡션 초안 표 제시** — Read한 내용으로 각 사진의 캡션과 단계(phase)를 추정해 표로 보여준다:

```
## 사진 분석 (초안) — 확인해주세요

| 순서 | 파일 | 비전 캡션(초안) | 단계 |
|------|------|-----------------|------|
| 1 | 02.jpg | 작업 전, 휠에 염화칼슘 백화 현상 | before |
| 2 | 03.jpg | 스팀건으로 하부 염화칼슘 제거 | process |
| ... | | | |

VSCode에서 사진을 보시면서 틀린 항목만 알려주세요.
예) "3번: 타르 아니고 철분제거 / 7번 패스 / 나머지 확정"
모두 맞으면 "확정"이라고 답해주세요.
```

3. 사용자 보정을 반영한다. "패스"한 사진은 본문 서술에서 비중을 낮추되 배치에는 포함한다.

### 4단계: 확정 분석 저장 (중간 데이터)

보정 반영 후 `docs/20.working/22.state/.photo_analysis_{페르소나}_{날짜}.json` 작성:
```json
{
  "persona": "샘플세차샵",
  "date": "20260602",
  "folder": "...",
  "photos": [
    {"idx": 1, "filename": "02.jpg", "taken_at": "...", "caption": "작업 전 휠 염화칼슘", "phase": "before", "body_hint": "도입 통념 반박용", "user_edited": false}
  ]
}
```

### 5단계: 골격 생성

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/scaffold_post.py" "<제목>" --keyword "<키워드>"
```

`docs/30.output/31.posts/{제목}_{YYYYMMDD}.md` 골격을 만들고 경로를 출력한다.

### 6단계: 본문 작성 (이미지 위치 마커 `[[IMG]]` 필수)

0단계 페르소나(닉네임·톤·content_structure)와 4단계 캡션을 녹여 **본문** 섹션을 작성한다.
- 샘플세차샵 예: 도입(자기소개 + 통념 질문) → 전개(사진 순서대로 작업 과정) → 마무리(행동 제안 + 응원)
- 사진 캡션을 그대로 나열하지 말고, **작업 스토리**로 자연스럽게 풀어낸다.

#### ⚠️ 이미지 위치 마커 (핵심)

사진이 들어갈 자리에 **`[[IMG]]` 마커를 빈 줄로 분리해 직접 본문에 박는다.** autopost가 이 마커 위치·순서에 정확히 사진을 넣는다(단락당 1장 제약 없음). 마커가 없으면 autopost가 단락당 1장으로 자동 배치해 **사진이 누락·어긋난다.**

규칙:
- **마커 개수 = staging할 사진 개수**(4단계 분석의 전체 사진 수). 하나도 빠뜨리지 않는다.
- **마커 순서 = 사진 정렬 순서(촬영일시순)** 와 1:1 일치한다. 8단계 staging이 같은 순서로 `__01 … __NN` 을 만들기 때문. 따라서 본문도 **phase 순서(도입 → before → process → after → 완성)** 대로 마커를 배치하면 사진과 내용이 맞는다.
- 마커는 텍스트가 아니라 위치 신호다. 본문에는 마커 외 캡션을 따로 적지 않는다.

**연속 마커 = 한 줄 콜라주 (네이버 자동 배치):**
- 빈 줄 없이 **연속된 `[[IMG]]` 묶음**은 네이버에서 **한 줄에 나란히(콜라주)** 들어간다.
- 한 문장에 **2장이면 2겹, 3장이면 3겹**(한 줄). 네이버 콜라주는 한 줄 최대 3장.
- **4장 이상**을 한 구역에 두면 autopost가 자동으로 2장씩 분할(홀수는 끝줄 3장)한다. 예: 4장→2+2, 5장→2+3, 6장→2+2+2.
- **세로로 따로** 보여주려면 마커 사이에 **빈 줄**을 넣어 구역을 나눈다.
- 권장: 한 문장(설명)에 어울리는 사진을 **2~3장씩 묶어** 한 줄 콜라주로 두면 실제 블로그처럼 깔끔하다.

예시(콜라주):
```
도어트림에 먼지가 뽀얗게...
[[IMG]]
[[IMG]]
[[IMG]]                          ← 3장 → 한 줄 3겹

발매트는 더 심했습니다...
[[IMG]]
[[IMG]]                          ← 2장 → 한 줄 2겹
```

예시:
```
안녕하세요. ...홍길동입니다.

오늘은 ...싼타페... 맡겨본다구요.

[[IMG]]

먼저 차량 상태부터... 도어트림에 먼지가...

[[IMG]]
[[IMG]]
[[IMG]]

센터페시아 공조구도... 송풍구 틈새마다...

[[IMG]]
[[IMG]]
```

완성 본문은 stdin으로 정리 통과(본문 텍스트 전용, frontmatter 금지). 마커 `[[IMG]]` 는 구문 검사에 걸리지 않으므로 그대로 통과한다:
```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/clean_text.py" --fix -
```

**필수 규칙(Clean Text Mode):** 볼드/마크다운 머리표/리스트 금지, AI 멘트 금지, "여러분"→"당신"(단, 페르소나 관용 마무리는 페르소나 우선), 시작은 "안녕하세요, {닉네임}입니다."

### 7단계: `## 사진 배치` 표 작성 (검수용 메타)

마크다운 하단에 배치 표를 남긴다(autopost는 이 표를 읽지 않고, 사용자 검수용):

```
## 사진 배치

| 순서 | 파일 | 캡션 | 본문 위치 |
|------|------|------|-----------|
| 01 | 02.jpg | 작업 전 휠 염화칼슘 | 도입 직후 |
| ... | | | |
```

### 8단계: 사진 staging (짧은 경로)

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write-photo/scripts/stage_photos.py" "<폴더>"
```

배치(촬영) 순서대로 사진을 `docs/20.working/22.state/.imgstage/{NN}.png`(01.png, 02.png …)로 복사한다(jpg→png 자동 변환).
⚠️ **파일명을 짧게(NN.png) 두는 게 핵심.** 네이버 사진 업로드는 OS 파일 다이얼로그에 경로를 붙여넣는 방식이라, 한글 긴 제목이 든 파일명을 콜라주로 여러 장 묶으면 경로가 잘려 실패한다. 짧은 파일명이면 안정적이다.
파일명순(01,02,…)이 곧 본문 `[[IMG]]` 마커 순서와 1:1로 매칭된다.
(순서를 바꾸려면 `--order 02.jpg,05.jpg,...` 옵션 사용)

### 9단계: 완료 안내

```
## 사진 블로그 글 완성

| 항목 | 내용 |
|------|------|
| 파일 | docs/30.output/31.posts/{제목}_{YYYYMMDD}.md |
| 페르소나 | {이름} ({닉네임}) |
| 사진 | {N}장 staging 완료 (.imgstage) |

👉 이어서: `/autopost upload "docs/30.output/31.posts/{제목}_{YYYYMMDD}.md" --photos-dir "docs/20.working/22.state/.imgstage"`
   네이버 임시저장에 본문 + 실제 사진(콜라주 포함)이 함께 올라갑니다. (발행은 직접)
```

---

## 재사용·연계

| 대상 | 용도 |
|------|------|
| `write/scripts/persona_context.py` | 활성 페르소나·가이드 로딩 (0단계) |
| `write/scripts/scaffold_post.py` | 마크다운 골격 (5단계) |
| `write/scripts/clean_text.py` | 본문 정리 (6단계, 본문 전용) |
| `autopost/scripts/image_prompts.py` | staging 파일명 라벨 규칙(도입/본문N/마무리) — stage_photos가 import |
| `/autopost upload` | staging된 실제 사진 + 본문 임시저장 (9단계 이후) |

## 중요 규칙

- **실제 사진만 사용** (AI 생성 금지). 원본은 읽기 전용.
- 사진 순서 = EXIF 촬영일시순(없으면 mtime/파일명). 사용자가 `--order`로 재정의 가능.
- staging 파일은 반드시 `.png`, 파일명에 `_v` 금지(autopost primary 필터 때문).
- **AskUserQuestion은 3단계 사진 수 선택에서만** 사용. 캡션 보정·제목 확인은 텍스트로 대기.
- 공개 발행은 절대 자동화하지 않는다(autopost 원칙 승계).

## 참조 파일

- PRD: `docs/90.reference/91.archive/Naver_WritePhoto_PRD.md`
- 페르소나: `config/personas/{이름}.json`, `docs/90.reference/93.context/페르소나 - {이름}.md`
- 가이드: `docs/90.reference/93.context/Naver Blog Writer.md`
