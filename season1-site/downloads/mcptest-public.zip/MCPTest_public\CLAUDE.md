# MCPTest

TODO: 프로젝트 설명

## 프로젝트 개요

## 폴더 구조

docs/
  10.input/      ← 외부에서 받은 원본 자료 (수정하지 않음)
  20.working/    ← 작업 중인 초안·중간 산출물
  30.output/     ← 최종 결과물 (공유·배포용)
  90.reference/  ← 참고 문서·링크·캡처

## 작업 규칙 (Claude가 따라야 할 규칙)

### Skill 구성 규칙
- 사용자가 생성한 Skill은 반드시 `.claude/skills/{스킬명}/SKILL.md` 형태로 만든다.
  (스킬명 폴더를 만들고 그 아래에 `SKILL.md`를 둔다 — `.claude/skills/SKILL.md` 처럼 평탄하게 두지 않는다)
- Skill에서 사용하는 스크립트는 `.claude/skills/{스킬명}/scripts/` 아래에 둔다.
- Skill이 참고하는 문서·예시·데이터 파일은 `.claude/skills/{스킬명}/references/` 아래에 둔다.

## MCP 활용 (Google Calendar / Sheets)

이 워크스페이스는 claude.ai 계정에 연결된 Google MCP 도구를 사용한다.
사용자가 "일정", "캘린더", "시트", "스프레드시트"를 언급하면 아래 도구를 쓴다.

### Google Calendar — 일정 (완전한 CRUD 가능)
| 하고 싶은 일 | 사용하는 MCP 도구 |
|---|---|
| 내 캘린더 목록 보기 | `list_calendars` |
| 기간 내 일정 조회 | `list_events` (startTime·endTime ISO 8601) |
| 일정 1건 상세 보기 | `get_event` (eventId) |
| 일정 만들기 | `create_event` (summary·startTime·endTime 필수) |
| 일정 수정 | `update_event` (eventId + 바꿀 필드만) |
| 일정 삭제 | `delete_event` (eventId) |
| 빈 시간 찾기 | `suggest_time` (attendeeEmails에 `primary` 포함) |

- **모든 시간은 서울(KST, `Asia/Seoul`) 기준이다.** 일정 생성·수정·조회 시 항상 `timeZone: "Asia/Seoul"`을 지정한다.
- 시간은 ISO 8601(`2026-06-01T14:00:00`)로 넣는다. 사용자가 시간대를 따로 말하지 않으면 서울 기준으로 해석한다.
- 종일 일정은 `allDay: true` + 시작/종료를 자정으로 설정한다.

### Google Sheets — 시트 (전용 MCP 서버 `google-sheets`)
`mcp-google-sheets` 서버를 `.mcp.json`에 등록해 사용한다. **셀 단위 읽기·쓰기 가능.**
설정 절차는 `docs/90.reference/google-sheets-mcp-setup.md` 참고. (OAuth / 내 구글 계정)

| 하고 싶은 일 | 사용하는 MCP 도구 |
|---|---|
| 스프레드시트 목록 | `list_spreadsheets` |
| 시트 데이터 읽기 | `get_sheet_data` (범위 지정 가능, 예 `A1:C10`) |
| 수식 보기 | `get_sheet_formulas` |
| 셀 쓰기/수정 | `update_cells`, 여러 범위는 `batch_update_cells` |
| 행·열 추가 | `add_rows`, `add_columns` |
| 새 스프레드시트 | `create_spreadsheet` |
| 시트(탭) 만들기/이름변경/복사 | `create_sheet`, `rename_sheet`, `copy_sheet` |
| 검색 | `find_in_spreadsheet`, `search_spreadsheets` |
| 공유 | `share_spreadsheet` |

- 내 구글 계정 권한으로 동작하므로, 접근하려는 시트는 내 계정이 볼 수 있어야 한다.
- 셀 쓰기·덮어쓰기·공유처럼 되돌리기 어려운 작업은 실행 전 사용자에게 확인한다.
- 단순 조회/내보내기만 필요할 땐 기존 Google Drive MCP(`read_file_content`, `download_file_content`)도 쓸 수 있다.

### 외부 반영 시 규칙
- 캘린더 일정 생성·수정·삭제, 시트 생성·덮어쓰기처럼 **되돌리기 어렵거나 외부에 반영되는 작업**은 실행 전에 내용을 사용자에게 보여주고 확인받는다.
- 조회(`list_*`, `get_*`, `read_*`, `search_*`)는 확인 없이 바로 실행해도 된다.

## 자주 쓰는 명령

---
이 문서는 Claude가 매 대화 시작 시 자동으로 읽는다.
