# .claude/secrets/

이 폴더에는 **절대 커밋하면 안 되는** 비밀 파일을 둔다. (`.gitignore`로 제외됨)

> ⚠️ 공유용(public) 버전에서는 실제 키·토큰 파일을 제외했다.
> 아래 절차대로 본인 계정의 파일을 직접 채워 넣어야 동작한다.

## 들어가는 파일
- `gcp-oauth-client.json` — Google Cloud에서 발급한 **OAuth 2.0 클라이언트 ID(데스크톱 앱)** JSON.
  사용자가 직접 내려받아 이 이름으로 저장한다.
- `token.json` — 최초 브라우저 인증 후 MCP 서버가 **자동 생성**하는 액세스 토큰. 직접 만들 필요 없음.

자세한 발급 절차는 `docs/90.reference/google-sheets-mcp-setup.md` 참고.
