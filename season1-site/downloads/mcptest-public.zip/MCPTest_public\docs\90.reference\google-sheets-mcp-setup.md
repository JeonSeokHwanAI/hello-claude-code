# Google Sheets MCP 서버 설정 가이드 (OAuth 방식)

`mcp-google-sheets` 서버를 OAuth(내 구글 계정) 방식으로 연결한다.
셀 단위 읽기·쓰기(`get_sheet_data`, `update_cells`, `batch_update_cells` 등)를 지원한다.

- 실행 방식: `uvx mcp-google-sheets@latest` (uv가 알아서 파이썬·패키지 준비)
- 등록 위치: 프로젝트 루트의 `.mcp.json` (이미 작성됨)
- 비밀 파일 위치: `.claude/secrets/` (`.gitignore`로 제외됨)

---

## 1단계 — Google Cloud 프로젝트 & API 활성화  *(사용자가 브라우저에서)*

1. https://console.cloud.google.com 접속 → 상단에서 **프로젝트 만들기** (예: `MCPTest-Sheets`).
2. **API 및 서비스 → 라이브러리**에서 아래 2개를 검색해 각각 **사용 설정**:
   - **Google Sheets API**
   - **Google Drive API**

## 2단계 — 동의 화면(브랜딩) 만들기  *(사용자가 브라우저에서)*

> 최근 구글이 "OAuth 동의 화면"을 **"Google 인증 플랫폼(Google Auth Platform)"** 으로 개편했다.
> 좌측 메뉴는 `개요 / 브랜딩 / 대상 / 클라이언트 / 데이터 액세스 / 인증 센터 / 설정` 구조다.
> 우리가 쓰는 건 **브랜딩 → 대상 → 클라이언트** 세 개. 이 가이드는 **개편 화면 기준**이다.

좌측 **브랜딩** → **시작하기(Get started)** 를 누르면 **4단계 마법사**가 순서대로 나온다.

**① 앱 정보(App Information)**
- **앱 이름**: 동의 창에 뜰 이름. 예) `MCPTest` 또는 `MCP Bridge`.
  - ⚠️ **앱 이름에 `Google`이라는 단어나 Google 제품명(`Sheets`·`Drive`·`Gmail` 등)을 넣으면 안 된다.**
    넣으면 만들기 단계에서 *"앱 이름 필드가 Google 요구사항을 준수하지 않음"* 오류가 난다.
    (예: `googleMCP Sheets` → 거부 / `MCPTest` → 통과)
- **사용자 지원 이메일**: 드롭다운에서 `your-email@example.com` 선택
- **다음**

**② 대상(Audience)** ← **여기서 "외부/내부"를 고른다**
- **외부(External)** 선택. (개인 Gmail은 항상 외부. `내부`는 Workspace 조직 계정 전용이라 비활성일 수 있음)
- **다음**

**③ 연락처 정보(Contact Information)**
- `your-email@example.com` 입력 → **다음**

**④ 완료(Finish)**
- 동의 체크 → **만들기**

> ⚠️ 이 마법사에는 **"테스트 사용자"와 "스코프" 항목이 없다.** 각각 아래 2-1, (선택)에서 처리한다.

### 2-1. 테스트 사용자 등록  ★빠지면 인증 실패★
마법사를 끝낸 뒤, 좌측 **대상(Audience)** 탭으로 들어간다.
- **게시 상태(Publishing status)** 가 **테스트(Testing)** 인지 확인 — **그대로 둔다. "게시" 버튼 누르지 않는다.**
  게시하면 구글 검수가 필요해 오히려 복잡해진다. 테스트 상태의 유일한 제약은
  *토큰이 주기적으로(보통 7일) 만료*되는 것뿐 — 만료되면 `.claude/secrets/token.json` 지우고 4단계 재인증.
- **테스트 사용자(Test users)** → **추가(Add users)** → `your-email@example.com` 입력 → 저장.
  - 누락 시 인증에서 `403: access_denied`(앱이 테스트 중) 발생.

### 2-2. (선택) 스코프 — 건너뛴다
좌측 **데이터 액세스(Data Access)** 탭의 스코프는 **추가하지 않아도 된다.**
실제 권한은 MCP 서버가 실행 시점에 직접 요청한다.

## 3단계 — OAuth 클라이언트 ID 발급  *(사용자가 브라우저에서)*

좌측 **클라이언트(Clients)** 탭으로 들어간다.
1. **+ 클라이언트 만들기(Create client)**.
2. 애플리케이션 유형: **데스크톱 앱(Desktop app)** 선택 → 만들기.
3. 생성된 항목에서 **JSON 다운로드**.
4. 받은 파일을 아래 경로·이름으로 저장:

   ```
   <프로젝트_루트>\.claude\secrets\gcp-oauth-client.json
   ```

## 4단계 — Claude Code에 서버 로드 & 최초 인증

1. `gcp-oauth-client.json`을 위치시킨 뒤 **Claude Code를 재시작**한다.
   (`.mcp.json`은 시작 시 읽히며, 새 MCP 서버는 한 번 **승인**해야 한다)
2. 서버 승인 후 시트 도구를 처음 호출하면 **브라우저 동의 창**이 뜬다 →
   본인 구글 계정으로 로그인하고 권한 허용.
3. 성공하면 `.claude/secrets/token.json`이 자동 생성된다. 이후로는 브라우저 인증 불필요.

> 동의 화면에서 "Google에서 확인하지 않은 앱" 경고가 나오면,
> **고급 → (앱 이름)(으)로 이동**을 눌러 진행한다 (내가 만든 테스트 앱이라 정상).

## 5단계 — 동작 확인

Claude에게 다음처럼 요청해 확인한다:
- "내 스프레드시트 목록 보여줘" → `list_spreadsheets`
- "○○ 시트의 A1:C10 읽어줘" → `get_sheet_data`
- "○○ 시트 B2에 '테스트' 써줘" → `update_cells`

---

## 참고 — 주요 도구
`list_spreadsheets`, `create_spreadsheet`, `get_sheet_data`, `get_sheet_formulas`,
`update_cells`, `batch_update_cells`, `add_rows`, `add_columns`, `list_sheets`,
`create_sheet`, `rename_sheet`, `copy_sheet`, `find_in_spreadsheet`,
`search_spreadsheets`, `share_spreadsheet`, `add_chart` 등 19종.

## 문제 해결
- **`uvx`를 못 찾음**: 터미널에서 `uvx --version` 확인. 없으면 uv 재설치.
- **`invalid_grant` / 토큰 만료**: `.claude/secrets/token.json` 삭제 후 4단계 재인증.
- **`403 PERMISSION_DENIED`**: 1단계의 두 API가 모두 사용 설정됐는지 확인.
- **다른 사람이 만든 시트 접근 불가**: 그 시트를 내 계정에 공유받아야 한다.
