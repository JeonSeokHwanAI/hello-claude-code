"""
write 스킬용: 블로그 글 파일 골격 생성 (IO 전용)

파일명 sanitize + frontmatter + 빈 섹션 템플릿을 docs/30.output/31.posts/ 에 생성하고
생성된 경로를 출력한다. 본문/제목/이미지/태그 등 창작 내용은 LLM이 채운다.

사용법:
    python scaffold_post.py "<제목 또는 키워드>" [--keyword "<키워드>"] [--source "<write|write-photo|agent>"]
    → 생성된 파일 경로를 stdout으로 출력
"""

import os
import re
import argparse
from datetime import datetime

# 이 스크립트는 .claude/skills/write/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
POSTS_DIR = os.path.join(ROOT, "docs", "30.output", "31.posts")

TEMPLATE = '''---
title: "{title}"
created_at: "{created_at}"
status: "draft"
source: "{source}"
keyword: "{keyword}"
category: ""
---

# {title}

---

## 작성자 원본

> 사용자가 직접 작성한 영역 (AI 영역 아님)


---

## 리서치 (키워드·트렌드·브릿지)

> 이 글이 무엇을 근거로 쓰였는지 남기는 곳. 핵심은 **어떤 키워드로, 어떤 트렌드를 골랐고, 브릿지를 어떻게 적용했는지**다.
> 사용한 항목만 채우고 안 썼으면 "사용 안 함"으로 둔다. (autopost는 이 섹션을 업로드하지 않음)

**작성 경로:** {source}

**선택한 키워드:** 사용 안 함
<!-- 예: 메인 "겨울철 하부세차" / 골든키워드 "휠하우스 염화칼슘 제거"(문서수 적음) / 연관 "온수 고압수, 에어건 건조" -->

**선택한 트렌드:** 사용 안 함
<!-- 예: "언더코팅 vs 하부세차" 논쟁이 커뮤니티 핫이슈 → 이 각도를 본문에 채택 (출처: ...) -->

**브릿지 적용:** 사용 안 함
<!-- 예: me.json 주제와 연결 — "무약품 스팀의 한계를 솔직히 인정" 신뢰 각도로 적용 -->

---

## 본문

(작성 예정)

---

## 추천 제목


---

## Image Prompt


---

## Tags


---

## 메모

'''


def sanitize(name):
    name = re.sub(r'[\\/:*?"<>|]', "", name.strip())  # 파일명 금지문자 제거
    name = re.sub(r"\s+", "_", name)
    return name[:50] or "untitled"


def main():
    ap = argparse.ArgumentParser(description="블로그 글 골격 생성")
    ap.add_argument("title", help="제목 또는 키워드")
    ap.add_argument("--keyword", default="", help="frontmatter용 키워드")
    ap.add_argument("--source", default="write",
                    help="작성 경로: write | write-photo | agent (기본 write)")
    args = ap.parse_args()

    os.makedirs(POSTS_DIR, exist_ok=True)
    fname = f"{sanitize(args.title)}_{datetime.now():%Y%m%d}.md"
    path = os.path.join(POSTS_DIR, fname)

    if not os.path.exists(path):   # 이미 있으면 덮어쓰지 않고 그대로 반환
        with open(path, "w", encoding="utf-8") as f:
            f.write(TEMPLATE.format(
                title=args.title.strip(),
                created_at=f"{datetime.now():%Y-%m-%d %H:%M}",
                source=args.source.strip() or "write",
                keyword=args.keyword,
            ))
    print(path)


if __name__ == "__main__":
    main()
