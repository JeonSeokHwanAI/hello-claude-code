---
name: bloggers
description: config/blogs.json의 블로거 목록을 조회/추가/삭제/업데이트하고 별명으로 검색한다. '/bloggers', '블로거 목록 관리' 요청 시 사용.
model: haiku
allowed-tools:
  - Read
  - Write
  - Edit
  - Glob
  - Bash
  - WebSearch
  - AskUserQuestion
---

# 블로거 목록 관리

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- 블로그 목록(설정): `config/blogs.json`
- 즐겨찾기/변경이력(상태): `docs/20.working/22.state/.favorites.json`, `.blogger_history.json`

`config/blogs.json` 파일에 저장된 블로그 목록을 관리합니다.

## 빠른 조회 (CLI 사용)

**다음 명령은 Python CLI를 실행하여 즉시 결과를 출력합니다:**

```bash
python .claude/skills/bloggers/scripts/bloggers_cli.py <인자>
```

| 인자 | CLI로 처리 | 예시 |
|------|-----------|------|
| `all`, `list` | O | `python .claude/skills/bloggers/scripts/bloggers_cli.py all` |
| `<키워드>` | O | `python .claude/skills/bloggers/scripts/bloggers_cli.py 비움` |
| `#<주제>` | O | `python .claude/skills/bloggers/scripts/bloggers_cli.py #IT` |
| `@<ID>` | O | `python .claude/skills/bloggers/scripts/bloggers_cli.py @hhey0510` |
| `add`, `del`, `update`, `history` | X (AI 처리) | - |
| `?<별명>` | X (WebSearch 필요) | - |

**실행 방법:**
1. 위 표에서 "CLI로 처리: O"인 경우 → Bash로 CLI 실행
2. ⚠️ **CLI가 출력한 표 전체를 응답 텍스트에 그대로 복사해서 보여준다.** Bash 실행 결과는 사용자 화면에 자동으로 표시되지 않으므로, "완료했습니다" 같은 멘트만 하면 사용자에게는 아무것도 안 보인다. 반드시 표 본문(```…``` 박스 전체)을 응답에 붙일 것.
3. "CLI로 처리: X"인 경우 → 아래 상세 지침 따름

---

## 성능 최적화

**캐싱 전략:** 블로그 목록이 100개 이상일 수 있으므로 효율적으로 처리합니다.

1. **파일 읽기 최소화**: 세션 내 첫 호출 시만 `config/blogs.json` 읽기
2. **변경 시에만 갱신**: `add`, `del` 명령 실행 후에만 캐시 갱신
3. **인덱싱 활용**: ID, 주제별로 빠른 검색을 위해 구조화된 접근

**검색 최적화:**
- 키워드 검색: ID → name → description → topics 순서로 매칭
- 주제 필터: topics 필드 직접 매칭 (부분 문자열 포함)
- 대소문자 무시 검색

## 사용법 분기

**인자 분석:**
- 인자 없음 → 대화형 메뉴 표시 (AskUserQuestion 사용)
- 숫자 (1-99) → 해당 번호 블로그 열기
- `add <ID>` → 새 블로그 추가
- `del <ID>` → 블로그 삭제
- `update <ID>` → 분석 결과 기반 블로그 정보 업데이트
- `history <ID>` → 블로그 변경 이력 조회
- `#<주제>` → 주제로 필터링
- `@<ID>` → ID로 검색 (등록된 블로그)
- `?<별명>` → 네이버에서 별명으로 블로거 검색
- `?@<ID>` → 블로그 ID로 직접 조회 (미등록 블로그)
- `*` → 즐겨찾기만 보기
- `+<ID>` → 즐겨찾기 추가
- `-<ID>` → 즐겨찾기 제거
- `p<N>` 또는 `<N>-<M>` → 페이지/범위 보기
- 그 외 텍스트 → 키워드 검색 (등록된 블로그 내)

## 실행 방법

### 1. 사용법 안내 (인자 없음)

`config/blogs.json`을 읽지 않고, 바로 텍스트로 사용법만 표시:

```
## 어떤 작업을 하실건가요?

| # | 명령 | 설명 |
|---|------|------|
| 1 | `/bloggers *` | 즐겨찾기 |
| 2 | `/bloggers recent` | 최근 검색 10개 |
| 3 | `/bloggers all` | 전체 목록 |
| 4 | `/bloggers #<주제>` | 주제별 필터 |
| 5 | `/bloggers <키워드>` | 키워드 검색 (등록된 블로그) |
| 6 | `/bloggers @<ID>` | ID로 검색 |
| 7 | `/bloggers ?<별명>` | 별명으로 블로거 검색 |
| 8 | `/bloggers ?@<ID>` | ID로 블로그 직접 조회 |
| 9 | `/bloggers +<ID>` | 즐겨찾기 추가 |
| 10 | `/bloggers add <ID>` | 새 블로그 추가 |
| 11 | `/bloggers del <ID>` | 블로그 삭제 |
| 12 | `/bloggers update <ID>` | 분석 기반 정보 업데이트 |
| 13 | `/bloggers history <ID>` | 변경 이력 조회 |
```

### 2. 블로그 열기 (숫자)
해당 번호의 블로그 URL을 `start` 명령으로 브라우저에서 열기.

### 3. 새 블로그 추가 (`add <ID>`)
1. 네이버 블로그 페이지에서 블로그명 가져오기 (Python 스크립트 사용)
2. 포스트 내용 기반으로 주제 자동 분류 제안
3. `config/blogs.json`에 추가
4. 메모리 파일 업데이트

### 4. 블로그 삭제 (`del <ID>`)
등록된 블로그를 삭제합니다.

**실행 방법:**
1. `config/blogs.json`에서 해당 ID 확인
2. 삭제 전 블로그 정보 표시
3. 확인 후 삭제 실행
4. `docs/20.working/22.state/.favorites.json`에서도 제거 (있다면)
5. 메모리 파일 업데이트

**출력 형식:**
```
## 블로그 삭제: <ID>

| 항목 | 내용 |
|------|------|
| ID | <ID> |
| 블로그명 | ... |
| 주제 | ... |

삭제 완료되었습니다.
```

**예시:**
- `/bloggers del questioncue` - questioncue 블로그 삭제

### 5. 블로그 정보 업데이트 (`update <ID>`)
전체 분석 결과를 기반으로 블로거 정보를 업데이트합니다.

**실행 방법:**
1. `docs/30.output/32.reviews/{ID}_전체분석_*.md` 파일에서 최신 분석 데이터 로드
2. 분석 결과의 주제 분포, 브랜딩 정보 추출
3. 현재 `config/blogs.json` 정보와 비교
4. 변경 사항 표시 및 확인 후 업데이트
5. **변경 이력을 `docs/20.working/22.state/.blogger_history.json`에 저장**

**출력 형식:**
```
## 블로거 정보 업데이트: <ID>

### 변경 사항 비교

| 항목 | 현재 | 분석 결과 (제안) |
|------|------|------------------|
| 설명 | ... | ... |
| 주제(메인) | ... | ... |
| 주제(서브) | ... | ... |

업데이트를 적용하시겠습니까?
```

**분석 데이터 매핑:**
- **설명**: 분석의 "주제 분포" 상위 3개를 조합하여 생성
- **주제(메인)**: 분석의 주요 주제를 네이버 카테고리에 매핑
- **주제(서브)**: 분석의 세부 주제들을 네이버 서브 카테고리에 매핑

**변경 이력 저장:**
업데이트 적용 시 `docs/20.working/22.state/.blogger_history.json`에 기록:
```json
{
  "zeroenter": [
    {
      "date": "2026-02-12",
      "analysis_file": "docs/30.output/32.reviews/zeroenter_전체분석_20260212.md",
      "overall_score": 89,
      "changes": {
        "description": {"from": "...", "to": "..."},
        "topics.sub": {"from": [...], "to": [...]}
      }
    }
  ]
}
```

**예시:**
- `/bloggers update zeroenter` - zeroenter 정보 업데이트

### 6. 변경 이력 조회 (`history <ID>`)
블로거 정보 변경 이력을 조회합니다.

**실행 방법:**
1. `docs/20.working/22.state/.blogger_history.json`에서 해당 ID 이력 로드
2. 날짜순으로 정렬하여 표시

**출력 형식:**
```
## 블로거 변경 이력: zeroenter

| 날짜 | 점수 | 변경 항목 |
|------|------|-----------|
| 2026-02-12 | 89 | 블로그명, 설명, 주제(서브) |
| 2026-01-15 | 82 | 설명 |

### 2026-02-12 변경 내역

| 항목 | 이전 | 이후 |
|------|------|------|
| 블로그명 | 지식의 대장장이가 알려주는 AI | 지식의 대장장이 |
| 설명 | AI 활용, 바이브 코딩... | AI 바이브코딩, 비전공자... |
| 주제(서브) | IT·컴퓨터 | IT·컴퓨터, 교육·학문 |

분석 파일: docs/30.output/32.reviews/zeroenter_전체분석_20260212.md
```

**예시:**
- `/bloggers history zeroenter` - zeroenter 변경 이력 조회
- `/bloggers history` - 전체 변경 이력 요약

### 7. 주제 필터링 (`#<주제>`)
`config/naver_topics.json` 참조하여 해당 주제의 블로그만 필터링 표시.
예: `/bloggers #IT·컴퓨터`

주제 선택 시 대분류만 선택하면 바로 목록 표시 (소분류 단계 생략).

### 5. ID 검색 (`@<ID>`)
정확한 ID 매칭으로 블로그 정보 상세 표시.

### 6. 키워드 검색 (그 외)
블로그명, 설명, 주제에서 키워드 포함 여부로 필터링.
등록된 블로그 내에서만 검색합니다.

### 6-1. 별명으로 블로거 검색 (`?<별명>`)
등록되지 않은 블로거를 별명/닉네임으로 네이버에서 검색합니다.

**실행 방법:**
1. WebSearch로 `네이버 블로그 "<별명>" 블로거` 검색
2. 검색 결과에서 블로그 URL 추출
3. 블로그 ID, 블로그명, 주제 정보 표시

**출력 형식:**
```
## 네이버 검색 결과: 별명 "<별명>"

| # | ID | 블로그명 | 별명 | URL |
|---|-----|----------|------|-----|
| 1 | ... | ...      | ...  | ... |

---
💡 `/bloggers add <ID>` - 블로그 등록
💡 `/bloggers ?@<ID>` - ID로 직접 조회
```

**예시:**
- `/bloggers ?띵큐` - "띵큐" 별명 블로거 검색
- `/bloggers ?육아 띵큐` - 육아 분야 "띵큐" 블로거
- `/bloggers ?맛집 리뷰어` - 맛집 리뷰어 블로거 검색

### 6-2. ID로 블로그 직접 조회 (`?@<ID>`)
블로그 ID를 알고 있을 때 직접 조회합니다.

**실행 방법:**
1. `https://blog.naver.com/<ID>` 접근
2. 블로그명, 별명, 소개글, 주제 추출
3. 등록 여부 확인

**출력 형식:**
```
## 블로그 조회: @<ID>

| 항목 | 내용 |
|------|------|
| ID | <ID> |
| 블로그명 | ... |
| 별명 | ... |
| 소개 | ... |
| URL | https://blog.naver.com/<ID> |
| 등록 여부 | 미등록 |

---
💡 `/bloggers add <ID>` - 블로그 등록
```

**예시:**
- `/bloggers ?@questioncue` - questioncue 블로그 조회
- `/bloggers ?@zeroenter` - zeroenter 블로그 조회

### 7. 즐겨찾기 (`*`)
`docs/20.working/22.state/.favorites.json` 파일에서 즐겨찾기 목록만 표시.

### 8. 즐겨찾기 추가/제거 (`+<ID>`, `-<ID>`)
- `+zeroenter` → 즐겨찾기에 추가
- `-zeroenter` → 즐겨찾기에서 제거

`docs/20.working/22.state/.favorites.json` 파일 형식:
```json
["zeroenter", "ari_school", "980207"]
```

### 9. 페이지/범위 보기 (`p<N>`, `<N>-<M>`)
- `p2` → 21~40번 표시 (페이지당 20개)
- `1-20` → 1~20번 표시
- `50-60` → 50~60번 표시

## 출력 형식 (필수 준수 — 변경 금지)

목록 표시 시 **반드시 아래 ASCII 박스 표 형식**으로만 출력한다. 마크다운 표로 바꾸거나, 컬럼을 임의로 추가/생략하지 않는다.

**규칙:**
- 컬럼은 `#, ID, 블로그명, 별명, 주제` **5개로 고정** (설명/description 컬럼은 **항상 제외**).
- `┌┬┐ ├┼┤ └┴┘` 박스 문자를 사용하고, **각 데이터 행 사이에 구분선(`├┼┤`)을 넣는다**.
- 한글·전각 문자는 2칸으로 계산해 컬럼 폭을 맞춘다.

**구현:** 이 형식은 `scripts/bloggers_cli.py`의 `print_table()`에 고정되어 있다.
CLI로 처리되는 조회(`all`, `<키워드>`, `#<주제>`, `@<ID>`)는 **CLI 출력을 그대로 사용자에게 내보낸다** — 별도로 다시 그리지 않는다.
CLI를 거치지 않는 경우(즐겨찾기 `*`, 페이지/범위 등)도 아래와 동일한 형식으로 직접 그린다.

```
## 전체 목록 (N개)

┌───┬────────────┬──────────────┬────────────┬──────────────────┐
│ # │ ID         │ 블로그명     │ 별명       │ 주제             │
├───┼────────────┼──────────────┼────────────┼──────────────────┤
│ 1 │ zeroenter  │ AI블로그작가 │ 지식의대장장이 │ 지식·동향    │
├───┼────────────┼──────────────┼────────────┼──────────────────┤
│ 2 │ ...        │ ...          │ ...        │ ...              │
└───┴────────────┴──────────────┴────────────┴──────────────────┘

---
💡 `/bloggers <번호>` - 블로그 열기
💡 `/bloggers +<ID>` - 즐겨찾기 추가
```

## 참조 파일
- `config/blogs.json`: 블로그 메타데이터
- `config/naver_topics.json`: 네이버 주제 카테고리
- `docs/20.working/22.state/.favorites.json`: 즐겨찾기 목록
- `docs/20.working/22.state/.last_searches.json`: 최근 검색 기록

## 최근 검색 기록

`/search` 또는 `/review` 실행 시 `docs/20.working/22.state/.last_searches.json`에 기록:
```json
{
  "searches": [
    {"id": "zeroenter", "timestamp": "2024-01-15T10:30:00"},
    {"id": "ari_school", "timestamp": "2024-01-14T15:20:00"}
  ]
}
```
최대 20개까지 저장, 오래된 것은 자동 삭제.
