"""write-photo 스킬용: 사진 폴더를 EXIF 촬영일시순으로 정렬해 목록 JSON 출력 (읽기 전용).

정렬 우선순위: EXIF DateTimeOriginal → 파일 수정시각(mtime) → 파일명.
사진별 sort_source(exif/mtime/name)를 기록해 어떤 기준으로 정렬됐는지 투명하게 남긴다.

사용법:
    python -X utf8 list_photos.py "<사진폴더>"
출력(JSON):
    {
      "folder": "...",
      "count": 31,
      "sort_source_summary": {"exif": 0, "mtime": 31, "name": 0},
      "sample_indices": [0, 3, 6, ...],   # 13장 초과 시 균등 12개, 이하면 전체
      "photos": [
        {"idx": 0, "filename": "02.jpg", "taken_at": "2026-03-10T21:41:31", "sort_source": "exif"},
        ...
      ]
    }
"""
from __future__ import annotations

import os
import sys
import json
import argparse
from datetime import datetime

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".heic"}
SAMPLE_MAX = 12          # 대표 선별 시 Read할 최대 장수
SAMPLE_THRESHOLD = 13    # 이 장수 이상이면 sample_indices를 균등 축소

# EXIF 태그: 36867 = DateTimeOriginal, 306 = DateTime
_EXIF_DATETIME_ORIGINAL = 36867
_EXIF_DATETIME = 306


def _exif_taken_at(path: str):
    """EXIF 촬영일시(datetime) 반환, 없으면 None. Pillow 미설치/실패 시 None."""
    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        with Image.open(path) as img:
            exif = img.getexif()
            if not exif:
                return None
            raw = exif.get(_EXIF_DATETIME_ORIGINAL) or exif.get(_EXIF_DATETIME)
            if not raw:
                return None
            # EXIF 표준 포맷: "YYYY:MM:DD HH:MM:SS"
            return datetime.strptime(str(raw).strip(), "%Y:%m:%d %H:%M:%S")
    except Exception:
        return None


def _collect(folder: str):
    """폴더 내 이미지들의 (filename, sort_key:datetime, source) 목록."""
    items = []
    for name in os.listdir(folder):
        ext = os.path.splitext(name)[1].lower()
        if ext not in IMAGE_EXTS:
            continue
        full = os.path.join(folder, name)
        if not os.path.isfile(full):
            continue

        taken = _exif_taken_at(full)
        if taken is not None:
            source = "exif"
        else:
            try:
                taken = datetime.fromtimestamp(os.path.getmtime(full))
                source = "mtime"
            except OSError:
                taken = None
                source = "name"
        items.append({"filename": name, "taken": taken, "source": source})
    return items


def _sort_key(item):
    """taken_at 우선, 동률/None은 파일명으로 안정 정렬."""
    taken = item["taken"]
    # None(=name 소스)은 가장 뒤로 밀되 파일명순 유지
    has_dt = 0 if taken is not None else 1
    ts = taken.timestamp() if taken is not None else 0.0
    return (has_dt, ts, item["filename"].lower())


def _sample_indices(count: int):
    """13장 이상이면 균등 12개 인덱스, 이하면 전체 인덱스."""
    if count <= SAMPLE_MAX:
        return list(range(count))
    # 0..count-1 을 SAMPLE_MAX개로 균등 분배
    step = (count - 1) / (SAMPLE_MAX - 1)
    idxs = sorted({round(i * step) for i in range(SAMPLE_MAX)})
    return idxs


def main():
    ap = argparse.ArgumentParser(description="사진 폴더 EXIF 촬영일시순 목록 JSON")
    ap.add_argument("folder", help="사진 폴더 경로")
    args = ap.parse_args()

    folder = os.path.abspath(args.folder)
    if not os.path.isdir(folder):
        print(json.dumps({"error": f"폴더 없음: {folder}", "count": 0, "photos": []},
                         ensure_ascii=False))
        sys.exit(1)

    items = _collect(folder)
    items.sort(key=_sort_key)

    summary = {"exif": 0, "mtime": 0, "name": 0}
    photos = []
    for i, it in enumerate(items):
        summary[it["source"]] += 1
        photos.append({
            "idx": i,
            "filename": it["filename"],
            "taken_at": it["taken"].isoformat() if it["taken"] else None,
            "sort_source": it["source"],
        })

    result = {
        "folder": folder,
        "count": len(photos),
        "sort_source_summary": summary,
        "sample_indices": _sample_indices(len(photos)),
        "photos": photos,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
