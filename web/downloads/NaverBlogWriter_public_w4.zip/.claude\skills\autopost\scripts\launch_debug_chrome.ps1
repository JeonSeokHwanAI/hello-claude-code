<#
launch_debug_chrome.ps1 — Gemini 이미지 생성(generate-images)을 위한 디버그 모드 Chrome 보장.

배경:
  - image_gen.py(gemini_web)는 Chrome을 직접 띄우지 않고, 디버그 포트(9222)에 attach해서
    gemini.google.com 탭을 자동 조작한다. 그래서 이미지 생성 전에 디버그 Chrome이 떠 있어야 한다.
  - Chrome 136+는 보안상 "기본 프로필(Default User Data)에서는 원격 디버깅 포트를 막는다."
    → 반드시 전용 프로필(DebugProfile9222)로 띄운다. 전용 프로필이라 기존 일반 Chrome을 종료할 필요가 없다.
  - 처음 한 번은 열린 창에서 Gemini 로그인이 필요하다(이후 전용 프로필이 로그인을 기억).

동작:
  - 포트가 이미 열려 있으면 그대로 사용(ALREADY_OPEN).
  - 아니면 전용 프로필로 띄우고 포트가 열릴 때까지 대기(LAUNCHED_OK / LAUNCH_TIMEOUT).

출력(stdout 마지막 줄)과 exit code:
  ALREADY_OPEN(0) / LAUNCHED_OK(0) / LAUNCH_TIMEOUT(2) / CHROME_NOT_FOUND(3)
#>
param(
  [int]$Port = 9222,
  [int]$TimeoutSec = 20
)

function Test-DebugPort([int]$p) {
  try {
    $null = Invoke-WebRequest -Uri "http://127.0.0.1:$p/json/version" -UseBasicParsing -TimeoutSec 2
    return $true
  } catch {
    return $false
  }
}

if (Test-DebugPort $Port) {
  Write-Output "ALREADY_OPEN"
  exit 0
}

$chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
if (-not (Test-Path $chrome)) { $chrome = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" }
if (-not (Test-Path $chrome)) {
  Write-Output "CHROME_NOT_FOUND"
  exit 3
}

$dbg = Join-Path $env:LOCALAPPDATA "Google\Chrome\DebugProfile$Port"
Start-Process $chrome -ArgumentList "--remote-debugging-port=$Port", "--user-data-dir=`"$dbg`"", "https://gemini.google.com"

$deadline = (Get-Date).AddSeconds($TimeoutSec)
while ((Get-Date) -lt $deadline) {
  Start-Sleep -Milliseconds 800
  if (Test-DebugPort $Port) {
    Write-Output "LAUNCHED_OK"
    exit 0
  }
}

Write-Output "LAUNCH_TIMEOUT"
exit 2
