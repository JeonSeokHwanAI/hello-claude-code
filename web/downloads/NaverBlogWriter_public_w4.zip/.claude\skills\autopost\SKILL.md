---
name: autopost
description: |
  이미 작성된 마크다운 파일을 네이버 블로그 임시저장에 자동 업로드한다.
  Selenium으로 로그인 → SmartEditor에 제목/본문/태그 입력 → 임시저장 클릭.
  공개 발행 버튼은 절대 누르지 않는다 (사용자가 직접). 글 작성 자체는 /write 스킬 담당.
  '/autopost upload', '임시저장', '네이버 업로드' 요청 시 사용.
model: opus
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# /autopost — 네이버 블로그 자동 임시저장

> ⚠️ **이 스킬은 임시저장(Draft)까지만 합니다. 공개 발행 버튼은 절대 누르지 않습니다.**
> 마지막 "발행" 클릭은 사용자가 네이버 블로그 앱/웹에서 직접 수행합니다.

> 📝 **이 스킬은 글을 작성하지 않습니다.** 글 작성은 `/write` 스킬의 책임입니다.
> autopost는 `/write`가 만든 `docs/30.output/31.posts/*.md` 파일을 받아 네이버에 올릴 뿐입니다.

## 사용법

| 명령 | 동작 |
|------|------|
| `/autopost generate-images <파일>` | 마크다운의 Image Prompt 4개 → Gemini로 이미지 생성·다운로드 |
| `/autopost upload <파일>` | 마크다운 + 동일 md_stem의 Gemini 이미지를 네이버 임시저장에 올림 (메인) |
| `/autopost upload <파일> --photos-dir <폴더>` | **실제 사진**을 그 폴더에서 파일명순으로 올림 (write-photo staging용). 본문 `[[IMG]]` 마커 + 콜라주 지원 |
| `/autopost upload <파일> --skip-images` | 텍스트/태그만 업로드 (이미지 무시) |
| `/autopost upload <파일> --dry-run` | 임시저장 직전 60초 중단 (검증용) |
| `/autopost status` | `.drafts.json` 최근 N건 표시 |
| `/autopost explore-publish <파일>` | 개발자용: 발행 다이얼로그 selector 덤프 |

---

## 일반 흐름 (이미지 포함)

```powershell
$env:PYTHONIOENCODING="utf-8"

# 1) Gemini로 이미지 4장 생성 (Chrome 디버그 모드 + gemini.google.com 탭 필요)
py -3.12 ".claude\skills\autopost\scripts\autopost.py" generate-images "<md>"

# 2) 마크다운 + 이미지를 네이버 임시저장에 업로드
py -3.12 ".claude\skills\autopost\scripts\autopost.py" upload "<md>"
```

## `generate-images <파일>` 흐름
1. `## Image Prompt (N개)` 섹션 파싱 → 각 프롬프트 + 의미 라벨 (도입/본문N/마무리)
2. attach된 Gemini 탭에 "Generate an image: ..." 형식으로 순차 전송
3. 새 이미지 등장까지 대기 (각 최대 150초) → blob URL → canvas → PNG
4. 저장: `docs/10.input/gemini/{md_stem}__{NN}_{label}.png`

전제: 디버그 모드 Chrome(포트 9222 + 로그인된 gemini.google.com 탭)이 떠 있어야 함

> ✅ **권장: 헬퍼 스크립트로 띄운다.** 전용 프로필(`DebugProfile9222`)을 쓰므로 **기존 일반 Chrome을 종료할 필요가 없다.**
> ```powershell
> & ".claude\skills\autopost\scripts\launch_debug_chrome.ps1"
> ```
> 마지막 출력이 `ALREADY_OPEN`/`LAUNCHED_OK`면 준비 완료. **처음 한 번은 열린 창에서 Gemini 로그인**이 필요하다(이후 전용 프로필이 기억).
>
> ⚠️ **기본 프로필은 쓰지 않는다.** Chrome 136+는 보안상 기본 프로필(Default User Data)에서 원격 디버깅 포트를 막는다 —
> 기본 프로필로 띄우면 포트 9222가 열리지 않는다. 그래서 헬퍼는 전용 프로필을 쓴다.
>
> `generate-images`는 attach 전에 포트 9222를 프리플라이트로 확인하고, 막혀 있으면 안내를 출력한 뒤 종료한다(**exit code 2**).
> 이미지 없이 진행하려면 `upload <md> --skip-images`로 폴백한다.

수동으로 띄우려면(전용 프로필 직접 지정):
```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --remote-debugging-port=9222 `
  --user-data-dir="$env:LOCALAPPDATA\Google\Chrome\DebugProfile9222" `
  https://gemini.google.com
```

## `upload <파일>` 흐름
1. 마크다운 파싱 — title, body, tags
2. **이미지 매칭** — `--photos-dir` 지정 시 그 폴더의 파일을 파일명순으로(write-photo 실사진), 미지정 시 `docs/10.input/gemini/{md_stem}__*.png` 글롭(Gemini 생성)
3. 쿠키 로그인 → 글쓰기 페이지 진입 (쿠키 만료 시 ID/PW 재로그인)
4. 제목/본문 자동 입력 (`.se-section-documentTitle .se-text-paragraph`, `.se-section-text .se-text-paragraph`)
5. **본문 입력 + 이미지 배치** — 본문에 `[[IMG]]` 마커가 있으면 그 위치/순서에 삽입(없으면 단락당 1장 자동 배치). 연속 마커는 한 구역으로 묶어 `_collage_split`(2~3장)으로 한 줄씩 처리
6. **이미지 업로드(다이얼로그 없음)** — `input[type=file].click()`을 JS 후킹으로 막고 캡처한 input에 경로를 직접 `send_keys`. 2장 이상이면 '사진 첨부 방식' 팝업에서 **콜라주**(`div.se-image-type-option-collage`) 자동 선택 → 한 줄 콜라주
7. 발행 다이얼로그 오픈 → (dim 사라짐 대기 + JS click 폴백) 태그 input(`input[class^='tag_input']`) → 다이얼로그 닫기
8. 임시저장 버튼(`button[class^='save_btn']`) 자동 클릭 + 카운트 검증
9. `.drafts.json` 추가 + frontmatter 갱신 (`status: drafted`)

> 💡 **실사진 콜라주 글(write-photo 산출물)**: `upload <md> --photos-dir docs/20.working/22.state/.imgstage`
> 다이얼로그가 안 떠서 사용자 개입이 필요 없다(예전 pyautogui 방식 폐기).

이미지 없이 텍스트만 업로드: `--skip-images`

### 환경변수 (첫 로그인에만 필수)
```powershell
$env:NAVER_ID="아이디"
$env:NAVER_PW="비밀번호"
$env:NAVER_BLOG_ID="블로그아이디"   # 보통 NAVER_ID와 동일
$env:PYTHONIOENCODING="utf-8"       # 한글 콘솔 출력
```

> 🔑 **두 번째 실행부터는 환경변수 불필요.** 한 번 임시저장에 성공하면:
> - 쿠키 세션(`~/.config/naverblog/session.json`) + 전용 Chrome 프로필이 저장되어 재로그인 없이 진입
> - `blog_id`는 `config/autopost_config.json`에 저장되어 자동 사용 (비밀번호는 저장 안 함)
>
> 따라서 `NAVER_ID`/`NAVER_PW`는 **첫 로그인** 또는 **쿠키 만료 시 재로그인** 때만 필요하다.
> 쿠키 세션이 살아있으면 `upload`는 환경변수 없이 그대로 동작한다.
> (디스패처/에이전트도 쿠키 세션이 있으면 계정을 다시 묻지 않는다.)

### 가드레일 (절대 위반 금지)
- 공개 발행 버튼(`button[class^='publish_btn']`, `button[class^='confirm_btn']`)은 **selector 등록 + 텍스트 검증으로 이중 차단**
- `drafter.py`의 `FORBIDDEN_CLASS_PATTERNS` 위반 시 `RuntimeError`
- 파일 쓰기는 반드시 `_safe_write_text` (백업 + atomic replace, 빈 내용 거부)
- 자격증명은 코드/로그/메모리에 영구 저장 안 함 (쿠키만 OS 권한 폴더에 저장)

---

## `status`

`.drafts.json`의 최근 기록 출력.

```powershell
py -3.12 ".claude\skills\autopost\scripts\autopost.py" status --limit 10
```

---

## `dry-run <파일>`

본문 입력까지 진행하고 임시저장 직전 60초 중단. 사용자가 브라우저에서 시각 검증.

```powershell
py -3.12 ".claude\skills\autopost\scripts\autopost.py" upload "<파일>" --dry-run
```

dry-run 모드는 추가로 페이지의 모든 버튼/form 필드/제목·본문 영역 DOM을 stdout에 덤프 (selector 회귀 대비).

---

## `explore-publish <파일>` (개발자용)

⚠️ 개발자/디버그 전용. 발행 다이얼로그를 명시적으로 열어 내부 selector를 덤프한다. **다이얼로그 안의 어떤 버튼도 클릭하지 않음** (가드레일 유지).

```powershell
py -3.12 ".claude\skills\autopost\scripts\drafter.py" --explore-publish
```

사용 시점: 네이버 SmartEditor DOM이 바뀌어 카테고리/태그/저장 selector 회귀가 의심될 때.

---

## 저장 위치 (CLAUDE.md 일치)

| 데이터 | 위치 |
|--------|------|
| 입력 마크다운 (write 스킬 산출물) | `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md` |
| 임시저장 기록 | `docs/20.working/22.state/.drafts.json` |
| 실행 로그/스크린샷 | `docs/20.working/22.state/.autopost_log/{YYYYMMDD_HHMM}/` |
| 쿠키 세션 | `~/.config/naverblog/session.json` (git 커밋 금지) |
| 설정 (M5 이후) | `config/autopost_config.json` |

## 의존성

```
selenium>=4.15
webdriver-manager>=4.0
pyperclip>=1.8
pyautogui>=0.9.54
python-frontmatter>=1.0
```

설치: `py -3.12 -m pip install -r docs/90.reference/98.setup/requirements.txt`

## 참고

- 설계 문서: `docs/90.reference/91.archive/Naver_AutoPosting_PRD.md`
- 글쓰기 규약: `docs/90.reference/93.context/Naver Blog Writer.md` (write 스킬에서 적용)
- 원본 자산: `docs/90.reference/99.external-scripts/marketing_wizard_Extand_AutoLoad.py` (Selenium 베이스)
- Selector 카탈로그: `.claude/skills/autopost/references/smarteditor_selectors.md`

## 마일스톤 진행 상황

- [x] M0: 원본 함수 추출 + GUI 의존 제거
- [x] M1: 임시저장 버튼 자동 클릭 + 가드레일 + 카운트 검증
- [x] M2: 발행 다이얼로그 → 태그 자동 입력 → 다이얼로그 닫기
- [x] M3: `upload <파일>` 슬래시 + frontmatter 갱신 + `_safe_write_text` 안전장치
- [x] M5: 이미지 자동화
  - [x] Gemini 어댑터 (`image_gen.py`): 마크다운 → 4장 PNG (Chrome attach + blob→canvas)
  - [x] SE3 업로드 통합 (`drafter._upload_image`): file input 직접 send_keys + pyautogui 폴백
  - [x] `upload <md>` 자동 매칭: `docs/10.input/gemini/{md_stem}__*.png` 글롭 → 일괄 업로드
- [ ] M6: 안정화 (draft_id 추출 개선, 다중 블로그, 스케줄링, 이미지 위치/캡션 매핑)

**[future work]** `/write`를 subagent로 확장할 때 그 안에서 autopost upload를 호출 → 키워드 → 글 → 임시저장의 end-to-end 흐름은 write 책임으로 구현. autopost는 단일 책임(upload)만 유지.
