"""글쓰기 페이지에 들어가서 현재 URL, 제목, iframe 목록, body 일부를 덤프한다 (진단용)."""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# 같은 폴더의 session.py 사용
sys.path.insert(0, str(Path(__file__).parent))
from session import build_driver, load_or_login


def main():
    naver_id = os.environ["NAVER_ID"]
    naver_pw = os.environ["NAVER_PW"]
    blog_id = os.environ.get("NAVER_BLOG_ID", naver_id)

    driver = build_driver(headless=False)
    try:
        ok = load_or_login(driver, naver_id, naver_pw)
        print(f"[diag] login ok: {ok}")
        url = f"https://blog.naver.com/{blog_id}/postwrite"
        print(f"[diag] navigate: {url}")
        driver.get(url)
        time.sleep(5)

        print("=" * 60)
        print(f"[diag] current url     : {driver.current_url}")
        print(f"[diag] page title      : {driver.title}")
        print("=" * 60)

        iframes = driver.find_elements("tag name", "iframe")
        print(f"[diag] iframe count    : {len(iframes)}")
        for i, f in enumerate(iframes):
            try:
                print(f"  - iframe[{i}] id={f.get_attribute('id')!r}  name={f.get_attribute('name')!r}  src={f.get_attribute('src')!r}")
            except Exception as e:
                print(f"  - iframe[{i}] error: {e}")

        src = driver.page_source
        print(f"[diag] page_source len : {len(src)}")
        # 의미 있는 문자열 검사
        for needle in ["mainFrame", "se-section-text", "se-documentTitle", "추가 인증", "기기 등록", "2단계 인증", "PostWriteForm", "smarteditor", "nidlogin"]:
            print(f"  contains {needle!r}: {needle in src}")

        # iframe 안 진입 시도
        for fid in ("mainFrame",):
            try:
                driver.switch_to.default_content()
                driver.switch_to.frame(fid)
                print(f"[diag] entered iframe {fid!r}")
                inner = driver.page_source[:500]
                print(f"  inner head: {inner!r}")
                # editor selector 검사
                for sel in (".se-section-text .se-text-paragraph", ".se-section-documentTitle"):
                    found = driver.find_elements("css selector", sel)
                    print(f"  selector {sel!r}: {len(found)}개")
                driver.switch_to.default_content()
            except Exception as e:
                print(f"[diag] iframe {fid!r} 진입 실패: {e}")

        print("=" * 60)
        print("[diag] 5초 후 브라우저 종료. 화면을 확인하세요.")
        time.sleep(5)
    finally:
        try:
            driver.quit()
        except Exception:
            pass


if __name__ == "__main__":
    main()
