"""
trend 스킬용: 설정/데이터랩 API (IO 전용)

config 상태 확인·setup 저장·네이버 데이터랩 API 호출 등 결정적 작업만 처리한다.
트렌드 종합·골든키워드 판정·콘텐츠 아이디어는 LLM(opus)이 담당한다.
(WebSearch 기반 분석도 LLM 영역)

사용법:
    python trend_cli.py config                                  # API 설정 상태
    python trend_cli.py setup --client-id X --client-secret Y [--source both] [--category IT] [--period week]
    python trend_cli.py datalab "키워드1,키워드2" [--start 2026-01-01] [--end 2026-05-20] [--unit week]
"""

import os
import sys
import json
import argparse
from datetime import datetime, timedelta

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
CFG = os.path.join(ROOT, "config", "trend_config.json")


def read_cfg():
    if os.path.exists(CFG):
        with open(CFG, encoding="utf-8") as f:
            return json.load(f)
    return {}


def cmd_config():
    c = read_cfg()
    if not c:
        print("trend_config.json 없음 — `/trend setup` 필요 (WebSearch만 사용 가능)")
        return
    nd = c.get("naver_datalab", {})
    has = bool(nd.get("client_id") and nd.get("client_secret"))
    print(f"네이버 데이터랩 API: {'설정됨' if has else '미설정'}")
    print(f"source: {c.get('source', 'both')}")
    print(f"default_category: {c.get('default_category', '')}")
    print(f"period: {c.get('period', '')}")


def cmd_setup(args):
    cfg = {
        "naver_datalab": {"client_id": args.client_id, "client_secret": args.client_secret},
        "source": args.source,
        "default_category": args.category,
        "period": args.period,
    }
    os.makedirs(os.path.dirname(CFG), exist_ok=True)
    with open(CFG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print(f"저장 완료: config/trend_config.json (source={args.source})")


def cmd_datalab(args):
    c = read_cfg()
    nd = c.get("naver_datalab", {})
    cid, sec = nd.get("client_id"), nd.get("client_secret")
    if not (cid and sec):
        sys.exit("데이터랩 API 키가 없습니다 — `/trend setup` 필요. (WebSearch로 대체)")
    try:
        import requests
    except ImportError:
        sys.exit("requests 미설치")

    end = args.end or datetime.now().strftime("%Y-%m-%d")
    start = args.start or (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
    keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]
    groups = [{"groupName": k, "keywords": [k]} for k in keywords[:5]]
    body = {"startDate": start, "endDate": end, "timeUnit": args.unit, "keywordGroups": groups}

    try:
        r = requests.post(
            "https://openapi.naver.com/v1/datalab/search",
            headers={"X-Naver-Client-Id": cid, "X-Naver-Client-Secret": sec,
                     "Content-Type": "application/json"},
            json=body, timeout=10)
        r.raise_for_status()
    except Exception as e:
        sys.exit(f"데이터랩 API 호출 실패: {e}")

    data = r.json()
    print(f"## 데이터랩 검색어 트렌드 ({start} ~ {end}, {args.unit})\n")
    for res in data.get("results", []):
        pts = res.get("data", [])
        last = pts[-1]["ratio"] if pts else 0
        peak = max((p["ratio"] for p in pts), default=0)
        print(f"- {res.get('title')}: 최근 지수 {last:.1f} / 최고 {peak:.1f} (n={len(pts)})")


def main():
    ap = argparse.ArgumentParser(description="trend 설정/데이터랩 (IO 전용)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("config")
    sp = sub.add_parser("setup")
    sp.add_argument("--client-id", required=True)
    sp.add_argument("--client-secret", required=True)
    sp.add_argument("--source", default="both", choices=["api", "web", "both"])
    sp.add_argument("--category", default="IT")
    sp.add_argument("--period", default="week")
    sp = sub.add_parser("datalab")
    sp.add_argument("keywords")
    sp.add_argument("--start"); sp.add_argument("--end"); sp.add_argument("--unit", default="week")
    args = ap.parse_args()

    if args.cmd == "config": cmd_config()
    elif args.cmd == "setup": cmd_setup(args)
    elif args.cmd == "datalab": cmd_datalab(args)


if __name__ == "__main__":
    main()
