---
name: write
description: 활성 페르소나와 Naver Blog Writer 규칙을 적용해 네이버 블로그 글을 단계별로 작성한다. '/write', '블로그 글쓰기' 요청 시 사용.
model: opus
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - AskUserQuestion
---

# 블로그 글쓰기

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- 블로그 글: `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md`
- 페르소나·가이드는 읽기만: `config/personas/`, `docs/90.reference/93.context/`

블로그 글을 작성하기 위한 마크다운 파일을 생성하고, 단계별로 글을 완성합니다.

## 사용법

- `/write` → 새 글 생성 (이전 키워드 검색 결과 활용)
- `/write 제목` → 지정한 제목으로 새 글 생성

---

## 실행 흐름

### 0단계: 페르소나 로딩 (필수 - 가장 먼저 실행)

⚠️ **글 작성 전 반드시 페르소나를 완전히 로딩합니다. 이 단계를 건너뛰면 안 됩니다.**

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/persona_context.py"
```

이 스크립트가 활성 페르소나(`22.state/.active_persona.json`) → 페르소나 JSON(`config/personas/`) → `context_file` → `93.context/Naver Blog Writer.md` 가이드를 **한 번에** 읽어 통합 컨텍스트로 출력합니다. (활성 페르소나가 없으면 안내 후 종료 → `/persona use` 먼저)
출력된 닉네임·톤·패턴·구조·타겟독자·핵심고민·마무리공식·가이드 규칙을 글 전체에 적용합니다.

**로딩 완료 후 확인 출력:**

```
## 페르소나 로딩 완료

| 항목 | 값 |
|------|-----|
| 페르소나 | {이름} |
| 닉네임 | {profile.nickname} |
| 톤 | {style.tone} |
| 타겟 독자 | {context_file에서 추출} |
| 핵심 고민 | {context_file에서 추출} |
| 글 마무리 | {context_file에서 추출} |
```

**context_file이 있으면 반드시 읽어야 하는 항목:**
- 타겟 독자 (주요 독자층)
- 독자의 핵심 고민
- 콘텐츠 스타일 (글쓰기 톤, 활용 소재, 글의 구조)
- 글 마무리 공식
- 차별화 포인트

### 1단계: 컨텍스트 확인

**이전 대화에서 `/keyword`, `/bridge`, `/clip` 등을 실행했는지 확인합니다.**

실행한 경우 → 마지막 키워드/주제를 기억합니다.

### 2단계: 키워드 확인 질문

AskUserQuestion으로 질문:

```
이전에 검색한 키워드를 기준으로 블로그를 작성할까요?

키워드: {마지막 검색 키워드}
```

**옵션:**
- 예 → 해당 키워드 기반으로 진행
- 아니오 → 새로운 주제로 진행

### 3단계: 추가 내용 입력

텍스트로 질문 (AskUserQuestion 사용하지 않음):

```
추가로 작성할 내용이 있으면 입력하세요.
(없으면 엔터만 누르세요)
```

사용자 입력:
- 내용 입력 → **작성자 원본** 섹션에 저장
- 빈 줄/엔터 → 바로 파일 생성

### 4단계: 파일 생성 (스크립트)

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/scaffold_post.py" "{키워드 또는 제목}" --keyword "{키워드}" --source write
```

스크립트가 `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md`를 골격(frontmatter + 빈 섹션: 작성자 원본·리서치·본문·추천 제목·Image Prompt·Tags·메모)으로 생성하고 경로를 출력합니다. 이후 단계에서 이 파일의 해당 섹션을 채웁니다.

- `--source`는 frontmatter `source` 필드에 들어가 **이 글을 무엇으로 썼는지**를 남깁니다. `/write` 스킬로 직접 쓰면 `write`, `/write-photo`는 `write-photo`, blog-writer 에이전트가 쓰면 `agent (write)` / `agent (write-photo)`. (직접 `/write` 실행 시 `write` 그대로 둡니다.)

### 4-1단계: 리서치 섹션 기록 (사용한 경우)

이 글 작성에 `/keyword`·`/trend`·`/bridge` 결과를 활용했다면, 생성된 파일의 `## 리서치 (키워드·트렌드·브릿지)` 섹션을 채웁니다. **무엇을 근거로 썼는지가 핵심**이므로 다음을 구체적으로 적습니다 (안 쓴 항목은 "사용 안 함" 유지):

- **선택한 키워드**: 실제로 본문 방향으로 채택한 메인/골든/연관 키워드
- **선택한 트렌드**: 여러 트렌드 중 **어떤 것을 골라** 본문에 반영했는지 + 가능하면 출처
- **브릿지 적용**: 브릿지를 **어떻게** 본문 각도로 녹였는지

(이 섹션은 사용자가 나중에 "어떤 키워드·트렌드로, 브릿지를 어떻게 써서" 이 글이 나왔는지 추적하기 위한 것이며, autopost는 업로드하지 않습니다.)

### 5단계: 본문 작성 (초안)

키워드와 사용자 입력을 바탕으로 **본문** 섹션에 초안 작성.

**이 단계에서는 추천 제목, Image Prompt, Tags를 작성하지 않습니다.**

⚠️ **초안 작성 시에도 아래 "필수 적용 규칙"을 반드시 따릅니다.**

```
## 본문 초안 작성 완료

[초안 내용 표시]

---
글을 완성할까요? (제목, 이미지 프롬프트, 태그 생성)
```

### 6단계: 완성 확인 질문

AskUserQuestion으로 질문:

```
완성형으로 적용하시겠습니까?

@docs/90.reference/93.context/Naver Blog Writer.md
활성 페르소나: {현재 활성 페르소나 이름}

위 가이드와 활성 페르소나 스타일을 적용하여 글을 다듬고, 제목/이미지/태그를 생성합니다.
```

**옵션:**
- 예 → 7단계 진행
- 다시 작성 → 본문 재작성 (6단계 반복, 완성하지 않음)
- 아니오 → 초안 상태로 저장

### 7단계: 글 완성

**완성 시** 다음을 순서대로 실행:

1. ⚠️ **본문 Clean Text Mode 적용** (가이드 = 단일 출처)
   - 규칙·스타일은 0단계 `persona_context.py` 출력(가이드 §4 + 페르소나)에 이미 로딩됨 → 그대로 적용
   - 의미 규칙(LLM이 판단): AI 잡담 금지, 1:1 화법("여러분"→"당신"), 문체, 시작 문구("안녕하세요, {닉네임}입니다.")
   - 구문 안전망(스크립트): 완성 본문 텍스트를 통과시켜 볼드/마크다운 잔재를 기계적으로 제거
     ```bash
     cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/write/scripts/clean_text.py" --fix -
     ```
     (본문을 stdin으로 넣어 정리본을 받는다. 검사만 하려면 `--fix` 생략. ⚠️ **본문 텍스트 전용** — frontmatter/섹션 헤더가 있는 구조 md 파일 전체에 적용 금지)

2. **추천 제목** 5가지 생성 (후크형, 일반형, SEO, 궁금증, 숫자형)

3. **Image Prompt 4개** 본문 흐름에 맞춰 생성
   - 반드시 **16:9 비율** 명시 (Aspect ratio 16:9, horizontal composition)
   - 각 이미지에 **위치**, **스타일**, **비율** 기재
   - 본문의 주요 섹션별로 1개씩 배치

4. **Tags** 추천 태그 10개 생성

5. 상태를 `complete`로 변경

---

## 파일 템플릿

```markdown
---
title: "{제목}"
created_at: "{YYYY-MM-DD HH:MM}"
status: "draft"  # draft → complete
source: "write"  # write | write-photo | agent (write) | agent (write-photo)
keyword: "{키워드}"
category: ""
---

# {제목}

---

## 작성자 원본

> 사용자가 직접 작성한 영역 (AI 영역 아님)

{사용자 입력 내용}

---

## 리서치 (키워드·트렌드·브릿지)

> 무엇을 근거로 썼는지. 사용한 항목만 작성, 안 썼으면 "사용 안 함".

**작성 경로:** {source}
**선택한 키워드:** {채택한 키워드 또는 "사용 안 함"}
**선택한 트렌드:** {채택한 트렌드 + 출처 또는 "사용 안 함"}
**브릿지 적용:** {적용 방식 또는 "사용 안 함"}

---

## 본문

{AI가 작성한 블로그 글}

---

## 추천 제목

| 유형 | 제목 |
|------|------|
| 후크형 | {완성 시 작성} |
| 일반형 | {완성 시 작성} |
| SEO 최적화 | {완성 시 작성} |
| 궁금증 유발 | {완성 시 작성} |
| 숫자형 | {완성 시 작성} |

---

## Image Prompt (4개)

> 완성 시 본문 흐름에 맞춰 4개 작성

### 1. {섹션명}
**위치**: {본문 내 위치}
**스타일**: {일러스트 스타일}
**비율**: 16:9
```
{프롬프트 내용}. Aspect ratio 16:9, horizontal composition.
```

### 2. {섹션명}
**위치**: {본문 내 위치}
**스타일**: {일러스트 스타일}
**비율**: 16:9
```
{프롬프트 내용}. Aspect ratio 16:9, horizontal composition.
```

### 3. {섹션명}
**위치**: {본문 내 위치}
**스타일**: {일러스트 스타일}
**비율**: 16:9
```
{프롬프트 내용}. Aspect ratio 16:9, horizontal composition.
```

### 4. {섹션명}
**위치**: {본문 내 위치}
**스타일**: {일러스트 스타일}
**비율**: 16:9
```
{프롬프트 내용}. Aspect ratio 16:9, horizontal composition.
```

---

## Tags

> 완성 시 작성

```
#태그1 #태그2 #태그3
```

---

## 메모

```

---

## 필수 적용 규칙 (Clean Text Mode)

⚠️ **본문 작성 시 반드시 아래 규칙을 적용합니다. 초안/완성 모두 동일하게 적용.**

### 1. Naver Blog Writer 규칙 (`docs/90.reference/93.context/Naver Blog Writer.md`)

| 규칙 | 설명 |
|------|------|
| 볼드체 금지 | `**텍스트**` 절대 사용 금지 |
| 마크다운 서식 금지 | `###` 제목, `-` 리스트, `1.` 숫자목록 금지 |
| 줄글 유지 | 모든 내용은 자연스러운 문장으로 작성 |
| AI 멘트 금지 | "작성하겠습니다", "분석해보면" 등 금지 |
| 1:1 대화체 | "여러분" 금지 → "당신"으로 작성 |

### 2. 활성 페르소나 적용 (필수)

⚠️ **0단계에서 로딩한 페르소나를 글 전체에 적용합니다.**

**JSON에서 적용:**

| 항목 | 참조 필드 |
|------|-----------|
| 시작 문구 | "안녕하세요, {profile.nickname}입니다." |
| 톤앤매너 | style.tone, style.formality |
| 글쓰기 패턴 | style.writing_patterns |
| 자주 쓰는 표현 | style.favorite_expressions |
| 글 구조 | style.content_structure |

**context_file에서 적용 (있으면 필수):**

| 항목 | 적용 방법 |
|------|-----------|
| 타겟 독자 | 그 독자의 눈높이에 맞춰 작성 |
| 핵심 고민 | 도입부에서 공감, 본문에서 해결 |
| 콘텐츠 스타일 | 글쓰기 톤, 소재, 구조 반영 |
| 글 마무리 공식 | 마무리에 "바로 해볼 수 있는 한 가지 액션" 제시 |
| 차별화 포인트 | 글에 자연스럽게 녹여내기 |

**활성 페르소나가 없으면:** 페르소나 없이 Naver Blog Writer 규칙만 적용.

**우선순위:** context_file > 페르소나 JSON > Naver Blog Writer

---

## 중요 규칙

### 완성 조건
- **추천 제목, Image Prompt, Tags가 모두 작성되어야 완성**
- 사용자가 "완성해줘"라고 할 때만 완성 단계 진행
- "다시 작성해줘"는 본문만 수정, 완성하지 않음

### 재작성 요청 시
- 본문만 다시 작성
- 추천 제목, Image Prompt, Tags는 건드리지 않음
- "글 완성할까요?" 다시 질문

### 컨텍스트 참조
완성 단계에서 참조할 파일:
- `docs/90.reference/93.context/Naver Blog Writer.md`: 네이버 블로그 작성 가이드
- `docs/20.working/22.state/.active_persona.json` → `config/personas/{이름}.json`: 활성 페르소나
- 페르소나의 `context_file` 필드가 있으면 해당 문서도 참조

---

## 저장 위치

`docs/30.output/31.posts/{키워드 또는 제목}_{YYYYMMDD}.md`

## 참조 파일

- `docs/20.working/22.state/.active_persona.json`: 활성 페르소나 정보
- `config/personas/`: 페르소나별 JSON 파일
- `docs/90.reference/93.context/Naver Blog Writer.md`: 블로그 작성 가이드
- `docs/30.output/31.posts/`: 블로그 글 저장 폴더