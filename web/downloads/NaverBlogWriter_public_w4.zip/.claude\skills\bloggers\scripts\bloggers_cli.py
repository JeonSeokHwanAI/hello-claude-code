#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
블로거 목록 CLI - 빠른 조회용
사용법: python utils/bloggers_cli.py [명령] [인자]

명령:
  all           전체 목록
  <키워드>      키워드 검색
  #<주제>       주제 필터
  @<ID>         ID로 검색
"""

import json
import sys
import io
import unicodedata
from pathlib import Path

# Windows 콘솔 UTF-8 출력 설정
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 프로젝트 루트 기준 경로 (이 스크립트는 .claude/skills/bloggers/scripts/ 에 위치)
ROOT = Path(__file__).resolve().parents[4]
BLOGS_FILE = ROOT / "config" / "blogs.json"


def load_blogs():
    """blogs.json 로드"""
    with open(BLOGS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _width(text):
    """문자열의 표시 폭 계산 (한글·전각 문자는 2칸)"""
    w = 0
    for ch in str(text):
        w += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return w


def _pad(text, width):
    """표시 폭 기준으로 오른쪽 공백 패딩"""
    text = str(text)
    return text + " " * (width - _width(text))


# 출력 컬럼 정의 (헤더, 값 추출 함수) — '설명'은 의도적으로 제외
_COLUMNS = [
    ("#", None),
    ("ID", lambda i, bid, info: bid),
    ("블로그명", lambda i, bid, info: info.get("name", "")),
    ("별명", lambda i, bid, info: info.get("nickname", "")),
    ("주제", lambda i, bid, info: info.get("topics", {}).get("main", "")),
]


def print_table(blogs_dict, title="블로그 목록"):
    """ASCII 박스 표 출력 (행 구분선 포함, 설명 컬럼 제외)

    출력 형식은 이 함수에 고정되어 있습니다. 변경 시 모든 목록 조회
    (all/검색/필터/ID)에 동일하게 적용됩니다.
    """
    print(f"\n## {title} ({len(blogs_dict)}개)\n")

    headers = [c[0] for c in _COLUMNS]
    rows = []
    for i, (blog_id, info) in enumerate(blogs_dict.items(), 1):
        row = [str(i)]
        for _, getter in _COLUMNS[1:]:
            row.append(str(getter(i, blog_id, info)))
        rows.append(row)

    # 컬럼별 최대 폭 계산
    widths = [_width(h) for h in headers]
    for row in rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], _width(cell))

    def border(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def render(cells):
        return "│ " + " │ ".join(_pad(c, widths[idx]) for idx, c in enumerate(cells)) + " │"

    print("```")
    print(border("┌", "┬", "┐"))
    print(render(headers))
    print(border("├", "┼", "┤"))
    for n, row in enumerate(rows):
        print(render(row))
        if n < len(rows) - 1:
            print(border("├", "┼", "┤"))
    print(border("└", "┴", "┘"))
    print("```")


def search_blogs(blogs, keyword):
    """키워드로 검색"""
    keyword = keyword.lower()
    result = {}

    for blog_id, info in blogs.items():
        # ID, name, nickname, description에서 검색
        searchable = f"{blog_id} {info.get('name', '')} {info.get('nickname', '')} {info.get('description', '')}".lower()
        if keyword in searchable:
            result[blog_id] = info

    return result


def filter_by_topic(blogs, topic):
    """주제로 필터"""
    topic = topic.lstrip("#")
    result = {}

    for blog_id, info in blogs.items():
        topics = info.get("topics", {})
        main = topics.get("main", "")
        subs = topics.get("sub", [])

        if topic in main or topic in " ".join(subs):
            result[blog_id] = info

    return result


def get_by_id(blogs, target_id):
    """ID로 검색"""
    target_id = target_id.lstrip("@")
    if target_id in blogs:
        return {target_id: blogs[target_id]}
    return {}


def main():
    blogs = load_blogs()

    if len(sys.argv) < 2 or sys.argv[1] in ("all", "list"):
        print_table(blogs, "전체 목록")

    elif sys.argv[1].startswith("#"):
        topic = sys.argv[1]
        result = filter_by_topic(blogs, topic)
        print_table(result, f"주제: {topic}")

    elif sys.argv[1].startswith("@"):
        blog_id = sys.argv[1]
        result = get_by_id(blogs, blog_id)
        if result:
            print_table(result, f"ID: {blog_id}")
        else:
            print(f"❌ '{blog_id}' 없음")

    else:
        keyword = " ".join(sys.argv[1:])
        result = search_blogs(blogs, keyword)
        if result:
            print_table(result, f"검색: {keyword}")
        else:
            print(f"❌ '{keyword}' 검색 결과 없음")


if __name__ == "__main__":
    main()
