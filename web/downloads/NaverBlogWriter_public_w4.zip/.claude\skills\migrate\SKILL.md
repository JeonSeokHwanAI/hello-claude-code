---
name: migrate
description: 기존(구) NaverBlogWriter/Naver Scraping 프로젝트의 데이터를 현재 프로젝트의 새 폴더 구조로 이관한다. 폴더 구성이 상이하므로 항목별 매핑과 경로 재작성을 수행한다. '/migrate', '마이그레이션', '기존 데이터 이관' 요청 시 사용.
model: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - AskUserQuestion
---

# 데이터 이관 (migrate)

인자: $ARGUMENTS

기존 프로젝트(구 `Naver Scraping` 또는 이전 버전 NaverBlogWriter)의 데이터를
현재 프로젝트의 새 폴더 구조로 옮긴다. 두 프로젝트는 **폴더 구성이 상이**하므로
단순 복사가 아니라 항목별 매핑 + 경로 재작성을 수행한다(엔진 스크립트가 처리).

## 저장 위치 (필수 준수)

이관 대상은 모두 현재 프로젝트의 기존 규칙 위치로만 들어간다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조. 엔진이 자동으로 올바른 위치에 배치하므로 수동으로 다른 경로에 만들지 않는다.

## 엔진 스크립트

모든 매핑·복사·경로 재작성은 아래 스크립트가 담당한다. Claude는 경로를 묻고 항목을 받아 스크립트를 호출하는 역할만 한다.

```bash
python .claude/skills/migrate/scripts/migrate.py --source "<기존 폴더>" --items <항목들>
```

| 옵션 | 설명 |
|------|------|
| `--source "<경로>"` | 기존(구) 프로젝트 폴더 경로 (필수) |
| `--items all` | 전체 이관 |
| `--items posts,reviews,...` | 쉼표로 구분한 선택 이관 |
| `--list` | 이관 가능 항목 목록만 출력 |
| `--dry-run` | 실제 변경 없이 계획만 출력 |
| `--mode copy\|move` | 기본 `copy`(원본 보존). `move`는 원본 이동 |

## 진행 절차 (Claude가 따를 순서)

### 1단계 — 기존 폴더 경로 묻기

먼저 **사용자에게 기존 프로젝트 폴더가 어디에 있는지 묻는다.** (`AskUserQuestion` 또는 직접 질문)
예: `G:/내 드라이브/Source/Naver Scraping`. 인자로 경로가 이미 주어졌으면 생략한다.

경로를 받으면 존재 여부를 확인한다(`--dry-run`은 없는 경로면 에러를 낸다).

### 2단계 — 이관 항목 선택

다음 항목 목록을 사용자에게 제시하고 원하는 항목을 고르게 한다.
**`전체`를 고르면 모두 이관한다.** (`AskUserQuestion`의 multiSelect 사용)

| 키 | 항목 | 매핑 (구 → 신) |
|----|------|----------------|
| `blogs` | 블로그 목록 | `config/blogs.json` 병합(원본 우선) |
| `personas` | 페르소나 | `config/personas/*.json` + `context_file` 경로 자동 수정 |
| `me` | 내 프로필(레거시) | `config/me.json` |
| `state` | 런타임 상태 | `config/.*` 숨김 JSON → `docs/20.working/22.state/` |
| `posts` | 작성한 글 | `docs/blog` → `docs/30.output/31.posts/` |
| `reviews` | 리뷰·분석 | `docs/reviews` → `docs/30.output/32.reviews/` |
| `reports` | HTML 리포트 | `docs/reports`(+images) → `docs/30.output/33.reports/` |
| `clips` | 클리핑 | `docs/clips` → `docs/90.reference/92.clips/` |
| `context` | 글쓰기 참조 | `docs/context` → `docs/90.reference/93.context/` |
| `archive` | 보관 문서 | `docs/archive` → `docs/90.reference/91.archive/` (동명 파일 자동 skip) |
| `scraped` | 스크랩 원본 | `output/{blog_id}` → `docs/20.working/21.scraped/{blog_id}/` (`_old` 제외) |
| `monthly` | 이달의 블로그 | `output/monthly_blogs_*.json` → `docs/20.working/21.scraped/monthly/` |

> 구 폴더가 더 옛 구조(예: `output/`가 아니라 다른 이름)일 수 있다. 그럴 땐 먼저 `--dry-run`으로
> "원본 없음" 표시를 확인하고, 매핑이 비면 사용자에게 실제 하위 폴더명을 물어 스크립트의
> 핸들러 경로를 조정한다.

### 3단계 — Dry-run 미리보기

선택한 항목으로 **먼저 `--dry-run`을 실행**해 무엇이 복사/병합/건너뜀 되는지 보여주고 확인받는다.

```bash
python .claude/skills/migrate/scripts/migrate.py --source "<경로>" --items <선택> --dry-run
```

### 4단계 — 실제 이관

사용자 확인 후 `--dry-run` 없이 동일 명령을 실행한다. 기본은 `copy`라 원본은 보존된다.

### 5단계 — 결과 보고

스크립트의 요약(복사/건너뜀/병합/경로수정 수)과 검증해야 할 포인트를 정리해 전달한다.
필요하면 `docs/90.reference/97.guides/`에 이관 기록을 남긴다.

## 동작 특성 (알아둘 것)

- **멱등성**: 이미 존재하는 파일은 건너뛴다(skip). 재실행해도 안전하다.
- **blogs.json**은 덮어쓰지 않고 병합한다(원본 키 우선, 타겟 기존 키 유지).
- **페르소나 `context_file`**의 옛 경로(`docs/context/`)는 자동으로 `docs/90.reference/93.context/`로 바뀐다.
- **제외 대상**: `output/*.html`, `output/_old/`, `nul`, 그리고 이미 이관 완료된 코드(`main.py`, `scraper/`, `utils/`, `tests/`, `samples/`)와 환경별 API 설정(`keyword_config`/`trend_config`/`naver_topics`). 필요하면 사용자가 별도로 처리한다.
