# 네이버 블로그 AI 분석

## 사용법

### 1. 스크래핑
```bash
python main.py
```

### 2. AI에게 요청

```
@output/블로그ID_summary_날짜.json 전체 분석해줘
@output/블로그ID_posts_날짜.json 00번 분석해줘
@output/블로그ID_summary_날짜.json 빠른 요약해줘
@output/블로그ID_summary_날짜.json 제목 분석해줘
```

JSON 파일 안에 `_guide` 필드가 있어서 AI가 자동으로 분석 형식을 인식합니다.

### 파일 구분
| 파일 | 용도 |
|------|------|
| `*_summary_*.json` | 전체 분석, 제목 분석, 빠른 요약 |
| `*_posts_*.json` | 특정 글 심층 분석 (본문 포함) |
