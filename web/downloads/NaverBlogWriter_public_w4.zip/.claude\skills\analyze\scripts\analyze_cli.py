"""
analyze 스킬용: 블로그/이전분석 조회 (IO 전용)

결정적 작업만 처리한다. 12항목 분석·비교 서술은 LLM(opus)이
review 의 template/전체분석.md 양식을 채워서 수행한다.
새 스크래핑은 search 엔진(main.py)을 재사용한다.

사용법:
    python analyze_cli.py resolve <별명/ID>     # blogs.json에서 blog_id 해석
    python analyze_cli.py list                  # 전체분석이 저장된 블로그 목록
    python analyze_cli.py prev <blog>           # 최신 전체분석 YAML에서 이전 점수 추출
"""

import os
import sys
import re
import glob
import json
import argparse

# 이 스크립트는 .claude/skills/analyze/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
REVIEWS = os.path.join(ROOT, "docs", "30.output", "32.reviews")
BLOGS = os.path.join(ROOT, "config", "blogs.json")

ITEMS = ["콘텐츠장단점", "운영자문제점", "SEO개선점", "전략제안", "타겟독자", "브랜딩",
         "발행패턴", "제목패턴", "수익화", "경쟁환경", "AI대응력", "독자참여도"]


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def cmd_resolve(q):
    blogs = read_json(BLOGS)
    if q in blogs:
        print(q); return
    ql = q.lower()
    for bid, info in blogs.items():
        hay = f"{bid} {info.get('name','')} {info.get('nickname','')} {info.get('description','')}".lower()
        if ql in hay:
            print(bid); return
    sys.exit(f"'{q}' 매칭 실패 — blogs.json에 없음")


def analysis_files(blog):
    return sorted(glob.glob(os.path.join(REVIEWS, f"{blog}_전체분석_*.md")))


def cmd_list():
    files = glob.glob(os.path.join(REVIEWS, "*_전체분석_*.md"))
    blogs = {}
    for f in files:
        m = re.match(r"(.+)_전체분석_(\d+)\.md$", os.path.basename(f))
        if m:
            blogs.setdefault(m.group(1), []).append(m.group(2))
    if not blogs:
        sys.exit("저장된 전체분석이 없습니다.")
    print(f"## 전체분석 저장된 블로그 ({len(blogs)}개)\n")
    print("| # | 블로그 ID | 분석 횟수 | 최신 |")
    print("|---|-----------|-----------|------|")
    for i, (bid, dates) in enumerate(sorted(blogs.items()), 1):
        print(f"| {i} | {bid} | {len(dates)} | {max(dates)} |")


def parse_frontmatter(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    parts = text.split("---", 2)          # ['', frontmatter, body]
    fm = parts[1] if len(parts) >= 3 else ""
    res = {"scores": {}, "overall_score": None, "analyzed_at": None, "blog_name": None}
    in_scores = False
    for line in fm.splitlines():
        if re.match(r"^scores:", line):
            in_scores = True
            continue
        if in_scores:
            m = re.match(r"^\s+(\S+):\s*(\d+)", line)
            if m:
                res["scores"][m.group(1)] = int(m.group(2))
                continue
            if line.strip() and not line.startswith(" "):
                in_scores = False
        m = re.match(r'^overall_score:\s*(\d+)', line)
        if m:
            res["overall_score"] = int(m.group(1))
        m = re.match(r'^analyzed_at:\s*"?([\d-]+)', line)
        if m:
            res["analyzed_at"] = m.group(1)
        m = re.match(r'^blog_name:\s*"?(.+?)"?\s*$', line)
        if m:
            res["blog_name"] = m.group(1)
    return res


def cmd_prev(blog):
    files = analysis_files(blog)
    if not files:
        print(f"'{blog}' 이전 전체분석 없음 (최초 분석)")
        return
    latest = files[-1]
    fm = parse_frontmatter(latest)
    print(f"이전 분석 파일: {os.path.basename(latest)}")
    print(f"blog_name: {fm.get('blog_name')}")
    print(f"analyzed_at: {fm.get('analyzed_at')}")
    print(f"overall_score: {fm.get('overall_score')}")
    print("scores:")
    for k in ITEMS:
        if k in fm["scores"]:
            print(f"  {k}: {fm['scores'][k]}")


def main():
    ap = argparse.ArgumentParser(description="analyze 조회 (IO 전용)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sp = sub.add_parser("resolve"); sp.add_argument("query")
    sp = sub.add_parser("prev"); sp.add_argument("blog")
    args = ap.parse_args()

    if args.cmd == "list": cmd_list()
    elif args.cmd == "resolve": cmd_resolve(args.query)
    elif args.cmd == "prev": cmd_prev(args.blog)


if __name__ == "__main__":
    main()
