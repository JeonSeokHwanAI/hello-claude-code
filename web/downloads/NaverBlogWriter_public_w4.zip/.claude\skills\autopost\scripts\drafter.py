"""네이버 블로그 SmartEditor 자동 작성 + 임시저장 (M0+M1).

원본: docs/90.reference/99.external-scripts/marketing_wizard_Extand_AutoLoad.py
       줄 2502~2854 (naver_auto_blog_post, upload_blog_image)

M0: 원본 흐름 그대로 (로그인 → 본문 입력)
M1: 원본의 `time.sleep(60)` 자리를 `click_save_draft_button` + `extract_draft_id` 로 교체.
    FORBIDDEN_TEXTS 가드레일로 발행 버튼 절대 클릭 안 함.

GUI 의존 제거: messagebox → print + 스크린샷.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Iterable

import pyautogui
import pyperclip
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import re

from session import build_driver, load_or_login, manual_login

TITLE_SELECTORS = [
    # 가장 정확: documentTitle 명시
    ".se-section-documentTitle .se-text-paragraph",
    ".se-component.se-documentTitle .se-text-paragraph",
    ".se-documentTitle-editView",
    # 광범위 폴백 (SE3에서는 제목/본문 모두 매칭하므로 우선순위 낮춤)
    ".se-title-input",
    "div.se-title-input span",
    "input[placeholder*='제목']",
    "[data-placeholder='제목']",
]

# 본문은 반드시 se-section-text (documentTitle 제외) 안의 단락만 매칭
BODY_SELECTOR = ".se-section-text .se-text-paragraph"

PHOTO_BUTTON_SELECTORS = [
    "button.se-image-toolbar-button",                  # SE3 실측 (text='사진')
    "button[class*='se-image-toolbar-button']",
    "button[data-log='dot.photo']",
    "button[class*='se-main-toolbar-button-image']",
    "button[data-click-area='top.image']",
    "button[data-name='image']",
    ".se-toolbar-button-image",
]

# SE3 이미지 업로드 input (보통 사진 버튼 누르면 트리거되는 hidden file input)
PHOTO_INPUT_SELECTORS = [
    "input[type='file'][accept*='image']",
    "input.se-image-upload-input",
    "input[type='file']",
]

CANCEL_DRAFT_POPUP_SELECTORS = [
    ("css", "button.cancel"),
    ("css", "button.se-popup-button-cancel"),
    ("css", "button[class*='cancel']"),
    ("xpath", "//button[contains(text(), '취소')]"),
]

CLOSE_OTHER_POPUPS_CSS = (
    "button.se-popup-close-btn, .popup_close, .btn_close, "
    "button.se-help-panel-close-button"  # SE3 첫 진입 시 도움말 패널 (임시저장 버튼 클릭 가로챔)
)

FORBIDDEN_TEXTS = ["발행", "공개발행", "Publish"]
FORBIDDEN_CLASS_PATTERNS = [
    "publish_btn",   # 외부 발행 버튼 class 패턴
    "confirm_btn",   # 다이얼로그 내 발행 확정 버튼 (탐색 모드 외에는 차단)
]

# 임시저장 버튼 후보 (실측 2026-05-27 기준: button.save_btn__<hash>, text="저장")
# CSS Modules 해시는 빌드마다 바뀌므로 prefix 매칭 사용.
SAVE_DRAFT_SELECTORS = [
    ("css", "button[class^='save_btn']"),       # SE3 정공법
    ("css", "button[class*='save_btn']"),       # 폴백
    ("xpath", "//button[normalize-space()='저장']"),
    ("xpath", "//button[contains(., '저장') and not(contains(., '발행'))]"),
    ("css", "button[data-click-area*='save']"),
]

# 임시저장 완료 토스트
SAVE_TOAST_SELECTORS = [
    ("xpath", "//*[contains(text(), '임시저장')]"),
    ("xpath", "//*[contains(text(), '저장되었습니다')]"),
]


def _goto_write_page(driver, blog_id: str) -> None:
    primary = f"https://blog.naver.com/{blog_id}/postwrite"
    print(f"[drafter] 글쓰기 페이지 이동: {primary}")
    driver.get(primary)
    time.sleep(3)

    if "유효하지 않은" in driver.page_source or "error" in driver.current_url.lower():
        fallback = f"https://blog.naver.com/PostWriteForm.naver?blogId={blog_id}"
        print(f"[drafter] 폴백 URL 사용: {fallback}")
        driver.get(fallback)
        time.sleep(3)


def _is_login_redirect(driver) -> bool:
    """글쓰기 페이지가 네이버 로그인으로 리다이렉트됐는지 판정.

    쿠키가 메인 네이버엔 유효해도 블로그 에디터엔 만료된 경우, /postwrite 가
    nid.naver.com/nidlogin 으로 튕긴다. 이 경우 mainFrame 은 영영 안 뜬다.
    """
    try:
        url = driver.current_url
    except Exception:
        return False
    return ("nidlogin" in url) or ("nid.naver.com" in url)


def _enter_iframe(driver) -> None:
    try:
        WebDriverWait(driver, 10).until(
            EC.frame_to_be_available_and_switch_to_it((By.ID, "mainFrame"))
        )
        print("[drafter] mainFrame 진입")
    except Exception:
        print("[drafter] mainFrame 진입 실패 — 계속 진행")
    time.sleep(2)


def _close_popups(driver) -> None:
    for kind, selector in CANCEL_DRAFT_POPUP_SELECTORS:
        try:
            if kind == "xpath":
                btn = driver.find_element(By.XPATH, selector)
            else:
                btn = driver.find_element(By.CSS_SELECTOR, selector)
            if btn and btn.is_displayed():
                btn.click()
                print(f"[drafter] '작성 중인 글' 팝업 취소: {selector}")
                time.sleep(1)
                break
        except Exception:
            continue

    try:
        for btn in driver.find_elements(By.CSS_SELECTOR, CLOSE_OTHER_POPUPS_CSS):
            try:
                btn.click()
                time.sleep(0.5)
            except Exception:
                pass
    except Exception:
        pass


def _enter_title(driver, title: str) -> None:
    print(f"[drafter] 제목 입력: {title}")
    title_input = None
    for selector in TITLE_SELECTORS:
        try:
            title_input = WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )
            if title_input:
                print(f"[drafter] 제목 selector 매칭: {selector}")
                break
        except Exception:
            continue

    if not title_input:
        print("[drafter] [WARN]제목 입력 영역을 찾지 못함")
        return

    title_input.click()
    time.sleep(0.5)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
    time.sleep(0.2)
    for char in title:
        ActionChains(driver).send_keys(char).perform()
        time.sleep(0.02)


def _compute_image_positions(num_paragraphs: int, num_images: int) -> list:
    """단락 N개 본문에 이미지 M개를 끼울 위치 (단락 인덱스, 단락 입력 직후 삽입).

    정책:
    - 도입(첫 이미지) → 첫 단락(인사) 직후 (index 0)
    - 마무리(마지막 이미지) → 마지막 단락(Open Loop) 직전 (index N-2)
    - 중간 이미지들 → 본문 중간에 균등 분포
    이미지가 단락보다 많으면 단락마다 하나씩.
    """
    if num_images == 0 or num_paragraphs < 2:
        return list(range(min(num_images, num_paragraphs)))
    if num_images >= num_paragraphs:
        return list(range(num_paragraphs))[:num_images]

    positions = [0]                                # 도입
    if num_images == 1:
        return positions
    last_pos = num_paragraphs - 2                  # 마무리
    if num_images == 2:
        return [0, last_pos]
    # 중간 num_images-2개를 1 ~ last_pos-1 사이에 균등 분포
    middle_count = num_images - 2
    for i in range(1, middle_count + 1):
        pos = round(i * (last_pos) / (middle_count + 1))
        # 같은 단락에 두 이미지 안 들어가도록 보정
        if pos <= positions[-1]:
            pos = positions[-1] + 1
        positions.append(pos)
    positions.append(max(last_pos, positions[-1] + 1))
    return positions


# 본문 내 이미지 위치 마커. write-photo 가 사진 들어갈 자리에 이 토큰을 넣는다.
# (한 단락 뒤에 여러 장을 넣으려면 마커를 연속으로 둔다.)
IMG_MARKER = "[[IMG]]"


def _enter_body(driver, body: str, image_paths=()) -> None:
    """NBW 줄글 본문을 입력하면서 이미지를 삽입한다.

    두 가지 모드:
    - 마커 모드: 본문에 `[[IMG]]` 가 있으면 그 위치/개수에 정확히 맞춰 이미지 삽입.
                 (한 단락 뒤 여러 장 가능, 누락 없음 — write-photo 산출물 기준)
    - 자동 모드: 마커가 없으면 기존 `_compute_image_positions` (단락당 1장, /write 하위호환).
    """
    print("[drafter] 본문 입력 시작...")
    body_area = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, BODY_SELECTOR))
    )
    body_area.click()
    time.sleep(0.3)

    image_list = [str(p) for p in image_paths if p and Path(p).exists()]

    if IMG_MARKER in body and image_list:
        _enter_body_markers(driver, body, image_list)
    else:
        _enter_body_auto(driver, body, image_list)

    print("[drafter] 본문 입력 완료")
    time.sleep(1)


def _take_collage_rows(driver, imgs: list) -> None:
    """한 구역의 이미지들을 콜라주 줄(2~3장)로 나눠 업로드한다."""
    remaining = list(imgs)
    for row in _collage_split(len(remaining)):
        row_imgs = remaining[:row]
        remaining = remaining[row:]
        tag = "콜라주" if len(row_imgs) > 1 else "단독"
        print(f"[drafter] {tag} {len(row_imgs)}장 한 줄: {[Path(p).name for p in row_imgs]}")
        _upload_images(driver, row_imgs)
        time.sleep(1)


def _enter_body_markers(driver, body: str, image_list: list) -> None:
    """마커 모드: 연속된 `[[IMG]]` 를 한 구역으로 모아 콜라주 줄(2~3장)로 업로드한다.

    - 빈 줄 없이 연속된 `[[IMG]]` N개 = 한 구역 → _collage_split 으로 한 줄 2~3장씩 배치.
    - 빈 줄로 분리되면 별도 구역(별도 줄).
    """
    marker_count = body.count(IMG_MARKER)
    print(f"[drafter] 마커 모드 — [[IMG]] {marker_count}개 / 이미지 {len(image_list)}장")
    if marker_count != len(image_list):
        print(f"[drafter] [WARN] 마커({marker_count})와 이미지({len(image_list)}) 수 불일치 "
              f"— 마커 순서대로 채우고 남는 이미지는 본문 끝에 붙입니다.")

    img_iter = iter(image_list)
    lines = body.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        if line == IMG_MARKER:
            # 연속 마커 = 한 구역
            count = 0
            while i < len(lines) and lines[i].strip() == IMG_MARKER:
                count += 1
                i += 1
            imgs = []
            for _ in range(count):
                nxt = next(img_iter, None)
                if nxt:
                    imgs.append(nxt)
            _take_collage_rows(driver, imgs)
            continue

        if line == "":
            ActionChains(driver).send_keys(Keys.ENTER).perform()
            time.sleep(0.05)
            i += 1
            continue

        for char in lines[i]:
            ActionChains(driver).send_keys(char).perform()
            time.sleep(0.01)
        ActionChains(driver).send_keys(Keys.ENTER).perform()
        time.sleep(0.05)
        i += 1

    # 마커보다 이미지가 많으면 남은 사진을 본문 끝에 콜라주로 이어 붙임
    rest = list(img_iter)
    if rest:
        print(f"[drafter] 남은 이미지 {len(rest)}장 본문 끝 삽입")
        _take_collage_rows(driver, rest)


def _enter_body_auto(driver, body: str, image_list: list) -> None:
    """자동 모드(기존): 단락 분리 후 _compute_image_positions 로 단락당 1장 배치."""
    paragraphs = [p.strip() for p in body.split("\n\n")]
    paragraphs = [p for p in paragraphs if p]
    positions = _compute_image_positions(len(paragraphs), len(image_list))
    pos_to_img = dict(zip(positions, image_list))

    if image_list:
        print(f"[drafter] 자동 모드 — 단락 {len(paragraphs)}개, 이미지 {len(image_list)}개 → 위치: {positions}")

    for idx, para in enumerate(paragraphs):
        lines = para.split("\n")
        for li, line in enumerate(lines):
            if line:
                for char in line:
                    ActionChains(driver).send_keys(char).perform()
                    time.sleep(0.01)
            if li < len(lines) - 1:
                ActionChains(driver).send_keys(Keys.ENTER).perform()
                time.sleep(0.05)

        ActionChains(driver).send_keys(Keys.ENTER).perform()
        ActionChains(driver).send_keys(Keys.ENTER).perform()
        time.sleep(0.05)

        if idx in pos_to_img:
            img_path = pos_to_img[idx]
            print(f"[drafter] 단락 #{idx} 끝에 이미지 삽입: {Path(img_path).name}")
            _upload_image(driver, img_path)
            time.sleep(1)


def _collage_split(n: int) -> list:
    """한 구역 n장을 네이버 콜라주 줄 단위로 분할.

    네이버는 한 줄 콜라주에 최대 3장. 정책:
    - 1~3장 → 한 줄 그대로 [n]
    - 4장 이상 → 2장씩 떼고, 남는 2~3장을 끝줄로 (짝수=2씩, 홀수=마지막 3장)
      예: 4→[2,2], 5→[2,3], 6→[2,2,2], 7→[2,2,3]
    """
    if n <= 3:
        return [n] if n > 0 else []
    groups = []
    while n > 3:
        groups.append(2)
        n -= 2
    groups.append(n)  # 2 또는 3
    return groups


def _ensure_file_hook(driver) -> None:
    """input[type=file].click() 을 무력화해 OS 파일 다이얼로그를 띄우지 않고,
    네이버가 생성한 file input 을 window.__capturedFileInput 에 잡아둔다.
    (Selenium send_keys 로 직접 주입 → pyautogui/다이얼로그 불필요)"""
    driver.execute_script("""
        if (!window.__fileHook) {
            window.__fileHook = 1;
            const orig = HTMLInputElement.prototype.click;
            HTMLInputElement.prototype.click = function() {
                if (this.type === 'file') { window.__capturedFileInput = this; return; }
                return orig.apply(this, arguments);
            };
        }
        window.__capturedFileInput = null;
    """)


def _select_collage(driver) -> None:
    """여러 장 첨부 시 뜨는 '사진 첨부 방식'(개별/콜라주/슬라이드) 팝업에서 콜라주를 고른다."""
    try:
        btn = WebDriverWait(driver, 6).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "div.se-image-type-option-collage"))
        )
        try:
            btn.click()
        except Exception:
            driver.execute_script("arguments[0].click();", btn)
        print("[drafter] 사진 첨부 방식 → 콜라주 선택")
        time.sleep(2)
    except Exception:
        print("[drafter] [WARN] 콜라주 팝업 없음/선택 실패 (개별로 처리될 수 있음)")


def _upload_images(driver, image_paths) -> bool:
    """이미지 1장 이상을 OS 다이얼로그 없이 input 직접 주입으로 업로드.

    흐름: 사진버튼 클릭 → (후킹이 다이얼로그 막고 input 캡처) → input.send_keys(여러 경로)
          → 2장 이상이면 '사진 첨부 방식' 팝업에서 콜라주 선택 → 한 줄 콜라주.
    """
    paths = [str(Path(p).resolve()) for p in image_paths if p and Path(p).exists()]
    if not paths:
        print("[drafter] [WARN] 업로드할 이미지 없음")
        return False

    _ensure_file_hook(driver)

    # 사진 버튼 클릭 → 네이버가 input 생성+click() → 후킹이 다이얼로그 차단 + input 캡처
    photo_btn = None
    for selector in PHOTO_BUTTON_SELECTORS:
        try:
            b = driver.find_element(By.CSS_SELECTOR, selector)
            if b.is_displayed():
                photo_btn = b
                break
        except Exception:
            continue
    if not photo_btn:
        print("[drafter] [WARN] 사진 버튼을 찾지 못함")
        return False
    try:
        photo_btn.click()
    except Exception:
        driver.execute_script("arguments[0].click();", photo_btn)
    time.sleep(1.0)

    # 캡처된 input (없으면 DOM에서 탐색)
    inp = driver.execute_script("return window.__capturedFileInput")
    if inp is None:
        cands = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
        inp = cands[-1] if cands else None
    if inp is None:
        print("[drafter] [WARN] file input 확보 실패")
        return False

    inp.send_keys("\n".join(paths))
    time.sleep(2 + len(paths))

    if len(paths) >= 2:
        _select_collage(driver)

    mode = "콜라주" if len(paths) >= 2 else "단독"
    print(f"[drafter] 이미지 {len(paths)}장 업로드 (input 주입, {mode})")
    return True


def _upload_image(driver, image_path: str) -> bool:
    """이미지 1장 업로드 (하위호환 — _upload_images 위임)."""
    return _upload_images(driver, [image_path])


def _assert_not_publish(element, label: str = "버튼") -> None:
    """가드레일: element 텍스트/클래스에 '발행' 류가 있으면 즉시 실패."""
    try:
        text = (element.text or "").strip()
    except Exception:
        text = ""
    try:
        cls = element.get_attribute("class") or ""
    except Exception:
        cls = ""
    for forbidden in FORBIDDEN_TEXTS:
        if forbidden in text:
            raise RuntimeError(
                f"가드레일 위반: {label} 텍스트에 '{forbidden}' 포함 - 클릭 차단 (text={text!r})"
            )
    for pattern in FORBIDDEN_CLASS_PATTERNS:
        if pattern in cls:
            raise RuntimeError(
                f"가드레일 위반: {label} class에 '{pattern}' 포함 - 클릭 차단 (class={cls!r})"
            )


def dump_title_body_areas(driver, label: str = "") -> None:
    """제목/본문 영역의 정확한 DOM 구조를 덤프 (selector 식별용)."""
    print(f"---- DUMP TITLE/BODY {label} ----")
    try:
        driver.switch_to.default_content()
    except Exception:
        pass

    for css in (
        ".se-documentTitle",
        ".se-documentTitle-editView",
        ".se-component.se-documentTitle",
        ".se-component.se-text",
        ".se-text-paragraph",
        "[contenteditable='true']",
        "[placeholder*='제목']",
        "[placeholder*='본문']",
        "[data-placeholder*='제목']",
        "[data-placeholder*='본문']",
    ):
        try:
            els = driver.find_elements(By.CSS_SELECTOR, css)
        except Exception:
            els = []
        print(f"  '{css}' -> {len(els)}개")
        for i, el in enumerate(els[:5]):
            try:
                disp = el.is_displayed()
                tag = el.tag_name
                cls = el.get_attribute("class") or ""
                ph = el.get_attribute("placeholder") or el.get_attribute("data-placeholder") or ""
                ce = el.get_attribute("contenteditable") or ""
                txt = (el.text or "")[:50]
                parents_cls = []
                try:
                    parent = el
                    for _ in range(3):
                        parent = parent.find_element(By.XPATH, "..")
                        parents_cls.append(parent.get_attribute("class") or "")
                except Exception:
                    pass
                print(f"    #{i} disp={disp} <{tag}> ce={ce!r} ph={ph!r} class={cls[:80]!r} text={txt!r} parents={parents_cls}")
            except Exception:
                pass
    print("---- END DUMP ----")


def dump_form_fields(driver, label: str = "") -> None:
    """input/textarea/select + '카테고리'·'태그' 텍스트 element 덤프 (M2 실측용)."""
    print(f"---- DUMP FORM FIELDS {label} ----")
    for ctx in ["default", "iframe"]:
        try:
            if ctx == "default":
                driver.switch_to.default_content()
            else:
                driver.switch_to.default_content()
                try:
                    driver.switch_to.frame("mainFrame")
                except Exception:
                    continue
        except Exception:
            continue

        for tag in ("input", "textarea", "select"):
            try:
                elements = driver.find_elements(By.TAG_NAME, tag)
            except Exception:
                continue
            shown = 0
            for i, el in enumerate(elements):
                try:
                    if not el.is_displayed():
                        continue
                    name = el.get_attribute("name") or ""
                    typ = el.get_attribute("type") or ""
                    cls = el.get_attribute("class") or ""
                    ph = el.get_attribute("placeholder") or ""
                    aria = el.get_attribute("aria-label") or ""
                    if name or ph or aria or "tag" in cls.lower() or "categ" in cls.lower():
                        print(f"  [{ctx}] <{tag}> #{i} name={name!r} type={typ!r} placeholder={ph!r} aria={aria!r} class={cls!r}")
                        shown += 1
                except Exception:
                    continue
            print(f"  [{ctx}] <{tag}> 표시된 요소 {shown}/{len(elements)}")

        # "카테고리" / "태그" 텍스트가 들어간 element 주변 탐색
        for keyword in ("카테고리", "태그"):
            try:
                for el in driver.find_elements(By.XPATH, f"//*[contains(text(), '{keyword}')]"):
                    if not el.is_displayed():
                        continue
                    tag = el.tag_name
                    cls = el.get_attribute("class") or ""
                    txt = (el.text or "")[:40]
                    print(f"  [{ctx}] {keyword!r} 발견: <{tag}> class={cls!r} text={txt!r}")
            except Exception:
                continue

    print("---- END DUMP ----")


def _read_save_count(driver) -> int | None:
    """임시저장 글 카운트 버튼(`save_count_btn__*`)의 숫자를 읽음. 검증용."""
    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    for selector in (
        "button[class^='save_count_btn']",
        "button[class*='save_count_btn']",
    ):
        try:
            btn = driver.find_element(By.CSS_SELECTOR, selector)
            text = (btn.text or "").strip()
            if text.isdigit():
                return int(text)
        except Exception:
            continue
    return None


def dump_buttons(driver, label: str = "") -> None:
    """페이지의 모든 button 요소를 텍스트와 함께 출력 (selector 실측용)."""
    print(f"---- DUMP BUTTONS {label} ----")
    for ctx in ["default", "iframe"]:
        try:
            if ctx == "default":
                driver.switch_to.default_content()
            else:
                driver.switch_to.default_content()
                try:
                    driver.switch_to.frame("mainFrame")
                except Exception:
                    continue
        except Exception:
            continue

        try:
            btns = driver.find_elements(By.TAG_NAME, "button")
        except Exception:
            continue
        print(f"  [{ctx}] button 개수: {len(btns)}")
        for i, b in enumerate(btns):
            try:
                if not b.is_displayed():
                    continue
                txt = (b.text or "").strip()
                cls = b.get_attribute("class") or ""
                aria = b.get_attribute("aria-label") or ""
                if txt or "save" in cls.lower() or "발행" in txt or "저장" in txt or aria:
                    print(f"  [{ctx}] #{i} text={txt!r} class={cls!r} aria={aria!r}")
            except Exception:
                continue
    print("---- END DUMP ----")


def click_save_draft_button(driver) -> bool:
    """SmartEditor의 '저장(임시저장)' 버튼만 클릭. '발행' 버튼은 절대 안 누름.

    Returns: 클릭 성공 여부.
    """
    print("[drafter] 임시저장 버튼 탐색...")

    # iframe 안에서 못 찾으면 default content로도 시도
    contexts = ["iframe", "default"]
    for ctx in contexts:
        if ctx == "default":
            try:
                driver.switch_to.default_content()
                print("[drafter] default content로 전환해 다시 시도")
            except Exception:
                pass

        for kind, selector in SAVE_DRAFT_SELECTORS:
            try:
                if kind == "xpath":
                    candidates = driver.find_elements(By.XPATH, selector)
                else:
                    candidates = driver.find_elements(By.CSS_SELECTOR, selector)
            except Exception:
                candidates = []

            for i, btn in enumerate(candidates):
                try:
                    displayed = btn.is_displayed()
                    text = (btn.text or "").strip()
                    cls = btn.get_attribute("class") or ""
                    print(f"  [{ctx}] {selector} #{i} displayed={displayed} text={text!r} class={cls!r}")
                    if not displayed:
                        continue
                    # ★ 가드레일: 발행 버튼 거부
                    _assert_not_publish(btn, label=f"임시저장 후보({selector})")
                    # JS 클릭으로 fallback (네이티브 click이 막힐 때)
                    try:
                        btn.click()
                    except Exception as click_err:
                        print(f"  [{ctx}] 네이티브 클릭 실패, JS 클릭 시도: {click_err}")
                        driver.execute_script("arguments[0].click();", btn)
                    print(f"[drafter] 임시저장 클릭 성공: {selector}")
                    time.sleep(2)
                    return True
                except RuntimeError:
                    raise  # 가드레일 위반은 즉시 전파
                except Exception as e:
                    print(f"  [{ctx}] {selector} #{i} 클릭 예외: {e}")
                    continue

    print("[drafter] [WARN]임시저장 버튼을 찾지 못함 (실측 필요)")
    return False


def wait_save_toast(driver, timeout: int = 15) -> bool:
    """임시저장 완료 토스트 등장 대기."""
    end = time.time() + timeout
    while time.time() < end:
        for kind, selector in SAVE_TOAST_SELECTORS:
            try:
                if kind == "xpath":
                    if driver.find_elements(By.XPATH, selector):
                        return True
            except Exception:
                pass
        time.sleep(0.5)
    return False


def extract_draft_id(driver, blog_id: str) -> str | None:
    """임시저장 후 draft_id 추출.

    방안 2 (안정적): 현재 URL의 쿼리에서 draftSeq/draftId 탐색
                     → 없으면 임시저장 목록 페이지 방문해 첫 항목 추출.
    방안 1 (네트워크 캡처)은 selenium-wire 필요 — M6 안정화에서 검토.
    """
    # 시도 1: 현재 URL
    try:
        url = driver.current_url
        for key in ("draftSequence", "draftSeq", "draftId", "tempPostNo"):
            m = re.search(rf"{key}=([^&]+)", url)
            if m:
                print(f"[drafter] draft_id from URL: {m.group(1)} ({key})")
                return m.group(1)
    except Exception:
        pass

    # 시도 2: default content로 나간 뒤 PostList의 임시저장 영역 방문
    try:
        driver.switch_to.default_content()
    except Exception:
        pass

    try:
        # 임시저장 목록 페이지 (네이버 블로그)
        driver.get(f"https://blog.naver.com/PostWriteForm.naver?blogId={blog_id}")
        time.sleep(3)
        page = driver.page_source
        # 임시저장 항목의 식별자 패턴 (실측 시 selector 정확화 필요)
        for key in ("draftSequence", "draftSeq", "draftId"):
            m = re.search(rf'{key}["\']?\s*[:=]\s*["\']?(\d+)', page)
            if m:
                print(f"[drafter] draft_id from drafts page: {m.group(1)} ({key})")
                return m.group(1)
    except Exception as e:
        print(f"[drafter] draft_id 추출 실패: {e}")

    print("[drafter] [WARN]draft_id를 추출하지 못함 (None 반환). 임시저장 자체는 성공했을 수 있음.")
    return None


def _click_outer_publish_button_for_exploration_only(driver) -> bool:
    """⚠️ 발행 다이얼로그를 *열기 위해서만* 외부 발행 버튼을 클릭한다.
    탐색 모드에서만 사용. 다이얼로그가 열린 후 안의 어떤 버튼도 클릭하지 않는다.
    """
    print("[EXPLORE] 발행 다이얼로그를 열기 위해 외부 발행 버튼 클릭...")
    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    btn = driver.find_element(By.CSS_SELECTOR, "button[class^='publish_btn']")
    try:
        btn.click()
    except Exception:
        driver.execute_script("arguments[0].click();", btn)
    time.sleep(2)
    return True


def explore_publish_dialog(driver) -> None:
    """발행 다이얼로그를 열고 내부 요소만 덤프. 어떤 버튼도 클릭하지 않음."""
    print("=" * 60)
    print("[EXPLORE MODE] 발행 다이얼로그 탐색")
    print("외부 '발행' 버튼 → 다이얼로그 오픈 → 내부 덤프. 안의 발행 버튼 NEVER 클릭.")
    print("=" * 60)
    _click_outer_publish_button_for_exploration_only(driver)
    time.sleep(2)
    dump_buttons(driver, "PUBLISH DIALOG OPEN")
    dump_form_fields(driver, "PUBLISH DIALOG OPEN")
    print("[EXPLORE] 60초 대기 - 직접 다이얼로그를 닫거나 자동 종료를 기다리세요.")
    time.sleep(60)


TAG_INPUT_SELECTORS = [
    ("css", "input.tag_input__rvUB5"),                    # 정공법 (해시 변경 대비)
    ("css", "input[class^='tag_input']"),
    ("css", "input[placeholder*='태그 입력']"),
]

PUBLISH_DIALOG_OPEN_SELECTORS = [
    ("css", "button[class^='publish_btn']"),  # 외부 발행 버튼 (다이얼로그 오픈 전용)
]

PUBLISH_DIALOG_CLOSE_SELECTORS = [
    ("css", "button.publish_fold_btn__DtZcG"),
    ("css", "button[class^='publish_fold_btn']"),
    ("xpath", "//button[normalize-space()='발행 설정 닫기']"),
]


def open_publish_dialog(driver) -> bool:
    """발행 다이얼로그를 *오픈*하기 위해서만* 외부 발행 버튼 클릭.
    내부의 confirm_btn은 절대 클릭하지 않는다 (가드레일).
    """
    print("[drafter] 태그 입력을 위해 발행 다이얼로그 오픈...")
    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    for kind, selector in PUBLISH_DIALOG_OPEN_SELECTORS:
        try:
            btn = driver.find_element(By.CSS_SELECTOR, selector) if kind == "css" \
                else driver.find_element(By.XPATH, selector)
            try:
                btn.click()
            except Exception:
                driver.execute_script("arguments[0].click();", btn)
            time.sleep(2)
            return True
        except Exception:
            continue
    print("[drafter] [WARN] 외부 발행 버튼을 찾지 못함")
    return False


def close_publish_dialog(driver) -> bool:
    """발행 다이얼로그 닫기 ('발행 설정 닫기' 버튼)."""
    for kind, selector in PUBLISH_DIALOG_CLOSE_SELECTORS:
        try:
            btn = driver.find_element(By.CSS_SELECTOR, selector) if kind == "css" \
                else driver.find_element(By.XPATH, selector)
            if not btn.is_displayed():
                continue
            # 가드레일: '발행 설정 닫기'에는 '발행' 글자가 포함되어 있으나
            # 닫기 버튼이므로 명시적으로 클래스/aria로 검증
            cls = btn.get_attribute("class") or ""
            if "publish_fold_btn" not in cls and "닫기" not in (btn.text or ""):
                continue
            try:
                btn.click()
            except Exception:
                driver.execute_script("arguments[0].click();", btn)
            print("[drafter] 발행 다이얼로그 닫기 성공")
            time.sleep(1)
            return True
        except Exception:
            continue
    print("[drafter] [WARN] 다이얼로그 닫기 버튼을 찾지 못함")
    return False


def enter_tags_in_dialog(driver, tags: Iterable[str]) -> int:
    """발행 다이얼로그가 열린 상태에서 태그 input에 각 태그 입력 + ENTER 확정.

    Returns: 입력 시도된 태그 개수.
    """
    tags = [t.strip().lstrip("#") for t in tags if t and t.strip()]
    if not tags:
        return 0

    tag_input = None
    for kind, selector in TAG_INPUT_SELECTORS:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector) if kind == "css" \
                else driver.find_elements(By.XPATH, selector)
            for el in elements:
                if el.is_displayed():
                    tag_input = el
                    print(f"[drafter] 태그 input 매칭: {selector}")
                    break
            if tag_input:
                break
        except Exception:
            continue

    if not tag_input:
        print("[drafter] [WARN] 태그 input을 찾지 못함")
        return 0

    # 발행 다이얼로그가 뜨는 전환 중 se-popup-dim(반투명 오버레이)이 태그 input을
    # 잠깐 가린다. dim 이 사라질 때까지 대기하고, 그래도 막히면 JS click 으로 우회한다.
    try:
        WebDriverWait(driver, 4).until(
            EC.invisibility_of_element_located((By.CSS_SELECTOR, "div.se-popup-dim"))
        )
    except Exception:
        pass
    time.sleep(0.6)
    try:
        tag_input.click()
    except Exception:
        print("[drafter] 태그 input 일반 클릭 차단(dim) → JS click 폴백")
        driver.execute_script("arguments[0].click();", tag_input)
    time.sleep(0.3)
    for tag in tags:
        # 봇 탐지 회피 위해 clipboard 사용
        pyperclip.copy(tag)
        ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
        time.sleep(0.3)
        ActionChains(driver).send_keys(Keys.ENTER).perform()
        time.sleep(0.3)
    print(f"[drafter] 태그 {len(tags)}개 입력 완료")
    return len(tags)


def write_post(
    naver_id: str,
    naver_pw: str,
    blog_id: str,
    title: str,
    body: str,
    image_paths: Iterable[str] = (),
    tags: Iterable[str] = (),
    dry_run: bool = False,
    explore_publish: bool = False,
) -> dict:
    """로그인 → 본문 입력 → **임시저장**까지 자동 수행.

    Returns: {
        "draft_id": str | None,
        "saved": bool,
        "blog_id": str,
        "title": str,
    }

    dry_run=True 면 임시저장 직전에 중단하고 60초 대기 (검증용).
    """
    driver = None
    started = time.time()
    try:
        driver = build_driver(headless=False)

        if not load_or_login(driver, naver_id, naver_pw):
            raise RuntimeError("네이버 로그인 실패")

        _goto_write_page(driver, blog_id)

        # 쿠키가 에디터엔 만료되어 로그인으로 튕긴 경우 처리
        if _is_login_redirect(driver):
            print("[drafter] 글쓰기 페이지가 로그인으로 리다이렉트됨 — 쿠키가 에디터에 만료됨")
            if naver_id and naver_pw:
                print("[drafter] NAVER_ID/PW 로 재로그인 시도 (필요 시 휴대폰 2FA)...")
                if not manual_login(driver, naver_id, naver_pw):
                    raise RuntimeError("재로그인 실패 (2FA 시간 초과 등)")
                _goto_write_page(driver, blog_id)
                if _is_login_redirect(driver):
                    raise RuntimeError("재로그인 후에도 글쓰기 페이지 진입 실패")
            else:
                raise RuntimeError(
                    "쿠키가 만료되어 글쓰기 페이지가 로그인으로 리다이렉트됩니다. "
                    "환경변수 NAVER_ID / NAVER_PW 를 설정한 뒤 다시 실행하세요 "
                    "(최초 1회 휴대폰 2FA 필요). 성공하면 쿠키가 갱신되어 이후엔 다시 생략됩니다."
                )

        _enter_iframe(driver)
        _close_popups(driver)
        if dry_run:
            dump_title_body_areas(driver, "BEFORE title input")
        _enter_title(driver, title)
        # 이미지는 본문 단락 사이 적절한 위치에 자동 삽입됨 (_enter_body 내부)
        _enter_body(driver, body, image_paths=image_paths)

        tags_list = [t for t in tags if t and str(t).strip()]
        if tags_list:
            if open_publish_dialog(driver):
                entered = enter_tags_in_dialog(driver, tags_list)
                if entered:
                    close_publish_dialog(driver)
                    time.sleep(1)

        if explore_publish:
            explore_publish_dialog(driver)
            return {"draft_id": None, "saved": False, "blog_id": blog_id, "title": title}

        if dry_run:
            print("=" * 60)
            print("[DRY-RUN] 임시저장 직전에 중단합니다.")
            print("   브라우저를 절대 닫지 마세요. 자동으로 버튼을 덤프하고 종료합니다.")
            print("=" * 60)
            time.sleep(2)
            dump_buttons(driver, "DRY-RUN")
            dump_form_fields(driver, "DRY-RUN")
            dump_title_body_areas(driver, "DRY-RUN")
            print("[DRY-RUN] 덤프 완료. 60초 후 자동 종료. (수동 검사하려면 그 안에 확인하세요)")
            time.sleep(60)
            return {"draft_id": None, "saved": False, "blog_id": blog_id, "title": title}

        # ★ M1: 원본의 sleep(60) 자리를 임시저장 자동 클릭으로 교체
        # 임시저장 개수 사전 측정 (성공 검증용)
        before_count = _read_save_count(driver)
        if before_count is not None:
            print(f"[drafter] 임시저장 글 개수 (저장 전): {before_count}")

        saved = click_save_draft_button(driver)
        if saved:
            if wait_save_toast(driver, timeout=15):
                print("[drafter] '임시저장' 토스트 확인")
            else:
                print("[drafter] 토스트 미감지 - 카운트로 검증 시도")
            after_count = _read_save_count(driver)
            if after_count is not None:
                print(f"[drafter] 임시저장 글 개수 (저장 후): {after_count}")
                if before_count is not None and after_count > before_count:
                    print(f"[drafter] [OK] 카운트 증가 확인 ({before_count} -> {after_count})")
                else:
                    print(f"[drafter] [WARN] 카운트 변동 없음 - 임시저장 실패 가능성")

        draft_id = extract_draft_id(driver, blog_id) if saved else None

        elapsed = int(time.time() - started)
        print("=" * 60)
        if saved:
            print(f"[OK] 임시저장 완료 (draft_id={draft_id}, {elapsed}초)")
            print(f"   네이버 블로그 앱 > 글쓰기 > 임시저장 글에서 검토 후 발행하세요.")
        else:
            print(f"[FAIL] 임시저장 실패 ({elapsed}초) - 로컬 마크다운은 보존됩니다.")
        print("=" * 60)

        return {"draft_id": draft_id, "saved": saved, "blog_id": blog_id, "title": title}

    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass


if __name__ == "__main__":
    # 스모크 테스트용 진입점 (실제 자격증명은 환경변수로)
    import os as _os
    nid = _os.environ.get("NAVER_ID")
    npw = _os.environ.get("NAVER_PW")
    bid = _os.environ.get("NAVER_BLOG_ID") or nid
    if not (nid and npw):
        raise SystemExit("환경변수 NAVER_ID, NAVER_PW (옵션 NAVER_BLOG_ID) 가 필요합니다")

    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="임시저장 직전에 중단")
    ap.add_argument("--explore-publish", action="store_true", help="발행 다이얼로그 탐색 (안 누름)")
    ap.add_argument("--title", default="M1 스모크 테스트")
    ap.add_argument("--tags", default="", help="쉼표 구분 태그 목록 (예: AI,블로그,코딩)")
    args = ap.parse_args()

    result = write_post(
        naver_id=nid,
        naver_pw=npw,
        blog_id=bid,
        title=args.title,
        body=(
            "안녕하세요, 테스트입니다.\n\n"
            "이 글은 M1 검증용 — 자동 임시저장 동작을 확인합니다.\n"
            "검토 후 직접 발행하거나 삭제해주세요."
        ),
        image_paths=[],
        tags=[t.strip() for t in args.tags.split(",") if t.strip()],
        dry_run=args.dry_run,
        explore_publish=args.explore_publish,
    )
    print(f"결과: {result}")
