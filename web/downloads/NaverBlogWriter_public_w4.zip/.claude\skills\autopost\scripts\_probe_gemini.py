"""일회성 — Gemini 웹(https://gemini.google.com)에 Selenium으로 접근 가능한지 검증.

목적: 기술 검증만. 로그인 X, 프롬프트 X. 페이지 도달 + DOM 구조 덤프 후 종료.
실행: py -3.12 _probe_gemini.py
"""
from __future__ import annotations

import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

options = webdriver.ChromeOptions()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)
driver.execute_script(
    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
)
driver.set_window_size(1280, 900)

try:
    print("=" * 60)
    print("[probe] gemini.google.com 접근 시작...")
    driver.get("https://gemini.google.com")
    time.sleep(5)

    print(f"[probe] 최종 URL: {driver.current_url}")
    print(f"[probe] 페이지 제목: {driver.title!r}")
    print(f"[probe] User-Agent: {driver.execute_script('return navigator.userAgent;')}")
    print(f"[probe] webdriver 속성: {driver.execute_script('return navigator.webdriver;')}")

    # 캡차/차단 감지
    src = driver.page_source
    triggers = ["recaptcha", "unusual traffic", "automated", "탐지", "비정상", "차단"]
    flags = [t for t in triggers if t.lower() in src.lower()]
    if flags:
        print(f"[probe] [WARN] 봇 탐지/차단 키워드 감지: {flags}")
    else:
        print("[probe] 봇 탐지/차단 키워드 미감지")

    # 주요 element 카운트
    inputs_ce = driver.find_elements(By.CSS_SELECTOR, "[contenteditable='true']")
    textareas = driver.find_elements(By.TAG_NAME, "textarea")
    buttons = driver.find_elements(By.TAG_NAME, "button")
    a_signin = driver.find_elements(By.XPATH, "//a[contains(., 'Sign in') or contains(., '로그인')]")

    print(f"[probe] contenteditable=true 요소: {len(inputs_ce)}")
    print(f"[probe] textarea 요소: {len(textareas)}")
    print(f"[probe] button 요소: {len(buttons)}")
    print(f"[probe] '로그인'/'Sign in' 링크: {len(a_signin)}")

    # 현재 화면이 로그인 요구 페이지인지 채팅 페이지인지 추측
    if "accounts.google.com" in driver.current_url:
        print("[probe] 판정: 로그인 페이지로 리다이렉트됨 (예상된 동작)")
    elif inputs_ce or textareas:
        print("[probe] 판정: 입력 가능한 채팅 페이지로 보임 (이미 로그인된 세션?)")
    else:
        print("[probe] 판정: 알 수 없음 — 화면 캡처 확인 필요")

    # 30초 대기 — 사용자가 시각으로 확인
    print("[probe] 30초 대기 — 브라우저 창에서 직접 확인하세요. 종료는 자동.")
    time.sleep(30)

finally:
    print("=" * 60)
    print("[probe] 종료")
    driver.quit()
