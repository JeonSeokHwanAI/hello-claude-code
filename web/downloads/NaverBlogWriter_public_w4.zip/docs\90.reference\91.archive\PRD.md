== 나의 요구 사항 ==

나는 네이버 블로그를 스크래핑 또는 크롤링 하고 싶다.
네이버 주소 또는 계정중 어떤 것으로 할 수 있을건인가?
파이썬으로 구성한다.
UI 모드는 필요없다.
디버깅만 해보자.

== 위 글은 절대 지우지 마시오 ==

---

# 네이버 블로그 스크래퍼 PRD (완전판)

## 1. 프로젝트 개요

네이버 블로그 ID를 입력하면 해당 블로그의 포스트 목록과 본문을 수집하여 JSON 파일로 저장하는 CLI 도구입니다.

### 핵심 기능
- RSS 피드로 포스트 목록 수집 (제목, 발행일, logNo)
- 모바일 버전 HTML 파싱으로 본문 추출
- AI 분석을 위한 `_guide` 필드 포함 JSON 출력

### 기술적 선택
| 항목 | 선택 | 이유 |
|------|------|------|
| 목록 수집 | RSS 피드 | 공식 지원, 안정적 |
| 본문 수집 | 모바일 HTML | iframe 없음, 구조 단순 |
| 데이터 형식 | JSON | AI 분석에 적합 |

---

## 2. 프로젝트 구조

```
Naver Scraping/
├── PRD.md
├── requirements.txt
├── main.py
├── scraper/
│   ├── __init__.py
│   ├── blog_scraper.py
│   └── parser.py
├── utils/
│   ├── __init__.py
│   └── helpers.py
└── output/
    ├── {blogId}_posts_{timestamp}.json
    └── {blogId}_summary_{timestamp}.json
```

---

## 3. 의존성 (requirements.txt)

```
requests>=2.28.0
beautifulsoup4>=4.11.0
```

---

## 4. 전체 코드

### 4.1 main.py

```python
"""
네이버 블로그 스크래퍼 - 메인 진입점

사용법:
    python main.py
"""

from scraper import NaverBlogScraper
from utils import save_posts_to_files


def extract_blog_id(user_input):
    """URL 또는 ID에서 블로그 ID 추출"""
    user_input = user_input.strip()

    # URL인 경우 ID 추출
    if "blog.naver.com" in user_input:
        # https://blog.naver.com/blogid 또는 https://blog.naver.com/blogid/포스트번호
        parts = user_input.replace("https://", "").replace("http://", "")
        parts = parts.split("/")
        if len(parts) >= 2:
            return parts[1].split("?")[0]  # 쿼리스트링 제거

    # 그냥 ID인 경우
    return user_input


def main():
    print("=" * 60)
    print("네이버 블로그 스크래퍼")
    print("=" * 60)
    print()

    # 블로그 ID 입력
    user_input = input(">> 네이버 블로그 아이디를 입력하세요: ").strip()
    if not user_input:
        print("블로그 아이디가 입력되지 않았습니다.")
        return

    blog_id = extract_blog_id(user_input)
    print(f"   블로그 ID: {blog_id}")
    print()

    # 검색 수 입력
    limit_input = input(">> 검색할 블로그 수를 입력하세요 (최대 50개, 기본 10): ").strip()
    if not limit_input:
        limit = 10
    else:
        try:
            limit = int(limit_input)
            if limit < 1:
                limit = 1
            elif limit > 50:
                print("   최대 50개로 제한됩니다.")
                limit = 50
        except ValueError:
            print("   잘못된 입력입니다. 기본값 10으로 설정합니다.")
            limit = 10

    print()
    print("-" * 60)
    print(f"블로그를 체크합니다... (ID: {blog_id}, 수량: {limit}개)")
    print("-" * 60)
    print()

    # 스크래퍼 초기화 및 실행
    scraper = NaverBlogScraper(blog_id=blog_id, delay=1.0)

    posts = scraper.scrape_all(
        limit=limit,
        include_content=True,
        include_images=True
    )

    if not posts:
        print("스크래핑된 포스트가 없습니다. 블로그 ID를 확인해주세요.")
        return

    # 결과 저장 (블로그 ID를 prefix로)
    result = save_posts_to_files(posts, output_dir="output", prefix=blog_id)

    print()
    print("=" * 60)
    print("완료!")
    print("=" * 60)
    print(f"총 포스트: {result['total']}개")
    print(f"저장 위치: {result['summary_file']}")
    print()


if __name__ == "__main__":
    main()
```

### 4.2 scraper/__init__.py

```python
from .blog_scraper import NaverBlogScraper
from .parser import PostParser

__all__ = ["NaverBlogScraper", "PostParser"]
```

### 4.3 scraper/blog_scraper.py

```python
"""
네이버 블로그 스크래퍼 핵심 모듈
- RSS 피드로 포스트 목록 수집
- 모바일 버전으로 본문 추출
"""

import requests
import xml.etree.ElementTree as ET
import time
import re
from typing import Optional
from .parser import PostParser


class NaverBlogScraper:
    """네이버 블로그 스크래퍼"""

    # User-Agent 헤더
    DESKTOP_HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    MOBILE_HEADERS = {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1"
    }

    def __init__(self, blog_id: str, delay: float = 1.0):
        """
        Args:
            blog_id: 네이버 블로그 ID
            delay: 요청 간 딜레이 (초)
        """
        self.blog_id = blog_id
        self.delay = delay
        self.parser = PostParser()

    def get_post_list(self, limit: Optional[int] = None) -> list:
        """
        RSS 피드에서 포스트 목록 가져오기

        Args:
            limit: 가져올 포스트 수 (None이면 전체)

        Returns:
            포스트 목록 (제목, 링크, logNo, 날짜, 요약)
        """
        url = f"https://rss.blog.naver.com/{self.blog_id}.xml"

        try:
            response = requests.get(url, headers=self.DESKTOP_HEADERS, timeout=10)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"RSS 요청 실패: {e}")
            return []

        # XML 파싱
        try:
            root = ET.fromstring(response.content)
        except ET.ParseError as e:
            print(f"XML 파싱 실패: {e}")
            return []

        posts = []
        for item in root.findall(".//item"):
            post = {
                "title": "",
                "link": "",
                "logNo": "",
                "pubDate": "",
                "description": ""
            }

            # 제목
            title_elem = item.find("title")
            if title_elem is not None and title_elem.text:
                post["title"] = title_elem.text

            # 링크
            link_elem = item.find("link")
            if link_elem is not None and link_elem.text:
                post["link"] = link_elem.text
                # logNo 추출
                match = re.search(r"/(\d+)", post["link"])
                if match:
                    post["logNo"] = match.group(1)

            # 발행일
            pub_elem = item.find("pubDate")
            if pub_elem is not None and pub_elem.text:
                post["pubDate"] = pub_elem.text

            # 설명 (요약)
            desc_elem = item.find("description")
            if desc_elem is not None and desc_elem.text:
                # HTML 태그 제거
                desc = re.sub(r"<[^>]+>", "", desc_elem.text)
                desc = desc[:500] if len(desc) > 500 else desc
                post["description"] = desc

            posts.append(post)

            if limit and len(posts) >= limit:
                break

        return posts

    def get_post_content(self, log_no: str) -> Optional[dict]:
        """
        모바일 버전에서 포스트 본문 가져오기

        Args:
            log_no: 포스트 번호

        Returns:
            포스트 데이터 (제목, 본문, 이미지) 또는 None
        """
        url = f"https://m.blog.naver.com/{self.blog_id}/{log_no}"

        try:
            response = requests.get(url, headers=self.MOBILE_HEADERS, timeout=10)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"포스트 요청 실패 ({log_no}): {e}")
            return None

        return self.parser.parse_mobile_post(response.text, self.blog_id, log_no)

    def scrape_all(self, limit: Optional[int] = None, include_content: bool = True, include_images: bool = False) -> list:
        """
        전체 스크래핑 (목록 + 본문)

        Args:
            limit: 스크래핑할 포스트 수
            include_content: 본문 포함 여부
            include_images: 이미지 URL 포함 여부

        Returns:
            전체 포스트 데이터 리스트
        """
        print(f"[1/2] 포스트 목록 가져오는 중...")
        posts = self.get_post_list(limit=limit)
        print(f"      {len(posts)}개 포스트 발견")

        if not include_content:
            return posts

        print(f"[2/2] 포스트 본문 가져오는 중...")
        results = []

        for i, post in enumerate(posts, 1):
            log_no = post.get("logNo")
            if not log_no:
                continue

            print(f"      [{i}/{len(posts)}] {post['title'][:30]}...")

            content_data = self.get_post_content(log_no)

            if content_data:
                # RSS 정보와 본문 정보 병합
                merged = {
                    **post,
                    "content": content_data.get("content", "")
                }
                if include_images:
                    merged["images"] = content_data.get("images", [])
                results.append(merged)
            else:
                results.append(post)

            # 딜레이
            if i < len(posts):
                time.sleep(self.delay)

        return results
```

### 4.4 scraper/parser.py

```python
"""
HTML 파싱 모듈
- 모바일 버전 포스트 본문 파싱
"""

import re
from bs4 import BeautifulSoup


class PostParser:
    """네이버 블로그 포스트 HTML 파서"""

    @staticmethod
    def parse_mobile_post(html: str, blog_id: str, log_no: str) -> dict:
        """
        모바일 버전 포스트 HTML 파싱

        Args:
            html: HTML 문자열
            blog_id: 블로그 ID
            log_no: 포스트 번호

        Returns:
            파싱된 포스트 데이터 딕셔너리
        """
        soup = BeautifulSoup(html, "html.parser")

        result = {
            "blogId": blog_id,
            "logNo": log_no,
            "title": "",
            "content": "",
            "images": []
        }

        # 제목 추출
        result["title"] = PostParser._extract_title(soup)

        # 본문 추출
        result["content"] = PostParser._extract_content(soup)

        # 이미지 추출
        result["images"] = PostParser._extract_images(soup)

        return result

    @staticmethod
    def _extract_title(soup: BeautifulSoup) -> str:
        """제목 추출"""
        title_elem = soup.find("title")
        if title_elem:
            title = title_elem.get_text(strip=True)
            # " : 네이버 블로그" 제거
            title = re.sub(r"\s*:\s*네이버\s*블로그.*$", "", title)
            return title
        return ""

    @staticmethod
    def _extract_content(soup: BeautifulSoup) -> str:
        """본문 추출"""
        # 여러 선택자 시도
        content_selectors = [
            {"class_": "se-main-container"},
            {"class_": "post_ct"},
            {"id": "postViewArea"},
            {"class_": "__se_component_area"}
        ]

        content_text = ""
        for selector in content_selectors:
            content_elem = soup.find("div", **selector)
            if content_elem:
                content_text = content_elem.get_text(separator="\n", strip=True)
                break

        # 대안: se-text 클래스들 수집
        if not content_text:
            text_elems = soup.find_all(class_=re.compile(r"se-text|se_textarea"))
            if text_elems:
                texts = [e.get_text(strip=True) for e in text_elems]
                content_text = "\n".join(texts)

        # 특수 문자 제거 (zero-width space 등)
        content_text = re.sub(r'[\u200b\u200c\u200d\ufeff]', '', content_text)

        return content_text

    @staticmethod
    def _extract_images(soup: BeautifulSoup) -> list:
        """이미지 URL 추출"""
        images = []
        for img in soup.find_all("img"):
            src = img.get("src") or img.get("data-src")
            if src and ("blogthumb" in src or "postfiles" in src or "pstatic" in src):
                # 썸네일이 아닌 원본 이미지 URL로 변환
                if "type=w80" in src:
                    src = re.sub(r"\?type=w\d+.*$", "", src)
                images.append(src)
        return images
```

### 4.5 utils/__init__.py

```python
from .helpers import save_json, save_posts_to_files

__all__ = ["save_json", "save_posts_to_files"]
```

### 4.6 utils/helpers.py

```python
"""
유틸리티 함수 모듈
"""

import json
import os
from datetime import datetime


def save_json(data: list | dict, filepath: str) -> str:
    """
    데이터를 JSON 파일로 저장

    Args:
        data: 저장할 데이터
        filepath: 저장 경로

    Returns:
        저장된 파일 경로
    """
    # 디렉토리 생성
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return filepath


def save_posts_to_files(posts: list, output_dir: str = "output", prefix: str = "") -> dict:
    """
    포스트 데이터를 파일로 저장

    Args:
        posts: 포스트 리스트
        output_dir: 출력 디렉토리
        prefix: 파일명 앞에 붙일 접두사 (예: 블로그 ID)

    Returns:
        저장 결과 정보
    """
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 파일명 생성 (prefix가 있으면 prefix_summary_날짜.json)
    if prefix:
        posts_filename = f"{prefix}_posts_{timestamp}.json"
        summary_filename = f"{prefix}_summary_{timestamp}.json"
    else:
        posts_filename = f"posts_{timestamp}.json"
        summary_filename = f"summary_{timestamp}.json"

    # 전체 데이터 저장
    all_posts_file = os.path.join(output_dir, posts_filename)
    save_json(posts, all_posts_file)

    # 요약 정보 저장
    def parse_pubdate(pub_date_str):
        """pubDate에서 요일 추출"""
        if not pub_date_str:
            return ""
        # "Tue, 27 Jan 2026 08:02:27 +0900" 형식
        day_map = {"Mon": "월", "Tue": "화", "Wed": "수", "Thu": "목", "Fri": "금", "Sat": "토", "Sun": "일"}
        parts = pub_date_str.split(",")
        if parts:
            day_abbr = parts[0].strip()
            return day_map.get(day_abbr, day_abbr)
        return ""

    def build_post_summary(i, p):
        title = p.get("title", "")
        content = p.get("content", "")
        pub_date = p.get("pubDate", "")
        log_no = p.get("logNo", "")
        images = p.get("images", [])

        return {
            "index": f"{i:02d}",
            "logNo": log_no,
            "url": f"https://blog.naver.com/{prefix}/{log_no}" if prefix and log_no else "",
            "title": title,
            "title_length": len(title),
            "pubDate": pub_date,
            "day_of_week": parse_pubdate(pub_date),
            "has_content": bool(content),
            "content_length": len(content) if content else 0,
            "image_count": len(images)
        }

    summary = {
        "_guide": {
            "출력규칙": "반드시 마크다운 표(|---|---|) 형식 사용. 각 섹션은 ### 헤더로 구분. 항목별 상세 설명 필수.",
            "전체분석": {
                "설명": "블로그 전체를 12가지 항목으로 종합 분석",
                "형식": "각 항목마다 마크다운 표(항목|점수/100|분석내용) 사용",
                "항목": ["콘텐츠장단점", "운영자문제점", "SEO개선점", "전략제안", "타겟독자", "브랜딩", "발행패턴", "제목패턴", "수익화", "경쟁환경", "AI대응력", "독자참여도"],
                "필수": "각 항목 100점 만점 점수 + 장점/단점/개선안 구체적 서술"
            },
            "특정글분석": {
                "설명": "posts 파일에서 index 번호로 지정된 글의 본문을 심층 분석",
                "형식": [
                    "### 1. 콘텐츠 구조 분석 - 마크다운 표(구성요소|내용|평가) + 별점(★) 5점 만점",
                    "### 2. 강점 4가지 - 번호 매기고 각각 2-3문장으로 상세 설명",
                    "### 3. 약점 및 개선점 - 마크다운 표(약점|현재상태|개선방안) 3개 이상",
                    "### 4. SEO 분석 - 제목패턴, 핵심키워드 5개, 추천 메타설명 50자 이상",
                    "### 5. 독자 반응 예측 - 마크다운 표(반응유형|예상반응|근거) 4개 이상",
                    "### 6. 종합 평가 - 마크다운 표(평가항목|점수/100|코멘트) 정보성,가독성,SEO,독창성,실용성",
                    "### 7. 총평 - 3-4문장으로 글의 가치와 개선 방향 요약"
                ]
            },
            "빠른요약": {
                "설명": "블로그 전체를 3줄로 요약",
                "형식": ["- **주제**: ...", "- **강점**: ...", "- **개선점**: ..."]
            },
            "제목분석": {
                "설명": "제목 패턴과 SEO 분석",
                "형식": ["제목패턴 분류표", "SEO 키워드 추출", "개선 필요 제목 3개 + 수정안"]
            }
        },
        "blog_id": prefix,
        "blog_url": f"https://blog.naver.com/{prefix}" if prefix else "",
        "total_posts": len(posts),
        "scraped_at": datetime.now().isoformat(),
        "posts": [build_post_summary(i, p) for i, p in enumerate(posts)]
    }

    summary_file = os.path.join(output_dir, summary_filename)
    save_json(summary, summary_file)

    return {
        "posts_file": all_posts_file,
        "summary_file": summary_file,
        "total": len(posts)
    }
```

---

## 5. 사용법

### 설치
```bash
pip install -r requirements.txt
```

### 실행
```bash
python main.py
```

### 입력 예시
```
>> 네이버 블로그 아이디를 입력하세요: example_blog
   블로그 ID: example_blog

>> 검색할 블로그 수를 입력하세요 (최대 50개, 기본 10): 10
```

### 출력 파일
- `output/{blogId}_posts_{timestamp}.json` - 전체 데이터 (본문 포함)
- `output/{blogId}_summary_{timestamp}.json` - 요약 + _guide

---

## 6. AI 분석 활용법

summary JSON 파일을 AI에게 제공하면 `_guide` 필드를 읽고 일관된 형식으로 분석합니다:

```
@output/블로그ID_summary_날짜.json 전체분석해줘
@output/블로그ID_summary_날짜.json 00번 분석해줘
@output/블로그ID_summary_날짜.json 빠른요약
@output/블로그ID_summary_날짜.json 제목분석
```

분석 결과는 `output/{블로그ID}.md` 파일로 저장합니다.

---

## 7. URL 패턴

| 용도 | URL |
|------|-----|
| RSS 피드 | `https://rss.blog.naver.com/{blogId}.xml` |
| 모바일 포스트 | `https://m.blog.naver.com/{blogId}/{logNo}` |
| 데스크톱 포스트 | `https://blog.naver.com/{blogId}/{logNo}` |

---

## 8. 주의사항

1. **요청 딜레이**: 서버 부담 최소화를 위해 기본 1초 딜레이 적용
2. **최대 수량**: RSS는 최근 50개 포스트만 제공
3. **HTML 구조 변경**: 네이버 업데이트 시 parser.py 수정 필요
4. **robots.txt 준수**: 개인 용도 분석 목적으로만 사용
