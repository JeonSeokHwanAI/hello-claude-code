"""일회성 — attach된 Gemini 탭에 내 ChatGPT 5.5 글의 Image Prompt #1 입력 →
응답 대기 → 생성된 이미지를 docs/10.input/gemini/ 에 다운로드.

전제: Chrome --remote-debugging-port=9222, gemini.google.com 탭 열림.
"""
from __future__ import annotations

import base64
import re
import sys
import time
from pathlib import Path

import pyperclip
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

# 내가 ChatGPT_5.5_무엇이_달라졌나_20260527.md 에 작성한 Image Prompt #1
# "Generate an image:" 접두사로 이미지 생성 모드 명시 트리거
PROMPT = (
    "Generate an image: A modern laptop screen showing a sleek ChatGPT interface with a subtle "
    "\"5.5\" version badge in the corner, soft morning desk light, coffee cup nearby, minimalist "
    "illustration style with warm cream and blue palette, evoking a quiet but meaningful update. "
    "Aspect ratio 16:9, horizontal composition."
)
TARGET_NAME_BASE = "chatgpt55_01_quiet_update"

OUT_DIR = Path(r"G:\내 드라이브\WorkSpace\NaverBlogWriter\docs\10.input\gemini")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def attach():
    options = webdriver.ChromeOptions()
    options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    for handle in driver.window_handles:
        try:
            driver.switch_to.window(handle)
            if "gemini.google.com" in driver.current_url:
                return driver
        except Exception:
            continue
    raise SystemExit("Gemini 탭이 없습니다.")


def submit_prompt(driver, prompt: str) -> None:
    candidates = driver.find_elements(By.CSS_SELECTOR, "[contenteditable='true']")
    target = None
    for el in candidates:
        if el.is_displayed():
            aria = (el.get_attribute("aria-label") or "").lower()
            cls = el.get_attribute("class") or ""
            if "prompt" in aria or "프롬프트" in (el.get_attribute("aria-label") or "") or "ql-editor" in cls:
                target = el
                break
    if not target:
        raise SystemExit("프롬프트 박스를 찾지 못함")
    target.click()
    time.sleep(0.5)
    # 기존 입력 지우기
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
    ActionChains(driver).send_keys(Keys.DELETE).perform()
    time.sleep(0.3)
    pyperclip.copy(prompt)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
    time.sleep(1)
    ActionChains(driver).send_keys(Keys.ENTER).perform()
    print("[OK] 프롬프트 전송")


def _scan_big_imgs(driver, min_size_px: int, exclude_srcs: set) -> list:
    """현재 페이지에서 min_size 이상의 새 이미지 (img, src, w, h) 리스트."""
    out = []
    for img in driver.find_elements(By.CSS_SELECTOR, "img"):
        try:
            src = img.get_attribute("src") or ""
            if not src or src in exclude_srcs:
                continue
            w = int(img.get_attribute("naturalWidth") or 0)
            h = int(img.get_attribute("naturalHeight") or 0)
            if w >= min_size_px and h >= min_size_px:
                out.append((img, src, w, h))
        except Exception:
            continue
    return out


def wait_for_images(driver, exclude_srcs: set, timeout: int = 120, min_size_px: int = 200) -> list:
    """새 이미지가 등장하고 안정될 때까지 대기 (기준선 이미지는 exclude_srcs로 제외)."""
    start = time.time()
    last_count = 0
    while time.time() - start < timeout:
        new_imgs = _scan_big_imgs(driver, min_size_px, exclude_srcs)
        if len(new_imgs) > last_count:
            print(f"  [모니터] 새 이미지 {len(new_imgs)}개 감지 ({int(time.time() - start)}s 경과)")
            last_count = len(new_imgs)
        # 안정성 검사: 3초 후에도 같은 개수면 응답 완료로 간주
        if new_imgs:
            time.sleep(3)
            new_imgs_2 = _scan_big_imgs(driver, min_size_px, exclude_srcs)
            if len(new_imgs_2) == len(new_imgs):
                return new_imgs_2
        time.sleep(2)
    return []


def download(driver, img_el, src: str, dest: Path) -> bool:
    """src 형식별 다운로드.
    - data:image — base64 디코드
    - http(s) — requests
    - blob: — 브라우저에서 canvas로 그려 dataURL로 변환 후 디코드
    """
    try:
        if src.startswith("data:image"):
            header, b64 = src.split(",", 1)
            ext = "png" if "png" in header else "jpg" if "jpeg" in header else "img"
            dest = dest.with_suffix("." + ext)
            dest.write_bytes(base64.b64decode(b64))
            print(f"  [저장] data URI -> {dest.name} ({dest.stat().st_size:,} 바이트)")
            return True

        if src.startswith("blob:"):
            # img element를 canvas에 그려서 dataURL로 변환 (브라우저 컨텍스트 필요)
            data_url = driver.execute_script(
                """
                var img = arguments[0];
                var canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                var ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                try {
                    return canvas.toDataURL('image/png');
                } catch (e) {
                    return 'ERROR:' + e.message;
                }
                """,
                img_el,
            )
            if not data_url or data_url.startswith("ERROR:"):
                print(f"  [실패] canvas 변환 실패: {data_url}")
                return False
            header, b64 = data_url.split(",", 1)
            dest = dest.with_suffix(".png")
            dest.write_bytes(base64.b64decode(b64))
            print(f"  [저장] blob (canvas) -> {dest.name} ({dest.stat().st_size:,} 바이트)")
            return True

        if src.startswith("http"):
            r = requests.get(src, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            ctype = r.headers.get("content-type", "")
            ext = "png" if "png" in ctype else "jpg" if "jpeg" in ctype else "img"
            dest = dest.with_suffix("." + ext)
            dest.write_bytes(r.content)
            print(f"  [저장] {src[:60]}... -> {dest.name} ({len(r.content):,} 바이트)")
            return True

        print(f"  [실패] 지원하지 않는 src 형식: {src[:60]}...")
        return False
    except Exception as e:
        print(f"  [실패] {src[:60]}... : {e}")
        return False


def main():
    download_only = "--download-only" in sys.argv

    driver = attach()
    print(f"[OK] Gemini attach: {driver.current_url}")

    if download_only:
        # 현재 떠 있는 모든 큰 이미지 다운로드 (새 프롬프트 안 보냄)
        print("[모드] download-only — 현재 페이지의 큰 이미지 모두 다운로드")
        new_imgs = _scan_big_imgs(driver, min_size_px=400, exclude_srcs=set())
        print(f"[발견] 큰 이미지 {len(new_imgs)}개")
    else:
        # 사전 이미지 카운트 (응답 전 기준선)
        pre_srcs = {img.get_attribute("src") or ""
                    for img in driver.find_elements(By.CSS_SELECTOR, "img")
                    if (int(img.get_attribute("naturalWidth") or 0) >= 200)}
        print(f"[기준선] 입력 전 큰 이미지: {len(pre_srcs)}개")

        submit_prompt(driver, PROMPT)
        print("[대기] 응답 생성 + 이미지 등장 대기 (최대 120초)...")
        new_imgs = wait_for_images(driver, exclude_srcs=pre_srcs, timeout=120)
        print(f"[발견] 새 이미지 {len(new_imgs)}개 (입력 전 {len(pre_srcs)}개 제외)")

    if not new_imgs:
        print("[FAIL] 새 이미지 0개. Gemini가 텍스트로만 응답했거나 selector 변경 가능성.")
        sys.exit(1)

    for i, (img, src, w, h) in enumerate(new_imgs, 1):
        suffix = "" if i == 1 else f"_{i}"
        dest = OUT_DIR / f"{TARGET_NAME_BASE}{suffix}"
        print(f"\n  #{i} {w}x{h} src={src[:80]}...")
        download(driver, img, src, dest)

    print()
    print(f"[완료] 저장 위치: {OUT_DIR}")


if __name__ == "__main__":
    main()
