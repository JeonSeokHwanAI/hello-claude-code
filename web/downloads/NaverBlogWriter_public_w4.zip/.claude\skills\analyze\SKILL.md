---
name: analyze
description: 블로그 전체를 12개 항목으로 분석하고 이전 분석과 비교해 성장 추이를 추적한다. '/analyze', '성장 분석' 요청 시 사용.
model: opus
allowed-tools:
  - Read
  - Glob
  - Write
  - Edit
  - Bash
---

# 블로그 성장 분석

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- 전체분석 결과: `docs/30.output/32.reviews/{blog_id}_전체분석_{YYYYMMDD}.md`
- 검색 기록(상태): `docs/20.working/22.state/.last_searches.json`

블로그 전체 분석 및 이전 분석과 비교합니다.

## 사용법

- `/analyze <블로그>` → 최신 데이터로 전체 분석 + 이전 분석과 비교
- `/analyze <블로그> full` → 새로 스크래핑(20개) 후 전체 분석
- `/analyze <블로그> compare` → 저장된 분석들만 비교 (스크래핑 없음)
- `/analyze list` → 전체 분석 저장된 블로그 목록

## 스크립트 & 템플릿 (결정적 작업)

조회는 `analyze_cli.py`로, 전체분석 출력은 **review의 `template/전체분석.md` 양식**을 그대로 사용한다(이전 점수는 `previous_analysis`/비교표에 반영). 12항목 분석·비교 서술은 LLM(opus)이 담당한다.

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter"
python -X utf8 ".claude/skills/analyze/scripts/analyze_cli.py" resolve "<블로그>"  # blog_id 해석
python -X utf8 ".claude/skills/analyze/scripts/analyze_cli.py" list                # 전체분석 보유 블로그
python -X utf8 ".claude/skills/analyze/scripts/analyze_cli.py" prev <blog>         # 이전 점수(YAML 파싱)
# full 옵션 — search 스크래핑 엔진 재사용
python -X utf8 ".claude/skills/search/scripts/main.py" "<blog>" 20
```

출력 양식: `.claude/skills/review/template/전체분석.md`

## 실행 흐름

### 1. 블로그 ID 확인
- `analyze_cli.py resolve "<블로그>"` → blog_id (예: "셀슈머" → happy_selsumer)
- 인자가 `list`면 `analyze_cli.py list` 실행 후 종료

### 2. 이전 분석 데이터 로드
- `analyze_cli.py prev <blog>` → 최신 전체분석의 analyzed_at·overall_score·12개 점수 출력 (없으면 "최초 분석")
- 이 값을 현재 분석과의 비교(점수 변화표)에 사용

### 3. 현재 데이터 분석
**full 옵션 시:**
```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/search/scripts/main.py" "{blog_id}" 20
```

**기본/compare 시:**
- `docs/20.working/21.scraped/{blog_id}/` 폴더의 최신 summary 파일 사용

### 4. 12가지 항목 분석

| 항목 | 분석 내용 |
|------|----------|
| 콘텐츠장단점 | 주제 다양성, 깊이, 일관성 |
| 운영자문제점 | 발행 빈도, 공백 기간 |
| SEO개선점 | 제목 길이, 키워드 배치 |
| 전략제안 | 시리즈화, 카테고리 |
| 타겟독자 | 1차/2차/3차 타겟 |
| 브랜딩 | 블로그명, 정체성, 톤 |
| 발행패턴 | 요일별 빈도, 일관성 |
| 제목패턴 | 감성형/정보형/스토리형 |
| 수익화 | 현재/가능성/추천 |
| 경쟁환경 | 주제별 경쟁 수준 |
| AI대응력 | 실제 경험 기반 콘텐츠 |
| 독자참여도 | CTA, 댓글 유도 |

### 5. 비교 분석 (이전 분석 있을 시)

**점수 변화 표:**
```
| 항목 | 이전 | 현재 | 변화 |
|------|------|------|------|
| 콘텐츠장단점 | 75 | 88 | +13 |
...
```

**주요 변화 포인트:**
- 가장 많이 상승한 항목 3개
- 하락한 항목 (있다면)
- 발행 패턴 변화
- 주제 비중 변화

### 6. 결과 저장

**`review/template/전체분석.md` 양식을 채워** `docs/30.output/32.reviews/{blog_id}_전체분석_{YYYYMMDD}.md`로 저장한다.
- frontmatter의 `scores`·`overall_score`·`topics`는 현재 분석값으로,
- `previous_analysis`(date·overall_score·change)는 2단계 `prev` 출력값으로 채운다.

## 출력 형식

```
## {블로그명} 성장 분석

> 분석일: {날짜}
> 이전 분석: {이전 날짜} (있을 시)
> 종합 점수: {점수}/100 ({변화})

### 핵심 변화

| 항목 | 이전 → 현재 | 변화 |
|------|-------------|------|
| {항목} | {이전} → {현재} | {+/-} |

### 성장 포인트
1. {가장 많이 상승한 항목}
2. ...

### 개선 필요
1. {하락 또는 낮은 점수 항목}
2. ...

### 12가지 항목 상세
(기존 전체분석 형식)

---
저장됨: docs/30.output/32.reviews/{파일명}
```

## 검색 기록 업데이트

분석 완료 후 `docs/20.working/22.state/.last_searches.json` 업데이트

## 참조 파일

- `docs/20.working/21.scraped/{blog_id}/*_summary_*.json`: 포스트 목록
- `docs/30.output/32.reviews/{blog_id}_전체분석_*.md`: 이전 분석
- `config/blogs.json`: 블로그 메타데이터
