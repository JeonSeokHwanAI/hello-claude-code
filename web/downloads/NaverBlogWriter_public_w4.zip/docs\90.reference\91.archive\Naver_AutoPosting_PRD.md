# Naver AutoPosting PRD

> "마크다운까지는 작가가, 임시저장은 봇이, 발행은 다시 작가의 손으로."

> **중요 원칙 (Scope Boundary)**:
> - 글 작성(키워드 → 본문)은 **`/write` 스킬의 책임**. 본 스킬(`autopost`)은 다루지 않는다.
> - autopost는 **이미 작성된 마크다운 파일(`docs/30.output/31.posts/*.md`)을 받아 네이버 블로그 임시저장(Draft)까지만** 수행한다.
> - **공개 발행(Publish)은 절대 자동으로 누르지 않는다.** 마지막 발행 권한은 항상 사용자에게 있다.
> - 본 문서에서 "AutoPosting" = "마크다운 파일 → 자동 임시저장" 을 의미한다.

| 항목 | 내용 |
|------|------|
| 문서 종류 | PRD (Product Requirements Document) + 기술 설계 |
| 버전 | v0.5 (M0~M5 완료 반영) |
| 작성일 | 2026-05-27 (v0.1) / 2026-05-27 (v0.5 — M5 Gemini 이미지) |
| 작성자 | 시스템 자동 작성 (사용자 검토 필요) |
| 대상 산출물 | `.claude/skills/autopost/` (운영 중) |
| 상태 | 운영 중 (M5 완료, M6 진행 예정) |

---

## 1. 개요 (Overview)

### 1.1 배경

NaverBlogWriter는 "AI는 펜이고, 당신이 작가입니다" 라는 슬로건으로 **블로그 분석 → 페르소나 → 글 작성**까지의 파이프라인을 구현해왔다. 현재 다음 스킬이 운영 중이다.

- 수집/분석: `/search`, `/review`, `/analyze`, `/monthly`
- 리서치: `/trend`, `/keyword`, `/bridge`
- 작성: `/persona`, `/write`

그러나 `/write`의 산출물(`docs/30.output/31.posts/{제목}_{YYYYMMDD}.md`)은 **로컬 마크다운 파일까지만** 생성한다. 사용자는 여전히:

1. 결과 파일을 연다
2. 네이버 블로그 에디터에 복붙한다 (마크다운 → 줄글 변환 손실 발생)
3. 카테고리/태그를 직접 입력한다
4. 이미지를 별도 생성/업로드한다
5. 검토 후 발행 버튼을 누른다

이 중 2~4단계는 매번 15~25분의 단순작업이다. AutoPosting은 **2~4단계를 자동화**하여 사용자가 네이버 블로그 임시저장 목록에서 글을 열어 **검토 후 발행 버튼만 누르면 되도록** 한다.

### 1.2 목적

**`/write` 산출물(마크다운 파일)을 입력받아 네이버 블로그 임시저장(Draft) 함에 그대로 올린다.** 사용자는 모바일/데스크탑 네이버 블로그 앱에서 "임시저장 글" 목록을 열어 검토 후 직접 발행한다.

키워드→글 작성 흐름은 **`/write` 스킬의 책임**이며, 향후 `/write`가 subagent로 확장될 때 그 내부에서 `autopost upload <파일>`을 호출하는 형태로 end-to-end가 완성된다.

### 1.3 성공 정의

- 사용자가 `/autopost upload <md파일>`을 실행하고 자리를 비웠다 돌아오면, **본인 네이버 블로그 임시저장 함에 그 글이 들어가 있어야 한다** (제목, 본문, 태그, **이미지 4장**까지 채워진 상태).
- 사용자 개입은 **세션 만료 시 재로그인**과 **캡차 발생 시 해제**만 허용된다.
- **공개 발행은 사용자가 네이버 앱/웹에서 직접 수행**한다.

### 1.4 Non-Goals (이 PRD가 다루지 않는 것)

- **글 작성 자체** — 본문 생성/페르소나/NBW 규약 적용은 `/write` 스킬 책임. autopost는 결과물만 받음.
- **키워드 → 글 end-to-end 오케스트레이션** — `/write`를 subagent로 확장할 때 그 내부에서 처리. autopost는 단일 책임(upload)만 가짐.
- **공개 발행 (Publish) 자동화** — 임시저장까지만. "발행" 버튼은 절대 누르지 않는다.
- 예약 발행 — 임시저장에는 예약 개념이 없으므로 다루지 않음
- 카테고리 자동 선택 — 임시저장 시점에는 사용자가 발행 단계에서 선택
- 댓글/이웃 자동 관리
- 광고 수익 최적화 (애드포스트, 제휴 링크 자동 삽입)
- 멀티 계정 동시 운영 (단일 사용자 기준)
- 네이버 외 플랫폼(티스토리, 브런치)
- 영상/숏폼 자동 업로드

---

## 2. 사용자 시나리오 (User Scenarios)

### 시나리오 A — 단발 업로드 (Happy Path)

```
사전: 사용자가 /write 로 docs/30.output/31.posts/AI바이브코딩_20260527.md 생성

사용자: /autopost upload docs/30.output/31.posts/AI바이브코딩_20260527.md

[parse]  마크다운에서 title/본문/태그 추출 .............. 즉시
[save]   Selenium 쿠키 로그인 → 글쓰기 페이지 진입
         → 제목/본문 입력 → 발행 다이얼로그에서 태그 입력
         → 다이얼로그 닫기 → 임시저장 버튼 클릭 ........ 1~2분
[verify] 임시저장 카운트 N → N+1 확인
[record] .drafts.json 추가 + frontmatter 갱신 (status: drafted)

✅ 임시저장 완료 (소요 74초)
   👉 네이버 블로그 앱 > 글쓰기 > 임시저장 글 목록에서 검토 후 발행하세요.
```

### 시나리오 B — 스케줄 업로드 (매일 아침 큐 적재) — future work

> 외부 스케줄러(Windows 작업 스케줄러 / `/loop`)가 다음 두 단계를 순차 실행:
>
> 1. `/write` subagent (또는 사용자 워크플로우)가 docs/30.output/31.posts/에 마크다운 생성
> 2. `autopost upload <오늘 생성된 파일>`
>
> 사용자는 출근길에 임시저장 글 목록에서 검토 → 발행. autopost 자체는 단일 명령(upload)만 노출하므로 스케줄링 책임은 외부 layer.

### 시나리오 C — 검토 후 업로드

```
사용자가 /write 결과를 직접 검토·수정한 뒤:

사용자: /autopost upload docs/30.output/31.posts/다이어트_20260527.md
        → 수정된 마크다운을 네이버 임시저장에 올림
```

### 시나리오 D — 실패 복구

```
[save] 임시저장 중 캡차 감지
[WARN] 네이버 캡차가 발생했습니다.
    스크린샷: docs/20.working/22.state/.autopost_log/2026-05-27_capcha.png

    브라우저 창을 직접 확인하고 캡차를 풀어주세요.
    완료 후 엔터를 누르면 임시저장을 재개합니다.
    (실패 시 마크다운은 31.posts/에 안전하게 보존됩니다)
```

---

## 3. 기능 요구사항 (Functional Requirements)

### 3.1 autopost 책임 (본 PRD 범위)

| ID | 요구사항 | 우선순위 | 상태 |
|----|----------|----------|------|
| FR1 | `upload <파일>` — 마크다운을 받아 네이버 임시저장에 업로드 | P0 | ✅ M3 완료 |
| FR2 | 마크다운 파싱 (frontmatter title, `## 본문`, `## Tags`) | P0 | ✅ M3 완료 |
| FR3 | 네이버 블로그 로그인 세션 영속화 (쿠키) | P0 | ✅ M0 완료 |
| FR4 | 마크다운 단락 → SE3 본문 입력 | P0 | ✅ M0~M2 완료 |
| FR5 | 발행 다이얼로그 → 태그 input 자동 입력 → 다이얼로그 닫기 | P0 | ✅ M2 완료 |
| FR6 | 임시저장 버튼 자동 클릭 + 카운트 증가 검증 | P0 | ✅ M1 완료 |
| FR7 | **공개 발행 버튼 절대 클릭 금지** (가드레일) | P0 | ✅ M1 완료 |
| FR8 | 임시저장 결과(`naver_draft_id`, `saved_at`) 기록 + frontmatter 갱신 | P0 | ✅ M3 완료 (draft_id 추출은 None — M6 개선) |
| FR9 | 실패 시 재시도 + 로컬 마크다운 보존 (`_safe_write_text`) | P0 | ✅ M3 완료 |
| FR10 | dry-run 모드 (브라우저 띄우되 임시저장 직전 중단 + DOM 덤프) | P1 | ✅ M1 완료 |
| FR11 | 마크다운의 `## Image Prompt (N개)` 섹션 → Gemini로 이미지 생성 (`generate-images` 서브커맨드) | P1 | ✅ M5 완료 |
| FR12 | `upload` 시 `docs/10.input/gemini/{md_stem}__*.png` 자동 매칭 → 단락 위치에 분산 삽입 (SE3 file input send_keys + pyautogui 폴백) | P1 | ✅ M5 완료 |
| FR13 | `--skip-images` 플래그 — 이미지 무시하고 텍스트/태그만 업로드 | P2 | ✅ M5 완료 |
| FR14 | 다중 블로그 지원 (`config/blogs.json`의 여러 블로그 중 선택) | P3 | ⏳ M6 |

### 3.2 외부 책임 (autopost가 다루지 않음)

| ID | 요구사항 | 책임 |
|----|----------|------|
| EXT1 | 키워드/주제로부터 글감 결정 | `/trend`, `/keyword`, `/bridge` |
| EXT2 | 활성 페르소나 적용 본문 생성 (NBW Clean Text Mode 준수) | `/write`, `/persona` |
| EXT3 | NBW 규약 검증 (볼드/헤딩/리스트 금지, 도입부 패턴, 자기지칭 금지) | `/write` 내부 `clean_text.py` |
| EXT4 | end-to-end 오케스트레이션 (키워드 → 글 → 업로드) | `/write` subagent로 확장될 때 그 안에서 `autopost upload` 호출 |
| ~~EXT5~~ | ~~이미지 *생성* (DALL·E 등)~~ | **M5에서 autopost 내부로 흡수** — `generate-images` 서브커맨드가 Gemini 어댑터로 직접 생성 (`image_gen.py`) |
| EXT6 | 스케줄링 (매일 아침 자동 임시저장 등) | Windows 작업 스케줄러, `/loop`, 또는 외부 cron |

---

## 4. 비기능 요구사항 (Non-Functional Requirements)

| ID | 요구사항 | 측정 기준 |
|----|----------|----------|
| NFR1 | 임시저장 단계 단독 실행 시간 | ≤ 10분 |
| NFR2 | 캡차/2FA 시 사용자 개입 요청 | 스크린샷 + 명확한 안내 메시지 |
| NFR3 | 자격증명 보안 | 환경변수 또는 OS keyring, git 커밋 금지 |
| NFR4 | 실행 로그/스크린샷 보존 | `docs/20.working/22.state/.autopost_log/{YYYYMMDD_HHMM}/` |
| NFR5 | 멱등성 | 같은 마크다운 재실행 시 기존 임시저장 ID 갱신 (frontmatter `naver_draft_id` 검사) |
| NFR6 | 관측성 | 각 단계 시작/끝/소요시간 stdout 로깅 |
| NFR7 | **공개 발행 가드레일** | "발행", "공개", "publish" 라벨 버튼은 selector 화이트리스트에 등록되지 않음. 코드 리뷰에서 해당 selector 발견 시 차단. |

---

## 5. 기술 설계 (Technical Design)

### 5.1 전체 아키텍처

```
┌──────────────────────── 외부 (autopost 책임 밖) ────────────────────────┐
│                                                                          │
│   ┌────────┐    ┌─────────┐    ┌─────────────────────────────────┐      │
│   │ /trend │ ─▶ │ /write  │ ─▶ │ docs/30.output/31.posts/*.md    │      │
│   │/keyword│    │/persona │    │ (제목 frontmatter + 본문 + 태그) │      │
│   └────────┘    └─────────┘    └─────────────────────────────────┘      │
│                                              │                           │
└──────────────────────────────────────────────┼───────────────────────────┘
                                               │ 입력
                                               ▼
                       ┌──────────────────────────────────────┐
                       │           /autopost upload           │
                       │  ┌────────────┐    ┌──────────────┐  │
                       │  │ autopost.py│ ─▶ │  drafter.py  │  │
                       │  │ (파서)     │    │  (Selenium)  │  │
                       │  └────────────┘    └──────────────┘  │
                       │            │              │           │
                       │  ┌─────────▼───┐  ┌──────▼───────┐   │
                       │  │  record.py  │  │  session.py  │   │
                       │  │ .drafts.json│  │  쿠키/2FA    │   │
                       │  └─────────────┘  └──────────────┘   │
                       └──────────────┬───────────────────────┘
                                      │ 임시저장 (Draft)
                                      ▼
                              ┌───────────────┐
                              │  네이버 블로그 │
                              │  임시저장 함   │
                              └───────┬───────┘
                                      │ 사용자가 직접 발행 클릭
                                      ▼
                              ┌───────────────┐
                              │  공개 발행됨  │
                              └───────────────┘

⚠️ drafter는 "임시저장" 버튼만 클릭. "발행" 버튼 selector는 등록 금지 (가드레일).
```

### 5.1.1 입력 마크다운 규약 — NBW (Naver Blog Writer)

본문 생성 규약은 **`/write` 스킬이 적용**하며, autopost는 그 결과를 받기만 한다.
원천 가이드: `docs/90.reference/93.context/Naver Blog Writer.md` (이하 [NBW]).

autopost가 입력 마크다운에 기대하는 형식:

| 항목 | 위치 |
|------|------|
| 제목 | frontmatter `title:` |
| 본문 | `## 본문` 섹션 (다음 `---` 또는 `## ` 헤더까지) |
| 태그 | `## Tags` 섹션의 코드블록 내 `#키워드` |

NBW 규약(볼드/헤딩/리스트 금지, "안녕하세요, {닉네임}입니다." 시작, 1:1 화법 등)은 `/write`가 책임지고 적용한다. autopost가 추가 검증을 할 수 있으나(`nbw_validator.py` — 향후 옵션) **필수는 아니다** (write에서 이미 검증됨).

> 참고용 — write 스킬이 적용하는 NBW 핵심 규약:

#### 본문 형식 — Clean Text Mode 강제

| 항목 | 규칙 | AutoPosting 검증 |
|------|------|-------------------|
| 볼드 `**...**` | 금지 | 본문에 `\*\*` 매칭 시 임시저장 차단 |
| 마크다운 헤딩 `##`, `###` | 금지 | 라인 시작 `#` 매칭 시 차단 |
| 리스트 `-`, `1.` | 금지 | 라인 시작 `-`, `1.` 매칭 시 차단 |
| 줄글(이어지는 문장) | 필수 | 본문 라인 평균 길이 검사 |
| AI 멘트 ("작성하겠습니다" 등) | 금지 | 키워드 블랙리스트 매칭 |
| 자기지칭 ("AI", "언어 모델") | 금지 | 키워드 블랙리스트 매칭 |
| 도입부 | "안녕하세요, [블로그 닉네임]입니다." 로 시작 | 첫 줄 패턴 매칭 |

> 함의: **md→SmartEditor 변환기(`md_to_naver.py`)의 복잡도가 크게 줄어든다.** 헤딩·리스트·볼드 매핑이 모두 불필요하고, 단락 구분(빈 줄)과 이미지 삽입 정도만 처리하면 된다.

#### 구조 — Hook → Story(Old vs New) → Offer → Open Loop

draft 단계에서 `/write`가 반환하는 본문은 반드시 다음 4부 구조를 가진다 (마크다운 헤딩 없이 단락 흐름으로):

1. **Hook**: 꿈의 고객의 Pain에 1:1로 공감
2. **Story**: 기존 방식(Old Opportunity)의 한계 → 새로운 기회(New Opportunity) 발견의 순간
3. **Offer**: 해결책 제시 (CTA 포함)
4. **Open Loop**: 시리즈인 경우 다음 화 예고 + 이웃추가 유도

#### 검색 기반 팩트 체크 (Search-First)

[NBW] 제1원칙. draft 단계 진입 전 **plan 단계에서 반드시 검색을 1회 이상 실행**한다.

- 숫자/통계/가격/날짜는 `/keyword`·`/trend` 또는 WebSearch로 검증
- 한국식 표기 (예: `10,000`) 강제
- 검증 출처는 frontmatter `sources: []`에 URL 기록

#### 제목·해시태그

| 항목 | 규칙 | 산출 위치 |
|------|------|----------|
| 후킹 제목 3선 | 충격/현실/반전/논란/진실 중 1개 키워드 필수 | frontmatter `title_candidates: [..., ..., ...]` |
| 최종 제목 | 후보 중 1개 선택 (사용자 또는 자동) | frontmatter `title` |
| 해시태그 | 정확히 10개 (제목 키워드 + 소단락 세부 + 본문 형태소) | frontmatter `tags: [...]` |

#### 페르소나 빙의 (Identity Masking)

- 본문 자기지칭은 오직 `config/personas/{active}.json`의 `nickname` (예: "테크요정")
- `config/personas/{active}.json`에 `dream_customer`, `character_type`(지도자/모험가/기자), `character_flaw` 필드가 없으면 draft 진입 거부 → `/persona` 보강 유도

#### draft 검증 게이트 (선택 사항, 향후)

write 스킬이 이미 검증하므로 autopost는 추가 검증을 **하지 않아도 된다**. 다만 회귀 방지용 보조 게이트로 향후 `nbw_validator.py`를 추가할 수 있다 (현재 미구현). 정의 예:

```python
def validate_nbw_compliance(body: str, persona_nickname: str) -> list[str]:
    errors = []
    if re.search(r'\*\*[^*]+\*\*', body): errors.append("볼드 금지")
    if re.search(r'^#{1,6}\s', body, re.M): errors.append("헤딩 금지")
    if re.search(r'^[-*]\s|^\d+\.\s', body, re.M): errors.append("리스트 금지")
    if persona_nickname and not body.lstrip().startswith(f"안녕하세요, {persona_nickname}"):
        errors.append("도입부 규칙 위반")
    for banned in ["AI", "언어 모델", "분석가로서", "작성하겠습니다"]:
        if banned in body: errors.append(f"금지어: {banned}")
    return errors
```

위반 시 정책: **경고만 출력하고 업로드는 진행**(write 산출물을 신뢰). 강제 차단으로 바꾸려면 write 단계에서 강제하는 것이 옳다.

---

### 5.2 파이프라인 단계 (autopost upload 흐름)

| 단계 | 입력 | 처리 | 출력 |
|------|------|------|------|
| **parse** | 마크다운 파일 경로 | frontmatter에서 title, `## 본문` 섹션, `## Tags` 코드블록 추출 | `(title, body, tags)` 튜플 |
| **login** | NAVER_ID/NAVER_PW 환경변수 | 쿠키 로그인 → 만료 시 ID/PW + 2FA 폴링 | 인증된 driver |
| **save** | 인증된 driver + (title, body, tags) | 글쓰기 페이지 진입 → 제목/본문 ActionChains 입력 → 발행 다이얼로그 → 태그 input → 다이얼로그 닫기 → **임시저장 버튼** | 임시저장 완료 + 카운트 증가 검증 |
| **record** | 임시저장 결과 | `.drafts.json` append + frontmatter 갱신 (`naver_draft_id`, `saved_at`, `status: drafted`) — `_safe_write_text`로 atomic | 기록 완료. 사용자에게 "임시저장 글 목록에서 발행하세요" 안내 |

**M5 (완료) — 이미지 자동화**:
- 별도 서브커맨드 `generate-images <md>`로 분리. 마크다운의 `## Image Prompt (N개)` 섹션을 파싱해 Chrome attach된 Gemini 탭에 순차 전송 → blob URL → canvas → PNG 추출.
- 저장 경로: `docs/10.input/gemini/{md_stem}__{NN}_{label}.png` (label = 도입/본문N/마무리)
- `upload` 단계는 동일 md_stem 글롭으로 자동 매칭 → 단락 수 기준 등간격 위치 계산 → SE3 file input `send_keys` (실패 시 pyautogui 클립보드 폴백).
- 본문 내 `![alt](path)` 매칭은 **사용 안 함**. NBW 규약에 마크다운 이미지 문법이 없으므로 외부 매칭 방식 채택.

> plan/draft 단계는 외부(`/write` 스킬) 책임이라 본 PRD에서 제거됨.

### 5.3 신규 컴포넌트

| 파일 | 책임 | 의존성 |
|------|------|--------|
| `.claude/skills/autopost/SKILL.md` | 슬래시 명령 정의, 오케스트레이션 프롬프트 | (Skill) |
| `.claude/skills/autopost/scripts/drafter.py` | Playwright **임시저장** 엔진 (메인 진입점). **발행 버튼 selector는 의도적으로 누락** | playwright, session.py, md_to_naver.py |
| `.claude/skills/autopost/scripts/md_to_naver.py` | **줄글 마크다운**(NBW 규칙) → SmartEditor 단락/이미지 컴포넌트 (헤딩·리스트·볼드 미사용) | markdown, beautifulsoup4 |
| `.claude/skills/autopost/scripts/nbw_validator.py` | (선택, 미구현) NBW 회귀 보조 검증. write가 1차 책임 | re |
| `.claude/skills/autopost/scripts/session.py` | 네이버 로그인 쿠키 저장/복원 | playwright |
| `.claude/skills/autopost/scripts/image_gen.py` | Image Prompt → PNG 파일. Chrome `--remote-debugging-port=9222` attach → Gemini 탭 사용. 새 이미지 등장 폴링 → blob → canvas → PNG byte 추출 → `docs/10.input/gemini/`에 저장 | selenium (Chrome attach), pillow 불필요 (브라우저 canvas로 처리) |
| `.claude/skills/autopost/scripts/record.py` | `.drafts.json` 읽기/쓰기 + frontmatter 갱신 | python-frontmatter |
| `.claude/skills/autopost/references/smarteditor_selectors.md` | DOM selector 카탈로그 (변경 시 1곳만 수정) | — |

### 5.4 데이터 모델

#### 5.4.1 `config/autopost_config.json` (신규, 영속)

```json
{
  "default_blog_id": "zeroenter",
  "default_category_id": "1",
  "default_tags_strategy": "from_frontmatter",
  "image_provider": "openai_dalle",
  "image_count_per_post": 4,
  "headless": false,
  "safety": {
    "publish_button_enabled": false,
    "_note": "이 값은 true로 변경할 수 없음. 코드가 false를 hard-assert함."
  }
}
```

> `default_visibility`, `publish_interval_min_minutes`, `--schedule` 같이 **공개 발행과 관련된 필드는 의도적으로 제외**한다.

#### 5.4.2 `docs/20.working/22.state/.drafts.json` (신규, 런타임)

```json
[
  {
    "post_file": "docs/30.output/31.posts/AI바이브코딩_20260527.md",
    "naver_draft_id": "abc123def456",
    "draft_url": "https://blog.naver.com/PostWriteForm.naver?blogId=zeroenter&draftId=abc123def456",
    "saved_at": "2026-05-27T09:14:22+09:00",
    "blog_id": "zeroenter",
    "persona": "AI블로그작가",
    "category_id": "1",
    "tags": ["AI", "바이브코딩", "Claude"],
    "status": "drafted",
    "duration_sec": 312
  }
]
```

> `status` 값은 `drafted` 만 사용. `published`는 본 시스템에서 발생하지 않는다 (사용자가 네이버에서 직접 발행).

#### 5.4.3 `31.posts` 마크다운 frontmatter 확장

기존:
```yaml
---
title: "AI 바이브 코딩 입문"
created_at: "2026-05-27 09:00"
status: "complete"
keyword: "AI 바이브 코딩"
category: "IT·컴퓨터"
---
```

확장 후 (autopost가 채움):
```yaml
---
title: "AI 바이브 코딩 입문"
created_at: "2026-05-27 09:00"
status: "drafted"                                # complete → drafted
keyword: "AI 바이브 코딩"
category: "IT·컴퓨터"
naver_category_id: "1"                           # 신규
naver_draft_id: "abc123def456"                   # 신규 (멱등성 키)
saved_at: "2026-05-27T09:14:22+09:00"            # 신규
---
```

> 사용자가 네이버에서 직접 발행한 뒤 URL을 알아내고 싶다면, 별도 스킬(예: `/sync`)로 임시저장 → 발행 상태를 폴링하는 것은 향후 과제. 본 PRD 범위 밖.

### 5.5 네이버 임시저장 자동화 — SmartEditor 매핑

#### 로그인

- 쿠키 저장 위치: `~/.config/naverblog/session.json` (Windows: `%USERPROFILE%\.config\naverblog\session.json`)
- 첫 실행 또는 만료 시: 비헤드리스 모드로 브라우저를 띄우고 사용자에게 수동 로그인 요청
- 로그인 완료 감지: `https://www.naver.com` 진입 후 우상단 닉네임 element 확인

#### 작성 페이지 진입

- URL: `https://blog.naver.com/{blog_id}?Redirect=Write`
- iframe 진입 순서: `mainFrame` → SmartEditor iframe (SE2: `se2_iframe` / SE3: `iframe[id^="se_"]`)

#### 본문 입력 (NBW 규칙 적용 — 단순화됨)

[NBW]가 본문에서 마크다운 서식을 전면 금지하므로, 변환기는 다음 두 가지만 처리한다:

- **단락**: 빈 줄로 구분된 텍스트 블록 → SmartEditor 단락 컴포넌트 (줄글 그대로)
- **이미지**: `![alt](path)` → 업로드 후 SmartEditor 이미지 컴포넌트

frontmatter의 `title`은 SmartEditor 상단 제목 input에 입력. 본문 안에는 어떤 헤딩도 만들지 않는다.

> 헤딩·리스트·볼드·인용·코드블록 매핑은 **의도적으로 미구현**. 이런 요소가 본문에 있으면 `nbw_validator`가 차단한다.

#### 이미지 업로드 (M5 완료)

**생성** (`generate-images` 서브커맨드, 별도 실행):

1. 사용자가 Chrome을 디버그 모드(`--remote-debugging-port=9222`)로 실행, `gemini.google.com` 탭 로그인 상태
2. `image_gen.py`가 해당 Chrome에 attach → 마크다운 `## Image Prompt (N개)` 섹션의 프롬프트를 `Generate an image: ...` 형식으로 순차 전송
3. 새 이미지 등장 폴링(최대 150초/장) → blob URL → canvas → PNG byte
4. `docs/10.input/gemini/{md_stem}__{NN}_{label}.png` 저장 (label = `도입`/`본문1`/`본문2`/`마무리`)

**업로드** (`upload` 단계 내장):

1. `glob('docs/10.input/gemini/{md_stem}__*.png')` 로 매칭. 매칭 0개면 텍스트만 업로드
2. 본문 단락 수에 따라 등간격 삽입 위치 계산 (예: 24단락 + 4장 → [0, 7, 15, 22])
3. 각 위치에서 이미지 도구 버튼 클릭 → SE3 file input에 `send_keys(절대경로)` 시도 → 실패 시 pyautogui로 OS 파일 다이얼로그 자동 입력
4. 업로드 완료 대기 (썸네일 등장 감지)
5. 대표이미지는 SmartEditor가 자동으로 첫 이미지 사용 (별도 체크 불필요)

#### 카테고리·태그 입력 (발행 다이얼로그 진입하지 않음)

| 옵션 | DOM 위치 | autopost_config 키 |
|------|----------|--------------------|
| 카테고리 | 에디터 상단 카테고리 select | `default_category_id` |
| 태그 | 본문 하단 태그 input | frontmatter `tags` |

> 공개범위/예약 발행 input은 **건드리지 않는다**. 임시저장은 그 단계 이전에 종료.

#### 임시저장 실행

**원본 코드의 종료 지점** (`marketing_wizard_Extand_AutoLoad.py` 줄 2800~2806):
```python
# 원본: 본문 입력 후 사용자에게 수동 발행 요청하고 종료
self.root.after(0, lambda: messagebox.showinfo(
    "발행 대기", "브라우저에서 내용을 확인하고 '발행' 버튼을 클릭해주세요"))
time.sleep(60)
driver.quit()
```

**본 PRD가 그 자리를 대체** (`drafter.py` 신규):
```python
# 1. 본문/제목/카테고리/태그 입력 완료 후
click_save_draft_button(driver)        # "저장" 텍스트만 매칭, "발행" 거부
draft_id = extract_draft_id(driver)    # 아래 두 방안 중 택1
record.append(md_path, draft_id, status="drafted")
driver.quit()
```

**임시저장 버튼 클릭 규약**:
- 셀렉터: `button:has-text("저장")` 류 + 텍스트에 "발행" 미포함 검증 (5.5의 안전 가드 참조)
- 클릭 후 "임시저장되었습니다" 토스트 또는 네트워크 응답 감지로 완료 확인

**임시저장 ID 추출 — 두 방안 모두 등재, 구현 시점에 실측 후 선택**:

| 방안 | 방법 | 장점 | 단점 |
|------|------|------|------|
| 방안 1 | `PostSaveTempPost.naver` 응답을 네트워크 가로채기 (`selenium-wire` 또는 BiDi) | 빠름 (1회 추가 요청 없음) | 추가 의존성, 응답 포맷 변경 시 깨짐 |
| 방안 2 | 임시저장 직후 임시저장 목록 페이지 방문 → 최신 draftId 추출 | 안정적, 의존성 적음 | 추가 페이지 로드 (~3초) |

> 권장: M0~M3은 **방안 2**로 빠르게 동작 확보 → M6 안정화에서 **방안 1**로 교체 검토.

#### 안전 가드 (코드 차원)

```python
# drafter.py 상단
FORBIDDEN_SELECTORS = ["button:has-text('발행')", "button:has-text('Publish')", "button[data-action='publish']"]

def click_save_button(page):
    btn = page.locator("button:has-text('저장')").first
    # 발행 버튼을 잘못 잡지 않았는지 이중 확인
    assert "발행" not in btn.inner_text(), f"발행 버튼은 누르면 안 됨!"
    btn.click()
```

### 5.6 슬래시 명령 인터페이스

```
/autopost <키워드>              # 시나리오 A (전체 자동화)
/autopost --draft <키워드>      # 임시저장만
/autopost publish <파일경로>    # 시나리오 C (기존 md 발행)
/autopost dry-run <파일경로>    # NFR — 발행 직전 중단
/autopost schedule <cron> ...   # 시나리오 B (스케줄 등록)
/autopost status                # .published.json 최근 N건 조회
/autopost retry <파일경로>      # 실패 건 재발행
```

### 5.7 에러 처리

| 에러 | 감지 방식 | 대응 |
|------|----------|------|
| 세션 만료 | 작성 페이지 진입 시 로그인 폼 표시 | 비헤드리스 재로그인 흐름 |
| 캡차 | 캡차 iframe selector 존재 | 스크린샷 + 사용자 대기 |
| DOM 변경 | selector timeout | 스크린샷 + 에러 로그 + 로컬 마크다운 보존 |
| 이미지 업로드 실패 | 썸네일 미등장 (30s) | 이미지 없이 진행 + 경고 |
| 임시저장 버튼 응답 없음 | 토스트 미등장 (30s) | 재시도 1회 → 실패 시 종료 (로컬 md 보존) |
| 네트워크 오류 | playwright 예외 | 3회 재시도 (지수 백오프) |
| 발행 버튼 selector 발견 | 코드 정적 검사 / 런타임 assert | 즉시 중단 (가드레일 위반) |

### 5.8 보안 / 개인정보

- 네이버 ID/PW는 **저장하지 않음**. 쿠키만 OS 권한으로 보호된 위치에 저장
- 쿠키 파일은 `.gitignore`에 명시
- 스크린샷에 개인정보(타 사용자 닉네임/이메일)가 포함될 수 있어 `.autopost_log/`도 `.gitignore`
- `config/autopost_config.json`은 자격증명 없이 동작 옵션만 포함

---

## 6. 기존 자산과의 통합

### 6.0 기존 자산 — `marketing_wizard_Extand_AutoLoad.py` 추출 대상 (★ 핵심)

`docs/90.reference/99.external-scripts/marketing_wizard_Extand_AutoLoad.py` (7472줄, ttkbootstrap GUI)에 **이미 검증된 Selenium 기반 자동 로그인 + SmartEditor 본문 작성 코드**가 있다. AutoPosting의 발행 엔진은 이 코드를 **추출 + GUI 의존 제거 + 임시저장 버튼 클릭 추가** 방식으로 만든다 (zero-from-scratch 회피).

#### 추출 대상 함수 맵

| 원본 함수 (줄번호) | 책임 | 새 위치 | 변경 정도 |
|-------------------|------|---------|-----------|
| `naver_auto_blog_post` (2502~2806) | 메인 발행 흐름 (로그인→작성→사용자 수동발행 대기) | `drafter.py` | **중간**: GUI 알림→로깅, 수동 대기 → **임시저장 버튼 자동 클릭** 추가 |
| `save_naver_cookies` (2455) | 쿠키 JSON 저장 | `session.py` | 그대로 |
| `load_naver_cookies` (2465) | 쿠키 JSON 로드 | `session.py` | 그대로 (저장 경로만 `~/.config/naverblog/`) |
| `check_naver_login_status` (2487) | 로그인 상태 확인 | `session.py` | 그대로 |
| `upload_blog_image` (2818) | 이미지 업로드 (pyautogui 클립보드 방식) | `drafter.py` (private) | 그대로 |
| `extract_blog_content` (2404) | 마크다운에서 제목/본문 파싱 | `md_to_naver.py` | **재작성** (현 코드는 마케팅 위저드 전용 마크업 가정) |
| `start_blog_posting` (2334) + `posting_task` (2396) | GUI 트리거 + 스레드 래퍼 | 제거 | 슬래시 명령이 대체 |

#### 기술 스택 변경 (Playwright → Selenium)

기존 PRD는 Playwright 가정이었으나, **이미 동작하는 Selenium 코드를 재사용하는 것이 압도적으로 효율적**이다.

- **변경**: 발행 엔진을 Selenium + webdriver-manager + pyperclip + pyautogui 기반으로 결정
- **영향**: `requirements.txt`에 `selenium`, `webdriver-manager`, `pyperclip`, `pyautogui` 추가 (playwright는 스크래핑용으로 유지)
- **트레이드오프**: Selenium은 봇 탐지에 약하나 원본 코드가 우회 옵션(`--disable-blink-features=AutomationControlled`, custom UA) 이미 적용

#### 원본 코드의 한계 (PRD에서 해결)

| 항목 | 원본 코드 | 본 PRD에서 |
|------|-----------|------------|
| 임시저장/발행 버튼 클릭 | **없음** (사용자 수동 + 1분 대기) | **임시저장 버튼만** 자동 클릭 추가. 발행 버튼은 절대 클릭 안 함 (5.5 안전 가드) |
| 카테고리/태그 입력 | 없음 | 추가 (5.5) |
| 2FA/캡차 | messagebox 팝업 | stdout + 스크린샷 + 사용자 대기 (5.7) |
| 쿠키 저장 위치 | 작업 폴더 `naver_cookies.json` (평문, git 위험) | `~/.config/naverblog/session.json` + `.gitignore` (5.8) |
| 본문 입력 속도 | ActionChains 문자별 0.02초 (전체 글에 수 분) | 동일 유지 (봇 탐지 회피) |
| 마크다운 파서 | 마케팅 위저드 헤더(`## 2. Blog Post Body`) 하드코딩 | NBW 줄글 마크다운 파서로 교체 |

#### 검증된 Selector 카탈로그 (원본에서 그대로 가져옴 → `references/smarteditor_selectors.md`로 이관)

```yaml
login:
  id_input: "#id"
  pw_input: "#pw"
  login_button: "#log\\.login"
  input_method: clipboard_paste  # send_keys 우회

write_page:
  url_primary: "https://blog.naver.com/{blog_id}/postwrite"
  url_fallback: "https://blog.naver.com/PostWriteForm.naver?blogId={blog_id}"
  iframe: "#mainFrame"

editor:
  title_selectors:   # 7가지 시도 (SE 버전별)
    - ".se-title-input"
    - ".se-documentTitle-editView"
    - ".se-title-text"
    - "span.se-title-text"
    - "div.se-title-input span"
    - "input[placeholder*='제목']"
    - "[data-placeholder='제목']"
  body_selectors:
    - ".se-text-paragraph"
    - ".se-component-content"
  image_buttons:    # 5가지 시도
    - "button[data-log='dot.photo']"
    - "button[class*='se-main-toolbar-button-image']"
    - "button[data-click-area='top.image']"
    - "button[data-name='image']"
    - ".se-toolbar-button-image"

popups_to_close:    # 작성 중인 글 있음 등
  - "button.se-popup-button-cancel"
  - "button[class*='cancel']"
  - "button.se-popup-close-btn"
  - ".popup_close"
  - ".btn_close"

# 본 PRD에서 신규 식별 필요 (원본 코드에 없음):
to_be_identified:
  - category_select
  - tags_input
  - save_draft_button  # "저장" 텍스트, "발행"과 분리 확인 필수
  # publish_button: 의도적으로 식별/등록 금지
```

### 6.1 재사용하는 스킬 (수정 없음)

- `/trend`, `/keyword`, `/bridge` — 입력 단계 + Search-First 팩트 수집
- `/persona` — 활성 페르소나 조회 (NBW 필수 필드: `nickname`, `dream_customer`, `character_type`, `character_flaw`)
- `/write` — 본문 생성. **이미 `docs/90.reference/93.context/Naver Blog Writer.md`를 시스템 프롬프트로 포함**한다고 가정. autopost는 결과를 `nbw_validator`로 검증만 한다 (이중 안전망).

### 6.2 참조 문서

- `docs/90.reference/93.context/Naver Blog Writer.md` — 본 PRD의 모든 글쓰기 규칙의 원천. 수정 시 본 PRD와 `nbw_validator.py`도 함께 갱신.

### 6.3 영향 받는 기존 파일

| 파일 | 변경 내용 |
|------|----------|
| `CLAUDE.md` | "자주 쓰는 명령" 표에 `/autopost` 행 추가 |
| `docs/90.reference/98.setup/requirements.txt` | 추가: `selenium>=4.15`, `webdriver-manager>=4.0`, `pyperclip>=1.8`, `pyautogui>=0.9.54`, `markdown`, `python-frontmatter`. (옵션) 방안 1 채택 시 `selenium-wire>=5.1`. `playwright`는 search 스크래핑용으로 유지. |
| `.gitignore` | `.autopost_log/`, `~/.config/naverblog/` 패턴 |
| `config/blogs.json` | 변경 없음 (블로그 메타만 참조) |

### 6.4 CLAUDE.md 파일 저장 위치 가이드 준수

| 신규 파일 | 위치 | 분류 |
|----------|------|------|
| `autopost_config.json` | `config/` | 설정 파일 (영속) |
| `.drafts.json` | `docs/20.working/22.state/` | 런타임 상태 |
| `.autopost_log/` | `docs/20.working/22.state/` | 런타임 상태 |
| 임시저장된 마크다운 | `docs/30.output/31.posts/` (기존) | 변경 없음 |

---

## 7. 마일스톤 (Milestones)

| ID | 기간 | 산출물 | 완료 기준 (DoD) |
|----|------|--------|-----------------|
| M0 | 2일 | **원본 추출** | `marketing_wizard_Extand_AutoLoad.py`에서 `naver_auto_blog_post`, `*_cookies`, `upload_blog_image` 함수를 GUI 의존 제거하고 `drafter.py`/`session.py`로 이식 | ✅ 완료 |
| M1 | 3일 | **임시저장 버튼 자동 클릭** | 원본의 "사용자 수동 발행 대기"를 제거. 임시저장 버튼 selector 실측·식별 + JS 클릭 폴백 + 카운트 증가 검증. 발행 버튼 selector 등록 금지 (가드레일) | ✅ 완료 |
| M2 | 3일 | **발행 다이얼로그 → 태그 자동 입력** | 외부 발행 버튼 클릭으로 다이얼로그 오픈 → `input.tag_input` 입력 → "발행 설정 닫기"로 다이얼로그 닫기 → 임시저장. NBW 줄글 파서로 마크다운 본문 입력 | ✅ 완료 |
| M3 | 2일 | **`upload <파일>` 슬래시 + 안전장치** | autopost.py 오케스트레이터, 마크다운 파서, .drafts.json 기록, frontmatter 갱신. `_safe_write_text` (atomic + backup + 빈내용 거부) | ✅ 완료 |
| M5 | 3일 | **이미지 자동화 (Gemini)** | `image_gen.py` — Chrome attach + Gemini blob→canvas로 4장 PNG 생성. `generate-images` 서브커맨드 신설. `upload`가 `docs/10.input/gemini/{md_stem}__*.png` 자동 매칭 → 단락 위치에 분산 삽입 (SE3 send_keys + pyautogui 폴백). `--skip-images` 플래그. | ✅ 완료 |
| M6 | 1주 | 안정화 | draft_id 추출 개선, 다중 블로그 지원, 이미지 위치/캡션 매핑, 10회 연속 임시저장 성공률 ≥ 90%, 발행 버튼 0회 클릭 검증 | ⏳ |

**[future work]** end-to-end 오케스트레이션 (키워드 → 글 → 임시저장)은 `/write` 스킬이 subagent로 확장될 때 그 내부에서 `autopost upload`를 호출하는 형태로 구현. autopost는 단일 책임(upload) 유지.

총 예상 (남은 작업): **약 1주** (M6).

---

## 8. 리스크 & 완화 (Risks & Mitigations)

| ID | 리스크 | 영향 | 완화 |
|----|--------|------|------|
| R1 | 네이버 ToS — 자동화 명시적 금지 조항 | 계정 정지 가능성 | 개인용 한정 명시, 임시저장만 수행(공개 발행 X) → 자동 공개 트래픽 0, 명시적 동의 흐름 |
| R2 | SmartEditor DOM 변경 | 임시저장 실패 | selector를 `references/smarteditor_selectors.md` 한 곳에 모음, 시각 회귀 스크린샷 |
| R3 | 캡차 / IP 차단 | 임시저장 중단 | 임시저장 간격 권장 30분, 인간형 딜레이, 동일 IP 유지 |
| R4 | 이미지 저작권 | 법적 리스크 | 생성형 이미지만 사용, frontmatter에 생성 모델/프롬프트 명기. 어차피 사용자가 발행 전 검토. |
| R5 | **잘못된 글 자동 공개 발행** | 평판 손상 | 본 시스템은 임시저장만 함. 공개 발행은 사용자의 명시적 클릭 필요 → 구조적으로 방지됨 |
| R6 | 세션 쿠키 유출 | 계정 탈취 | OS 권한 폴더 저장, .gitignore, 평문 저장 시 사용자 경고 |
| R7 | LLM 환각 | 잘못된 정보 노출 | `/write` 단계의 사실관계 검증 + 사용자가 발행 전 반드시 검토 (구조적 안전망) |
| R8 | 임시저장 함 가득 참 | 자동화 정지 | 네이버 임시저장 제한(보통 100건) 도달 시 가장 오래된 것부터 정리 권고 |

---

## 9. 성공 지표 (Success Metrics)

| 지표 | 목표 | 측정 방법 |
|------|------|----------|
| 임시저장 성공률 | ≥ 90% | `.drafts.json`의 `status=drafted` 비율 |
| 사용자 개입 횟수 (캡차/세션) | ≤ 1회/주 | `.autopost_log/` 의 캡차/로그인 이벤트 수 |
| 작성→임시저장 사이클 | ≤ 30분 | `duration_sec` 평균 |
| 일일 임시저장 가능 횟수 | ≥ 3건 | 인터벌 30분 기준 산술적 가능성 |
| **공개 발행 자동 클릭 횟수** | **= 0** (절대값) | 코드 정적 검사 + 런타임 assert 카운터 |
| 사용자 만족도 | "수동 복붙보다 낫다" | 정성 피드백 |

---

## 10. 오픈 이슈 (Open Questions)

1. **네이버 공식 OpenAPI** 가 블로그 임시저장을 지원하는가?
   - 지원한다면 Playwright보다 안정적 → drafter 엔진 교체 검토
   - 미지원 또는 제약 심함이 일반론 → 본 PRD는 Playwright 전제
2. ~~**이미지 생성 모델** — Claude API는 이미지 생성 미지원. OpenAI DALL·E / Stability AI / Imagen 등 어댑터 패턴으로 추상화하되 기본은 무엇으로?~~ **→ 해결됨 (M5).** Gemini를 Chrome attach 방식으로 사용 — API 키/과금 불필요, 사용자 Google 계정 세션 재사용. 다른 모델 어댑터는 필요 시 추후 추가.
3. **다중 블로그 시점** — M6 이후로 미루는 것이 합당한가, 아니면 M2부터 blog_id 파라미터화?
4. **모바일 알림** — 스케줄 임시저장 시 "임시저장 N건 추가됨" 알림을 어떤 채널로? (Gmail? Pushover? 일단 stdout만?)
5. **발행 후 URL 회수** — 사용자가 네이버에서 발행한 뒤 그 URL을 시스템에 다시 기록하려면? (별도 `/sync` 스킬로 분리하는 게 본 PRD 가드레일을 깨지 않음)

---

## 11. 부록

### A. 파일 트리 (신규/변경)

```
NaverBlogWriter/
├── CLAUDE.md                              [변경] /autopost 행 추가
├── .gitignore                             [변경] 로그/세션 제외
├── config/
│   └── autopost_config.json               [신규]
├── docs/
│   ├── 20.working/22.state/
│   │   ├── .drafts.json                   [신규, 런타임 자동 생성]
│   │   └── .autopost_log/                 [신규, 런타임]
│   ├── 30.output/31.posts/                [기존, frontmatter 확장]
│   └── 90.reference/
│       ├── 91.archive/
│       │   └── Naver_AutoPosting_PRD.md   [본 문서]
│       └── 98.setup/requirements.txt      [변경] 라이브러리 추가
└── .claude/skills/autopost/               [신규 스킬]
    ├── SKILL.md
    ├── scripts/
    │   ├── drafter.py
    │   ├── nbw_validator.py
    │   ├── md_to_naver.py
    │   ├── session.py
    │   ├── image_gen.py
    │   └── record.py
    └── references/
        └── smarteditor_selectors.md
```

### B. SKILL.md 프론트매터 예시

```yaml
---
name: autopost
description: |
  이미 작성된 마크다운 파일을 네이버 블로그 임시저장에 자동 업로드한다.
  Selenium으로 로그인 → SmartEditor에 제목/본문/태그 입력 → 임시저장 클릭.
  공개 발행 버튼은 절대 누르지 않는다 (사용자가 직접). 글 작성 자체는 /write 스킬 담당.
  '/autopost upload', '임시저장', '네이버 업로드' 요청 시 사용.
model: opus
allowed-tools:
  - Bash        # selenium/pyautogui 스크립트 실행에 필수
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---
```

### C. `upload` 1회 호출 시퀀스 (의사코드, 현재 구현)

```python
def upload(md_path: Path, dry_run: bool = False) -> dict:
    # 1) parse — frontmatter, 본문, 태그 추출
    title, body, tags = parse_post(md_path)

    # 2) login — 쿠키 우선, 만료 시 ID/PW + 2FA 폴링
    driver = build_driver(headless=False)
    if not session.load_or_login(driver, naver_id, naver_pw):
        raise RuntimeError("네이버 로그인 실패")

    # 3) save — Selenium으로 SmartEditor 입력 + 임시저장 클릭
    result = drafter.write_post(
        driver, blog_id, title, body, tags=tags, dry_run=dry_run,
    )
    # drafter 내부:
    #   - 제목/본문 입력 (.se-section-documentTitle, .se-section-text)
    #   - 발행 다이얼로그 오픈 → 태그 input → 다이얼로그 닫기
    #   - 임시저장 버튼 클릭 (FORBIDDEN_CLASS_PATTERNS 가드레일)
    #   - 카운트 증가 검증

    # 4) record — atomic 안전 쓰기
    if result["saved"] and not dry_run:
        record.append(md_path, result["draft_id"], blog_id, tags=tags, ...)
        record.update_frontmatter(md_path, draft_id, status="drafted")
        # _safe_write_text: 백업 → tmp 파일 → atomic replace, 빈 내용 거부

    return result   # {"draft_id", "saved", "blog_id", "title"}
```

end-to-end 오케스트레이션(키워드 입력 → 글 작성 → upload)은 본 PRD 범위 밖이며, `/write` subagent가 향후 책임진다.

### D. 원본 코드 발췌 — `marketing_wizard_Extand_AutoLoad.py` 핵심 구간

본 PRD가 추출 대상으로 삼는 원본 코드의 핵심 발췌. `drafter.py`/`session.py`에 그대로 이식할 영역과 본 PRD가 대체할 영역을 표시한다.

#### D.1 쿠키 로그인 흐름 (줄 2455~2501) — `session.py`에 그대로 이식

```python
# 줄 2455 — save_naver_cookies
def save_naver_cookies(self, driver):
    cookies = driver.get_cookies()
    with open(self.get_cookie_path(), "w", encoding="utf-8") as f:
        json.dump(cookies, f, ensure_ascii=False, indent=2)

# 줄 2465 — load_naver_cookies
def load_naver_cookies(self, driver):
    cookie_path = self.get_cookie_path()
    if not os.path.exists(cookie_path):
        return False
    with open(cookie_path, "r", encoding="utf-8") as f:
        cookies = json.load(f)
    for cookie in cookies:
        if 'expiry' in cookie:
            cookie['expiry'] = int(cookie['expiry'])  # 타입 정규화 필수
        driver.add_cookie(cookie)
    return True

# 줄 2487 — check_naver_login_status
def check_naver_login_status(self, driver):
    driver.get("https://www.naver.com")
    time.sleep(2)
    page_source = driver.page_source
    return ("로그아웃" in page_source or "내정보" in page_source or "MY" in page_source)
```

**이식 변경점**: `self.get_cookie_path()` → `~/.config/naverblog/session.json` (또는 `%USERPROFILE%\.config\naverblog\session.json`)

#### D.2 ID/PW 입력 + 2FA 폴링 (줄 2544~2601) — `session.py`에 그대로 이식

```python
# 핵심: pyperclip + Ctrl+V 방식 (send_keys 우회로 봇 탐지 회피)
driver.get("https://nid.naver.com/nidlogin.login")
time.sleep(2)

id_input = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.ID, "id")))
id_input.click(); time.sleep(0.5)
pyperclip.copy(naver_id)
ActionChains(driver).key_down(Keys.CONTROL).send_keys('v').key_up(Keys.CONTROL).perform()

pw_input = driver.find_element(By.ID, "pw")
pw_input.click(); time.sleep(0.5)
pyperclip.copy(naver_pw)
ActionChains(driver).key_down(Keys.CONTROL).send_keys('v').key_up(Keys.CONTROL).perform()

driver.find_element(By.ID, "log.login").click()

# 2FA 폴링 (최대 60초)
max_wait, wait_interval, waited = 60, 2, 0
while waited < max_wait:
    if "nidlogin" not in driver.current_url and "nid.naver.com" not in driver.current_url:
        break
    # 본 PRD: messagebox 대신 stdout + 스크린샷
    time.sleep(wait_interval); waited += wait_interval
```

**이식 변경점**: `messagebox.showwarning(...)` → `print("⚠️ 2FA 필요 ...")` + 스크린샷 저장 (NFR2)

#### D.3 제목/본문 입력 (줄 2669~2785) — `drafter.py`에 이식 + NBW 마크다운 파서로 교체

```python
# 줄 2672 — 제목 selector 7가지 시도
title_selectors = [
    ".se-title-input", ".se-documentTitle-editView", ".se-title-text",
    "span.se-title-text", "div.se-title-input span",
    "input[placeholder*='제목']", "[data-placeholder='제목']",
    ".se-component.se-documentTitle .se-text-paragraph"
]

# 줄 2702 — 제목 입력 (ActionChains 문자별, 0.02s 간격)
for char in title:
    ActionChains(driver).send_keys(char).perform()
    time.sleep(0.02)

# 줄 2714 — 본문 영역
body_area = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located(
        (By.CSS_SELECTOR, ".se-text-paragraph, .se-component-content")))
```

**이식 변경점**: 원본 줄 2737~2758의 `## 2. Blog Post Body` 마커 기반 파싱은 **삭제**하고, NBW 줄글 마크다운(빈 줄로 단락 구분)을 그대로 입력하는 단순 파서로 교체.

#### D.4 원본의 종료 지점 — 본 PRD가 대체할 핵심 영역 (줄 2800~2806)

```python
# ★ 원본: 사용자에게 수동 발행 위임하고 종료
print("DEBUG: Blog post prepared. Please review and publish manually.")
self.root.after(0, lambda: messagebox.showinfo("포스팅 준비 완료",
    "블로그 포스팅이 준비되었습니다.\n"
    "브라우저에서 내용을 확인하고 '발행' 버튼을 클릭해주세요."))
time.sleep(60)
```

**본 PRD의 대체**:
```python
# drafter.py
click_save_draft_button(driver)        # "저장" 텍스트만, "발행" 거부 (5.5 안전 가드)
draft_id = extract_draft_id(driver)    # 5.5 두 방안 중 택1
print(f"✅ 임시저장 완료 (draft_id={draft_id}). "
      f"네이버 블로그 앱 > 임시저장 글에서 검토 후 발행하세요.")
```

이것이 본 PRD의 가장 큰 신규 기여(M1)이며, 동시에 **공개 발행 가드레일**(FR7, NFR7)이 작동하는 지점이다.

---

**문서 끝.** 검토 후 승인되면 M0부터 구현 시작.
