"""임시저장 기록 (.drafts.json + frontmatter 갱신).

데이터 안전 규칙 (절대 위반 금지):
- 절대 파일을 'wb'/'w' 모드로 직접 열지 않는다 (truncate 후 예외 발생 시 데이터 손실).
- 모든 갱신은 (1) 원본 백업 → (2) 임시 파일에 새 내용 → (3) atomic replace 순서로 한다.
- 새 내용이 0바이트면 쓰지 않는다.
"""
from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional


def _safe_write_text(path: Path, content: str) -> None:
    """원본 백업 + 임시 파일 → atomic replace. 새 내용이 0바이트면 거부."""
    if not content:
        raise ValueError(f"safe_write_text: 빈 내용으로 {path} 덮어쓰기 거부")
    backup = path.with_suffix(path.suffix + ".bak")
    if path.exists():
        shutil.copy2(path, backup)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)
    if backup.exists() and path.read_text(encoding="utf-8") == content:
        backup.unlink()

KST = timezone(timedelta(hours=9))


def _project_root() -> Path:
    return Path(__file__).resolve().parents[4]  # scripts/autopost/skills/.claude/<root>


def _drafts_path() -> Path:
    p = _project_root() / "docs" / "20.working" / "22.state" / ".drafts.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def append(
    post_file: str,
    draft_id: Optional[str],
    blog_id: str,
    persona: str = "",
    category_id: str = "",
    tags: Optional[list] = None,
    duration_sec: int = 0,
    status: str = "drafted",
) -> None:
    """`.drafts.json`에 1건 추가."""
    path = _drafts_path()
    records = []
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                records = json.load(f)
        except Exception:
            records = []

    records.append({
        "post_file": post_file,
        "naver_draft_id": draft_id,
        "saved_at": datetime.now(KST).isoformat(timespec="seconds"),
        "blog_id": blog_id,
        "persona": persona,
        "category_id": category_id,
        "tags": tags or [],
        "status": status,
        "duration_sec": duration_sec,
    })

    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    print(f"[record] .drafts.json 에 기록 ({len(records)}건)")


def update_frontmatter(post_file: str, draft_id: Optional[str], status: str = "drafted") -> None:
    """31.posts 마크다운 frontmatter에 naver_draft_id/saved_at/status 추가/갱신.

    python-frontmatter가 설치되어 있으면 그것을 쓰고, 아니면 단순 YAML 블록 갱신.
    """
    path = Path(post_file)
    if not path.exists():
        print(f"[record] [WARN]마크다운 파일 없음: {post_file}")
        return

    saved_at = datetime.now(KST).isoformat(timespec="seconds")

    try:
        import frontmatter as fm  # type: ignore
        post = fm.load(str(path))
        post["naver_draft_id"] = draft_id
        post["saved_at"] = saved_at
        post["status"] = status
        _safe_write_text(path, fm.dumps(post))
        print(f"[record] frontmatter 갱신 (python-frontmatter): {path.name}")
        return
    except ImportError:
        pass

    # 폴백: 단순 텍스트 처리
    text = path.read_text(encoding="utf-8")
    new_lines = [
        f'status: "{status}"',
        f'naver_draft_id: "{draft_id or ""}"',
        f'saved_at: "{saved_at}"',
    ]
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            head = text[3:end].strip().splitlines()
            kept = [
                line for line in head
                if not any(line.lstrip().startswith(k + ":") for k in ("status", "naver_draft_id", "saved_at"))
            ]
            new_fm = "---\n" + "\n".join(kept + new_lines) + "\n---" + text[end + 4:]
            _safe_write_text(path, new_fm)
            print(f"[record] frontmatter 갱신 (수동): {path.name}")
            return

    print(f"[record] [WARN]frontmatter 형식을 인식하지 못함: {path.name}")
