"""마크다운 파일의 모든 Image Prompt를 순차 Gemini 처리 → 매칭 파일명으로 저장.

전제: Chrome --remote-debugging-port=9222, gemini.google.com 탭 열림.

사용:
  py -3.12 _probe_gemini_batch.py <md파일경로>
  py -3.12 _probe_gemini_batch.py <md파일경로> --first-only   # 응답당 첫 이미지만 저장
"""
from __future__ import annotations

import argparse
import base64
import sys
import time
from pathlib import Path

import pyperclip
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

from image_prompts import parse_image_prompts

OUT_DIR = Path(r"G:\내 드라이브\WorkSpace\NaverBlogWriter\docs\10.input\gemini")
OUT_DIR.mkdir(parents=True, exist_ok=True)

PER_PROMPT_TIMEOUT = 150   # 각 프롬프트당 최대 대기 (Gemini 이미지 생성 시간)
MIN_PX = 400               # 이 이상이어야 결과 이미지로 인정


def attach():
    options = webdriver.ChromeOptions()
    options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    for handle in driver.window_handles:
        try:
            driver.switch_to.window(handle)
            if "gemini.google.com" in driver.current_url:
                return driver
        except Exception:
            continue
    raise SystemExit("[FAIL] Gemini 탭이 없습니다. https://gemini.google.com 을 Chrome에서 열어주세요.")


def find_prompt_box(driver):
    for el in driver.find_elements(By.CSS_SELECTOR, "[contenteditable='true']"):
        if not el.is_displayed():
            continue
        aria = el.get_attribute("aria-label") or ""
        cls = el.get_attribute("class") or ""
        if "프롬프트" in aria or "prompt" in aria.lower() or "ql-editor" in cls:
            return el
    raise SystemExit("[FAIL] 프롬프트 박스를 찾지 못함")


def submit_prompt(driver, prompt: str) -> None:
    box = find_prompt_box(driver)
    box.click()
    time.sleep(0.4)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
    ActionChains(driver).send_keys(Keys.DELETE).perform()
    time.sleep(0.3)
    pyperclip.copy(prompt)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
    time.sleep(0.8)
    ActionChains(driver).send_keys(Keys.ENTER).perform()


def scan_big_srcs(driver, min_px: int = MIN_PX) -> set:
    out = set()
    for img in driver.find_elements(By.CSS_SELECTOR, "img"):
        try:
            src = img.get_attribute("src") or ""
            if not src:
                continue
            w = int(img.get_attribute("naturalWidth") or 0)
            h = int(img.get_attribute("naturalHeight") or 0)
            if w >= min_px and h >= min_px:
                out.add(src)
        except Exception:
            continue
    return out


def wait_new_images(driver, baseline_srcs: set, timeout: int) -> list:
    """baseline 이후 새로 등장한 큰 이미지 리스트 (element, src, w, h)."""
    start = time.time()
    stable_count = 0
    last_new_count = 0
    while time.time() - start < timeout:
        new_imgs = []
        for img in driver.find_elements(By.CSS_SELECTOR, "img"):
            try:
                src = img.get_attribute("src") or ""
                if not src or src in baseline_srcs:
                    continue
                w = int(img.get_attribute("naturalWidth") or 0)
                h = int(img.get_attribute("naturalHeight") or 0)
                if w >= MIN_PX and h >= MIN_PX:
                    new_imgs.append((img, src, w, h))
            except Exception:
                continue

        if len(new_imgs) != last_new_count:
            print(f"    [모니터] 새 이미지 {len(new_imgs)}개 ({int(time.time() - start)}s)")
            last_new_count = len(new_imgs)
            stable_count = 0
        elif new_imgs:
            stable_count += 1
            if stable_count >= 2:   # 4~6초 안정 = 응답 완료
                return new_imgs
        time.sleep(2)
    return []


def download_blob(driver, img_el, dest: Path) -> bool:
    """img element를 canvas로 그려 PNG로 저장 (blob URL 우회)."""
    try:
        data_url = driver.execute_script(
            """
            var img = arguments[0];
            var canvas = document.createElement('canvas');
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            canvas.getContext('2d').drawImage(img, 0, 0);
            try { return canvas.toDataURL('image/png'); }
            catch (e) { return 'ERROR:' + e.message; }
            """,
            img_el,
        )
        if not data_url or data_url.startswith("ERROR:"):
            print(f"    [실패] canvas 변환: {data_url}")
            return False
        _, b64 = data_url.split(",", 1)
        dest.write_bytes(base64.b64decode(b64))
        print(f"    [저장] {dest.name} ({dest.stat().st_size:,} 바이트)")
        return True
    except Exception as e:
        print(f"    [실패] {e}")
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("md", help="docs/30.output/31.posts/*.md 경로")
    ap.add_argument("--first-only", action="store_true",
                    help="응답당 첫 이미지만 저장 (기본: 모든 새 이미지)")
    args = ap.parse_args()

    md_path = Path(args.md).resolve()
    if not md_path.exists():
        raise SystemExit(f"파일 없음: {md_path}")

    prompts = parse_image_prompts(md_path)
    if not prompts:
        raise SystemExit(f"Image Prompt 섹션을 찾지 못함: {md_path}")

    print(f"[md] {md_path.name}  ({len(prompts)}개 프롬프트)")
    for p in prompts:
        print(f"     #{p.idx:02d} {p.label}  -> {p.filename(md_path.stem)}")

    driver = attach()
    print(f"\n[OK] Gemini attach: {driver.current_url}\n")

    md_stem = md_path.stem
    success, failed = 0, 0

    for p in prompts:
        print(f"=== #{p.idx:02d}/{p.total} {p.label} ===")
        print(f"    title: {p.title}")

        baseline = scan_big_srcs(driver)
        full_prompt = f"Generate an image: {p.prompt}"

        try:
            submit_prompt(driver, full_prompt)
            print(f"    [전송] {len(full_prompt)}자")
        except Exception as e:
            print(f"    [실패] 전송 오류: {e}")
            failed += 1
            continue

        new_imgs = wait_new_images(driver, baseline, timeout=PER_PROMPT_TIMEOUT)
        if not new_imgs:
            print("    [실패] 새 이미지 0개 (타임아웃 또는 텍스트 응답)")
            failed += 1
            continue

        to_save = new_imgs[:1] if args.first_only else new_imgs
        for i, (img, src, w, h) in enumerate(to_save):
            suffix = "" if i == 0 else f"_v{i + 1}"
            dest = OUT_DIR / f"{md_stem}__{p.idx:02d}_{p.label}{suffix}.png"
            print(f"    #v{i + 1} {w}x{h}")
            if download_blob(driver, img, dest):
                success += 1
            else:
                failed += 1

        # Gemini가 다음 프롬프트를 받을 수 있도록 잠시 대기
        time.sleep(3)

    print(f"\n[완료] 성공 {success} / 실패 {failed}")
    print(f"       저장 위치: {OUT_DIR}")


if __name__ == "__main__":
    main()
