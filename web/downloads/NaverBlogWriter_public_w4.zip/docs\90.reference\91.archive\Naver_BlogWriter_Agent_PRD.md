# PRD: 블로그 글쓰기 에이전트 (blog-writer agent)

## Context (배경)

현재 NaverBlogWriter는 모든 기능이 독립 Skill로 제공되고, 사용자가 `/keyword` → `/write` → `/autopost`를
**순서대로 직접 호출**해야 한다. autopost SKILL.md에도 "future work: `/write`를 subagent로 확장해 키워드→글→임시저장
end-to-end 흐름을 만든다"는 메모가 이미 남아 있다.

이 PRD는 그 end-to-end 흐름을 **하나의 백그라운드 에이전트**로 묶는다. 사용자는 에이전트 실행 시 몇 가지 선택만 하면,
이후 리서치 → 글 작성 → (선택) 임시저장까지 사람 개입 없이 백그라운드에서 완료되고, 결과만 검토한다.

### 핵심 설계 결정 (사용자 확정)
1. **구현 방식**: `.claude/agents/` subagent 정의 (새 Skill 만들지 않음)
2. **상호작용**: 백그라운드 subagent는 실행 중 질문 불가 → **시작 전 일괄 질문, 이후 완전 자율**
   (write-photo의 사진 캡션 확정, write의 초안/완성 확인은 자율 진행하고 결과를 사용자가 사후 검토)
3. **autopost 범위**: 사용자가 원하면 **임시저장까지 자동**. 공개 발행은 절대 안 함(기존 가드레일 유지)

### 핵심 제약 (반드시 반영)
- 백그라운드 subagent는 `AskUserQuestion`을 쓸 수 없다 → 모든 분기 결정은 **실행 전에** 메인 대화(디스패처)가 수집한다.
- 따라서 구조는 **2계층**: ①디스패처(메인 루프) = 질문 수집·검증·백그라운드 기동, ②실행 에이전트(백그라운드) = 자율 실행.

---

## 사용자 플로우

```
사용자: "블로그 글쓰기 에이전트 실행해줘"
   │
   ▼  [디스패처 = 메인 대화 루프, AskUserQuestion 사용]
Q1. write vs write-photo ?
Q2. (write 선택 시) 리서치: 없음 / keyword / trend / 둘 다 ?
Q3. (write 선택 시) bridge 아이디어 사용 ?
Q4. 주제·제목(write) 또는 날짜·폴더(write-photo) 입력
Q5. 끝나고 네이버 임시저장(autopost)까지 진행 ?
   │
   ▼  [사전 검증]  활성 페르소나 존재? / (photo) 폴더·이미지 존재? / (autopost) NAVER_ID·PW 존재?
   │
   ▼  Agent(run_in_background: true) 로 blog-writer 기동 + 위 답을 "작업 지시서"로 전달
   │
   ▼  [백그라운드 자율 실행] 리서치 → 글 작성 → 사진 staging → (선택)임시저장
   │
   ▼  완료 알림 → 메인 대화가 결과 요약 표시 (파일 경로 + "검토 필요" 포인트)
```

write-photo는 이미 찍은 사진으로 작성하므로 Q2(리서치)·Q3(bridge)를 **건너뛴다**.

---

## 구현 범위

### 새로 만들 파일 (1개)
**`.claude/agents/blog-writer.md`** — 백그라운드 실행 에이전트 정의

프론트매터(Claude Code subagent 형식):
```yaml
---
name: blog-writer
description: 활성 페르소나로 (리서치→)블로그 글 작성하고 선택 시 네이버 임시저장까지 백그라운드로 수행하는 에이전트
tools: Read, Write, Edit, Bash, Glob, WebSearch
model: opus
---
```
- `AskUserQuestion` 제외 (백그라운드 = 질문 불가). 디스패처가 모든 결정을 지시서로 넘기므로 불필요.
- 본문은 아래 "자율 실행 프로토콜"을 단계별로 기술. **write/write-photo/autopost의 절차는 각 SKILL.md를
  단일 출처(source of truth)로 참조**하되, 모든 `AskUserQuestion` 단계는 "지시서의 사전 결정으로 대체하고 건너뛴다"고 명시.

### 수정할 파일 (1개)
**`G:\내 드라이브\WorkSpace\NaverBlogWriter\CLAUDE.md`** — 디스패처 진입 규칙 추가
- "자주 쓰는 명령" 근처에 `### 에이전트` 절 추가: 트리거 문구("블로그 글쓰기 에이전트", "글쓰기 에이전트 실행" 등),
  디스패처가 던질 질문 목록(위 Q1~Q5), 사전 검증 항목, `Agent(run_in_background:true)`로 `blog-writer` 기동한다는 규칙.
- CLAUDE.md는 매 세션 자동 로드되므로, 메인 루프가 질문 수집·백그라운드 기동을 일관되게 수행하게 하는 **유일한 안전한 위치**.
  (별도 Skill을 만들지 않기로 한 결정과 양립 — 이건 새 기능이 아니라 디스패치 규약 문서)

### 권한 (settings.local.json)
- 백그라운드 에이전트가 쓰는 Bash(python *), WebSearch, autopost(py -3.12 ...)는 기존 allow에 이미 포함 → **추가 변경 불필요**.
- 단, `Agent`(=Task) 호출과 `run_in_background`는 권한 프롬프트가 한 번 뜰 수 있음(정상).

---

## 자율 실행 프로토콜 (blog-writer.md 본문 핵심)

에이전트는 지시서(JSON 또는 구조화 텍스트)를 받는다:
```
mode: write | write-photo
research: none | keyword | trend | both      # write 전용
bridge: true | false                          # write 전용
topic_or_title: "..."                         # write
photo_date_or_folder: "20260602" | "<경로>"   # write-photo
autopost: true | false
```

### 0. 페르소나 로딩 (공통, 필수)
`python -X utf8 ".claude/skills/write/scripts/persona_context.py"` 실행 → 활성 페르소나·context_file·가이드 통합 로드.
(활성 페르소나 없으면 디스패처가 기동 전에 막으므로 여기선 정상 전제)

### 1. (write + research) 리서치 — WebSearch
- `research`에 keyword 포함 → `.claude/skills/keyword/SKILL.md` 절차대로 연관/검색의도/골든키워드 분석
- `research`에 trend 포함 → `.claude/skills/trend/SKILL.md` 절차대로 트렌드 수집 (trend_cli.py 사용)
- 결과를 글 작성용 키워드 세트로 요약 (파일 저장은 선택)

### 2. (write + bridge) 브릿지 아이디어
- `config/me.json` 읽고 `.claude/skills/bridge/SKILL.md`의 5패턴으로 제목/각도 후보 생성 → 본문 방향에 반영
- me.json 없으면 bridge 단계만 건너뛰고 로그에 기록(중단 아님)

### 3-A. mode=write — 글 작성
`.claude/skills/write/SKILL.md`의 4~7단계를 그대로 실행하되 **AskUserQuestion(2·6단계) 생략**:
- `scaffold_post.py "<제목/키워드>" --keyword "<키워드>"` → 골격 생성
- 본문 작성(페르소나 + Naver Blog Writer 규칙) → `clean_text.py --fix -`로 정리
- 추천 제목 5 / Image Prompt 4(16:9) / Tags 10 생성 → status `complete`

### 3-B. mode=write-photo — 사진 글 작성
`.claude/skills/write-photo/SKILL.md`의 1~9단계 실행하되 **3단계 캡션 확정 AskUserQuestion 생략**:
- `list_photos.py "<폴더>"` → 정렬 목록
- 사진 Read(비전)로 캡션 **자동 확정**(사용자 보정 없이) → `.photo_analysis_*.json` 저장
- `scaffold_post.py` → 본문에 `[[IMG]]` 마커(개수·순서 = 사진 수·정렬순) → `clean_text.py` → `## 사진 배치` 표
- `stage_photos.py "<폴더>"` → `.imgstage/NN.png` staging

### 4. (autopost=true) 임시저장
- write: `py -3.12 ".claude/skills/autopost/scripts/autopost.py" upload "<md>"`
- write-photo: 위에 `--photos-dir "docs/20.working/22.state/.imgstage"` 추가
- autopost 가드레일(공개 발행 금지) 그대로 — 임시저장까지만.
- NAVER_ID/PW 미설정이면 업로드 생략하고 "환경변수 필요"를 결과에 명시(글 작성물은 보존).

### 5. 최종 보고 (메인 루프로 반환)
- 생성 파일 경로, 페르소나, 수행 단계 요약, draft 상태
- **검토 필요 포인트**: 자율 확정된 캡션/초안 중 사용자가 확인하면 좋은 항목, 임시저장 결과(또는 미실행 사유)

---

## 재사용 자산 (이미 존재 — 신규 코드 작성 불필요)
| 용도 | 경로 |
|------|------|
| 페르소나 로딩 | `.claude/skills/write/scripts/persona_context.py` |
| 골격 생성 | `.claude/skills/write/scripts/scaffold_post.py` |
| 본문 정리 | `.claude/skills/write/scripts/clean_text.py` |
| 사진 목록(EXIF정렬) | `.claude/skills/write-photo/scripts/list_photos.py` |
| 사진 staging | `.claude/skills/write-photo/scripts/stage_photos.py` |
| 임시저장 | `.claude/skills/autopost/scripts/autopost.py` |
| 트렌드 API | `.claude/skills/trend/scripts/trend_cli.py` |
| 활성 페르소나 상태 | `docs/20.working/22.state/.active_persona.json` |

이 에이전트는 새 Python 스크립트를 만들지 않고 위 스크립트 + 각 SKILL.md 절차를 그대로 호출/참조한다.

---

## 검증 (End-to-End 테스트)

1. **write 경로(autopost 없이)**: "글쓰기 에이전트 실행" → write / research=keyword / bridge=no / 주제 입력 / autopost=no
   → 백그라운드 완료 후 `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md` 생성 확인, 본문에 볼드/마크다운 머리표 없음(clean_text 적용), 제목5·이미지4·태그10 포함.
2. **write-photo 경로**: 활성 페르소나의 `docs/10.input/{페르소나}/{날짜}/`에 샘플 사진 두고 실행 → md에 `[[IMG]]` 마커 수 = 사진 수, `.imgstage/NN.png` 생성 확인.
3. **autopost=yes (dry-run)**: 임시저장 단계는 먼저 `--dry-run`으로 확인 권장(임시저장 직전 중단). 실제 임시저장은 NAVER_ID/PW 설정 후 1회 수동 확인.
4. **사전 검증 동작**: 활성 페르소나 없는 상태로 실행 → 디스패처가 백그라운드 기동 전에 "`/persona use`로 활성화 먼저" 안내하고 중단하는지 확인.
5. **백그라운드 비차단**: 에이전트 실행 중 메인 대화가 막히지 않고, 완료 시 알림으로 결과 요약이 표시되는지 확인.

---

## 미해결/주의
- 디스패처 질문 수집을 CLAUDE.md 규약에 의존 → 메인 루프가 트리거 문구를 인식해야 함. 인식 안 될 경우 사용자가 "blog-writer 에이전트 백그라운드로 실행, 먼저 질문해줘"처럼 명시하면 동일 동작.
- write/write-photo의 자율 확정 품질(특히 비전 캡션)은 사람 확인보다 낮을 수 있음 → 결과 보고의 "검토 필요" 섹션으로 보완(설계상 의도된 트레이드오프).

---

## 구현 상태 (2026-06-08)

이 PRD에 따라 아래 두 파일이 이미 작성됨:
- `.claude/agents/blog-writer.md` — 백그라운드 실행 에이전트 정의 (신규)
- `CLAUDE.md` — `### 에이전트` 절(디스패처 규약) 추가

> 원본 플랜 파일: `~/.claude/plans/write-agent-glistening-hanrahan.md`
