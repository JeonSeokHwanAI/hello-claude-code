"""autopost 오케스트레이터.

사용:
    py -3.12 autopost.py upload <md파일>
    py -3.12 autopost.py upload <md파일> --dry-run

환경변수: NAVER_ID, NAVER_PW, NAVER_BLOG_ID (생략 시 NAVER_ID 사용)

/write 스킬이 만든 docs/30.output/31.posts/{제목}_{YYYYMMDD}.md 를 받아
네이버 블로그 임시저장에 자동으로 올린다.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import time
from pathlib import Path
from typing import Tuple

import drafter
import image_gen
import record
import session


def parse_post(md_path: Path) -> Tuple[str, str, list]:
    """31.posts 마크다운에서 title, body, tags 추출.

    Returns:
        title: frontmatter `title` (없으면 파일명에서 추출)
        body: `## 본문` 섹션의 내용 (다음 헤더/구분선 직전까지)
        tags: `## Tags` 코드블록의 #태그 목록 (# 제거)
    """
    text = md_path.read_text(encoding="utf-8")

    # 1) Title (frontmatter)
    title = ""
    fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    fm_body = ""
    if fm_match:
        fm_body = fm_match.group(1)
        for line in fm_body.splitlines():
            m = re.match(r'\s*title\s*:\s*"?(.+?)"?\s*$', line)
            if m:
                title = m.group(1).strip().strip('"')
                break
        text = text[fm_match.end():]
    if not title:
        title = md_path.stem.rsplit("_", 1)[0]

    # 2) Body (## 본문 ~ 다음 ## 또는 --- 직전)
    body = ""
    body_match = re.search(r"^##\s*본문\s*\n(.*?)(?=^---\s*$|^##\s|\Z)", text, re.MULTILINE | re.DOTALL)
    if body_match:
        body = body_match.group(1).strip()
    else:
        body = text.strip()

    # 3) Tags (## Tags 섹션의 코드블록 또는 #해시태그 라인)
    tags = []
    tags_section = re.search(r"^##\s*Tags\s*\n(.*?)(?=^---\s*$|^##\s|\Z)", text, re.MULTILINE | re.DOTALL)
    if tags_section:
        section = tags_section.group(1)
        # 코드블록 안의 #태그 또는 그냥 #태그 라인
        for token in re.findall(r"#([\w가-힣]+)", section):
            if token not in tags:
                tags.append(token)

    return title, body, tags


def upload(md_path: Path, dry_run: bool = False, skip_images: bool = False,
           photos_dir: str = None) -> dict:
    naver_id = os.environ.get("NAVER_ID")
    naver_pw = os.environ.get("NAVER_PW")

    # 저장된 계정 설정(blog_id, naver_id 힌트) — 한 번 성공하면 환경변수 없이 재사용
    cfg = session.load_account_config()
    blog_id = os.environ.get("NAVER_BLOG_ID") or naver_id or cfg.get("blog_id")
    cookie_ready = session.cookie_session_exists()

    if not (naver_id and naver_pw):
        # 쿠키 세션이 살아있으면 환경변수 없이도 로그인 가능 (만료 시 session 에서 안내)
        if not cookie_ready:
            raise SystemExit(
                "첫 로그인입니다 — 환경변수 NAVER_ID, NAVER_PW 가 필요합니다.\n"
                "한 번 임시저장에 성공하면 쿠키 세션이 저장되어 이후엔 생략됩니다."
            )
        print("[autopost] 쿠키 세션 사용 (환경변수 없이 진행)")

    if not blog_id:
        raise SystemExit(
            "blog_id 를 알 수 없습니다 — 환경변수 NAVER_BLOG_ID(또는 NAVER_ID)를 "
            "한 번만 지정해 주세요. 성공 후 config/autopost_config.json 에 저장됩니다."
        )

    title, body, tags = parse_post(md_path)
    print(f"[autopost] 파일: {md_path}")
    print(f"[autopost] 제목: {title}")
    print(f"[autopost] 본문 길이: {len(body)}자 / {len(body.splitlines())}줄")
    print(f"[autopost] 태그: {tags}")

    # 이미지 매칭:
    #  --photos-dir 지정 시 → 그 폴더의 파일을 파일명순으로 (write-photo 실사진 staging, 짧은 경로)
    #  미지정 시          → docs/10.input/gemini/ 에서 동일 md_stem 매칭 (Gemini 생성 이미지)
    image_paths = []
    if not skip_images:
        if photos_dir:
            pd = Path(photos_dir)
            exts = ("*.png", "*.jpg", "*.jpeg")
            files = sorted(f for ext in exts for f in pd.glob(ext))
            image_paths = [str(f) for f in files]
            print(f"[autopost] --photos-dir {pd} : 이미지 {len(image_paths)}개 (파일명순)")
        else:
            image_paths = [str(p) for p in image_gen.list_generated_for(md_path)]
        if image_paths:
            print(f"[autopost] 이미지 {len(image_paths)}개 매칭:")
            for p in image_paths:
                print(f"             {Path(p).name}")
        else:
            print(f"[autopost] 매칭 이미지 없음")

    started = time.time()
    result = drafter.write_post(
        naver_id=naver_id,
        naver_pw=naver_pw,
        blog_id=blog_id,
        title=title,
        body=body,
        image_paths=image_paths,
        tags=tags,
        dry_run=dry_run,
    )
    duration = int(time.time() - started)

    if result.get("saved") and not dry_run:
        # 성공한 blog_id(및 가능하면 naver_id)를 영속화 → 다음부터 환경변수 없이 진행
        session.save_account_config(blog_id=blog_id, naver_id=naver_id)
        record.append(
            post_file=str(md_path),
            draft_id=result.get("draft_id"),
            blog_id=blog_id,
            persona="",  # M5에서 페르소나 연동
            tags=tags,
            duration_sec=duration,
            status="drafted",
        )
        record.update_frontmatter(
            post_file=str(md_path),
            draft_id=result.get("draft_id"),
            status="drafted",
        )

    return result


def status(limit: int = 10) -> None:
    """`.drafts.json`의 최근 N건 출력."""
    import json
    from datetime import datetime
    drafts_path = Path(__file__).resolve().parents[4] / "docs" / "20.working" / "22.state" / ".drafts.json"
    if not drafts_path.exists():
        print("아직 임시저장 기록이 없습니다.")
        return
    records = json.loads(drafts_path.read_text(encoding="utf-8"))
    recent = records[-limit:]
    print(f"임시저장 기록 (최근 {len(recent)}건 / 전체 {len(records)}건)")
    print("-" * 80)
    for r in recent:
        title = Path(r["post_file"]).stem
        ts = r.get("saved_at", "")[:16].replace("T", " ")
        tags = ",".join(r.get("tags", []) or [])
        status_mark = "[saved]" if r.get("status") == "drafted" else f"[{r.get('status', '?')}]"
        print(f"  {ts}  {status_mark}  {title}")
        if tags:
            print(f"             tags: {tags}")


def main():
    ap = argparse.ArgumentParser(prog="autopost")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_upload = sub.add_parser("upload", help="기존 md 파일을 네이버에 임시저장 (이미지 자동 매칭)")
    p_upload.add_argument("file", help="docs/30.output/31.posts/*.md 경로")
    p_upload.add_argument("--dry-run", action="store_true", help="임시저장 직전에 중단")
    p_upload.add_argument("--skip-images", action="store_true",
                          help="매칭 이미지를 무시하고 텍스트만 업로드")
    p_upload.add_argument("--photos-dir", default=None,
                          help="이미지 폴더 직접 지정(파일명순). write-photo 실사진 staging용 짧은 경로")

    p_gen = sub.add_parser("generate-images", help="md의 Image Prompt → Gemini 이미지 생성")
    p_gen.add_argument("file", help="docs/30.output/31.posts/*.md 경로")
    p_gen.add_argument("--provider", default="gemini_web", help="현재: gemini_web")
    p_gen.add_argument("--all-variations", action="store_true",
                       help="응답당 모든 변형 저장 (기본: 첫 이미지만)")

    p_status = sub.add_parser("status", help=".drafts.json 최근 기록 출력")
    p_status.add_argument("--limit", type=int, default=10)

    args = ap.parse_args()

    if args.cmd == "upload":
        md_path = Path(args.file).resolve()
        if not md_path.exists():
            raise SystemExit(f"파일이 없습니다: {md_path}")
        result = upload(md_path, dry_run=args.dry_run, skip_images=args.skip_images,
                        photos_dir=args.photos_dir)
        print(f"결과: {result}")
        sys.exit(0 if result.get("saved") or args.dry_run else 1)

    elif args.cmd == "generate-images":
        md_path = Path(args.file).resolve()
        if not md_path.exists():
            raise SystemExit(f"파일이 없습니다: {md_path}")
        try:
            saved = image_gen.generate_from_markdown(
                md_path,
                provider=args.provider,
                first_only=not args.all_variations,
            )
        except RuntimeError as e:
            # 디버그 Chrome 미실행/기존 Chrome 충돌 등 사용자가 조치 가능한 상황은
            # 트레이스백 없이 안내 메시지만 보여주고 종료한다(이미지 없이 upload 폴백 가능).
            print(f"[generate-images 중단] {e}", file=sys.stderr)
            sys.exit(2)
        sys.exit(0 if saved else 1)

    elif args.cmd == "status":
        status(limit=args.limit)
        sys.exit(0)


if __name__ == "__main__":
    main()
