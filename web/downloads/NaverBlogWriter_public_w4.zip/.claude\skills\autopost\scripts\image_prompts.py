"""마크다운의 Image Prompt 섹션 파싱 + 파일명 슬러그 생성.

마크다운 구조 가정 (/write 산출물):
    ## Image Prompt (4개)

    ### 1. 도입 - 백지 앞에서 막막한 블로거
    **위치**: ...
    **스타일**: ...
    **비율**: 16:9
    ```
    A cozy flat illustration of ...
    ```

    ### 2. 본문 - ...
    ...
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass
class ImagePrompt:
    idx: int          # 1-based section number
    total: int        # 전체 이미지 개수 (라벨 계산용)
    title: str        # 섹션 제목 원본
    prompt: str       # 코드블록 내용 (Gemini/DALL-E에 보낼 텍스트)

    @property
    def label(self) -> str:
        """위치 기반 의미 라벨: 첫=도입, 끝=마무리, 중간=본문N."""
        if self.idx == 1:
            return "도입"
        if self.idx == self.total:
            return "마무리"
        return f"본문{self.idx - 1}"

    def filename(self, md_stem: str, ext: str = "png") -> str:
        """{md_stem}__{NN}_{label}.{ext} 형식의 파일명."""
        return f"{md_stem}__{self.idx:02d}_{self.label}.{ext}"


def slugify(text: str, max_len: int = 50) -> str:
    """한글/영숫자만 유지, 그 외는 언더스코어. 양끝 트림 + 길이 제한."""
    # 한글 자모/완성형 + 영숫자만 유지
    cleaned = re.sub(r"[^\w가-힣]+", "_", text)
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned[:max_len].rstrip("_")


def parse_image_prompts(md_path: Path) -> List[ImagePrompt]:
    """마크다운에서 Image Prompt 섹션들 추출."""
    text = md_path.read_text(encoding="utf-8")

    # ## Image Prompt 섹션 범위 찾기 (다음 ## 또는 EOF 까지)
    section = re.search(
        r"^##\s*Image\s*Prompt.*?\n(.*?)(?=^##\s|\Z)",
        text, re.MULTILINE | re.DOTALL,
    )
    if not section:
        return []
    body = section.group(1)

    # ### N. 제목 ... ``` 코드블록 ``` 패턴
    # (제목 라인 ~ 첫 번째 fenced 코드블록 사이를 묶음)
    pattern = re.compile(
        r"^###\s*(\d+)\.\s*(.+?)\s*$"      # ### N. 제목
        r"(?:.*?)"                          # 메타 (위치/스타일/비율)
        r"```[a-z]*\n(.+?)\n```",          # ``` ... ``` 본문
        re.MULTILINE | re.DOTALL,
    )

    raw = []
    for m in pattern.finditer(body):
        idx = int(m.group(1))
        title = m.group(2).strip()
        prompt = m.group(3).strip()
        raw.append((idx, title, prompt))

    total = len(raw)
    return [ImagePrompt(idx=i, total=total, title=t, prompt=p) for (i, t, p) in raw]


if __name__ == "__main__":
    # 빠른 시험: 사용자 파일로 파싱 확인
    import sys
    if len(sys.argv) < 2:
        target = Path(r"G:\내 드라이브\WorkSpace\NaverBlogWriter\docs\30.output\31.posts\어질러진_AI_작업실_대청소_20260520.md")
    else:
        target = Path(sys.argv[1])

    prompts = parse_image_prompts(target)
    md_stem = target.stem
    print(f"파일: {target.name}  ({len(prompts)}개 프롬프트)")
    print(f"md_stem: {md_stem}\n")
    for p in prompts:
        print(f"  #{p.idx:02d}/{p.total}  label={p.label!r}  title={p.title!r}")
        print(f"          file:   {p.filename(md_stem)}")
        print(f"          prompt: {p.prompt[:80]}...")
        print()
