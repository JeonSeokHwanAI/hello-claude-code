# Naver SmartEditor Selectors

원본: `docs/90.reference/99.external-scripts/marketing_wizard_Extand_AutoLoad.py` 줄 2502~2854 검증됨.

DOM 변경 시 이 파일만 수정한다. 코드는 이 카탈로그를 import해서 사용.

## 로그인 (nid.naver.com)

| 항목 | Selector | 입력 방식 |
|------|----------|-----------|
| ID | `#id` (By.ID, "id") | pyperclip 클립보드 + Ctrl+V |
| PW | `#pw` (By.ID, "pw") | pyperclip 클립보드 + Ctrl+V |
| 로그인 버튼 | `#log\.login` (By.ID, "log.login") | click |
| 로그인 완료 감지 | URL에 `nidlogin`/`nid.naver.com` 미포함 | polling 60s |
| 2FA 감지 | URL이 로그인 도메인에 머무름 | 사용자에게 수동 처리 요청 |

## 로그인 상태 확인 (www.naver.com)

| 항목 | 판정 |
|------|------|
| 로그인 됨 | page_source에 "로그아웃" / "내정보" / "MY" 포함 |
| 보조 selector | `.MyView-module__my_menu___BQAAQ`, `.link_login`, `#account` |

## 글쓰기 페이지

| 항목 | URL |
|------|-----|
| 1차 시도 | `https://blog.naver.com/{blog_id}/postwrite` |
| 2차 폴백 | `https://blog.naver.com/PostWriteForm.naver?blogId={blog_id}` |
| 실패 판정 | page_source에 "유효하지 않은" 또는 URL에 "error" |

## iframe

| 항목 | Selector | 비고 |
|------|----------|------|
| 에디터 iframe | `#mainFrame` (By.ID, "mainFrame") | `frame_to_be_available_and_switch_to_it` |

## 팝업 처리

### "작성 중인 글이 있습니다" — 취소 클릭 (새로 작성)

```python
cancel_selectors = [
    "button.cancel",
    "button.se-popup-button-cancel",
    "button[class*='cancel']",
    "//button[contains(text(), '취소')]",   # XPath
]
```

### 기타 팝업 닫기

```python
close_selectors = "button.se-popup-close-btn, .popup_close, .btn_close"
```

## 제목 입력 (7가지 시도)

```python
title_selectors = [
    ".se-title-input",
    ".se-documentTitle-editView",
    ".se-title-text",
    "span.se-title-text",
    "div.se-title-input span",
    "input[placeholder*='제목']",
    "[data-placeholder='제목']",
    ".se-component.se-documentTitle .se-text-paragraph",
]
```

입력 방식: 클릭 → Ctrl+A → ActionChains 문자별 `send_keys`, 0.02s 간격

## 본문 입력

| 항목 | Selector |
|------|----------|
| 본문 영역 | `.se-text-paragraph, .se-component-content` |
| 입력 방식 | ActionChains 문자별 `send_keys`, 0.01s 간격, 줄바꿈은 ENTER |

## 이미지 업로드 (5가지 시도)

```python
photo_selectors = [
    "button[data-log='dot.photo']",
    "button[class*='se-main-toolbar-button-image']",
    "button[data-click-area='top.image']",
    "button[data-name='image']",
    ".se-toolbar-button-image",
]
```

입력 방식: 사진 버튼 클릭 → 파일 다이얼로그 → `pyperclip.copy(path)` → `pyautogui.hotkey('ctrl','v')` → `pyautogui.press('enter')`

## 임시저장 버튼 (실측 2026-05-27, SE3)

DOM:
```html
<button type="button" class="save_btn__bzc5B" data-click-area="tpb.save">저장</button>
<button class="save_count_btn__ZTLNa" aria-label="임시저장된 글 보기, 28개">28</button>
<button type="button" class="publish_btn__m9KHH" data-click-area="...">발행</button>  <!-- 절대 클릭 금지 -->
```

CSS Modules 해시(`__bzc5B`)는 빌드마다 바뀌므로 prefix 매칭 사용.

```python
SAVE_DRAFT_SELECTORS = [
    ("css", "button[class^='save_btn']"),       # 1차: 정공법
    ("css", "button[class*='save_btn']"),       # 2차: 폴백
    ("xpath", "//button[normalize-space()='저장']"),
    ("xpath", "//button[contains(., '저장') and not(contains(., '발행'))]"),
    ("css", "button[data-click-area*='save']"),  # data-click-area='tpb.save'
]
```

**필수 가드**:
- 매칭된 element의 텍스트에 `발행`/`공개발행`/`Publish` 포함되면 `RuntimeError`
- class에 `publish_btn` 포함되어도 `RuntimeError`

**JS 클릭 폴백 필수**: 네이티브 click이 도움말 패널(`<h1 class="se-help-title">`)에 가로채지는 경우 → `driver.execute_script("arguments[0].click();", btn)` 로 우회.

## 도움말 패널 닫기 (필수 — 임시저장 버튼 클릭 가로챔)

SE3 첫 사용 시 우측에 도움말 패널이 떠서 임시저장 버튼 클릭을 가로챈다. 사전에 닫아야 함:

```python
"button.se-help-panel-close-button"  # 도움말 패널 X 버튼
```

`CLOSE_OTHER_POPUPS_CSS`에 포함됨.

## 임시저장 완료 토스트 (M1)

```python
SAVE_TOAST_SELECTORS = [
    ("xpath", "//*[contains(text(), '임시저장')]"),
    ("xpath", "//*[contains(text(), '저장되었습니다')]"),
]
```

## draft_id 추출 (M1)

방안 2 (현재 구현): URL 쿼리 `draftSequence|draftSeq|draftId|tempPostNo` → 폴백으로 `PostWriteForm.naver` 페이지에서 정규식 추출.

방안 1 (M6 검토): `selenium-wire`로 `PostSaveTempPost.naver` 응답 캡처.

## 신규 식별 필요 (M2)

| 항목 | 비고 |
|------|------|
| 카테고리 select | M2에서 실측 |
| 태그 input | M2에서 실측 |
| 발행 버튼 | **의도적으로 식별/등록 금지** (가드레일) |

## 안전 가드 (코드 차원)

```python
FORBIDDEN_TEXTS = ["발행", "공개발행", "Publish"]

def click_save_draft_button(driver):
    """임시저장 버튼만 클릭. 발행 버튼은 절대 안 누름."""
    btn = driver.find_element(By.XPATH, "//button[contains(text(), '저장')]")
    text = btn.text
    for forbidden in FORBIDDEN_TEXTS:
        assert forbidden not in text, f"가드레일 위반: '{forbidden}' 텍스트가 포함된 버튼은 누르지 않음"
    btn.click()
```
