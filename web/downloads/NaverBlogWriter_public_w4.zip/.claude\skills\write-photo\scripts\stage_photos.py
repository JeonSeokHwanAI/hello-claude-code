"""write-photo 스킬용: 실제 사진을 autopost가 업로드할 staging 파일로 복사.

⚠️ 파일명은 반드시 **짧게**(NN.png). 네이버 사진 업로드는 OS 파일 다이얼로그에
   경로를 붙여넣는 방식이라, 한글 긴 제목이 들어간 파일명을 여러 장 묶으면
   다이얼로그에서 경로가 잘려 업로드가 실패한다(콜라주 멀티 선택 시 특히).

staging 위치: docs/20.working/22.state/.imgstage/{NN}.png  (짧은 ASCII 파일명)
  - 파일명순(01,02,...)이 곧 본문 [[IMG]] 마커 순서와 1:1.
  - autopost는 `upload <md> --photos-dir <이 폴더>` 로 파일명순으로 읽어 업로드한다.
  - jpg 등은 Pillow 로 png 변환 후 저장.

사용법:
    python -X utf8 stage_photos.py "<사진폴더>" [--order 02.jpg,05.jpg,...]
    --order 생략 시 폴더를 list_photos 와 동일 기준(EXIF→mtime→파일명)으로 정렬해 사용.
출력(JSON): {"stage_dir": ".../.imgstage", "count": N, "staged": [...]}
"""
from __future__ import annotations

import os
import sys
import json
import shutil
import argparse
from pathlib import Path

# 같은 폴더의 list_photos (정렬 재사용)
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parents[3]  # .claude/skills/write-photo/scripts → 4단계 상위 = 프로젝트 루트
sys.path.insert(0, str(_HERE))

import list_photos  # noqa: E402


def _stage_dir() -> Path:
    d = _ROOT / "docs" / "20.working" / "22.state" / ".imgstage"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ordered_filenames(folder: str, order_arg: str | None):
    """배치 순서대로 파일명 리스트 반환."""
    if order_arg:
        names = [n.strip() for n in order_arg.split(",") if n.strip()]
        return names
    # list_photos 와 동일 정렬
    items = list_photos._collect(folder)
    items.sort(key=list_photos._sort_key)
    return [it["filename"] for it in items]


def _save_as_png(src: str, dest: Path) -> bool:
    """src 이미지를 png로 dest에 저장. 이미 png면 단순 복사."""
    if src.lower().endswith(".png"):
        shutil.copyfile(src, dest)
        return True
    try:
        from PIL import Image
        with Image.open(src) as img:
            # 투명도 없는 포맷은 RGB로 (jpg→png 안전 변환)
            if img.mode in ("RGBA", "LA", "P"):
                img = img.convert("RGBA")
            else:
                img = img.convert("RGB")
            img.save(dest, "PNG")
        return True
    except ImportError:
        # Pillow 없으면 확장자만 png로 바꿔 복사(네이버 업로드는 내용으로 판별하므로 동작)
        shutil.copyfile(src, dest)
        return True
    except Exception as e:
        print(f"  [실패] {os.path.basename(src)} → {dest.name}: {e}", file=sys.stderr)
        return False


def main():
    ap = argparse.ArgumentParser(description="실제 사진을 짧은 staging png(NN.png)로 복사")
    ap.add_argument("folder", help="사진 폴더")
    ap.add_argument("--order", default=None,
                    help="배치 순서 파일명(쉼표구분). 생략 시 EXIF→mtime→파일명순")
    args = ap.parse_args()

    folder = os.path.abspath(args.folder)
    if not os.path.isdir(folder):
        print(json.dumps({"error": f"폴더 없음: {folder}", "staged": []}, ensure_ascii=False))
        sys.exit(1)

    names = _ordered_filenames(folder, args.order)
    if not names:
        print(json.dumps({"error": "사진 없음", "staged": []}, ensure_ascii=False))
        sys.exit(1)

    out_dir = _stage_dir()
    # 기존 staging 전체 정리 (한 번에 한 글 업로드 가정 — 재실행 멱등성)
    for old in out_dir.glob("*"):
        if old.is_file():
            old.unlink()

    staged = []
    for i, name in enumerate(names, start=1):
        src = os.path.join(folder, name)
        if not os.path.isfile(src):
            print(f"  [건너뜀] 없는 파일: {name}", file=sys.stderr)
            continue
        dest = out_dir / f"{i:02d}.png"   # 짧은 ASCII 파일명 (다이얼로그 잘림 방지)
        if _save_as_png(src, dest):
            staged.append({"idx": i, "src": name, "dest": dest.name})

    result = {
        "stage_dir": str(out_dir),
        "count": len(staged),
        "staged": staged,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
