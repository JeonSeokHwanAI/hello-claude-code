"""네이버 로그인 세션 관리 (쿠키 저장/로드/검증 + ID/PW 로그인 + 2FA 폴링).

원본: docs/90.reference/99.external-scripts/marketing_wizard_Extand_AutoLoad.py
       줄 2455~2601 (save_naver_cookies, load_naver_cookies, check_naver_login_status,
       및 naver_auto_blog_post의 로그인 부분)

GUI 의존 제거: tkinter.messagebox → print + 스크린샷 저장.
쿠키 저장 경로: 작업 폴더 → ~/.config/naverblog/session.json (.gitignore 대상)
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path

import pyperclip
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service


def _cookie_path() -> Path:
    base = Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".config" / "naverblog"
    base.mkdir(parents=True, exist_ok=True)
    return base / "session.json"


def cookie_session_exists() -> bool:
    """쿠키 세션 파일이 존재하면 True (유효성까지 보장하지는 않음)."""
    return _cookie_path().exists()


def _account_config_path() -> Path:
    """영속 계정 설정(blog_id 등) — CLAUDE.md 규칙상 config/ 에 둔다.

    비밀번호는 절대 저장하지 않는다 (쿠키만 OS 권한 폴더에 저장).
    """
    project_root = Path(__file__).resolve().parents[4]  # scripts/autopost/skills/.claude/<root>
    return project_root / "config" / "autopost_config.json"


def load_account_config() -> dict:
    """저장된 계정 설정 로드. 없으면 빈 dict."""
    path = _account_config_path()
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_account_config(blog_id: str = None, naver_id: str = None) -> None:
    """blog_id / naver_id 힌트를 config/autopost_config.json 에 병합 저장.

    한 번 성공하면 이후엔 환경변수 없이도 쿠키 로그인으로 진행할 수 있도록
    글쓰기에 필요한 blog_id 를 영속화한다. 비밀번호는 저장하지 않는다.
    """
    path = _account_config_path()
    data = load_account_config()
    if blog_id:
        data["blog_id"] = blog_id
    if naver_id:
        data["naver_id"] = naver_id
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[session] 계정 설정 저장: {path}")
    except Exception as e:
        print(f"[session] 계정 설정 저장 실패: {e}")


def _log_dir() -> Path:
    project_root = Path(__file__).resolve().parents[4]  # scripts/autopost/skills/.claude/<root>
    d = project_root / "docs" / "20.working" / "22.state" / ".autopost_log" / datetime.now().strftime("%Y%m%d_%H%M")
    d.mkdir(parents=True, exist_ok=True)
    return d


def _profile_dir() -> Path:
    base = Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".config" / "naverblog" / "chrome-profile"
    base.mkdir(parents=True, exist_ok=True)
    return base


def build_driver(headless: bool = False) -> webdriver.Chrome:
    """봇 탐지 우회 옵션 적용된 Chrome WebDriver.

    자동화 전용 user-data-dir 를 영구 지정 → 한 번 디바이스 등록(2중 인증 통과)하면
    이후 같은 디바이스로 인식되어 추가 인증 없이 글쓰기 페이지 진입 가능.
    """
    options = webdriver.ChromeOptions()
    profile_dir = _profile_dir()
    options.add_argument(f"--user-data-dir={profile_dir}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )
    options.add_experimental_option(
        "prefs", {"profile.default_content_setting_values.clipboard": 1}
    )
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    if headless:
        options.add_argument("--headless=new")

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    driver.maximize_window()
    return driver


def save_cookies(driver) -> None:
    """네이버 로그인 쿠키 저장."""
    cookies = driver.get_cookies()
    path = _cookie_path()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cookies, f, ensure_ascii=False, indent=2)
    print(f"[session] 쿠키 저장: {path}")


def load_cookies(driver) -> bool:
    """저장된 쿠키 로드. 없거나 실패하면 False."""
    path = _cookie_path()
    if not path.exists():
        return False
    try:
        with open(path, "r", encoding="utf-8") as f:
            cookies = json.load(f)
        for cookie in cookies:
            if "expiry" in cookie:
                cookie["expiry"] = int(cookie["expiry"])
            try:
                driver.add_cookie(cookie)
            except Exception as e:
                print(f"[session] cookie add error: {e}")
        print(f"[session] 쿠키 로드 성공 ({len(cookies)}개)")
        return True
    except Exception as e:
        print(f"[session] 쿠키 로드 실패: {e}")
        return False


def is_logged_in(driver) -> bool:
    """www.naver.com 방문 후 로그인 상태 판정."""
    try:
        driver.get("https://www.naver.com")
        time.sleep(2)
        src = driver.page_source
        return ("로그아웃" in src) or ("내정보" in src) or ("MY" in src)
    except Exception:
        return False


def manual_login(driver, naver_id: str, naver_pw: str, max_2fa_wait: int = 300) -> bool:
    """ID/PW로 로그인. 2FA는 사용자가 휴대폰에서 처리할 때까지 폴링.

    봇 탐지 우회를 위해 send_keys 대신 pyperclip 클립보드 + Ctrl+V 사용.
    """
    print("[session] 로그인 페이지 이동...")
    driver.get("https://nid.naver.com/nidlogin.login")
    time.sleep(2)

    print("[session] ID 입력...")
    id_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "id"))
    )
    id_input.click()
    time.sleep(0.5)
    pyperclip.copy(naver_id)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
    time.sleep(0.5)

    print("[session] PW 입력...")
    pw_input = driver.find_element(By.ID, "pw")
    pw_input.click()
    time.sleep(0.5)
    pyperclip.copy(naver_pw)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
    time.sleep(0.5)

    print("[session] 로그인 버튼 클릭...")
    driver.find_element(By.ID, "log.login").click()
    time.sleep(3)

    waited = 0
    while waited < max_2fa_wait:
        url = driver.current_url
        if "nidlogin" not in url and "nid.naver.com" not in url:
            print("[session] 로그인 완료")
            save_cookies(driver)
            return True
        if waited == 0:
            screenshot = _log_dir() / "2fa_required.png"
            try:
                driver.save_screenshot(str(screenshot))
            except Exception:
                pass
            print(
                "[WARN][session] 2FA 필요 — 휴대폰에서 인증을 완료해주세요. "
                f"(스크린샷: {screenshot})"
            )
        print(f"[session] 2FA 대기 중... ({waited}s / {max_2fa_wait}s)")
        time.sleep(2)
        waited += 2

    print("[session] 로그인 실패 (2FA 시간 초과)")
    return False


def load_or_login(driver, naver_id: str, naver_pw: str) -> bool:
    """쿠키 로그인 우선, 실패 시 ID/PW 로그인. 성공하면 True."""
    print("[session] 쿠키 로그인 시도...")
    driver.get("https://www.naver.com")
    time.sleep(1)

    if load_cookies(driver):
        driver.refresh()
        time.sleep(2)
        if is_logged_in(driver):
            print("[session] 쿠키 로그인 성공")
            return True
        print("[session] 쿠키 만료 — 일반 로그인으로 전환")

    if not (naver_id and naver_pw):
        print(
            "[session] 쿠키가 만료되어 재로그인이 필요합니다. "
            "환경변수 NAVER_ID / NAVER_PW 를 설정한 뒤 다시 실행하세요."
        )
        return False

    return manual_login(driver, naver_id, naver_pw)
