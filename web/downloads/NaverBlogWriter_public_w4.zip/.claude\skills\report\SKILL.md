---
name: report
description: 전체 분석 결과를 고객용 HTML 리포트 랜딩 페이지로 생성한다. '/report', '리포트 생성' 요청 시 사용.
model: opus
allowed-tools:
  - Read
  - Write
  - Glob
  - Bash
---

# 블로그 분석 리포트 생성

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- HTML 리포트: `docs/30.output/33.reports/{blog_id}_report_{YYYYMMDD}.html` (이미지: `images/`)
- 분석 데이터는 읽기: `docs/30.output/32.reviews/`

전체 분석 결과를 고객용 HTML 랜딩 페이지로 생성합니다.

## 사용법

- `/report <블로그>` → HTML 리포트 생성
- `/report <블로그> open` → 생성 후 브라우저에서 열기
- `/report list` → 생성된 리포트 목록
- 인자 없음 → 기존 리포트 목록 + 생성 가능 블로그 표시

## 인자 파싱 (최우선)

**패턴:**
- `list` → 생성된 리포트 목록 표시
- `<별명/ID>` → 해당 블로그 리포트 생성
- `<별명/ID> open` → 생성 후 브라우저에서 열기
- 인자 없음 → 아래 "자동 안내" 로직 실행

**별명/ID 매칭:** `report_cli.py resolve "<별명/ID>"` 사용.

## 스크립트 & 템플릿 (결정적 작업)

HTML 생성은 `report_cli.py`가 전체분석 데이터(`32.reviews`)로 `template/report.html`을 채워 만든다. LLM(opus)은 이미지 프롬프트(창작)만 제공한다.

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter"
python -X utf8 ".claude/skills/report/scripts/report_cli.py" resolve "<블로그>"  # blog_id
python -X utf8 ".claude/skills/report/scripts/report_cli.py" list                # 리포트+생성가능 목록
python -X utf8 ".claude/skills/report/scripts/report_cli.py" generate <blog>     # 33.reports/에 HTML 생성
```

디자인 수정이 필요하면 `template/report.html`을 편집한다.

## 자동 안내 (인자 없음일 때)

`report_cli.py list` 실행 → 생성된 리포트 + 전체분석 보유(생성 가능) 블로그 목록 출력. 그 뒤 `/report <블로그>` 안내.

## 실행 흐름

### 1. 분석 데이터 확인 + HTML 생성 (스크립트)

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/report/scripts/report_cli.py" generate <blog>
```
스크립트가 최신 전체분석(`32.reviews/{blog}_전체분석_*.md`)을 읽어 점수 막대·주제 차트·성장/개선/추천액션이 채워진 HTML을 `33.reports/`에 생성하고 경로를 출력한다. (전체분석 없으면 안내 → `/analyze` 먼저)

### 2. 이미지 프롬프트 생성
리포트에 사용할 이미지 4개의 프롬프트 제공:

**1. 히어로 이미지 (상단 배너)**
```
[블로그 주제]를 상징하는 미니멀한 일러스트.
파스텔 톤 배경, 깔끔한 아이콘 스타일, 16:9 비율.
예: 공동구매/벤더사 → 악수하는 두 손과 상품 박스
```

**2. 성장 그래프 배경**
```
상승 곡선을 추상적으로 표현한 그래픽.
그라데이션 배경, 미니멀 라인아트, 긍정적인 느낌.
색상: [블로그 테마 컬러]
```

**3. 주제별 섹션 아이콘**
```
[각 주제]를 나타내는 심플 아이콘 세트.
일관된 스타일, 단색 또는 2색, 64x64 사이즈.
```

**4. CTA 배경 이미지**
```
행동을 유도하는 밝고 에너지 넘치는 배경.
추상적 패턴, 그라데이션, 미래지향적 느낌.
```

### 3. HTML 생성 (자동)

HTML은 1단계 `report_cli.py generate`가 `template/report.html`을 데이터로 채워 생성한다.
구조/디자인 수정이 필요하면 `template/report.html`을 편집한다. (점수 막대·주제 차트·성장/개선/추천액션은 스크립트가 자동 채움)
### 4. 이미지 프롬프트 출력

리포트 생성 후, 사용자가 AI로 이미지를 생성할 수 있도록 프롬프트 제공:

```
## 이미지 프롬프트

### 1. 히어로 이미지 (1920x600)
{구체적인 프롬프트}

### 2. 성장 그래프 배경 (1200x400)
{구체적인 프롬프트}

### 3. 주제 아이콘 (512x512, 투명 배경)
{구체적인 프롬프트}

### 4. CTA 배경 (1200x300)
{구체적인 프롬프트}

---
이미지 생성 후 `docs/30.output/33.reports/images/` 폴더에 저장하세요.
```

## 출력 형식

```
## 리포트 생성 완료

| 항목 | 내용 |
|------|------|
| 파일 | docs/30.output/33.reports/{filename}.html |
| 블로그 | {blog_id} ({blog_name}) |
| 종합 점수 | {score}/100 |

### 이미지 프롬프트

#### 1. 히어로 이미지
{프롬프트}

#### 2. 성장 그래프 배경
{프롬프트}

#### 3. 주제 아이콘
{프롬프트}

#### 4. CTA 배경
{프롬프트}

---
💡 이미지 생성 후 HTML 파일의 img src를 수정하세요.
💡 `/report {blog_id} open` - 브라우저에서 열기
```

## 디자인 컨셉

**색상 팔레트:**
- 메인: #4F46E5 (인디고)
- 서브: #10B981 (에메랄드)
- 배경: #F9FAFB (라이트 그레이)
- 텍스트: #1F2937 (다크 그레이)

**폰트:**
- 제목: Pretendard Bold
- 본문: Pretendard Regular

**스타일:**
- 미니멀, 모던
- 카드 기반 레이아웃
- 충분한 여백
- 부드러운 그림자

## 참조 파일

- `docs/30.output/32.reviews/{blog_id}_전체분석_*.md`: 분석 데이터
- `docs/30.output/33.reports/`: 리포트 저장 폴더
- `docs/30.output/33.reports/images/`: 이미지 저장 폴더
