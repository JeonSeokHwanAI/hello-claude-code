"""
save 스킬용: 리뷰 저장 경로/목록 (IO 전용)

파일명 sanitize·목록(list)만 처리한다. 저장할 분석 내용은 대화(LLM)에서 오고,
파일 구조는 review 의 template/특정글분석.md(또는 전체분석.md) 양식을 재사용한다.

사용법:
    python save_cli.py path <blog_id> "<제목>"   # 저장 경로(파일명 sanitize) 출력
    python save_cli.py list                      # 저장된 리뷰 목록
"""

import os
import re
import glob
import argparse

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
REVIEWS = os.path.join(ROOT, "docs", "30.output", "32.reviews")


def sanitize(name):
    name = re.sub(r'[\\/:*?"<>|]', "", name.strip())
    name = re.sub(r"\s+", "_", name)
    return name[:60] or "review"


def fm_value(text, key):
    m = re.search(rf'(?m)^{key}:\s*"?(.+?)"?\s*$', text)
    return m.group(1) if m else ""


def cmd_path(blog_id, title):
    os.makedirs(REVIEWS, exist_ok=True)
    print(os.path.join(REVIEWS, f"{blog_id}_{sanitize(title)}.md"))


def cmd_list():
    files = sorted(glob.glob(os.path.join(REVIEWS, "*.md")))
    if not files:
        print("저장된 리뷰가 없습니다.")
        return
    print(f"## 저장된 리뷰 ({len(files)}개)\n")
    print("| # | 블로그 | 제목 | 점수 | 리뷰일 |")
    print("|---|--------|------|------|--------|")
    for i, f in enumerate(files, 1):
        with open(f, encoding="utf-8") as fh:
            head = fh.read(1500)
        blog = fm_value(head, "blog_id") or os.path.basename(f).split("_")[0]
        title = fm_value(head, "title") or "(전체분석)"
        score = fm_value(head, "score") or fm_value(head, "overall_score")
        date = fm_value(head, "reviewed_at") or fm_value(head, "analyzed_at")
        print(f"| {i} | {blog} | {title[:30]} | {score} | {date} |")


def main():
    ap = argparse.ArgumentParser(description="save 경로/목록 (IO 전용)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sp = sub.add_parser("path"); sp.add_argument("blog_id"); sp.add_argument("title")
    args = ap.parse_args()
    if args.cmd == "list":
        cmd_list()
    elif args.cmd == "path":
        cmd_path(args.blog_id, args.title)


if __name__ == "__main__":
    main()
