"""
persona 스킬용: 페르소나 CRUD/상태 조작 (IO 전용)

결정적 작업만 처리한다: 목록(list), 상태(status), 상세(show), 전환(use), 삭제(delete).
인터뷰 생성·블로그 스타일 분석·페르소나 문서 작성 등 창작은 LLM(opus)이 담당한다.

사용법:
    python persona_cli.py list                 # 등록된 페르소나 목록(+활성 표시)
    python persona_cli.py status               # 활성 페르소나 상세
    python persona_cli.py show <이름>           # 특정 페르소나 상세 (부분 매칭)
    python persona_cli.py use <이름>            # 활성 전환 (부분 매칭)
    python persona_cli.py delete <이름>         # 삭제 (+활성이면 활성 해제)
"""

import os
import sys
import json
import argparse
from datetime import datetime

# 이 스크립트는 .claude/skills/persona/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
PERSONA_DIR = os.path.join(ROOT, "config", "personas")
ACTIVE = os.path.join(ROOT, "docs", "20.working", "22.state", ".active_persona.json")


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def list_names():
    if not os.path.isdir(PERSONA_DIR):
        return []
    return sorted(os.path.splitext(f)[0] for f in os.listdir(PERSONA_DIR) if f.endswith(".json"))


def get_active():
    if os.path.exists(ACTIVE):
        try:
            return read_json(ACTIVE).get("active")
        except Exception:
            return None
    return None


def persona_path(name):
    return os.path.join(PERSONA_DIR, f"{name}.json")


def resolve(name):
    """부분 매칭으로 페르소나 이름 해석. 정확히 하나면 반환, 없거나 모호하면 종료."""
    names = list_names()
    if name in names:
        return name
    cand = [n for n in names if name.lower() in n.lower()]
    if len(cand) == 1:
        return cand[0]
    if not cand:
        sys.exit(f"'{name}' 페르소나를 찾을 수 없습니다. (등록: {', '.join(names) or '없음'})")
    sys.exit(f"'{name}' 후보가 여러 개입니다: {', '.join(cand)} — 더 구체적으로 지정하세요.")


def show_one(name):
    p = read_json(persona_path(name))
    prof = p.get("profile", {})
    style = p.get("style", {})
    print(f"## 페르소나: {name}\n")
    print("| 항목 | 내용 |")
    print("|------|------|")
    print(f"| 닉네임 | {prof.get('nickname','')} |")
    print(f"| 톤 | {style.get('tone','')} |")
    print(f"| 어투 | {style.get('formality','')} |")
    print(f"| 구조 | {style.get('content_structure','')} |")
    print(f"| 평균 길이 | {style.get('average_length','')} |")
    if p.get("blog_id"):
        print(f"| 블로그 | {p.get('blog_id')} ({p.get('blog_name','')}) |")
    print(f"| 소스 | {p.get('source','')} |")
    print(f"| context_file | {p.get('context_file','')} |")


def cmd_list():
    names = list_names()
    active = get_active()
    if not names:
        print("등록된 페르소나가 없습니다.")
        return
    print(f"## 등록된 페르소나 ({len(names)}개)\n")
    print("| # | 이름 | 닉네임 | 소스 | 활성 |")
    print("|---|------|--------|------|------|")
    for i, n in enumerate(names, 1):
        p = read_json(persona_path(n))
        nick = p.get("profile", {}).get("nickname", "")
        mark = "✅" if n == active else ""
        print(f"| {i} | {n} | {nick} | {p.get('source','')} | {mark} |")


def cmd_status():
    active = get_active()
    if not active:
        print("활성 페르소나가 없습니다. /persona use <이름> 으로 설정하세요.")
        return
    print("(현재 활성 페르소나)")
    show_one(active)


def cmd_use(name):
    target = resolve(name)
    prev = get_active()
    os.makedirs(os.path.dirname(ACTIVE), exist_ok=True)
    with open(ACTIVE, "w", encoding="utf-8") as f:
        json.dump({"active": target, "activated_at": datetime.now().isoformat()},
                  f, ensure_ascii=False, indent=2)
    print(f"활성 페르소나 전환: {prev or '없음'} → {target}")


def cmd_delete(name):
    target = resolve(name)
    os.remove(persona_path(target))
    msg = f"삭제 완료: {target}"
    if get_active() == target and os.path.exists(ACTIVE):
        os.remove(ACTIVE)
        msg += " (활성 페르소나였으므로 활성 해제됨)"
    print(msg)


def main():
    ap = argparse.ArgumentParser(description="페르소나 CRUD/상태 (IO 전용)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sub.add_parser("status")
    for c in ("show", "use", "delete"):
        sp = sub.add_parser(c)
        sp.add_argument("name")
    args = ap.parse_args()

    {"list": lambda: cmd_list(),
     "status": lambda: cmd_status(),
     "show": lambda: show_one(resolve(args.name)),
     "use": lambda: cmd_use(args.name),
     "delete": lambda: cmd_delete(args.name)}[args.cmd]()


if __name__ == "__main__":
    main()
