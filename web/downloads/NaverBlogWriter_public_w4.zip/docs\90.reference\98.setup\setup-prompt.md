# 새 폴더 Claude Code 초기 구성 프롬프트

> 새 폴더를 만들 때마다 Claude Code에 그대로 붙여넣어 사용하세요.
> 더 편하게 쓰려면 `/init-workspace` Skill로 등록되어 있습니다 (`~/.claude/skills/init-workspace/`).

---

## 📋 복사용 프롬프트

```
이 폴더를 Claude Code 작업 공간으로 초기 구성해줘. 다음 두 가지를 만들어줘.

1. 루트에 `CLAUDE.md` 파일 생성
   - `# {폴더명}` 제목과 "TODO: 프로젝트 설명" 한 줄
   - 아래 섹션을 비어 있는 상태로 미리 만들어줘:
     - ## 프로젝트 개요
     - ## 폴더 구조
     - ## 작업 규칙 (Claude가 따라야 할 규칙)
     - ## 자주 쓰는 명령
   - 마지막에 "이 문서는 Claude가 매 대화 시작 시 자동으로 읽는다"는 안내 한 줄 추가

2. `.claude/skills/` 폴더 생성
   - `.claude/skills/.gitkeep` 빈 파일 함께 생성 (빈 폴더는 git에 안 올라감)
   - `.claude/skills/README.md`에 "이 폴더에 Skill을 추가하면 Claude Code가 자동으로 인식한다"는 한 줄 안내

완료되면 생성된 파일 트리를 보여줘.
```

---

## 💡 사용 방법

1. 새 폴더 만들기 → VS Code로 열기
2. Claude Code 열고 위 프롬프트 붙여넣기 (또는 `/init-workspace` 실행)
3. 끝

---

## 🛠️ `/init-workspace` Skill 내 PC에 설치하기

위 프롬프트를 매번 복사·붙여넣기 하지 않고 `/init-workspace` 한 줄로 실행하려면, 강의 repo에 들어있는 Skill을 본인 PC의 사용자 Skill 폴더로 복사하면 됩니다.

### 📍 사용자 Skill 폴더 위치

| OS | 경로 |
|----|------|
| Windows | `%USERPROFILE%\.claude\skills\` |
| Mac / Linux | `~/.claude/skills/` |

### 📥 설치 명령

**Windows (PowerShell)**
```powershell
# 1) 사용자 Skill 폴더가 없으면 만든다
New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills" | Out-Null

# 2) 강의 repo의 Skill을 복사한다 (강의 repo 폴더에서 실행)
Copy-Item -Recurse -Force .claude\skills\init-workspace "$env:USERPROFILE\.claude\skills\"
```

**Mac / Linux**
```bash
mkdir -p ~/.claude/skills
cp -r .claude/skills/init-workspace ~/.claude/skills/
```

### ✅ 설치 확인

1. Claude Code를 **재시작** (Skill은 시작 시 한 번만 로드됨)
2. 아무 새 폴더를 열고 Claude Code에서 입력:
   ```
   /init-workspace
   ```
3. `CLAUDE.md`와 `.claude/skills/` 가 자동 생성되면 성공

### 🔄 Skill 업데이트

강사가 Skill을 수정해서 강의 repo에 새 버전을 올리면, `git pull` 후 위 복사 명령을 한 번 더 실행하면 최신 버전으로 갱신됩니다.
