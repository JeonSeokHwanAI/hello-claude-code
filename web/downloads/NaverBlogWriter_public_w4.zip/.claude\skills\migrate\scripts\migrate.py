# -*- coding: utf-8 -*-
"""
NaverBlogWriter 이관 엔진.

기존 프로젝트(구 `Naver Scraping`)의 데이터를 현재 프로젝트의 새 폴더 구조로 옮긴다.
두 프로젝트는 폴더 구성이 상이하므로, 단순 복사가 아니라 항목별 매핑 + 경로 재작성을 수행한다.

사용 예:
    python migrate.py --source "G:/내 드라이브/Source/Naver Scraping" --list
    python migrate.py --source "G:/..." --items all
    python migrate.py --source "G:/..." --items posts,reviews,personas
    python migrate.py --source "G:/..." --items all --dry-run
    python migrate.py --source "G:/..." --items all --mode move

타겟 루트는 이 스크립트 위치(.claude/skills/migrate/scripts/)에서 4단계 상위로 계산한다.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

# Windows 콘솔(cp949)에서도 한글·기호 출력이 깨지지 않도록 UTF-8 강제
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

# .claude/skills/migrate/scripts/migrate.py -> 루트는 parents[4]
# (parents: 0=scripts, 1=migrate, 2=skills, 3=.claude, 4=프로젝트 루트)
TARGET_ROOT = Path(__file__).resolve().parents[4]

# 구→신 context 경로 접두 (페르소나 context_file 재작성용)
OLD_CONTEXT_PREFIX = "docs/context/"
NEW_CONTEXT_PREFIX = "docs/90.reference/93.context/"


class Stats:
    def __init__(self):
        self.copied = 0
        self.skipped = 0
        self.merged = 0
        self.rewritten = 0
        self.notes = []

    def note(self, msg):
        self.notes.append(msg)


def _ensure_dir(p: Path, dry: bool):
    if not dry:
        p.mkdir(parents=True, exist_ok=True)


def _place(src: Path, dst: Path, dry: bool, mode: str, st: Stats, *, overwrite=False):
    """파일 하나를 dst로 복사/이동. 이미 있으면(overwrite=False) 건너뜀."""
    if dst.exists() and not overwrite:
        st.skipped += 1
        st.note(f"  - skip(이미 존재): {dst.relative_to(TARGET_ROOT)}")
        return
    _ensure_dir(dst.parent, dry)
    if not dry:
        if mode == "move":
            shutil.move(str(src), str(dst))
        else:
            shutil.copy2(str(src), str(dst))
    st.copied += 1
    tag = "move" if mode == "move" else "copy"
    st.note(f"  + {tag}: {src.name} -> {dst.relative_to(TARGET_ROOT)}")


def _copy_glob(src_dir: Path, pattern: str, dst_dir: Path, dry, mode, st):
    if not src_dir.exists():
        st.note(f"  (원본 없음: {src_dir})")
        return
    for f in sorted(src_dir.glob(pattern)):
        if f.is_file():
            _place(f, dst_dir / f.name, dry, mode, st)


# ----- 항목별 핸들러 -----

def mig_blogs(src: Path, dry, mode, st):
    """config/blogs.json 을 타겟에 병합 (원본 우선, 타겟 기존 키 유지)."""
    s = src / "config" / "blogs.json"
    t = TARGET_ROOT / "config" / "blogs.json"
    if not s.exists():
        st.note("  (원본 blogs.json 없음)")
        return
    src_data = json.loads(s.read_text(encoding="utf-8"))
    tgt_data = json.loads(t.read_text(encoding="utf-8")) if t.exists() else {}
    before = len(tgt_data)
    tgt_data.update(src_data)  # 원본 우선
    added = len(tgt_data) - before
    if not dry:
        t.write_text(json.dumps(tgt_data, ensure_ascii=False, indent=2), encoding="utf-8")
    st.merged += 1
    st.note(f"  ~ blogs.json 병합: 원본 {len(src_data)}개 -> 타겟 총 {len(tgt_data)}개 (신규 {added})")


def mig_personas(src: Path, dry, mode, st):
    """페르소나 JSON 복사 + context_file 옛 경로 재작성."""
    s_dir = src / "config" / "personas"
    t_dir = TARGET_ROOT / "config" / "personas"
    if not s_dir.exists():
        st.note("  (원본 personas 없음)")
        return
    for f in sorted(s_dir.glob("*.json")):
        dst = t_dir / f.name
        if dst.exists():
            st.skipped += 1
            st.note(f"  - skip(이미 존재): personas/{f.name}")
            continue
        data = json.loads(f.read_text(encoding="utf-8"))
        cf = data.get("context_file")
        if isinstance(cf, str) and cf.startswith(OLD_CONTEXT_PREFIX):
            data["context_file"] = NEW_CONTEXT_PREFIX + cf[len(OLD_CONTEXT_PREFIX):]
            st.rewritten += 1
            st.note(f"    ↳ context_file 경로 수정: {data['context_file']}")
        _ensure_dir(t_dir, dry)
        if not dry:
            dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        st.copied += 1
        st.note(f"  + persona: {f.name}")


def mig_me(src: Path, dry, mode, st):
    """레거시 me.json."""
    s = src / "config" / "me.json"
    if s.exists():
        _place(s, TARGET_ROOT / "config" / "me.json", dry, mode, st)
    else:
        st.note("  (원본 me.json 없음)")


def mig_state(src: Path, dry, mode, st):
    """런타임 상태 숨김 JSON -> docs/20.working/22.state/."""
    s_dir = src / "config"
    t_dir = TARGET_ROOT / "docs" / "20.working" / "22.state"
    names = [
        ".active_persona.json", ".last_search.json", ".last_searches.json",
        ".favorites.json", ".clips_index.json", ".blogger_history.json",
    ]
    for n in names:
        f = s_dir / n
        if f.exists():
            _place(f, t_dir / n, dry, mode, st)


def mig_posts(src, dry, mode, st):
    _copy_glob(src / "docs" / "blog", "*.md",
               TARGET_ROOT / "docs" / "30.output" / "31.posts", dry, mode, st)


def mig_reviews(src, dry, mode, st):
    _copy_glob(src / "docs" / "reviews", "*.md",
               TARGET_ROOT / "docs" / "30.output" / "32.reviews", dry, mode, st)


def mig_reports(src, dry, mode, st):
    base = src / "docs" / "reports"
    dst = TARGET_ROOT / "docs" / "30.output" / "33.reports"
    _copy_glob(base, "*.html", dst, dry, mode, st)
    _copy_glob(base / "images", "*", dst / "images", dry, mode, st)


def mig_clips(src, dry, mode, st):
    _copy_glob(src / "docs" / "clips", "*.md",
               TARGET_ROOT / "docs" / "90.reference" / "92.clips", dry, mode, st)


def mig_context(src, dry, mode, st):
    _copy_glob(src / "docs" / "context", "*.md",
               TARGET_ROOT / "docs" / "90.reference" / "93.context", dry, mode, st)


def mig_archive(src, dry, mode, st):
    """docs/archive/* -> 91.archive (이름이 같은 기존 파일은 건너뜀)."""
    s_dir = src / "docs" / "archive"
    t_dir = TARGET_ROOT / "docs" / "90.reference" / "91.archive"
    if not s_dir.exists():
        st.note("  (원본 archive 없음)")
        return
    for f in sorted(s_dir.glob("*")):
        if f.is_file():
            _place(f, t_dir / f.name, dry, mode, st)  # overwrite=False -> 중복 자동 skip


def mig_scraped(src, dry, mode, st):
    """output/{blog_id}/*.json -> 21.scraped/{blog_id}/. _old/디버그 폴더 제외."""
    s_out = src / "output"
    t_dir = TARGET_ROOT / "docs" / "20.working" / "21.scraped"
    if not s_out.exists():
        st.note("  (원본 output 없음)")
        return
    skip_dirs = {"_old", "images"}
    for d in sorted(s_out.iterdir()):
        if d.is_dir() and d.name not in skip_dirs:
            for f in sorted(d.glob("*.json")):
                _place(f, t_dir / d.name / f.name, dry, mode, st)


def mig_monthly(src, dry, mode, st):
    """output/monthly_blogs_*.json -> 21.scraped/monthly/."""
    _copy_glob(src / "output", "monthly_blogs_*.json",
               TARGET_ROOT / "docs" / "20.working" / "21.scraped" / "monthly", dry, mode, st)


# 항목 레지스트리: key -> (라벨, 설명, 핸들러)
ITEMS = {
    "blogs":    ("블로그 목록", "config/blogs.json 병합 (원본 우선)", mig_blogs),
    "personas": ("페르소나", "config/personas/*.json + context_file 경로 수정", mig_personas),
    "me":       ("내 프로필(레거시)", "config/me.json", mig_me),
    "state":    ("런타임 상태", "config/.* 숨김 JSON -> 22.state/", mig_state),
    "posts":    ("작성한 글", "docs/blog -> 31.posts/", mig_posts),
    "reviews":  ("리뷰·분석", "docs/reviews -> 32.reviews/", mig_reviews),
    "reports":  ("HTML 리포트", "docs/reports(+images) -> 33.reports/", mig_reports),
    "clips":    ("클리핑", "docs/clips -> 92.clips/", mig_clips),
    "context":  ("글쓰기 참조", "docs/context -> 93.context/", mig_context),
    "archive":  ("보관 문서", "docs/archive -> 91.archive/ (중복 skip)", mig_archive),
    "scraped":  ("스크랩 원본", "output/{blog_id} -> 21.scraped/{blog_id}/", mig_scraped),
    "monthly":  ("이달의 블로그", "output/monthly_*.json -> 21.scraped/monthly/", mig_monthly),
}

# "all" 실행 순서
ALL_ORDER = ["blogs", "personas", "me", "state", "posts", "reviews",
             "reports", "clips", "context", "archive", "scraped", "monthly"]


def print_items():
    print("이관 가능 항목:")
    for k in ALL_ORDER:
        label, desc, _ = ITEMS[k]
        print(f"  {k:<10} {label:<14} {desc}")
    print('\n  all        전체           위 항목을 모두 이관')


def main():
    ap = argparse.ArgumentParser(description="NaverBlogWriter 이관 엔진")
    ap.add_argument("--source", help="기존(구) 프로젝트 폴더 경로")
    ap.add_argument("--items", default="", help="쉼표구분 항목 또는 all")
    ap.add_argument("--mode", choices=["copy", "move"], default="copy", help="기본 copy(원본 보존)")
    ap.add_argument("--dry-run", action="store_true", help="실제 변경 없이 계획만 출력")
    ap.add_argument("--list", action="store_true", help="이관 항목 목록 출력")
    args = ap.parse_args()

    if args.list or not args.items:
        print_items()
        if not args.items:
            return 0

    if not args.source:
        print("ERROR: --source 경로가 필요합니다.", file=sys.stderr)
        return 2
    src = Path(args.source)
    if not src.exists():
        print(f"ERROR: 원본 경로가 없습니다: {src}", file=sys.stderr)
        return 2

    if args.items.strip() == "all":
        keys = list(ALL_ORDER)
    else:
        keys = [k.strip() for k in args.items.split(",") if k.strip()]
    unknown = [k for k in keys if k not in ITEMS]
    if unknown:
        print(f"ERROR: 알 수 없는 항목: {unknown}", file=sys.stderr)
        print_items()
        return 2

    st = Stats()
    print(f"{'[DRY-RUN] ' if args.dry_run else ''}원본: {src}")
    print(f"타겟: {TARGET_ROOT}")
    print(f"모드: {args.mode} | 항목: {', '.join(keys)}\n")

    for k in keys:
        label, _, handler = ITEMS[k]
        print(f"■ {k} ({label})")
        handler(src, args.dry_run, args.mode, st)

    print("\n" + "=" * 50)
    for n in st.notes:
        print(n)
    print("=" * 50)
    print(f"결과: 복사/이동 {st.copied} · 건너뜀 {st.skipped} · "
          f"병합 {st.merged} · 경로수정 {st.rewritten}"
          f"{'  (DRY-RUN: 실제 변경 없음)' if args.dry_run else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
