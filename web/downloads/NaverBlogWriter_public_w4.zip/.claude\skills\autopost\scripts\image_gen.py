"""이미지 생성 어댑터.

현재 지원: gemini_web (attach된 Chrome의 gemini.google.com 탭 활용).
향후: dalle, imagen 등 API 어댑터 추가 가능.

흐름:
  parse_image_prompts(md) → 각 프롬프트 → Gemini 전송 → blob → canvas → PNG 저장
  파일명: {md_stem}__{NN}_{label}.png  (라벨: 도입/본문N/마무리)
  저장 위치: docs/10.input/gemini/

전제 (gemini_web): Chrome --remote-debugging-port=9222, gemini.google.com 탭 열림.
"""
from __future__ import annotations

import base64
import socket
import time
from pathlib import Path
from typing import Callable, List, Optional

import pyperclip
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

from image_prompts import ImagePrompt, parse_image_prompts

MIN_IMG_PX = 400
PER_PROMPT_TIMEOUT = 150
GEMINI_DEBUG_PORT = 9222

# 기존 일반 Chrome이 떠 있으면 --remote-debugging-port 플래그가 무시되어 포트가 안 열린다.
# 그래서 attach 시도 전에 포트를 먼저 두드려 보고, 막혀 있으면 "기존 Chrome 종료 → 디버그 모드 재실행"을 안내한다.
_CHROME_LAUNCH_HINT = (
    "Chrome 디버그 모드(포트 {port})에 연결할 수 없습니다.\n"
    "  1) 먼저 실행 중인 일반 Chrome 창을 모두 종료하세요 (작업 표시줄 + 트레이의 백그라운드 Chrome 포함).\n"
    "     ⚠️ 기존 Chrome이 떠 있으면 아래 명령의 --remote-debugging-port 플래그가 무시되어 포트 {port}가 열리지 않습니다.\n"
    "  2) 그 뒤 디버그 모드로 다시 띄우고 gemini.google.com 탭을 여세요:\n"
    "       chrome.exe --remote-debugging-port={port} "
    "--user-data-dir=\"%LOCALAPPDATA%\\Google\\Chrome\\User Data\" https://gemini.google.com\n"
    "  3) 다시 generate-images 를 실행하세요."
)


def _debug_port_open(host: str = "127.0.0.1", port: int = GEMINI_DEBUG_PORT,
                     timeout: float = 1.0) -> bool:
    """디버그 모드 Chrome의 원격 디버깅 포트가 열려 있는지 TCP로 확인."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _project_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _gemini_out_dir() -> Path:
    p = _project_root() / "docs" / "10.input" / "gemini"
    p.mkdir(parents=True, exist_ok=True)
    return p


# ---------- Gemini 웹 어댑터 ----------

def _attach_gemini():
    options = webdriver.ChromeOptions()
    options.add_experimental_option("debuggerAddress", f"127.0.0.1:{GEMINI_DEBUG_PORT}")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    for handle in driver.window_handles:
        try:
            driver.switch_to.window(handle)
            if "gemini.google.com" in driver.current_url:
                return driver
        except Exception:
            continue
    raise RuntimeError(
        "Gemini 탭을 찾지 못했습니다. Chrome을 디버그 모드로 띄우고 gemini.google.com 탭을 열어주세요:\n"
        f"  chrome.exe --remote-debugging-port={GEMINI_DEBUG_PORT} "
        "--user-data-dir=\"%LOCALAPPDATA%\\Google\\Chrome\\User Data\""
    )


def _find_prompt_box(driver):
    for el in driver.find_elements(By.CSS_SELECTOR, "[contenteditable='true']"):
        if not el.is_displayed():
            continue
        aria = el.get_attribute("aria-label") or ""
        cls = el.get_attribute("class") or ""
        if "프롬프트" in aria or "prompt" in aria.lower() or "ql-editor" in cls:
            return el
    raise RuntimeError("Gemini 프롬프트 입력창을 찾지 못함")


def _submit(driver, prompt: str) -> None:
    box = _find_prompt_box(driver)
    box.click()
    time.sleep(0.4)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
    ActionChains(driver).send_keys(Keys.DELETE).perform()
    time.sleep(0.3)
    pyperclip.copy(prompt)
    ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
    time.sleep(0.8)
    ActionChains(driver).send_keys(Keys.ENTER).perform()


def _scan_big_srcs(driver, min_px: int = MIN_IMG_PX) -> set:
    out = set()
    for img in driver.find_elements(By.CSS_SELECTOR, "img"):
        try:
            src = img.get_attribute("src") or ""
            if not src:
                continue
            w = int(img.get_attribute("naturalWidth") or 0)
            h = int(img.get_attribute("naturalHeight") or 0)
            if w >= min_px and h >= min_px:
                out.add(src)
        except Exception:
            continue
    return out


def _wait_new_imgs(driver, baseline_srcs: set, timeout: int) -> list:
    """baseline 이후 새로 등장한 큰 이미지 (element, src, w, h) 리스트."""
    start = time.time()
    stable = 0
    last = 0
    while time.time() - start < timeout:
        new_imgs = []
        for img in driver.find_elements(By.CSS_SELECTOR, "img"):
            try:
                src = img.get_attribute("src") or ""
                if not src or src in baseline_srcs:
                    continue
                w = int(img.get_attribute("naturalWidth") or 0)
                h = int(img.get_attribute("naturalHeight") or 0)
                if w >= MIN_IMG_PX and h >= MIN_IMG_PX:
                    new_imgs.append((img, src, w, h))
            except Exception:
                continue
        if len(new_imgs) != last:
            last = len(new_imgs)
            stable = 0
        elif new_imgs:
            stable += 1
            if stable >= 2:
                return new_imgs
        time.sleep(2)
    return []


def _save_blob_as_png(driver, img_el, dest: Path) -> bool:
    """img element를 canvas로 그려 PNG로 저장 (blob URL 우회)."""
    try:
        data_url = driver.execute_script(
            """
            var img = arguments[0];
            var canvas = document.createElement('canvas');
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            canvas.getContext('2d').drawImage(img, 0, 0);
            try { return canvas.toDataURL('image/png'); }
            catch (e) { return 'ERROR:' + e.message; }
            """,
            img_el,
        )
        if not data_url or data_url.startswith("ERROR:"):
            return False
        _, b64 = data_url.split(",", 1)
        dest.write_bytes(base64.b64decode(b64))
        return True
    except Exception:
        return False


# ---------- 공개 API ----------

def generate_from_markdown(
    md_path: Path,
    provider: str = "gemini_web",
    first_only: bool = True,
    log: Callable[[str], None] = print,
) -> List[Path]:
    """마크다운의 모든 Image Prompt → 이미지 생성 → 저장.

    Returns: 저장된 파일 경로 리스트.
    """
    if provider != "gemini_web":
        raise NotImplementedError(f"provider={provider!r} 아직 미지원. 현재: gemini_web")

    prompts = parse_image_prompts(md_path)
    if not prompts:
        log(f"[image_gen] Image Prompt 섹션 없음: {md_path}")
        return []

    out_dir = _gemini_out_dir()
    md_stem = md_path.stem
    log(f"[image_gen] {md_path.name}  ({len(prompts)}개 프롬프트)")

    # 프리플라이트: 디버그 포트가 닫혀 있으면(=기존 Chrome이 떠 있거나 디버그 모드 미실행)
    # selenium의 모호한 "cannot connect" 대신 종료/재실행 절차를 명확히 안내하고 중단한다.
    if not _debug_port_open():
        log(f"[image_gen] 디버그 포트 {GEMINI_DEBUG_PORT} 연결 불가 — 이미지 생성 중단")
        raise RuntimeError(_CHROME_LAUNCH_HINT.format(port=GEMINI_DEBUG_PORT))

    driver = _attach_gemini()
    log(f"[image_gen] Gemini attach OK: {driver.current_url}")

    saved: List[Path] = []
    for p in prompts:
        log(f"[image_gen] #{p.idx:02d}/{p.total} {p.label}  -- {p.title}")
        baseline = _scan_big_srcs(driver)
        try:
            _submit(driver, f"Generate an image: {p.prompt}")
        except Exception as e:
            log(f"  [실패] 전송: {e}")
            continue

        new_imgs = _wait_new_imgs(driver, baseline, timeout=PER_PROMPT_TIMEOUT)
        if not new_imgs:
            log(f"  [실패] 타임아웃 (응답 안 옴 또는 텍스트 응답)")
            continue

        to_save = new_imgs[:1] if first_only else new_imgs
        for i, (img, _src, w, h) in enumerate(to_save):
            suffix = "" if i == 0 else f"_v{i + 1}"
            dest = out_dir / f"{md_stem}__{p.idx:02d}_{p.label}{suffix}.png"
            if _save_blob_as_png(driver, img, dest):
                log(f"  [저장] {dest.name} ({dest.stat().st_size:,} 바이트)")
                saved.append(dest)
            else:
                log(f"  [실패] canvas 변환")
        time.sleep(2)

    log(f"[image_gen] 완료 — 저장 {len(saved)}개")
    return saved


def list_generated_for(md_path: Path) -> List[Path]:
    """주어진 md에 대해 이미 생성된 이미지 파일 목록 (idx 순)."""
    md_stem = md_path.stem
    out_dir = _gemini_out_dir()
    files = sorted(out_dir.glob(f"{md_stem}__*.png"))
    # 같은 idx의 _v2 같은 변형은 제외 (기본은 _v1만)
    primary = [f for f in files if "_v" not in f.stem.split("__")[-1]]
    return primary


if __name__ == "__main__":
    # 빠른 시험
    import sys
    if len(sys.argv) < 2:
        print("usage: py image_gen.py <md파일>")
        sys.exit(1)
    generate_from_markdown(Path(sys.argv[1]).resolve())
