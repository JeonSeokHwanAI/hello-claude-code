"""일회성 — 이미 떠있는 Chrome(디버그 포트 9222)에 attach해서 탭 목록 출력.

사용 전 사용자가 Chrome을 디버그 모드로 시작해야 함:
  & "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" `
    --remote-debugging-port=9222 `
    --user-data-dir="$env:LOCALAPPDATA\\Google\\Chrome\\User Data"

실행: py -3.12 _probe_attach.py
"""
from __future__ import annotations

import sys
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

options = webdriver.ChromeOptions()
options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")

try:
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
except Exception as e:
    print("=" * 60)
    print(f"[attach] Chrome attach 실패: {e}")
    print()
    print("Chrome을 디버그 모드로 먼저 띄워주세요:")
    print('  & "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" `')
    print("    --remote-debugging-port=9222 `")
    print('    --user-data-dir="$env:LOCALAPPDATA\\Google\\Chrome\\User Data"')
    print()
    print("기존 Chrome 창이 모두 닫힌 상태에서 실행해야 합니다.")
    sys.exit(1)

print("=" * 60)
print(f"[attach] 성공! 현재 열려있는 탭/창: {len(driver.window_handles)}개")
print("=" * 60)

for i, handle in enumerate(driver.window_handles):
    try:
        driver.switch_to.window(handle)
        print(f"  [{i}] handle={handle[:24]}...")
        print(f"      URL  : {driver.current_url}")
        print(f"      TITLE: {driver.title!r}")
    except Exception as e:
        print(f"  [{i}] handle={handle[:24]}... ERROR: {e}")
    print()

# Gemini 탭이 있는지 찾기
gemini_handle = None
for handle in driver.window_handles:
    try:
        driver.switch_to.window(handle)
        if "gemini.google.com" in driver.current_url:
            gemini_handle = handle
            break
    except Exception:
        continue

if gemini_handle:
    driver.switch_to.window(gemini_handle)
    print("=" * 60)
    print(f"[attach] Gemini 탭 발견! 활성화 완료")
    print(f"         URL: {driver.current_url}")
    print(f"         TITLE: {driver.title!r}")
    print(f"         contenteditable=true: {len(driver.find_elements('css selector', '[contenteditable=\"true\"]'))}개")
    print(f"         textarea: {len(driver.find_elements('tag name', 'textarea'))}개")
else:
    print("=" * 60)
    print("[attach] Gemini 탭은 열려있지 않습니다.")
    print("        Chrome에서 https://gemini.google.com 을 직접 열어두면 다음 실행에 활용 가능합니다.")

print("=" * 60)
# ★ 중요: attach 모드에서는 driver.quit() 하면 사용자 Chrome도 종료됩니다.
# 우리는 attach만 한 거라 그냥 끊기만 함.
print("[attach] 세션 해제 (Chrome 창은 그대로 유지)")
# driver.quit() 호출 안 함 — 사용자의 Chrome을 끄지 않기 위해
