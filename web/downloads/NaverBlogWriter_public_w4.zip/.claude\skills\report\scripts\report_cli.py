"""
report 스킬용: 전체분석 → 고객용 HTML 리포트 생성 (IO/결정적)

전체분석 md(YAML 점수·주제 + 본문 핵심추천액션)를 읽어 template/report.html을
채워 HTML을 생성한다. 점수 막대·주제 차트·성장/개선 항목은 데이터로 결정된다.
이미지 프롬프트(창작)는 LLM이 별도로 제공한다.

사용법:
    python report_cli.py resolve <별명/ID>      # blog_id 해석
    python report_cli.py list                   # 생성된 리포트 + 생성 가능 블로그
    python report_cli.py generate <blog>        # HTML 리포트 생성(경로 출력)
"""

import os
import sys
import re
import glob
import json
import argparse
from datetime import datetime

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
REVIEWS = os.path.join(ROOT, "docs", "30.output", "32.reviews")
REPORTS = os.path.join(ROOT, "docs", "30.output", "33.reports")
BLOGS = os.path.join(ROOT, "config", "blogs.json")
TEMPLATE = os.path.join(os.path.dirname(__file__), "..", "template", "report.html")

ITEMS = ["콘텐츠장단점", "운영자문제점", "SEO개선점", "전략제안", "타겟독자", "브랜딩",
         "발행패턴", "제목패턴", "수익화", "경쟁환경", "AI대응력", "독자참여도"]


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def cmd_resolve(q):
    blogs = read_json(BLOGS)
    if q in blogs:
        print(q); return
    ql = q.lower()
    for bid, info in blogs.items():
        hay = f"{bid} {info.get('name','')} {info.get('nickname','')} {info.get('description','')}".lower()
        if ql in hay:
            print(bid); return
    sys.exit(f"'{q}' 매칭 실패")


def latest_analysis(blog):
    files = sorted(glob.glob(os.path.join(REVIEWS, f"{blog}_전체분석_*.md")))
    return files[-1] if files else None


def parse(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    parts = text.split("---", 2)
    fm = parts[1] if len(parts) >= 3 else ""
    body = parts[2] if len(parts) >= 3 else text

    d = {"blog_name": "", "analyzed_at": "", "total_posts": "", "overall_score": None,
         "prev_overall": None, "scores": {}, "topics": [], "actions": []}
    section = None
    cur = {}
    for line in fm.splitlines():
        if re.match(r"^scores:", line):
            section = "scores"; continue
        if re.match(r"^topics:", line):
            section = "topics"; continue
        if re.match(r"^previous_analysis:", line):
            section = "prev"; continue
        if line.strip() and not line.startswith(" ") and not line.startswith("-"):
            if section == "topics" and cur:
                d["topics"].append(cur); cur = {}
            section = None
        if section == "scores":
            m = re.match(r"^\s+(\S+):\s*(\d+)", line)
            if m:
                d["scores"][m.group(1)] = int(m.group(2))
        elif section == "topics":
            m = re.match(r'^\s*-\s*name:\s*"?(.+?)"?\s*$', line)
            if m:
                if cur:
                    d["topics"].append(cur)
                cur = {"name": m.group(1)}
            elif re.match(r"^\s+count:", line):
                cur["count"] = re.search(r"(\d+)", line).group(1)
            else:
                mr = re.match(r'^\s+ratio:\s*"?(.+?)"?\s*$', line)
                if mr:
                    cur["ratio"] = mr.group(1)
        elif section == "prev":
            m = re.match(r"^\s+overall_score:\s*(\d+)", line)
            if m:
                d["prev_overall"] = int(m.group(1))
        m = re.match(r'^blog_name:\s*"?(.+?)"?\s*$', line)
        if m: d["blog_name"] = m.group(1)
        m = re.match(r'^analyzed_at:\s*"?([\d-]+)', line)
        if m: d["analyzed_at"] = m.group(1)
        m = re.match(r'^total_posts:\s*(\d+)', line)
        if m: d["total_posts"] = m.group(1)
        m = re.match(r'^overall_score:\s*(\d+)', line)
        if m: d["overall_score"] = int(m.group(1))
    if section == "topics" and cur:
        d["topics"].append(cur)

    # 본문에서 핵심 추천 액션 추출
    am = re.search(r"##\s*핵심 추천 액션\s*\n(.+?)(?:\n##\s|\Z)", body, re.S)
    if am:
        for ln in am.group(1).splitlines():
            mm = re.match(r"^\s*\d+\.\s*(.+)", ln)
            if mm:
                d["actions"].append(re.sub(r"\*\*", "", mm.group(1)).strip())
    return d


def li(items):
    return "".join(f"<li>{x}</li>" for x in items) or "<li>(없음)</li>"


def cmd_generate(blog):
    f = latest_analysis(blog)
    if not f:
        sys.exit(f"'{blog}' 전체분석 없음 — /analyze 먼저 실행하세요.")
    d = parse(f)

    bars = []
    for item in ITEMS:
        s = d["scores"].get(item, 0)
        bars.append(f'<div class="bar-row"><div class="label"><span>{item}</span><b>{s}</b></div>'
                    f'<div class="bar"><span style="width:{s}%"></span></div></div>')
    topic_bars = []
    for t in d["topics"]:
        ratio = str(t.get("ratio", "0%"))
        w = re.search(r"(\d+)", ratio)
        topic_bars.append(f'<div class="bar-row"><div class="label"><span>{t.get("name","")}</span>'
                          f'<b>{ratio}</b></div><div class="bar"><span style="width:{w.group(1) if w else 0}%"></span></div></div>')

    ranked = sorted(d["scores"].items(), key=lambda kv: kv[1], reverse=True)
    growth = [f"{k} ({v}점)" for k, v in ranked[:3]]
    improve = [f"{k} ({v}점)" for k, v in ranked[-3:][::-1]]

    change = ""
    if d["prev_overall"] is not None and d["overall_score"] is not None:
        delta = d["overall_score"] - d["prev_overall"]
        change = f"({'+' if delta >= 0 else ''}{delta} vs 이전)"

    with open(os.path.abspath(TEMPLATE), encoding="utf-8") as t:
        html = t.read()
    repl = {
        "{{BLOG_NAME}}": d["blog_name"] or blog,
        "{{BLOG_ID}}": blog,
        "{{DATE}}": d["analyzed_at"] or datetime.now().strftime("%Y-%m-%d"),
        "{{SCORE}}": str(d["overall_score"] if d["overall_score"] is not None else ""),
        "{{TOTAL_POSTS}}": str(d["total_posts"] or ""),
        "{{CHANGE}}": change,
        "{{SCORE_BARS}}": "\n".join(bars),
        "{{TOPIC_BARS}}": "\n".join(topic_bars) or "<p>(주제 데이터 없음)</p>",
        "{{GROWTH}}": li(growth),
        "{{IMPROVE}}": li(improve),
        "{{ACTIONS}}": li(d["actions"]),
    }
    for k, v in repl.items():
        html = html.replace(k, v)

    os.makedirs(REPORTS, exist_ok=True)
    out = os.path.join(REPORTS, f"{blog}_report_{datetime.now():%Y%m%d}.html")
    with open(out, "w", encoding="utf-8") as o:
        o.write(html)
    print(out)


def cmd_list():
    os.makedirs(REPORTS, exist_ok=True)
    reports = sorted(glob.glob(os.path.join(REPORTS, "*_report_*.html")))
    print(f"## 생성된 리포트 ({len(reports)}개)")
    for r in reports:
        print(f"- {os.path.basename(r)}")
    blogs = sorted({re.match(r'(.+)_전체분석_', os.path.basename(f)).group(1)
                    for f in glob.glob(os.path.join(REVIEWS, "*_전체분석_*.md"))})
    print(f"\n## 리포트 생성 가능 블로그 (전체분석 보유, {len(blogs)}개)")
    for b in blogs:
        print(f"- {b}")


def main():
    ap = argparse.ArgumentParser(description="report 생성 (IO/결정적)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sp = sub.add_parser("resolve"); sp.add_argument("query")
    sp = sub.add_parser("generate"); sp.add_argument("blog")
    args = ap.parse_args()
    if args.cmd == "list": cmd_list()
    elif args.cmd == "resolve": cmd_resolve(args.query)
    elif args.cmd == "generate": cmd_generate(args.blog)


if __name__ == "__main__":
    main()
