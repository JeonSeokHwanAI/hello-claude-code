"""
write 스킬용: Clean Text Mode 구문 후처리 (안전망, IO/정규식 전용)

Naver Blog Writer.md(93.context) §4의 '구문' 규칙만 기계적으로 보장한다:
  - 볼드체 **...** 제거 (안의 텍스트는 유지)
  - 마크다운 머리표(#, -, *, +, 1.) 제거 → 줄글
의미 규칙(AI 잡담 금지, 1:1 화법, 문체)은 가이드를 단일 출처로 LLM이 적용한다.
(가이드의 규칙을 재정의하지 않고, 최종 본문의 구문 잔재만 청소하는 보편 후처리)

⚠️ 본문(블로그에 붙여넣을 텍스트)에만 적용. frontmatter/섹션 헤더가 있는
   구조 md 파일 전체에 --fix 하지 말 것. 기본은 stdin→stdout 필터.

사용법:
    echo "<본문>" | python clean_text.py            # 위반 검사(리포트)
    echo "<본문>" | python clean_text.py --fix       # 수정본을 stdout으로
    python clean_text.py <본문파일> [--fix]           # 파일 검사/수정
"""

import sys
import re
import argparse

BOLD = re.compile(r"\*\*(.+?)\*\*", re.S)
HEADING = re.compile(r"^[ \t]{0,3}#{1,6}[ \t]+", re.M)
BULLET = re.compile(r"^[ \t]{0,3}[-*+][ \t]+", re.M)
NUMLIST = re.compile(r"^[ \t]{0,3}\d+\.[ \t]+", re.M)

CHECKS = [
    ("볼드체 **...**", BOLD),
    ("마크다운 제목 #", HEADING),
    ("리스트 - / * / +", BULLET),
    ("숫자목록 1.", NUMLIST),
]


def find_violations(text):
    return [(name, len(rx.findall(text))) for name, rx in CHECKS if rx.search(text)]


def fix(text):
    text = BOLD.sub(r"\1", text)   # 볼드 → 안쪽 텍스트
    text = HEADING.sub("", text)   # 제목 머리표 제거
    text = BULLET.sub("", text)    # 불릿 제거
    text = NUMLIST.sub("", text)   # 숫자목록 제거
    return text


def main():
    ap = argparse.ArgumentParser(description="Clean Text Mode 구문 후처리 (안전망)")
    ap.add_argument("path", nargs="?", default="-", help="대상 파일 (기본 '-' = stdin)")
    ap.add_argument("--fix", action="store_true", help="자동 수정 (파일이면 덮어쓰기, stdin이면 stdout)")
    args = ap.parse_args()

    if args.path == "-":
        text = sys.stdin.read().lstrip("﻿")  # 파이프로 들어온 BOM 제거
        is_stdin = True
    else:
        with open(args.path, encoding="utf-8") as f:
            text = f.read()
        is_stdin = False

    if args.fix:
        fixed = fix(text)
        removed = sum(c for _, c in find_violations(text))
        if is_stdin:
            sys.stdout.write(fixed)
        else:
            with open(args.path, "w", encoding="utf-8") as f:
                f.write(fixed)
            print(f"수정 완료: {args.path} (구문 잔재 {removed}건 제거)")
        return

    v = find_violations(text)
    if not v:
        print("OK: 구문 위반 없음")
    else:
        print("구문 위반 발견 (Naver Blog Writer.md §4 구문 규칙):")
        for name, cnt in v:
            print(f"  - {name}: {cnt}건")
        print("→ --fix 로 자동 수정. 의미 규칙(잡담/1:1 화법/문체)은 가이드 기준 LLM이 점검.")


if __name__ == "__main__":
    main()
