"""
유틸리티 함수 모듈
"""
from __future__ import annotations  # Python 3.7 호환: `list | dict` 등 union 어노테이션 지연 평가

import json
import os
from datetime import datetime


def save_json(data: list | dict, filepath: str) -> str:
    """
    데이터를 JSON 파일로 저장

    Args:
        data: 저장할 데이터
        filepath: 저장 경로

    Returns:
        저장된 파일 경로
    """
    # 디렉토리 생성
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return filepath


def save_posts_to_files(posts: list, output_dir: str = "output", prefix: str = "") -> dict:
    """
    포스트 데이터를 파일로 저장

    Args:
        posts: 포스트 리스트
        output_dir: 출력 디렉토리
        prefix: 파일명 앞에 붙일 접두사 (예: 블로그 ID)

    Returns:
        저장 결과 정보
    """
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 파일명 생성 (prefix가 있으면 prefix_summary_날짜.json)
    if prefix:
        posts_filename = f"{prefix}_posts_{timestamp}.json"
        summary_filename = f"{prefix}_summary_{timestamp}.json"
    else:
        posts_filename = f"posts_{timestamp}.json"
        summary_filename = f"summary_{timestamp}.json"

    # 전체 데이터 저장
    all_posts_file = os.path.join(output_dir, posts_filename)
    save_json(posts, all_posts_file)

    # 요약 정보 저장
    def parse_pubdate(pub_date_str):
        """pubDate에서 요일 추출"""
        if not pub_date_str:
            return ""
        # "Tue, 27 Jan 2026 08:02:27 +0900" 형식
        day_map = {"Mon": "월", "Tue": "화", "Wed": "수", "Thu": "목", "Fri": "금", "Sat": "토", "Sun": "일"}
        parts = pub_date_str.split(",")
        if parts:
            day_abbr = parts[0].strip()
            return day_map.get(day_abbr, day_abbr)
        return ""

    def build_post_summary(i, p):
        title = p.get("title", "")
        content = p.get("content", "")
        pub_date = p.get("pubDate", "")
        log_no = p.get("logNo", "")
        images = p.get("images", [])

        return {
            "index": f"{i:02d}",
            "logNo": log_no,
            "url": f"https://blog.naver.com/{prefix}/{log_no}" if prefix and log_no else "",
            "title": title,
            "title_length": len(title),
            "pubDate": pub_date,
            "day_of_week": parse_pubdate(pub_date),
            "has_content": bool(content),
            "content_length": len(content) if content else 0,
            "image_count": len(images)
        }

    # 분석 형식 지침은 review/analyze SKILL.md를 단일 출처로 사용한다.
    # (과거 여기에 임베드하던 _guide는 중복 제거를 위해 삭제)
    summary = {
        "blog_id": prefix,
        "blog_url": f"https://blog.naver.com/{prefix}" if prefix else "",
        "total_posts": len(posts),
        "scraped_at": datetime.now().isoformat(),
        "posts": [build_post_summary(i, p) for i, p in enumerate(posts)]
    }

    summary_file = os.path.join(output_dir, summary_filename)
    save_json(summary, summary_file)

    return {
        "posts_file": all_posts_file,
        "summary_file": summary_file,
        "total": len(posts)
    }
