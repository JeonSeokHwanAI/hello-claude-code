"""
review 스킬용: 분석 대상 조회/로딩 (IO 전용)

결정적 작업만 처리한다. 실제 분석(12항목/8섹션)·댓글 작성은 LLM(opus)이
template/ 의 양식을 채워서 수행한다.

사용법:
    python review_cli.py accounts                # 스크래핑된 계정(블로그) 목록
    python review_cli.py resolve <별명/ID>        # blogs.json에서 blog_id 해석
    python review_cli.py posts <blog> [N]         # 최신 summary에서 포스트 목록(최대 N)
    python review_cli.py post <blog> <index>      # 최신 posts에서 해당 글 본문 출력
    python review_cli.py last                      # .last_search 자동 연결 정보
"""

import os
import sys
import json
import glob
import argparse

# 이 스크립트는 .claude/skills/review/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
SCRAPED = os.path.join(ROOT, "docs", "20.working", "21.scraped")
BLOGS = os.path.join(ROOT, "config", "blogs.json")
LAST = os.path.join(ROOT, "docs", "20.working", "22.state", ".last_search.json")

_MONTHS = {"Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "May": "05", "Jun": "06",
           "Jul": "07", "Aug": "08", "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"}


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def latest(blog, kind):
    """{blog}_{kind}_*.json 중 가장 최신(파일명 타임스탬프 기준) 경로"""
    files = sorted(glob.glob(os.path.join(SCRAPED, blog, f"{blog}_{kind}_*.json")))
    return files[-1] if files else None


def short_date(pub):
    """'Tue, 27 Jan 2026 08:02:27 +0900' → '2026-01-27'"""
    parts = (pub or "").split()
    if len(parts) >= 4 and parts[2] in _MONTHS:
        return f"{parts[3]}-{_MONTHS[parts[2]]}-{parts[1].zfill(2)}"
    return pub or ""


def cmd_accounts():
    if not os.path.isdir(SCRAPED):
        sys.exit("스크래핑된 데이터가 없습니다.")
    dirs = sorted(d for d in os.listdir(SCRAPED)
                  if os.path.isdir(os.path.join(SCRAPED, d)) and not d.startswith("_"))
    if not dirs:
        sys.exit("스크래핑된 계정이 없습니다.")
    print(f"## 스크래핑된 계정 ({len(dirs)}개)\n")
    print("| 번호 | 계정(블로그 ID) |")
    print("|------|-----------------|")
    for i, d in enumerate(dirs, 1):
        print(f"| {i} | {d} |")


def cmd_resolve(q):
    blogs = read_json(BLOGS)
    if q in blogs:
        print(q); return
    ql = q.lower()
    for bid, info in blogs.items():
        hay = f"{bid} {info.get('name','')} {info.get('nickname','')} {info.get('description','')}".lower()
        if ql in hay:
            print(bid); return
    sys.exit(f"'{q}' 매칭 실패 — blogs.json에 없음")


def cmd_posts(blog, n):
    f = latest(blog, "summary")
    if not f:
        sys.exit(f"'{blog}' summary 없음 — 먼저 /search 로 수집하세요.")
    posts = read_json(f).get("posts", [])
    if n:
        posts = posts[:n]
    print(f"## {blog} 포스트 목록 ({len(posts)}개)\n")
    print("| 번호 | 제목 | 날짜 |")
    print("|------|------|------|")
    for p in posts:
        print(f"| {p.get('index','')} | {p.get('title','')} | {short_date(p.get('pubDate',''))} |")


def cmd_post(blog, index):
    f = latest(blog, "posts")
    if not f:
        sys.exit(f"'{blog}' posts 없음 — 먼저 /search 로 수집하세요.")
    arr = read_json(f)
    try:
        i = int(index)
    except ValueError:
        sys.exit(f"잘못된 index: {index}")
    if i < 0 or i >= len(arr):
        sys.exit(f"index 범위 초과: {i} (총 {len(arr)}개)")
    p = arr[i]
    url = f"https://blog.naver.com/{blog}/{p.get('logNo','')}"
    print(f"# [{i:02d}] {p.get('title','')}")
    print(f"- URL: {url}")
    print(f"- 발행일: {p.get('pubDate','')}")
    print(f"- 본문 길이: {len(p.get('content','') or '')}자\n")
    print("## 본문\n")
    print(p.get("content", "") or "(본문 없음)")


def cmd_last():
    if not os.path.exists(LAST):
        sys.exit("최근 검색 기록(.last_search) 없음 → 계정 목록 흐름으로.")
    blog = read_json(LAST).get("blog_id")
    if not blog:
        sys.exit("최근 검색 blog_id 없음.")
    f = latest(blog, "summary")
    count = len(read_json(f).get("posts", [])) if f else 0
    if count == 1:
        mode = "특정글분석(1개 → 질문 없이 바로)"
    elif 2 <= count <= 5:
        mode = "포스트 목록 표시 후 번호 선택"
    else:
        mode = "분석 유형 선택(0:전체분석 / 포스트 번호)"
    print(f"blog_id: {blog}")
    print(f"posts: {count}")
    print(f"권장 흐름: {mode}")


def main():
    ap = argparse.ArgumentParser(description="review 대상 조회/로딩 (IO 전용)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("accounts")
    sub.add_parser("last")
    sp = sub.add_parser("resolve"); sp.add_argument("query")
    sp = sub.add_parser("posts"); sp.add_argument("blog"); sp.add_argument("n", nargs="?", type=int, default=0)
    sp = sub.add_parser("post"); sp.add_argument("blog"); sp.add_argument("index")
    args = ap.parse_args()

    if args.cmd == "accounts": cmd_accounts()
    elif args.cmd == "last": cmd_last()
    elif args.cmd == "resolve": cmd_resolve(args.query)
    elif args.cmd == "posts": cmd_posts(args.blog, args.n)
    elif args.cmd == "post": cmd_post(args.blog, args.index)


if __name__ == "__main__":
    main()
