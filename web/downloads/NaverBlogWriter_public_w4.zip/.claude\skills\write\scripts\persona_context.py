"""
write 스킬용: 활성 페르소나 통합 컨텍스트 로더 (IO 전용)

활성 페르소나 → 페르소나 JSON → context_file → Naver Blog Writer 가이드를
한 번에 읽어 통합 출력한다. 창작은 하지 않는다 (본문/제목/이미지/태그는 LLM 담당).

사용법:
    python persona_context.py          # 사람이 읽기 좋은 통합 컨텍스트
    python persona_context.py --json   # 원본 데이터를 JSON으로
"""

import os
import sys
import json
import argparse

# 이 스크립트는 .claude/skills/write/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
STATE = os.path.join(ROOT, "docs", "20.working", "22.state", ".active_persona.json")
PERSONA_DIR = os.path.join(ROOT, "config", "personas")
CONTEXT_DIR = os.path.join(ROOT, "docs", "90.reference", "93.context")
GUIDE = os.path.join(CONTEXT_DIR, "Naver Blog Writer.md")


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def read_text(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def resolve_context_file(stored):
    """persona JSON의 context_file 경로 해석 (옛 경로면 93.context로 폴백)"""
    if not stored:
        return None
    p = os.path.join(ROOT, stored)            # 1) ROOT 기준 그대로
    if os.path.exists(p):
        return p
    alt = os.path.join(CONTEXT_DIR, os.path.basename(stored))  # 2) 93.context 폴백
    if os.path.exists(alt):
        return alt
    return None


def load_bundle():
    if not os.path.exists(STATE):
        sys.exit("활성 페르소나가 없습니다. /persona use <이름> 으로 먼저 설정하세요.")
    active = read_json(STATE).get("active")
    if not active:
        sys.exit("활성 페르소나가 비어 있습니다.")

    persona_path = os.path.join(PERSONA_DIR, f"{active}.json")
    if not os.path.exists(persona_path):
        sys.exit(f"페르소나 파일을 찾을 수 없습니다: {persona_path}")
    persona = read_json(persona_path)

    ctx_path = resolve_context_file(persona.get("context_file"))
    return {
        "active_persona": active,
        "persona": persona,
        "context_file_path": ctx_path,
        "context_file_text": read_text(ctx_path) if ctx_path else "",
        "guide_path": GUIDE if os.path.exists(GUIDE) else None,
        "guide_text": read_text(GUIDE) if os.path.exists(GUIDE) else "",
    }


def main():
    ap = argparse.ArgumentParser(description="활성 페르소나 통합 컨텍스트 로더")
    ap.add_argument("--json", action="store_true", help="원본 데이터를 JSON으로 출력")
    args = ap.parse_args()

    b = load_bundle()
    if args.json:
        print(json.dumps(b, ensure_ascii=False, indent=2))
        return

    p = b["persona"]
    style = p.get("style", {})
    prof = p.get("profile", {})
    out = [
        f"# 활성 페르소나: {b['active_persona']}",
        f"- 닉네임: {prof.get('nickname','')}",
        f"- 시작 문구: 안녕하세요, {prof.get('nickname','')}입니다.",
        f"- 톤: {style.get('tone','')}",
        f"- 어투: {style.get('formality','')}",
        f"- 글쓰기 패턴: {', '.join(style.get('writing_patterns', []))}",
        f"- 자주 쓰는 표현: {', '.join(style.get('favorite_expressions', []))}",
        f"- 글 구조: {style.get('content_structure','')}",
        f"- 평균 길이: {style.get('average_length','')}",
        f"- 페르소나: {p.get('persona','')}",
        "",
        f"## 페르소나 상세 문서 ({b['context_file_path'] or '없음'})",
        b["context_file_text"] or "(없음)",
        "",
        f"## Naver Blog Writer 가이드 ({b['guide_path'] or '없음'})",
        b["guide_text"] or "(없음)",
    ]
    print("\n".join(out))


if __name__ == "__main__":
    main()
