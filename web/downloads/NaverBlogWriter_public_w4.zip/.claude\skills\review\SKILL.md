---
name: review
description: 수집된 데이터로 블로그를 분석(전체분석 12항목/특정글분석 8섹션)하거나 추천 댓글을 생성한다. '/review', '블로그 분석', '리뷰' 요청 시 사용.
model: opus
allowed-tools:
  - Read
  - Glob
  - Bash
---

# 블로그 분석 리뷰

인자: $ARGUMENTS

## 저장 위치 (필수 준수)

생성·갱신 파일은 아래 경로에만 저장한다. 그 외 경로(특히 프로젝트 루트)에 파일을 만들지 않는다. 전체 규칙은 `CLAUDE.md`의 '파일 저장 위치 가이드' 참조.

- 이 스킬은 파일을 생성하지 않는다 (분석·추천 댓글은 대화로 출력). 저장은 `/save` 사용.
- 참조 상태: `docs/20.working/22.state/.last_search.json`

수집된 데이터로 블로그 분석을 진행합니다.

## 인자 파싱 (최우선)

인자가 있으면 단계를 건너뛰고 바로 실행합니다.

**패턴:**
- `<별명/ID> <포스트번호>` → 해당 블로그의 특정 포스트 바로 분석
  - 예: `/review 비움 00` → hhey0510의 00번 포스트 특정글분석
- `<별명/ID> <수량>` → 해당 블로그의 포스트 N개 목록 표시 후 번호 선택 대기
  - 예: `/review 비움 5` → hhey0510의 포스트 5개 목록 표시
- `<별명/ID> 0` → 해당 블로그 전체분석 바로 실행
  - 예: `/review 비움 0` → hhey0510 전체분석
- `<별명/ID> <포스트번호> 댓글` → **댓글만 바로 생성** (분석 생략)
  - 예: `/review 리리 00 댓글` → 00번 포스트 댓글만 출력
- `<별명/ID> 댓글` → 최신 포스트 댓글만 바로 생성
  - 예: `/review 리리 댓글` → 최신 글 댓글만 출력
- `<별명/ID>` → 해당 블로그 선택 후 분석 유형 선택 대기
- 인자 없음 → 아래 "자동 연결" 로직 실행

**별명/ID 매칭:** `review_cli.py resolve "<별명/ID>"` 사용 (blogs.json의 ID·name·nickname·description 검색).

## 스크립트 & 템플릿 (결정적 작업)

조회·로딩은 `review_cli.py`로, 출력 구조는 `template/` 양식으로 한다. 분석 판단·서술·댓글 작성은 LLM(opus)이 담당한다.

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter"
python -X utf8 ".claude/skills/review/scripts/review_cli.py" accounts            # 계정 목록
python -X utf8 ".claude/skills/review/scripts/review_cli.py" resolve "<별명/ID>"  # blog_id 해석
python -X utf8 ".claude/skills/review/scripts/review_cli.py" posts <blog> [N]     # 포스트 목록
python -X utf8 ".claude/skills/review/scripts/review_cli.py" post <blog> <index>  # 글 본문 로딩
python -X utf8 ".claude/skills/review/scripts/review_cli.py" last                 # 자동 연결 정보
```

출력 양식(반드시 준수):
- 전체분석 → `.claude/skills/review/template/전체분석.md`
- 특정글분석 → `.claude/skills/review/template/특정글분석.md`
- 댓글만 → `.claude/skills/review/template/댓글.md`

## 자동 연결 (인자 없음일 때)

`/review`만 실행했을 때, 직전 `/search` 결과를 자동으로 이어받습니다.

**판단:** `review_cli.py last` 실행 → `blog_id`·`posts`·권장 흐름 출력
- 출력 있음 → 권장 흐름대로: 1개=질문 없이 바로 특정글분석 / 2~5개=목록 후 번호 선택 / 6개+=분석 유형 선택(0=전체분석)
- "최근 검색 없음" → 계정 목록 표시(아래)

## 실행 흐름 (자동 연결 불가 시)

### 1단계: 계정 목록 표시

```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/review/scripts/review_cli.py" accounts
```
스크립트가 `_`로 시작하는 폴더를 제외한 계정 목록을 번호 표로 출력한다. 그 뒤 "계정 번호를 입력하세요:" 출력 후 대기.

### 2단계: 분석 유형 선택

사용자가 계정 번호를 입력하면:

```
분석 유형을 선택하세요:
- 0: 전체분석 (12개 항목)
- 1~50: 해당 수량만큼 포스트 목록 표시

입력:
```

그리고 대기.

### 3단계: 분기 처리

**"0" 입력 시 → 전체분석:**
- **`template/전체분석.md` 양식을 그대로 채워** 12개 항목(콘텐츠장단점·운영자문제점·SEO개선점·전략제안·타겟독자·브랜딩·발행패턴·제목패턴·수익화·경쟁환경·AI대응력·독자참여도)을 분석한다.
- 각 항목 100점 만점 + 장점/단점/개선안 구체 서술, 끝에 종합점수·주제분포·핵심추천액션 포함. (메타는 `review_cli.py posts <blog>`로 확인)

**"1~50" 입력 시 → 포스트 목록:**
```bash
cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/review/scripts/review_cli.py" posts <blog> <N>
```
스크립트가 최신 summary에서 N개 목록(번호|제목|날짜)을 출력한다. 그 뒤 "분석할 포스트 번호를 입력하세요 (예: 00, 01):" 출력 후 대기.

### 4단계: 특정글 분석

포스트 번호가 결정되면:
- 본문 로딩(스크립트):
  ```bash
  cd "G:/내 드라이브/WorkSpace/NaverBlogWriter" && python -X utf8 ".claude/skills/review/scripts/review_cli.py" post <blog> <index>
  ```
- **`template/특정글분석.md` 양식을 그대로 채워** 8개 섹션(콘텐츠 구조 분석, 강점 4가지, 약점·개선점, SEO 분석, 독자 반응 예측, 종합 평가, 총평, 추천 댓글)으로 심층 분석한다. 8번 추천 댓글은 강점 언급 + 공감 + 후속 콘텐츠 기대

## 댓글만 생성 모드

인자에 `댓글`이 포함되면 분석을 생략하고 **추천 댓글만** 바로 출력합니다.

**실행 흐름:**
1. 본문 로딩: `review_cli.py post <blog> <index>` (index 생략 시 최신=0)
2. 본문 기반 추천 댓글 생성
3. `template/댓글.md` 양식으로 댓글만 출력 (분석 8개 섹션 생략)

**댓글 작성 가이드:**
- 글의 강점 1~2개 구체적으로 언급
- 공감 표현 (개인 경험 또는 감정)
- 후속 콘텐츠에 대한 기대감
- 자연스러운 어조 (과도한 칭찬 지양)
- 2~4문장 적정 길이

**출력 형식:** `template/댓글.md` 양식을 그대로 사용 (댓글은 `>` 인용 블록 없이 평문으로 출력하여 바로 복사 가능하게).

## 중요 사항

- **AskUserQuestion 도구를 사용하지 마세요.** 텍스트로 질문하고 사용자 입력을 기다립니다.
- 사용자 입력이 필요한 단계에서만 대기합니다.
- **자동 연결이 가능하면 질문 없이 바로 분석을 시작합니다.**
