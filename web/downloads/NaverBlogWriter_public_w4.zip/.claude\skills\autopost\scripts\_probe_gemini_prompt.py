"""일회성 — attach된 Chrome의 Gemini 탭에 이미지 프롬프트 입력 시연.

전제: Chrome이 --remote-debugging-port=9222 로 실행 중이고 Gemini 탭이 열려 있음.

흐름:
  1. Chrome attach
  2. Gemini 탭 활성화
  3. contenteditable 입력 필드 찾기
  4. clipboard + Ctrl+V 로 프롬프트 입력 (봇 탐지 회피)
  5. Enter 전송
  6. 응답 시작 감지 후 종료 (응답 완료까지 기다리지는 않음)
"""
from __future__ import annotations

import sys
import time

import pyperclip
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

# 사용자 파일의 첫 번째 Image Prompt
PROMPT = (
    "A cozy flat illustration of a person sitting in front of a blank blog screen "
    "looking stuck and overwhelmed, scattered notes around the laptop, warm pastel colors, "
    "soft lighting, relatable mood. Aspect ratio 16:9, horizontal composition."
)

options = webdriver.ChromeOptions()
options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")

try:
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
except Exception as e:
    print(f"[FAIL] attach 실패: {e}")
    sys.exit(1)

# Gemini 탭 찾기
gemini_handle = None
for handle in driver.window_handles:
    try:
        driver.switch_to.window(handle)
        if "gemini.google.com" in driver.current_url:
            gemini_handle = handle
            break
    except Exception:
        continue

if not gemini_handle:
    print("[FAIL] Gemini 탭이 없습니다. https://gemini.google.com 을 Chrome에서 열어주세요.")
    sys.exit(1)

driver.switch_to.window(gemini_handle)
print(f"[OK] Gemini 탭 활성화: {driver.current_url}")

# contenteditable 입력 필드 찾기 (Gemini는 보통 마지막 contenteditable이 프롬프트 박스)
candidates = driver.find_elements(By.CSS_SELECTOR, "[contenteditable='true']")
print(f"[info] contenteditable 후보: {len(candidates)}개")
for i, el in enumerate(candidates):
    try:
        aria = el.get_attribute("aria-label") or ""
        ph = el.get_attribute("data-placeholder") or el.get_attribute("placeholder") or ""
        cls = (el.get_attribute("class") or "")[:60]
        disp = el.is_displayed()
        print(f"  [{i}] disp={disp} aria={aria[:30]!r} ph={ph[:30]!r} class={cls!r}")
    except Exception:
        pass

# 프롬프트 input은 보통 aria-label에 'prompt' 또는 'Enter a prompt' 포함, 또는 마지막 displayed contenteditable
target = None
for el in candidates:
    try:
        if not el.is_displayed():
            continue
        aria = (el.get_attribute("aria-label") or "").lower()
        if "prompt" in aria or "message" in aria or "enter" in aria:
            target = el
            print(f"[OK] 프롬프트 박스 매칭 (aria-label='{aria}')")
            break
    except Exception:
        continue

if not target:
    # 폴백: 마지막으로 보이는 contenteditable
    visible = [el for el in candidates if el.is_displayed()]
    if visible:
        target = visible[-1]
        print(f"[OK] 폴백: 마지막 visible contenteditable 선택")

if not target:
    print("[FAIL] 프롬프트 박스를 찾지 못함")
    sys.exit(1)

# 클릭 → 클립보드 + Ctrl+V → Enter
print(f"[입력] 프롬프트 길이: {len(PROMPT)}자")
target.click()
time.sleep(0.5)

pyperclip.copy(PROMPT)
ActionChains(driver).key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
time.sleep(1)
print("[입력] 텍스트 붙여넣기 완료. Enter 전송...")
ActionChains(driver).send_keys(Keys.ENTER).perform()
time.sleep(3)

# 응답 시작 감지 — '응답 생성 중' 같은 마커 또는 새 응답 element 출현
src_after = driver.page_source
markers = ["답변", "stop response", "Stop response", "generating", "응답 생성"]
seen = [m for m in markers if m.lower() in src_after.lower()]
print(f"[감지] 응답 마커: {seen if seen else '미확인 (응답이 너무 빠르거나 selector 다름)'}")

print("[대기] 10초간 응답 추가 생성 모니터링...")
time.sleep(10)
print("[종료] attach 해제 (Chrome은 유지) — 응답은 브라우저에서 직접 확인하세요")
