"""
네이버 블로그 스크래퍼 - 진입점 (CLI)

사용법:
    python main.py <블로그ID 또는 URL> [포스트수]
    예) python main.py zeroenter 5
        python main.py https://blog.naver.com/zeroenter 10
    인자를 생략하면 블로그 ID를 대화형으로 입력받습니다.
"""

import os
import sys
import json
import argparse
from scraper import NaverBlogScraper
from utils import save_posts_to_files

# 이 스크립트는 .claude/skills/search/scripts/ 에 위치 → 4단계 상위가 프로젝트 루트
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
STATE_FILE = os.path.join(ROOT, "docs", "20.working", "22.state", ".last_search.json")
OUTPUT_BASE = os.path.join(ROOT, "docs", "20.working", "21.scraped")

MIN_COUNT, MAX_COUNT, DEFAULT_COUNT = 1, 50, 10


def save_last_search(blog_id, output_dir):
    """마지막 검색 정보를 상태 파일에 저장"""
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump({"blog_id": blog_id, "output_dir": output_dir}, f, ensure_ascii=False, indent=2)


def extract_blog_id(user_input):
    """URL 또는 ID에서 블로그 ID 추출"""
    user_input = user_input.strip()
    if "blog.naver.com" in user_input:
        # 예: https://blog.naver.com/blogid 또는 .../blogid/logNo?query
        parts = user_input.replace("https://", "").replace("http://", "").split("/")
        if len(parts) >= 2:
            return parts[1].split("?")[0]
    return user_input


def get_blog_output_dir(blog_id):
    """블로그 ID별 출력 디렉토리 반환 (없으면 생성)"""
    blog_dir = os.path.join(OUTPUT_BASE, blog_id)
    os.makedirs(blog_dir, exist_ok=True)
    return blog_dir


def clamp_count(value):
    """포스트 수를 1~50 범위로 보정 (잘못된 값은 기본값)"""
    try:
        count = int(value)
    except (TypeError, ValueError):
        return DEFAULT_COUNT
    return max(MIN_COUNT, min(MAX_COUNT, count))


def parse_args():
    p = argparse.ArgumentParser(description="네이버 블로그 스크래퍼")
    p.add_argument("blog", nargs="?", help="블로그 ID 또는 URL (생략 시 대화형 입력)")
    p.add_argument("count", nargs="?", default=DEFAULT_COUNT,
                   help=f"수집할 포스트 수 ({MIN_COUNT}~{MAX_COUNT}, 기본 {DEFAULT_COUNT})")
    return p.parse_args()


def main():
    args = parse_args()

    raw_blog = args.blog if args.blog else input(">> 블로그 ID 또는 URL: ").strip()
    if not raw_blog:
        print("블로그 ID 또는 URL이 필요합니다.")
        sys.exit(1)

    blog_id = extract_blog_id(raw_blog)
    count = clamp_count(args.count)

    print("=" * 60)
    print(f"네이버 블로그 스크래퍼  (ID: {blog_id}, 수량: {count}개)")
    print("=" * 60)

    scraper = NaverBlogScraper(blog_id=blog_id)
    posts = scraper.scrape_all(limit=count, include_content=True, include_images=True)

    if not posts:
        print("스크래핑된 포스트가 없습니다. 블로그 ID를 확인해주세요.")
        sys.exit(1)

    output_dir = get_blog_output_dir(blog_id)
    result = save_posts_to_files(posts, output_dir=output_dir, prefix=blog_id)
    save_last_search(blog_id, output_dir)

    print()
    print(f"완료!  총 포스트: {result['total']}개")
    print(f"저장 위치: {result['summary_file']}")


if __name__ == "__main__":
    main()
