# Naver WritePhoto PRD

> "사진은 작가가 찍고, 캡션은 AI가 거들고, 글은 페르소나의 목소리로."

> **중요 원칙 (Scope Boundary)**:
> - 본 스킬(`write-photo`)은 **사용자가 직접 찍은 실제 사진 폴더**를 입력받아 **활성 페르소나 말투의 블로그 글 + 사진 배치 마크다운**까지 만든다.
> - AI 이미지 생성은 하지 않는다. **실제 사진만** 사용한다.
> - 네이버 임시저장 업로드는 **`/autopost` 스킬의 책임**이며, 본 스킬은 autopost가 그대로 집어 올릴 수 있도록 사진을 staging만 한다.
> - 공개 발행은 절대 자동화하지 않는다 (autopost 원칙 승계).

| 항목 | 내용 |
|------|------|
| 문서 종류 | PRD (Product Requirements Document) + 기술 설계 |
| 버전 | v1.0 (구현 완료) |
| 작성일 | 2026-06-02 (v0.1 초안) / 2026-06-02 (v1.0 — 마커·콜라주·input주입 반영) |
| 작성자 | 시스템 자동 작성 (사용자 검토 필요) |
| 대상 산출물 | `.claude/skills/write-photo/` + `.claude/skills/autopost/` 확장 |
| 상태 | **구현 완료·검증됨** (샘플세차샵 31장 콜라주 임시저장 성공) |
| 연관 문서 | `Naver_AutoPosting_PRD.md`(업로드 책임), `페르소나 - 샘플세차샵.md` |

---

## 1. 개요 (Overview)

### 1.1 배경

NaverBlogWriter는 "AI는 펜이고, 당신이 작가입니다" 슬로건으로 블로그 분석 → 페르소나 → 글 작성 → 임시저장 파이프라인을 운영한다.

기존 `/write`는 **텍스트 작성 + 생성형 이미지 프롬프트(Gemini용)**를 만든다. 그러나 샘플세차샵(광명 스팀세차, sample_car) 같은 **현장 작업형 블로그**는 콘텐츠의 핵심이 **실제 작업 사진 20~50장**이다. before/after, 작업 과정 사진이 곧 신뢰이고 정체성이다. 이런 블로그에는 AI 생성 이미지가 아니라 **사장님이 직접 찍은 사진**을 글에 녹여야 한다.

### 1.2 목적

사용자가 폴더에 넣어둔 실제 사진을 **Claude가 비전으로 보고**, **활성 페르소나 말투**로 작업후기/경험형 글을 쓰고, 사진을 본문 흐름에 맞게 배치한 **마크다운(+ autopost용 사진 staging)**까지 생성한다. 이후 `/autopost upload`로 네이버 임시저장에 올린다.

### 1.3 성공 정의

- 사용자가 `docs/10.input/{페르소나}/{날짜}/`에 사진을 넣고 `/write-photo`를 실행하면, **활성 페르소나 목소리의 본문 + 사진 배치 표 + autopost가 인식 가능한 staging 사진**이 생성된다.
- 비전이 모르는 "사진의 의도"는 **비전 추정 캡션 → 사용자 보정** 인터뷰로 보강한다.
- 이어서 `/autopost upload <md>`만 실행하면 본문 단락 사이에 **실제 사진이 자동 배치**되어 임시저장된다.

### 1.4 Non-Goals (다루지 않는 것)

- **AI 이미지 생성** — 실제 사진만 사용. Gemini 생성 경로(autopost `generate-images`)는 호출하지 않는다.
- **네이버 임시저장/발행** — `/autopost` 책임. 본 스킬은 마크다운 + 사진 staging까지.
- **스크래핑 이미지(URL)로부터의 글쓰기** — 로컬 실제 사진 전용.
- **사진 보정/편집** — 원본은 읽기만, 수정·이동하지 않는다(`docs/10.input/` = 원본 보존).
- **공개 발행 자동화** — 항상 사용자 손으로.

---

## 2. 사용자 시나리오 (User Scenarios)

### 시나리오 A — 오늘 작업 후기 (Happy Path)

```
사전: /persona use 샘플세차샵  (활성 페르소나 설정)
      오늘 세차 작업 사진 30장을 docs/10.input/샘플세차샵/20260602/ 에 넣음

사용자: /write-photo            (인자 없으면 활성페르소나+오늘 폴더 자동)

[load]   persona_context.py → 닉네임 홍길동·톤·구조 로딩
[list]   list_photos.py → EXIF 촬영일시순 30장 정렬
[vision] 사진 순서대로 Read → 캡션 초안 표 제시
[edit]   사용자: "3번 타르제거 아님 / 12번 패스 / 나머지 확정"
[save]   .photo_analysis_샘플세차샵_20260602.json 저장
[write]  페르소나 말투 본문 작성 → clean_text 통과 → ## 사진 배치 표
[stage]  stage_photos.py → docs/10.input/gemini/{md_stem}__NN_label.png

✅ docs/30.output/31.posts/{제목}_20260602.md 완성
   👉 이어서: /autopost upload <md> 로 임시저장하세요.
```

### 시나리오 B — 날짜 지정

```
사용자: /write-photo 20260531
        → docs/10.input/샘플세차샵/20260531/ 의 사진으로 작성
```

### 시나리오 C — 사진이 많을 때 (토큰 절약)

```
[list] 사진 31장 감지 (13장 초과)
[ask]  전수 분석 vs 대표 12장 분석? → 기본 권장: 대표 12장
       (나머지는 촬영순서·파일명으로 before/after 추론, 본문엔 전부 배치)
```

### 시나리오 D — 폴더 없음/비어 있음

```
[error] docs/10.input/샘플세차샵/20260602/ 에 사진이 없습니다.
        이 폴더에 작업 사진을 넣고 다시 실행하세요.
```

---

## 3. 기능 요구사항 (Functional Requirements)

| ID | 요구사항 | 우선순위 | 상태 |
|----|----------|----------|------|
| FR1 | 활성 페르소나 로딩 (write/persona_context.py 재사용) | P0 | 예정 |
| FR2 | 인자(없음/날짜/경로) → `docs/10.input/{페르소나}/{날짜}/` 경로 해석 | P0 | 예정 |
| FR3 | 폴더 사진 EXIF 촬영일시순 정렬·목록 JSON (list_photos.py) | P0 | 예정 |
| FR4 | 사진 비전 Read → 캡션·phase 추정 | P0 | 예정 |
| FR5 | 추정 캡션 표 제시 → 사용자 보정 → 확정 분석 JSON 저장 | P0 | 예정 |
| FR6 | 13장 초과 시 전수/대표(12장) 선택 | P1 | 예정 |
| FR7 | 골격 생성 (write/scaffold_post.py 재사용) | P0 | 예정 |
| FR8 | 페르소나 말투 본문 작성 + clean_text 적용 | P0 | 예정 |
| FR9 | `## 사진 배치` 검수용 표 작성 | P1 | 예정 |
| FR10 | 사진 staging → autopost 글롭 규칙 png 복사 (stage_photos.py) | P0 | 예정 |
| FR11 | 완료 후 `/autopost upload` 안내 | P0 | 예정 |

---

## 4. 기술 설계 (Technical Design)

### 4.1 본문 마커 + 콜라주 (실제 구현)

초안의 "autopost 무수정 연결"은 검증 중 한계가 드러나 **autopost를 확장**하는 방향으로 확정됐다.

**(1) 본문 `[[IMG]]` 마커** — write-photo가 본문에 사진 위치/개수를 직접 박는다. drafter `_enter_body_markers`가 연속 마커를 한 구역으로 모아, `_collage_split(n)`(1~3장=한 줄, 4장↑=2장씩+홀수 끝줄 3장)으로 한 줄씩 배치한다. (마커 없으면 기존 `_compute_image_positions` 폴백 → `/write` 하위호환)

**(2) input 직접 주입 (다이얼로그 폐기)** — 네이버 SE3는 hidden file input이 미리 없고 사진버튼 클릭 시 OS 다이얼로그를 띄운다. pyautogui로 다이얼로그를 조작하면 포커스·타이밍·경로잘림으로 불안정했다. → `HTMLInputElement.prototype.click`을 JS 후킹으로 무력화(다이얼로그 차단)하고, 캡처한 `input[type=file]`(multiple)에 `send_keys("\n".join(paths))`로 직접 주입한다. **OS 다이얼로그가 안 떠 사용자 개입 불필요.**

**(3) 콜라주 자동 선택** — 사진 2장 이상 주입 시 네이버가 '사진 첨부 방식'(개별/콜라주/슬라이드) 팝업을 띄운다. drafter `_select_collage`가 `div.se-image-type-option-collage`를 클릭해 **한 줄 콜라주**로 만든다.

**(4) 짧은 staging 경로** — 다이얼로그 경로 잘림을 막기 위해(과거 pyautogui 잔재 대비) staging 파일명을 `.imgstage/{NN}.png`로 짧게 둔다. autopost는 `upload <md> --photos-dir docs/20.working/22.state/.imgstage`로 파일명순으로 읽는다.

**(5) 태그 단계 dim 회피** — 발행 다이얼로그 전환 중 `se-popup-dim`이 태그 input을 가려 클릭이 막히던 문제를, dim 사라짐 대기 + JS click 폴백으로 해결.

### 4.2 신규 파일

| 파일 | 역할 |
|------|------|
| `.claude/skills/write-photo/SKILL.md` | 0~9단계 실행흐름. `model: opus`, `allowed-tools: [Read, Write, Edit, Bash, Glob, AskUserQuestion]` |
| `scripts/list_photos.py` | 폴더→EXIF 촬영일시순(없으면 mtime/파일명) 정렬·개수·균등샘플 인덱스 JSON (읽기전용) |
| `scripts/stage_photos.py` | 배치순서대로 사진을 `gemini/{md_stem}__{NN}_{label}.png` 복사(+jpg→png Pillow 변환) |

### 4.3 재사용 (무수정)

- `write/scripts/persona_context.py` — 페르소나+가이드 통합 로딩
- `write/scripts/clean_text.py` — 본문 마크다운 잔재 제거(본문 전용)
- `write/scripts/scaffold_post.py` — 마크다운 골격
- `autopost/scripts/image_prompts.py` — `ImagePrompt.label`/`.filename()` 규칙(도입/본문N/마무리)
- `autopost/scripts/{image_gen,drafter}.py` — staging 글롭 규칙·위치계산·업로드

### 4.4 의존성

`Pillow` — EXIF 촬영일시 읽기 + jpg→png 변환. `docs/90.reference/98.setup/requirements.txt`에 없으면 추가. EXIF 없으면 mtime→파일명 fallback.

### 4.5 데이터 산출물 위치 (CLAUDE.md 준수)

| 산출물 | 위치 |
|--------|------|
| 사진 원본(입력) | `docs/10.input/{페르소나}/{YYYYMMDD}/` (수정 X) |
| 사진 분석(중간) | `docs/20.working/22.state/.photo_analysis_{페르소나}_{날짜}.json` |
| staging 사진 | `docs/10.input/gemini/{md_stem}__{NN}_{label}.png` |
| 블로그 글(산출) | `docs/30.output/31.posts/{제목}_{YYYYMMDD}.md` |

---

## 5. 마일스톤

| 마일스톤 | 내용 | 상태 |
|----------|------|------|
| M0 | PRD 작성 | ✅ |
| M1 | list_photos.py (EXIF 정렬·목록 JSON) | ✅ |
| M2 | stage_photos.py (짧은 `.imgstage/NN.png` staging) | ✅ |
| M3 | write-photo SKILL.md (0~9단계 + 마커/콜라주 지침) | ✅ |
| M4 | Pillow 의존성 + 샘플세차샵 31장 비전 분석 | ✅ |
| M5 | drafter 마커 배치 + autopost `--photos-dir` | ✅ |
| M6 | input 주입(다이얼로그 폐기) + 콜라주 자동선택 + dim 회피 | ✅ |
| M7 | E2E: 샘플세차샵 31장 콜라주 임시저장 성공 | ✅ |

---

## 6. 리스크 & 대응

| 리스크 | 대응 |
|--------|------|
| 사진 30장+ 전수 비전 = 토큰 과다 | 13장 초과 시 대표 12장 선별(FR6) |
| 비전이 사진 의도를 오해 | 캡션 초안 → 사용자 보정 인터뷰(FR5) |
| EXIF 없는 사진 정렬 오류 | mtime→파일명 fallback |
| gemini 폴더에 실제사진 섞임 | ✅ 해결: 실사진은 별도 `.imgstage`, `--photos-dir`로 분리 |
| OS 파일 다이얼로그 불안정(포커스/경로잘림) | ✅ 해결: input.click JS 후킹 + 직접 send_keys로 다이얼로그 폐기 |
| 멀티 업로드 시 '사진 첨부 방식' 팝업 막힘 | ✅ 해결: `_select_collage`가 콜라주 자동 선택 |
| `model: sonnet` 1M 크레딧 에러 재발 | `model: opus` 고정 |
