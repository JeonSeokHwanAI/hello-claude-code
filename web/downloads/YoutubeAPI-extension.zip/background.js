// 아이콘 클릭 → 검색 페이지를 새 탭으로 연다. (NaverAPI와 동일 방식)
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("search.html");
  // 이미 열린 검색 탭이 있으면 그 탭을 활성화, 없으면 새로 연다.
  const tabs = await chrome.tabs.query({ url: url + "*" });
  if (tabs.length > 0) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    if (tabs[0].windowId != null) {
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    }
  } else {
    await chrome.tabs.create({ url });
  }
});
