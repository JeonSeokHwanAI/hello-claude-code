// 옵션 페이지: API Key 저장/테스트, 전역 기본값, 관심 분야 CRUD.
import {
  getApiKey,
  setApiKey,
  getSettings,
  saveSettings,
  getTopics,
  saveTopics,
  setTopicActive,
} from "./lib/storage.js";
import { pingKey, videoCategories, searchList, channelsByIds, ApiError } from "./lib/api.js";
import { el, clear, uid, pickThumb } from "./lib/util.js";

const $ = (id) => document.getElementById(id);
let settings = null;
let topics = [];
let editing = null; // 편집 중 topic (사본)
let chosenChannels = []; // 편집 중 채널 [{id,title,thumb}]

init();

async function init() {
  settings = await getSettings();
  topics = await getTopics();
  $("apiKey").value = await getApiKey();
  $("defRegion").value = settings.regionCode || "KR";
  $("defLang").value = settings.relevanceLanguage || "ko";

  wireKey();
  wireDefaults();
  wireEditor();
  renderTopicList();
}

function toast(text) {
  const t = $("toast");
  t.textContent = text;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 1600);
}

// ── API Key ──────────────────────────────────────────
function wireKey() {
  $("toggleKey").addEventListener("click", () => {
    const inp = $("apiKey");
    inp.type = inp.type === "password" ? "text" : "password";
    $("toggleKey").textContent = inp.type === "password" ? "표시" : "숨김";
  });
  $("saveKey").addEventListener("click", async () => {
    await setApiKey($("apiKey").value);
    setStatus("키를 저장했습니다.", "ok");
  });
  $("testKey").addEventListener("click", async () => {
    await setApiKey($("apiKey").value); // 테스트 전 저장
    setStatus("테스트 중…", "");
    try {
      await pingKey();
      setStatus("✓ 키가 정상 동작합니다.", "ok");
    } catch (e) {
      setStatus("✗ " + (e instanceof ApiError ? e.message : e.message || e), "err");
    }
  });
}
function setStatus(text, kind) {
  const s = $("keyStatus");
  s.textContent = text;
  s.className = "status " + (kind || "");
}

// ── 전역 기본값 ──────────────────────────────────────
function wireDefaults() {
  $("saveDefaults").addEventListener("click", async () => {
    settings = await saveSettings({
      regionCode: ($("defRegion").value.trim().toUpperCase() || "KR"),
      relevanceLanguage: ($("defLang").value.trim() || "ko"),
    });
    toast("기본값 저장됨");
  });
}

// ── 분야 목록 ────────────────────────────────────────
function renderTopicList() {
  const list = $("topicList");
  clear(list);
  if (!topics.length) {
    list.appendChild(el("div", { class: "empty", text: "아직 분야가 없습니다. ‘+ 분야 추가’로 만들어보세요." }));
    return;
  }
  for (const t of topics) {
    const parts = [];
    if (t.categoryIds?.length) parts.push(`카테고리 ${t.categoryIds.length}`);
    if (t.keywordSets?.length) parts.push(`키워드세트 ${t.keywordSets.length}`);
    if (t.channels?.length) parts.push(`채널 ${t.channels.length}`);
    parts.push(`${t.regionCode || settings.regionCode}/${t.relevanceLanguage || settings.relevanceLanguage}`);

    const isActive = (settings.activeTopicIds || []).includes(t.id);
    const row = el("div", { class: "topic-row" }, [
      el("div", { class: "emoji", text: t.emoji || "📌" }),
      el("div", { class: "info" }, [
        el("div", { class: "name" }, [
          document.createTextNode(t.name || "(이름 없음)"),
          isActive ? el("span", { class: "tag", text: "활성" }) : null,
        ]),
        el("div", { class: "sub", text: parts.join(" · ") }),
      ]),
      isActive
        ? el("button", { text: "활성 해제", on: { click: () => toggleActive(t.id, false) } })
        : el("button", { class: "primary", text: "활성", on: { click: () => toggleActive(t.id, true) } }),
      el("button", { text: "편집", on: { click: () => openEditor(t) } }),
      el("button", { class: "danger", text: "삭제", on: { click: () => removeTopic(t) } }),
    ]);
    list.appendChild(row);
  }
}

async function toggleActive(id, active) {
  settings = await setTopicActive(id, active);
  toast(active ? "활성 분야 추가됨" : "활성에서 제외됨");
  renderTopicList();
}

async function removeTopic(t) {
  if (!confirm(`'${t.name || "이 분야"}'를 삭제할까요?`)) return;
  topics = topics.filter((x) => x.id !== t.id);
  await saveTopics(topics);
  settings = await setTopicActive(t.id, false); // 활성 목록에서도 제거
  renderTopicList();
  toast("분야 삭제됨");
}

// ── 분야 편집기 ──────────────────────────────────────
function wireEditor() {
  $("addTopic").addEventListener("click", () => openEditor(null));
  $("closeEditor").addEventListener("click", closeEditor);
  $("cancelEditor").addEventListener("click", closeEditor);
  $("addKs").addEventListener("click", () => addKsRow({ name: "", terms: [] }));
  $("chSearchBtn").addEventListener("click", searchChannels);
  $("chQuery").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); searchChannels(); } });
  $("saveTopic").addEventListener("click", saveEditing);
  $("deleteTopic").addEventListener("click", deleteEditing);
}

async function openEditor(topic) {
  editing = topic
    ? JSON.parse(JSON.stringify(topic))
    : { id: uid(), name: "", emoji: "📌", categoryIds: [], keywordSets: [], channels: [], regionCode: settings.regionCode, relevanceLanguage: settings.relevanceLanguage };

  $("editorTitle").textContent = topic ? "분야 편집" : "분야 추가";
  $("tName").value = editing.name || "";
  $("tEmoji").value = editing.emoji || "";
  $("tRegion").value = editing.regionCode || settings.regionCode;
  $("tLang").value = editing.relevanceLanguage || settings.relevanceLanguage;
  $("tActive").checked = (settings.activeTopicIds || []).includes(editing.id);
  $("deleteTopic").hidden = !topic;

  // 키워드 세트
  clear($("ksList"));
  (editing.keywordSets || []).forEach(addKsRow);

  // 채널
  chosenChannels = (editing.channels || []).map((c) => ({ ...c }));
  renderChosenChannels();
  clear($("chResults"));
  $("chQuery").value = "";

  $("editor").hidden = false;
  loadCategories(editing.regionCode || settings.regionCode);
}

function closeEditor() {
  $("editor").hidden = true;
  editing = null;
}

async function loadCategories(region) {
  const box = $("catBox");
  box.textContent = "불러오는 중…";
  try {
    const res = await videoCategories(region);
    const cats = (res.items || []).filter((c) => c.snippet && c.snippet.assignable !== false);
    clear(box);
    const sel = new Set(editing.categoryIds || []);
    for (const c of cats) {
      const cb = el("input", { type: "checkbox", value: c.id });
      cb.checked = sel.has(c.id);
      box.appendChild(el("label", {}, [cb, document.createTextNode(" " + c.snippet.title)]));
    }
  } catch (e) {
    console.error("[옵션] 카테고리 로드 실패:", e);
    clear(box);
    box.appendChild(el("div", { class: "status err", text: (e instanceof ApiError ? e.message : ("카테고리 로드 실패: " + (e?.message || e))) }));
    box.appendChild(el("div", { class: "hint", text: "API Key를 먼저 [저장]했는지, [키 테스트]가 ✓ 인지 확인하세요." }));
  }
}

function addKsRow(ks) {
  const nameInp = el("input", { class: "name", placeholder: "세트 이름", value: ks?.name || "" });
  const termsInp = el("input", { class: "terms", placeholder: "키워드, 콤마로 구분 (예: LLM, claude code)", value: (ks?.terms || []).join(", ") });
  const del = el("button", { text: "✕", on: { click: () => row.remove() } });
  const row = el("div", { class: "ks-item" }, [nameInp, termsInp, del]);
  $("ksList").appendChild(row);
}

async function searchChannels() {
  const q = $("chQuery").value.trim();
  if (!q) return;
  const box = $("chResults");
  clear(box);
  box.appendChild(el("div", { class: "status", text: "검색 중…" }));
  try {
    const res = await searchList({ q, type: "channel", maxResults: 8, regionCode: $("tRegion").value || settings.regionCode });
    const ids = (res.items || []).map((it) => it.id?.channelId).filter(Boolean);
    const detail = await channelsByIds(ids);
    clear(box);
    for (const c of detail.items || []) {
      box.appendChild(channelResultRow(c));
    }
    if (!(detail.items || []).length) box.appendChild(el("div", { class: "status", text: "결과 없음" }));
  } catch (e) {
    clear(box);
    box.appendChild(el("div", { class: "status err", text: e instanceof ApiError ? e.message : "채널 검색 실패" }));
  }
}

function channelResultRow(c) {
  const item = { id: c.id, title: c.snippet?.title || "", thumb: pickThumb(c.snippet?.thumbnails) };
  return el("div", { class: "ch-item" }, [
    el("img", { src: item.thumb, attrs: { alt: "" } }),
    el("div", { class: "t", text: item.title }),
    el("button", { text: "추가", on: { click: () => addChannel(item) } }),
  ]);
}

function addChannel(item) {
  if (chosenChannels.some((c) => c.id === item.id)) return toast("이미 추가됨");
  chosenChannels.push(item);
  renderChosenChannels();
}

function renderChosenChannels() {
  const box = $("chChosen");
  clear(box);
  if (!chosenChannels.length) return;
  box.appendChild(el("div", { class: "hint", text: "선택된 채널:" }));
  for (const c of chosenChannels) {
    box.appendChild(
      el("div", { class: "ch-item" }, [
        c.thumb ? el("img", { src: c.thumb, attrs: { alt: "" } }) : el("div", {}),
        el("div", { class: "t", text: c.title }),
        el("button", { text: "제거", on: { click: () => { chosenChannels = chosenChannels.filter((x) => x.id !== c.id); renderChosenChannels(); } } }),
      ])
    );
  }
}

async function saveEditing() {
  editing.name = $("tName").value.trim() || "새 분야";
  editing.emoji = $("tEmoji").value.trim() || "📌";
  editing.regionCode = $("tRegion").value.trim().toUpperCase() || settings.regionCode;
  editing.relevanceLanguage = $("tLang").value.trim() || settings.relevanceLanguage;
  editing.categoryIds = [...$("catBox").querySelectorAll("input:checked")].map((cb) => cb.value);
  editing.keywordSets = [...$("ksList").querySelectorAll(".ks-item")]
    .map((row) => ({
      name: row.querySelector(".name").value.trim(),
      terms: row.querySelector(".terms").value.split(",").map((s) => s.trim()).filter(Boolean),
    }))
    .filter((ks) => ks.terms.length);
  editing.channels = chosenChannels.map((c) => ({ id: c.id, title: c.title }));

  const idx = topics.findIndex((t) => t.id === editing.id);
  if (idx >= 0) topics[idx] = editing;
  else topics.push(editing);
  await saveTopics(topics);

  // 체크 상태대로 활성 목록에 반영(복수 허용)
  settings = await setTopicActive(editing.id, $("tActive").checked);

  closeEditor();
  renderTopicList();
  toast("분야 저장됨");
}

async function deleteEditing() {
  topics = topics.filter((t) => t.id !== editing.id);
  await saveTopics(topics);
  settings = await setTopicActive(editing.id, false);
  closeEditor();
  renderTopicList();
  toast("분야 삭제됨");
}
