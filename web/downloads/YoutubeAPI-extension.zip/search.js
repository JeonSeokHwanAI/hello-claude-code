// 검색 페이지 컨트롤러: 검색 / 트렌딩 / 내 분야 3탭.
import {
  searchList,
  mostPopular,
  videoCategories,
  videosByIds,
  channelsByIds,
  playlistItems,
  commentThreads,
  ApiError,
} from "./lib/api.js";
import {
  enrichVideos,
  enrichChannels,
  enrichPlaylists,
  renderCards,
  videoCard,
} from "./lib/render.js";
import { el, clear, daysAgoRFC3339, uid, formatCount } from "./lib/util.js";
import { toPlainText, toCSV, copyText, downloadCSV } from "./lib/export.js";
import {
  getApiKey,
  getSettings,
  saveSettings,
  getActiveTopic,
  getActiveTopics,
  getTopics,
  pushRecentQuery,
  getRecentQueries,
  clearRecentQueries,
  addChannelToTopic,
  addVideoBookmark,
  removeVideoBookmark,
} from "./lib/storage.js";

const $ = (id) => document.getElementById(id);
const main = $("main");
const resultsEl = $("results");
const chipBar = $("chipBar");
const moreWrap = $("moreWrap");
const searchControls = $("searchControls");

let settings = null;
let activeTopic = null; // 대표(첫 번째) 활성 분야 — 검색 기본값/배지용
let activeCount = 0; // 활성 분야 개수
let categoriesCache = null; // { region, list:[{id,title}] }

// 현재 화면 상태(더보기/내보내기용)
const state = {
  tab: "search",
  type: "video", // 마지막으로 그린 카드 종류
  items: [], // 누적 결과(내보내기 대상)
  nextPageToken: null,
  loadMore: null, // 더보기 콜백
  dashTopicId: null, // 내 분야에서 보고 있는 분야
  dashFilters: { order: "relevance", period: "", dur: "" }, // 내 분야 조건
  trendRegion: null, // 트렌딩 탭에서 선택한 지역(없으면 settings.regionCode)
};

// ── 부팅 ──────────────────────────────────────────────
init();

async function init() {
  settings = await getSettings();
  const actives = await getActiveTopics();
  activeTopic = actives[0] || null;
  activeCount = actives.length;
  $("regionInput").value = settings.regionCode || "KR";
  renderActiveTopicPill();
  wireTabs();
  wireSearchControls();
  wireTopicControls();
  wireExport();
  document.addEventListener("add-to-topic", (e) => openAddToTopicMenu(e.detail));
  document.addEventListener("show-comments", (e) => openComments(e.detail));
  document.addEventListener("show-channel", (e) => openChannelDetail(e.detail));
  $("optionsBtn").addEventListener("click", () => chrome.runtime.openOptionsPage());

  const hasKey = await getApiKey();
  if (!hasKey) {
    showNoKey();
    return;
  }
  // 활성 분야의 검색 기본값 적용
  applyTopicDefaultsToSearch();
  await renderRecent();
  showEmptyHint();
}

// 최근 검색어 칩 렌더 (검색 탭에서만 표시)
async function renderRecent() {
  const bar = $("recentBar");
  const list = await getRecentQueries();
  clear(bar);
  if (!list.length || state.tab !== "search") {
    bar.hidden = true;
    return;
  }
  bar.hidden = false;
  bar.appendChild(el("span", { class: "label", text: "최근 검색:" }));
  for (const q of list) {
    bar.appendChild(
      el("button", {
        class: "rq",
        text: q,
        on: {
          click: () => {
            $("qInput").value = q;
            runSearch(true);
          },
        },
      })
    );
  }
  bar.appendChild(
    el("button", { class: "clear-rq", text: "지우기", on: { click: async () => { await clearRecentQueries(); renderRecent(); } } })
  );
}

function renderActiveTopicPill() {
  const pill = $("activeTopicPill");
  if (activeTopic) {
    pill.hidden = false;
    clear(pill);
    const extra = activeCount > 1 ? ` +${activeCount - 1}` : "";
    pill.appendChild(document.createTextNode(`${activeTopic.emoji || "📌"} ${activeTopic.name}${extra}`));
  } else {
    pill.hidden = true;
  }
}

// 활성 분야 → 검색 기본값(지역/언어) 자동 적용
function applyTopicDefaultsToSearch() {
  if (!activeTopic) return;
  if (activeTopic.regionCode) $("regionInput").value = activeTopic.regionCode;
}

// ── 탭 전환 ───────────────────────────────────────────
function wireTabs() {
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });
}

async function switchTab(tab) {
  const prevTab = state.tab;
  // 검색 탭을 떠날 때 결과·상태를 저장(돌아오면 그대로 복원)
  if (prevTab === "search" && tab !== "search") saveSearchView();

  state.tab = tab;
  document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  searchControls.hidden = tab !== "search";
  $("topicControls").hidden = tab !== "topic";
  $("trendingControls").hidden = tab !== "trending";
  chipBar.hidden = tab === "search";
  moreWrap.hidden = true;
  clear(resultsEl);
  clear(chipBar);

  if (!(await getApiKey())) return showNoKey();

  await renderRecent();

  if (tab === "search") {
    if (!restoreSearchView()) showEmptyHint();
  } else if (tab === "trending") {
    await initTrending();
  } else if (tab === "topic") {
    await initTopicDashboard();
  }
}

// 검색 탭 결과·상태 보존용 스냅샷
let searchView = null;
function saveSearchView() {
  const frag = document.createDocumentFragment();
  while (resultsEl.firstChild) frag.appendChild(resultsEl.firstChild);
  searchView = {
    frag,
    items: state.items,
    nextPageToken: state.nextPageToken,
    type: state.type,
    moreHidden: moreWrap.hidden,
  };
}
function restoreSearchView() {
  if (!searchView) return false;
  clear(resultsEl);
  resultsEl.appendChild(searchView.frag);
  state.items = searchView.items;
  state.nextPageToken = searchView.nextPageToken;
  state.type = searchView.type;
  moreWrap.hidden = searchView.moreHidden;
  state.loadMore = () => runSearch(false);
  searchView = null;
  return true;
}

// ── 공통 상태 표시 ────────────────────────────────────
function showSpinner() {
  clear(resultsEl);
  resultsEl.appendChild(el("div", { class: "spinner" }));
}
function showEmptyHint() {
  clear(resultsEl);
  const msg = activeTopic
    ? `'${activeTopic.name}' 분야 기본값이 적용되어 있어요. 검색어를 입력해 보세요.`
    : "검색어를 입력하고 검색을 눌러보세요. (옵션에서 관심 분야를 만들면 더 편해요)";
  resultsEl.appendChild(el("div", { class: "center", text: msg }));
}
function showNoKey() {
  clear(resultsEl);
  moreWrap.hidden = true;
  const n = el("div", { class: "notice error" }, [
    el("strong", { text: "API Key가 필요합니다. " }),
    document.createTextNode("옵션 페이지에서 YouTube Data API 키를 입력·저장하세요. "),
    el("button", { class: "primary", text: "옵션 열기", on: { click: () => chrome.runtime.openOptionsPage() } }),
  ]);
  resultsEl.appendChild(n);
}
function showError(e) {
  clear(resultsEl);
  moreWrap.hidden = true;
  const msg = e instanceof ApiError ? e.message : "오류가 발생했습니다: " + (e?.message || e);
  const n = el("div", { class: "notice error" }, [el("strong", { text: "⚠ " }), document.createTextNode(msg)]);
  if (e instanceof ApiError && e.reason === "noKey") {
    n.appendChild(el("button", { class: "primary", text: "옵션 열기", on: { click: () => chrome.runtime.openOptionsPage() } }));
  }
  resultsEl.appendChild(n);
}
function toast(text) {
  const t = $("toast");
  t.textContent = text;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 1600);
}

// ── 검색 탭 ───────────────────────────────────────────
function wireSearchControls() {
  $("searchForm").addEventListener("submit", (e) => {
    e.preventDefault();
    runSearch(true);
  });
  $("typeSel").addEventListener("change", () => {
    const isVideo = $("typeSel").value === "video";
    document.querySelectorAll("[data-video-only]").forEach((n) => (n.style.display = isVideo ? "" : "none"));
  });
  $("regionInput").addEventListener("change", async () => {
    const rc = $("regionInput").value.trim().toUpperCase() || "KR";
    settings = await saveSettings({ regionCode: rc });
  });
  $("moreBtn").addEventListener("click", () => state.loadMore && state.loadMore());
}

// 내 분야 조건(정렬/기간/길이) 변경 → 현재 보고 있는 분야 대시보드 다시 그림
function wireTopicControls() {
  const apply = () => {
    state.dashFilters = {
      order: $("tOrderSel").value,
      period: $("tPeriodSel").value,
      dur: $("tDurSel").value,
    };
    initTopicDashboard();
  };
  $("tOrderSel").addEventListener("change", apply);
  $("tPeriodSel").addEventListener("change", apply);
  $("tDurSel").addEventListener("change", apply);
  $("tCopyBtn").addEventListener("click", async () => {
    if (!state.items.length) return toast("내보낼 결과가 없습니다");
    await copyText(toPlainText(state.items, "video"));
    toast(`${state.items.length}건 복사됨`);
  });
  $("tCsvBtn").addEventListener("click", () => {
    if (!state.items.length) return toast("내보낼 결과가 없습니다");
    downloadCSV(toCSV(state.items, "video"), `youtube-myfield.csv`);
    toast("CSV 저장됨");
  });
}

async function runSearch(reset) {
  const q = $("qInput").value.trim();
  const type = $("typeSel").value;
  if (!q) {
    toast("검색어를 입력하세요");
    return;
  }
  if (reset) {
    state.items = [];
    state.nextPageToken = null;
    showSpinner();
  }
  const order = $("orderSel").value;
  const region = $("regionInput").value.trim().toUpperCase() || "KR";
  const period = $("periodSel").value;
  const dur = $("durSel").value;
  const lang = (activeTopic && activeTopic.relevanceLanguage) || settings.relevanceLanguage || "ko";

  try {
    const res = await searchList({
      q,
      type,
      order,
      maxResults: 24,
      pageToken: state.nextPageToken || undefined,
      regionCode: region,
      relevanceLanguage: lang,
      publishedAfter: period ? daysAgoRFC3339(parseInt(period, 10)) : undefined,
      videoDuration: dur || undefined,
    });
    if (reset) {
      await pushRecentQuery(q);
      renderRecent();
    }
    state.nextPageToken = res.nextPageToken || null;
    state.type = type;

    let items = [];
    if (type === "video") items = await enrichVideos(res.items || []);
    else if (type === "channel") items = await enrichChannels(res.items || []);
    else items = await enrichPlaylists(res.items || []);

    if (reset) clear(resultsEl);
    if (!items.length && reset) {
      resultsEl.appendChild(el("div", { class: "center", text: "결과가 없습니다." }));
    } else {
      const grid = ensureGrid();
      renderCards(grid, items, type);
      state.items.push(...items);
    }
    moreWrap.hidden = !state.nextPageToken;
    state.loadMore = () => runSearch(false);
  } catch (e) {
    if (reset) showError(e);
    else toast(e instanceof ApiError ? e.message : "더 불러오지 못했습니다");
  }
}

function ensureGrid() {
  let grid = resultsEl.querySelector(".grid");
  if (!grid) {
    grid = el("div", { class: "grid" });
    resultsEl.appendChild(grid);
  }
  return grid;
}

// ── 트렌딩 탭 ─────────────────────────────────────────
// 트렌딩 탭에서 사용할 지역(드롭다운 선택값 우선, 없으면 전역 설정)
function trendRegion() {
  return state.trendRegion || settings.regionCode || "KR";
}

async function initTrending() {
  if (!state.trendRegion) state.trendRegion = settings.regionCode || "KR";
  const sel = $("trendRegionSel");
  sel.value = state.trendRegion;
  if (!sel.dataset.wired) {
    sel.dataset.wired = "1";
    sel.addEventListener("change", async () => {
      state.trendRegion = sel.value;
      await initTrending(); // 지역 변경 → 카테고리·목록 다시 로드
    });
  }
  showSpinner();
  try {
    const cats = await getCategories();
    state.trendCat = (activeTopic && activeTopic.categoryIds && activeTopic.categoryIds[0]) || "0";
    const onPick = (id) => {
      state.trendCat = id;
      renderCategoryChips(cats, id, onPick);
      loadTrending(true);
    };
    renderCategoryChips(cats, state.trendCat, onPick);
    await loadTrending(true);
  } catch (e) {
    showError(e);
  }
}

async function getCategories(region = trendRegion()) {
  if (categoriesCache && categoriesCache.region === region) return categoriesCache.list;
  const res = await videoCategories(region);
  const list = (res.items || [])
    .filter((c) => c.snippet && c.snippet.assignable !== false)
    .map((c) => ({ id: c.id, title: c.snippet.title }));
  categoriesCache = { region, list };
  return list;
}

function renderCategoryChips(cats, selectedId, onPick) {
  clear(chipBar);
  const topicCatIds = new Set((activeTopic && activeTopic.categoryIds) || []);
  const all = [{ id: "0", title: "전체" }, ...cats];
  for (const c of all) {
    const isStar = topicCatIds.has(c.id);
    const chip = el("button", {
      class: "chip" + (c.id === selectedId ? " active" : "") + (isStar ? " star" : ""),
      text: (isStar ? "★ " : "") + c.title,
      on: { click: () => onPick(c.id) },
    });
    chipBar.appendChild(chip);
  }
}

async function loadTrending(reset) {
  if (reset) {
    state.trendToken = null;
    showSpinner();
  }
  try {
    const res = await mostPopular({
      regionCode: trendRegion(),
      videoCategoryId: state.trendCat && state.trendCat !== "0" ? state.trendCat : undefined,
      pageToken: state.trendToken || undefined,
      maxResults: 24,
    });
    state.trendToken = res.nextPageToken || null;
    state.type = "video";
    if (reset) {
      clear(resultsEl);
      state.items = [];
    }
    const grid = ensureGrid();
    renderCards(grid, res.items || [], "video");
    state.items.push(...(res.items || []));
    moreWrap.hidden = !state.trendToken;
    state.loadMore = () => loadTrending(false);
  } catch (e) {
    if (reset) showError(e);
    else toast(e instanceof ApiError ? e.message : "더 불러오지 못했습니다");
  }
}

// ── 내 분야 대시보드 탭 (활성 분야만 표시) ────────────
async function initTopicDashboard() {
  clear(chipBar);
  const actives = await getActiveTopics();
  if (!actives.length) {
    clear(resultsEl);
    const topics = await getTopics();
    const msg = topics.length
      ? "활성화된 분야가 없습니다. 옵션에서 분야를 ‘활성’으로 켜면 여기에 표시됩니다. "
      : "아직 관심 분야가 없습니다. 옵션에서 분야를 만들어보세요. ";
    resultsEl.appendChild(
      el("div", { class: "notice" }, [
        document.createTextNode(msg),
        el("button", { class: "primary", text: "옵션 열기", on: { click: () => chrome.runtime.openOptionsPage() } }),
      ])
    );
    return;
  }
  // 보고 있는 분야(없거나 비활성화되면 첫 활성으로)
  let view = actives.find((t) => t.id === state.dashTopicId) || actives[0];
  state.dashTopicId = view.id;

  // 활성 분야 선택 칩 (클릭=보기 전환, 활성 상태는 옵션에서만 변경)
  for (const t of actives) {
    chipBar.appendChild(
      el("button", {
        class: "chip" + (t.id === view.id ? " active" : ""),
        text: `${t.emoji || "📌"} ${t.name}`,
        on: {
          click: () => {
            state.dashTopicId = t.id;
            initTopicDashboard();
          },
        },
      })
    );
  }
  await renderDashboard(view);
}

async function renderDashboard(topic) {
  clear(resultsEl);
  state.type = "video";
  state.items = [];
  moreWrap.hidden = true;

  const region = topic.regionCode || settings.regionCode || "KR";
  const cats = await getCategories(region).catch(() => []);
  const catTitle = (id) => (cats.find((c) => c.id === id) || {}).title || `카테고리 ${id}`;

  const f = state.dashFilters || { order: "relevance", period: "", dur: "" };
  const orderLabel = { relevance: "관련순", date: "최신", viewCount: "조회순", rating: "평점순" }[f.order] || "";
  const lang = topic.relevanceLanguage || settings.relevanceLanguage || "ko";

  // 0) 북마크한 영상 (가장 위 — 개인적으로 담아둔 것)
  if ((topic.videos || []).length) {
    const sec = addSection(`🔖 북마크한 영상 (${topic.videos.length})`);
    try {
      const ids = topic.videos.map((v) => v.id);
      const vres = await videosByIds(ids.slice(0, 50));
      const byId = new Map((vres.items || []).map((v) => [v.id, v]));
      const ordered = ids.map((id) => byId.get(id)).filter(Boolean);
      const items = applyDashFilters(ordered);
      if (!items.length) {
        sec.appendChild(el("div", { class: "center", text: "조건에 맞는 북마크가 없습니다." }));
      }
      for (const v of items) {
        const cardEl = videoCard(v);
        cardEl.appendChild(
          el("button", {
            class: "bm-remove",
            text: "✕",
            title: "북마크 제거",
            on: {
              click: async (e) => {
                e.preventDefault();
                e.stopPropagation();
                await removeVideoBookmark(topic.id, v.id);
                cardEl.remove();
                toast("북마크 제거됨");
              },
            },
          })
        );
        sec.appendChild(cardEl);
        state.items.push(v);
      }
    } catch (e) {
      sec.appendChild(el("div", { class: "center", text: e instanceof ApiError ? e.message : "불러오기 실패" }));
    }
  }

  // 1) 관심 채널 최신 업로드 (맨 위, 더보기 지원)
  if ((topic.channels || []).length) {
    const chRes = await channelsByIds(topic.channels.map((c) => c.id)).catch(() => ({ items: [] }));
    const uploads = (chRes.items || [])
      .map((c) => c.contentDetails?.relatedPlaylists?.uploads)
      .filter(Boolean)
      .map((pl) => ({ pl, token: undefined, done: false })); // 채널별 페이지 상태
    // 더보기 누를 때마다 각 채널의 다음 페이지를 6개씩 모아서 통계 보강
    const fetchChannelPage = async () => {
      const ids = [];
      for (const t of uploads) {
        if (t.done) continue;
        const pi = await playlistItems({ playlistId: t.pl, maxResults: 6, pageToken: t.token });
        for (const it of pi.items || []) {
          const vid = it.contentDetails?.videoId || it.snippet?.resourceId?.videoId;
          if (vid) ids.push(vid);
        }
        t.token = pi.nextPageToken;
        if (!pi.nextPageToken) t.done = true;
      }
      const vres = ids.length ? await videosByIds(ids.slice(0, 50)) : { items: [] };
      const anyMore = uploads.some((t) => !t.done);
      return { items: vres.items || [], nextPageToken: anyMore ? "more" : null };
    };
    await addPagedSection("📺 관심 채널 최신 업로드", fetchChannelPage);
  }

  // 2) 키워드 세트별 검색 (search 100u — 세트당 1회)
  // 키워드 세트를 안 넣었으면 '분야 이름'을 검색어로 자동 사용 → 다시 입력할 필요 없음.
  let keywordSets = (topic.keywordSets || []).filter((ks) => (ks.terms || []).length);
  if (!keywordSets.length && topic.name) {
    keywordSets = [{ name: topic.name, terms: [topic.name] }];
  }
  // publishedAfter는 페이지 간 동일해야 pageToken이 유효 → 루프 밖에서 한 번만 계산
  const publishedAfter = f.period ? daysAgoRFC3339(parseInt(f.period, 10)) : undefined;

  for (const ks of keywordSets) {
    const q = (ks.terms || []).join(" | ");
    if (!q) continue;
    await addPagedSection(
      `🔎 ${ks.name || "키워드"} · ${orderLabel}`,
      (pageToken) =>
        searchList({
          q,
          type: "video",
          order: f.order || "relevance",
          maxResults: 24,
          regionCode: region,
          relevanceLanguage: lang,
          publishedAfter,
          videoDuration: f.dur || undefined,
          pageToken: pageToken || undefined,
        }),
      { enrich: (items) => enrichVideos(items) }
    );
  }

  // 3) 카테고리별 인기
  for (const catId of topic.categoryIds || []) {
    await addPagedSection(`🔥 ${catTitle(catId)} 인기`, (pageToken) =>
      mostPopular({ regionCode: region, videoCategoryId: catId, maxResults: 12, pageToken: pageToken || undefined })
    );
  }

  if (!resultsEl.querySelector(".grid")) {
    resultsEl.appendChild(
      el("div", { class: "center", text: "이 분야에 카테고리·키워드·채널이 비어 있어요. 옵션에서 채워보세요." })
    );
  }
}

function addSection(title) {
  resultsEl.appendChild(el("div", { class: "section-title", text: title }));
  const grid = el("div", { class: "grid" });
  resultsEl.appendChild(grid);
  return grid;
}

// ISO8601 길이 → 초
function durationSec(iso) {
  const m = (iso || "").match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!m) return 0;
  return (+(m[1] || 0)) * 3600 + (+(m[2] || 0)) * 60 + (+(m[3] || 0));
}

// 내 분야 조건(정렬·길이·기간)을 화면(클라이언트)에서 일괄 적용.
// 채널·카테고리 API는 정렬/길이/기간 옵션이 없으므로 여기서 직접 처리한다.
function applyDashFilters(items) {
  const f = state.dashFilters || {};
  let out = items.slice();
  if (f.dur) {
    out = out.filter((v) => {
      const s = durationSec(v.contentDetails?.duration);
      if (!s) return true; // 길이 미상은 남김
      if (f.dur === "short") return s < 240;
      if (f.dur === "medium") return s >= 240 && s <= 1200;
      if (f.dur === "long") return s > 1200;
      return true;
    });
  }
  if (f.period) {
    const cutoff = Date.now() - parseInt(f.period, 10) * 86400000;
    out = out.filter((v) => {
      const t = Date.parse(v.snippet?.publishedAt || "");
      return isNaN(t) ? true : t >= cutoff;
    });
  }
  if (f.order === "viewCount") {
    out.sort((a, b) => Number(b.statistics?.viewCount || 0) - Number(a.statistics?.viewCount || 0));
  } else if (f.order === "date") {
    out.sort((a, b) => Date.parse(b.snippet?.publishedAt || 0) - Date.parse(a.snippet?.publishedAt || 0));
  }
  return out;
}

// 섹션 + 섹션 전용 "더보기". fetchPage(token)→{items,nextPageToken}, opts.enrich(items)→items
async function addPagedSection(title, fetchPage, opts = {}) {
  const grid = addSection(title);
  const moreBtn = el("button", { text: "더보기" });
  const wrap = el("div", { class: "more-wrap" }, [moreBtn]);
  wrap.hidden = true;
  resultsEl.appendChild(wrap);
  let token = null;
  let loading = false;
  let first = true;

  async function load() {
    if (loading) return;
    loading = true;
    moreBtn.disabled = true;
    moreBtn.textContent = "불러오는 중…";
    try {
      const res = await fetchPage(token);
      let items = res.items || [];
      if (opts.enrich) items = await opts.enrich(items);
      items = applyDashFilters(items); // 정렬·길이·기간 일괄 적용
      if (!items.length && first) {
        grid.appendChild(el("div", { class: "center", text: "결과 없음" }));
      } else {
        renderCards(grid, items, "video");
        state.items.push(...items);
      }
      token = res.nextPageToken || null;
      wrap.hidden = !token;
    } catch (e) {
      if (first) grid.appendChild(el("div", { class: "center", text: e instanceof ApiError ? e.message : "불러오기 실패" }));
      else toast(e instanceof ApiError ? e.message : "더 불러오지 못했습니다");
    } finally {
      first = false;
      loading = false;
      moreBtn.disabled = false;
      moreBtn.textContent = "더보기";
    }
  }
  moreBtn.addEventListener("click", load);
  await load();
}

// 영상 카드의 "＋분야" → 분야 선택 메뉴(채널 추가 / 영상 북마크)
async function openAddToTopicMenu(item) {
  document.querySelector(".menu-overlay")?.remove();
  const topics = await getTopics();
  const overlay = el("div", {
    class: "menu-overlay",
    on: { click: (e) => { if (e.target === overlay) overlay.remove(); } },
  });
  const card = el("div", { class: "menu-card" }, [
    el("h4", { text: "내 분야에 등록" }),
    el("div", { class: "vt", text: item.title || "" }),
  ]);

  if (!topics.length) {
    card.appendChild(el("div", { class: "center", text: "분야가 없습니다. 옵션에서 먼저 만들어주세요." }));
    card.appendChild(el("button", { class: "primary", text: "옵션 열기", on: { click: () => chrome.runtime.openOptionsPage() } }));
  } else {
    // 채널 추가 (channelId 있을 때만)
    if (item.channelId) {
      const opt1 = el("div", { class: "opt" });
      for (const t of topics) {
        opt1.appendChild(
          el("button", {
            text: `${t.emoji || "📌"} ${t.name}`,
            on: {
              click: async () => {
                const r = await addChannelToTopic(t.id, { id: item.channelId, title: item.channelTitle });
                toast(r === "exists" ? "이미 있는 채널" : `'${t.name}'에 채널 추가됨`);
                overlay.remove();
              },
            },
          })
        );
      }
      card.appendChild(el("div", { class: "grp" }, [
        el("div", { class: "grp-label", text: `📌 채널 추가 — ${item.channelTitle || ""}` }),
        opt1,
      ]));
    }

    // 영상 북마크
    const opt2 = el("div", { class: "opt" });
    for (const t of topics) {
      opt2.appendChild(
        el("button", {
          text: `${t.emoji || "📌"} ${t.name}`,
          on: {
            click: async () => {
              const r = await addVideoBookmark(t.id, item);
              toast(r === "exists" ? "이미 북마크됨" : `'${t.name}'에 북마크됨`);
              overlay.remove();
            },
          },
        })
      );
    }
    card.appendChild(el("div", { class: "grp" }, [
      el("div", { class: "grp-label", text: "🔖 이 영상 북마크" }),
      opt2,
    ]));
  }

  card.appendChild(el("button", { class: "ghost", text: "닫기", on: { click: () => overlay.remove() } }));
  overlay.appendChild(card);
  document.body.appendChild(overlay);
}

// ── 공용 모달 (채널 상세 / 댓글) ──────────────────────
function showModal(titleText) {
  document.querySelector(".menu-overlay")?.remove();
  const overlay = el("div", { class: "menu-overlay", on: { click: (e) => { if (e.target === overlay) overlay.remove(); } } });
  const head = el("div", { class: "modal-head2" }, [
    el("h4", { text: titleText }),
    el("button", { class: "ghost", text: "✕", on: { click: () => overlay.remove() } }),
  ]);
  const bodyEl = el("div", { class: "modal-body2" }, [el("div", { class: "spinner" })]);
  const card = el("div", { class: "menu-card wide" }, [head, bodyEl]);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  return { overlay, bodyEl };
}

// ── 댓글 보기 (commentThreads) ────────────────────────
async function openComments({ id, title }) {
  const { bodyEl } = showModal("💬 댓글");
  let order = "relevance";
  let token = null;
  let loading = false;

  const orderSel = el("select", {}, [
    el("option", { value: "relevance", text: "관련성순" }),
    el("option", { value: "time", text: "최신순" }),
  ]);
  const list = el("div", { class: "comment-list" });
  const moreBtn = el("button", { text: "더보기" });
  const moreWrapC = el("div", { class: "more-wrap" }, [moreBtn]);
  moreWrapC.hidden = true;

  async function load(reset) {
    if (loading) return;
    loading = true;
    moreBtn.disabled = true;
    if (reset) clear(list);
    try {
      const res = await commentThreads({ videoId: id, order, pageToken: token || undefined, maxResults: 20 });
      token = res.nextPageToken || null;
      for (const it of res.items || []) {
        const c = it.snippet?.topLevelComment?.snippet;
        if (!c) continue;
        list.appendChild(
          el("div", { class: "comment" }, [
            el("div", { class: "c-head" }, [
              el("span", { class: "c-author", text: c.authorDisplayName || "" }),
              el("span", { class: "c-like", text: `👍 ${c.likeCount || 0}` }),
            ]),
            el("div", { class: "c-text", text: c.textDisplay || "" }),
          ])
        );
      }
      if (!(res.items || []).length && reset) list.appendChild(el("div", { class: "center", text: "댓글이 없거나 사용 중지됨" }));
      moreWrapC.hidden = !token;
    } catch (e) {
      if (reset) clear(list);
      list.appendChild(el("div", { class: "notice error", text: e instanceof ApiError ? e.message : "댓글을 불러오지 못했습니다" }));
    } finally {
      loading = false;
      moreBtn.disabled = false;
    }
  }

  orderSel.addEventListener("change", () => { order = orderSel.value; token = null; load(true); });
  moreBtn.addEventListener("click", () => load(false));

  clear(bodyEl);
  bodyEl.appendChild(el("div", { class: "vt", text: title || "" }));
  bodyEl.appendChild(el("div", { class: "filters", style: "" }, [el("div", { class: "field" }, [el("label", { text: "정렬" }), orderSel])]));
  bodyEl.appendChild(list);
  bodyEl.appendChild(moreWrapC);
  load(true);
}

// ── 채널 상세 (channels.list + 최근 업로드) ───────────
async function openChannelDetail({ id, title }) {
  const { bodyEl } = showModal("📊 채널 상세");
  try {
    const chRes = await channelsByIds([id]);
    const ch = (chRes.items || [])[0];
    if (!ch) {
      clear(bodyEl);
      bodyEl.appendChild(el("div", { class: "center", text: "채널 정보를 찾지 못했습니다." }));
      return;
    }
    const sn = ch.snippet || {};
    const st = ch.statistics || {};
    const stats = [];
    if (st.subscriberCount != null) stats.push(`구독자 ${formatCount(st.subscriberCount)}`);
    if (st.videoCount != null) stats.push(`영상 ${formatCount(st.videoCount)}개`);
    if (st.viewCount != null) stats.push(`총 조회수 ${formatCount(st.viewCount)}`);

    clear(bodyEl);
    bodyEl.appendChild(
      el("div", { class: "ch-detail" }, [
        sn.thumbnails ? el("img", { class: "ch-avatar", src: (sn.thumbnails.medium || sn.thumbnails.default || {}).url, attrs: { alt: "" } }) : null,
        el("div", {}, [
          el("div", { class: "ch-name", text: sn.title || title || "" }),
          el("div", { class: "meta", text: stats.join(" · ") }),
          el("a", { class: "act-btn", text: "유튜브에서 열기 ↗", href: `https://www.youtube.com/channel/${id}`, attrs: { target: "_blank", rel: "noopener" } }),
        ]),
      ])
    );
    if (sn.description) bodyEl.appendChild(el("div", { class: "ch-desc", text: sn.description }));

    bodyEl.appendChild(el("div", { class: "section-title", text: "최근 업로드" }));
    const grid = el("div", { class: "grid" });
    bodyEl.appendChild(grid);
    const uploads = ch.contentDetails?.relatedPlaylists?.uploads;
    if (uploads) {
      const pi = await playlistItems({ playlistId: uploads, maxResults: 12 });
      const vids = (pi.items || []).map((it) => it.contentDetails?.videoId || it.snippet?.resourceId?.videoId).filter(Boolean);
      if (vids.length) {
        const vres = await videosByIds(vids.slice(0, 50));
        renderCards(grid, vres.items || [], "video");
      } else {
        grid.appendChild(el("div", { class: "center", text: "업로드가 없습니다." }));
      }
    }
  } catch (e) {
    clear(bodyEl);
    bodyEl.appendChild(el("div", { class: "notice error", text: e instanceof ApiError ? e.message : "채널 상세를 불러오지 못했습니다" }));
  }
}

function renderInto(grid, items, type) {
  if (!items.length) {
    grid.appendChild(el("div", { class: "center", text: "결과 없음" }));
    return;
  }
  renderCards(grid, items, type);
  state.items.push(...items);
}

// ── 내보내기 ──────────────────────────────────────────
function wireExport() {
  $("copyBtn").addEventListener("click", async () => {
    if (!state.items.length) return toast("내보낼 결과가 없습니다");
    await copyText(toPlainText(state.items, state.type));
    toast(`${state.items.length}건 복사됨`);
  });
  $("csvBtn").addEventListener("click", () => {
    if (!state.items.length) return toast("내보낼 결과가 없습니다");
    downloadCSV(toCSV(state.items, state.type), `youtube-${state.tab}-${state.type}.csv`);
    toast("CSV 저장됨");
  });
}
