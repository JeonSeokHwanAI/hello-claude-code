// 확장 아이콘 클릭 → 새 탭으로 검색 페이지 열기.
// (manifest의 action에 default_popup이 없어야 onClicked가 동작한다)
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("search.html") });
});
