"use strict";

// ── 검색 종류 메타데이터 ────────────────────────────────────────────
// value: 네이버 API 엔드포인트 종류 (https://openapi.naver.com/v1/search/{value}.json)
// thumb: 썸네일로 쓸 이미지 필드 (있으면)
// ogThumb: true 면 결과 페이지의 og:image를 비동기로 가져와 썸네일로 표시 (블로그·뉴스)
// image: true 면 갤러리(이미지 타일)로 렌더링
// dateField: 날짜 필터/표시에 쓸 필드 (blog=postdate, news=pubDate)
// sub: 카드 하단에 보여줄 부가 필드 [{ key, label, fmt? }]
const SEARCH_TYPES = [
  { value: "blog",        label: "블로그",   color: "#03c75a", ogThumb: true, dateField: "postdate", sub: [{ key: "bloggername", label: "작성자", blogger: true }, { key: "postdate", label: "작성일", fmt: "date8" }] },
  { value: "news",        label: "뉴스",     color: "#d6336c", ogThumb: true, dateField: "pubDate", sub: [{ key: "pubDate", label: "발행", fmt: "rfc" }] },
  { value: "book",        label: "책",       color: "#7048e8", thumb: "image", sub: [{ key: "author", label: "저자" }, { key: "publisher", label: "출판사" }, { key: "pubdate", label: "출간", fmt: "date8" }] },
  { value: "encyc",       label: "백과사전", color: "#1098ad", thumb: "thumbnail", sub: [] },
  { value: "cafearticle", label: "카페글",   color: "#f08c00", sub: [{ key: "cafename", label: "카페" }] },
  { value: "kin",         label: "지식iN",   color: "#0c8599", sub: [] },
  { value: "webkr",       label: "웹문서",   color: "#495057", sub: [] },
  { value: "local",       label: "지역",     color: "#2b8a3e", sub: [] },
  { value: "image",       label: "이미지",   color: "#e8590c", thumb: "thumbnail", image: true, sub: [] },
  { value: "author",      label: "작성자(블로그)", color: "#1864ab", ogThumb: true, dateField: "pubDate", author: true, sub: [{ key: "pubDate", label: "작성일", fmt: "rfc" }] },
  { value: "trend",       label: "검색어트렌드(데이터랩)", color: "#5f3dc4", trend: true, sub: [] },
  { value: "shopping",    label: "쇼핑인사이트(데이터랩)", color: "#d9480f", shopping: true, sub: [] },
  { value: "gtrend",      label: "최신 트렌드(구글)", color: "#4285f4", gtrend: true, sub: [] },
  { value: "weekly",      label: "주간 인기 트렌드(쇼핑)", color: "#0ca678", weekly: true, sub: [] },
];

// 주간 트렌드 대상: 쇼핑 상위 분야 (면세점 제외)
const TOP_CATEGORIES = [
  { name: "패션의류", param: "50000000" }, { name: "패션잡화", param: "50000001" },
  { name: "화장품/미용", param: "50000002" }, { name: "디지털/가전", param: "50000003" },
  { name: "가구/인테리어", param: "50000004" }, { name: "출산/육아", param: "50000005" },
  { name: "식품", param: "50000006" }, { name: "스포츠/레저", param: "50000007" },
  { name: "생활/건강", param: "50000008" }, { name: "여가/생활편의", param: "50000009" },
  { name: "도서", param: "50005542" },
];

const TREND_COLORS = ["#5f3dc4", "#1c7ed6", "#37b24d", "#f08c00", "#e03131"];

// 설정 미저장 시 사용할 기본 쇼핑 카테고리(상위 분야 10개)
const DEFAULT_SHOP_CATEGORIES = [
  { name: "패션의류", param: "50000000" }, { name: "패션잡화", param: "50000001" },
  { name: "화장품/미용", param: "50000002" }, { name: "디지털/가전", param: "50000003" },
  { name: "가구/인테리어", param: "50000004" }, { name: "출산/육아", param: "50000005" },
  { name: "식품", param: "50000006" }, { name: "스포츠/레저", param: "50000007" },
  { name: "생활/건강", param: "50000008" }, { name: "여가/생활편의", param: "50000009" },
];
const SHOP_MAX = 3; // 분야별 트렌드는 최대 3개 분야

const MAX_START = 1000;
const HISTORY_KEY = "recentQueries";
const HISTORY_MAX = 10;
const BOOKMARK_KEY = "bookmarks";
const PERIOD_DAYS = { week: 7, month: 30, year: 365 };

const $ = (id) => document.getElementById(id);
const TAG_RE = /<[^>]+>/g;

const state = {
  creds: null, query: "", typeMeta: null, display: 10,
  sort: "sim", period: "all", bloggerFilter: null,
  keywords: [], // 다중 키워드 AND ("+"로 구분, 2개 이상일 때만)
  authorId: null, // 작성자(블로그) 모드일 때 블로그ID
  shopCategories: [], // 설정에서 불러온 쇼핑 카테고리 목록
  rankItems: [], rankCtx: null, dailyData: [], // 인기검색어(쇼핑인사이트 통합)
  relatedData: [], // 연관검색어(검색어트렌드 통합)
  gtrendData: [], // 최신 트렌드(구글)
  weeklyPerCat: [], weeklyUnified: [], // 주간 인기 트렌드
  renderedType: null, // 현재 화면에 표시된 결과의 종류 (탭 캐시용)
  total: 0, items: [],
  bookmarkLinks: new Set(), bookmarksView: false,
};

// ── 유틸 ────────────────────────────────────────────────────────────
function clean(value) {
  if (typeof value !== "string") return value == null ? "" : value;
  const txt = value.replace(TAG_RE, "");
  const el = document.createElement("textarea");
  el.innerHTML = txt;
  return el.value;
}

// 부가필드 포맷 (작성일 등)
function formatField(value, fmt) {
  const s = clean(value);
  if (fmt === "date8") {
    const m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (m) return `${m[1]}.${m[2]}.${m[3]}`;
  }
  if (fmt === "rfc") {
    const d = new Date(s);
    if (!isNaN(d)) return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, "0")}.${String(d.getDate()).padStart(2, "0")}`;
  }
  return s;
}

// 항목의 모든 문자열 필드를 합친 검색용 텍스트 (AND 필터용)
function itemText(item) {
  let s = "";
  for (const v of Object.values(item)) if (typeof v === "string") s += " " + v;
  return clean(s).toLowerCase();
}

// 항목의 날짜(Date) — 기간 필터용
function itemDate(item, typeMeta) {
  const f = typeMeta && typeMeta.dateField;
  if (!f || !item[f]) return null;
  const v = clean(item[f]);
  const m = v.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m) return new Date(`${m[1]}-${m[2]}-${m[3]}T00:00:00`);
  const d = new Date(v);
  return isNaN(d) ? null : d;
}

function initTypeSelect() {
  const sel = $("type");
  for (const t of SEARCH_TYPES) {
    const opt = document.createElement("option");
    opt.value = t.value;
    opt.textContent = t.label;
    sel.appendChild(opt);
  }
}

function typeBadge(typeMeta) {
  const badge = document.createElement("span");
  badge.className = "badge";
  badge.style.background = typeMeta.color;
  badge.textContent = typeMeta.label;
  return badge;
}

function setMeta(typeMeta, text, showCsv) {
  const meta = $("meta");
  meta.replaceChildren();
  if (typeMeta) meta.appendChild(typeBadge(typeMeta));
  if (text) {
    const span = document.createElement("span");
    span.textContent = text;
    meta.appendChild(span);
  }
  if (showCsv) {
    const btn = document.createElement("button");
    btn.className = "ghost-btn";
    btn.textContent = "⬇ CSV 저장";
    btn.addEventListener("click", exportCsv);
    meta.appendChild(btn);
  }
}

function showLoading(count) {
  const frag = document.createDocumentFragment();
  const loading = document.createElement("div");
  loading.className = "loading";
  loading.innerHTML = '<span class="spinner"></span><span>검색 중…</span>';
  frag.appendChild(loading);
  for (let i = 0; i < Math.min(count, 5); i++) {
    const sk = document.createElement("div");
    sk.className = "skeleton";
    frag.appendChild(sk);
  }
  $("results").className = "results";
  $("results").replaceChildren(frag);
}

function showNotice(html, isError) {
  $("meta").replaceChildren();
  setMoreVisible(false);
  const div = document.createElement("div");
  div.className = "notice" + (isError ? " error" : "");
  div.innerHTML = html;
  $("results").className = "results";
  $("results").replaceChildren(div);
  const link = div.querySelector("#toOptions");
  if (link) link.addEventListener("click", () => chrome.runtime.openOptionsPage());
}

// ── og:image 썸네일 (블로그·뉴스) ───────────────────────────────────
const OG_MAX = 6;
const ogQueue = [];
let ogActive = 0;
const ogCache = new Map();

function pumpOg() {
  while (ogActive < OG_MAX && ogQueue.length) {
    const task = ogQueue.shift();
    ogActive++;
    task().finally(() => { ogActive--; pumpOg(); });
  }
}

async function fetchOgImage(pageUrl) {
  if (ogCache.has(pageUrl)) return ogCache.get(pageUrl);
  let result = null;
  try {
    const resp = await fetch(pageUrl, { credentials: "omit" });
    if (resp.ok) {
      const html = await resp.text();
      const m = html.match(/<meta[^>]+(?:property|name)=["']og:image["'][^>]*>/i)
             || html.match(/<meta[^>]+(?:property|name)=["']twitter:image(?::src)?["'][^>]*>/i);
      const c = m && m[0].match(/content=["']([^"']+)["']/i);
      if (c) result = new URL(c[1], pageUrl).href.replace(/^http:\/\//, "https://");
    }
  } catch (_) { /* 무시 */ }
  ogCache.set(pageUrl, result);
  return result;
}

function attachOgThumb(card, pageUrl) {
  if (!pageUrl) return;
  ogQueue.push(async () => {
    const url = await fetchOgImage(pageUrl);
    if (!url || !card.isConnected) return;
    const img = document.createElement("img");
    img.className = "thumb";
    img.loading = "lazy";
    img.alt = "";
    img.src = url;
    img.onerror = () => img.remove();
    card.insertBefore(img, card.firstChild);
  });
  pumpOg();
}

// ── 북마크 ──────────────────────────────────────────────────────────
function isBookmarked(link) { return state.bookmarkLinks.has(link); }

function toggleBookmark(item, typeMeta, btn) {
  chrome.storage.local.get([BOOKMARK_KEY], (data) => {
    let list = Array.isArray(data[BOOKMARK_KEY]) ? data[BOOKMARK_KEY] : [];
    const link = item.link || "";
    if (state.bookmarkLinks.has(link)) {
      list = list.filter((b) => b.link !== link);
      state.bookmarkLinks.delete(link);
    } else {
      list.unshift({
        link,
        type: typeMeta.value,
        title: clean(item.title),
        description: clean(item.description),
        bloggername: clean(item.bloggername),
        date: item[typeMeta.dateField] || "",
        thumb: item[typeMeta.thumb] || "",
      });
      state.bookmarkLinks.add(link);
    }
    chrome.storage.local.set({ [BOOKMARK_KEY]: list }, () => {
      updateBookmarkCount(list.length);
      if (btn) {
        const on = state.bookmarkLinks.has(link);
        btn.classList.toggle("on", on);
        btn.textContent = on ? "★" : "☆";
        btn.title = on ? "북마크 해제" : "북마크";
      }
      if (state.bookmarksView) renderBookmarks();
    });
  });
}

function bookmarkBtn(item, typeMeta) {
  const btn = document.createElement("button");
  btn.className = "bm-btn";
  const on = isBookmarked(item.link || "");
  btn.classList.toggle("on", on);
  btn.textContent = on ? "★" : "☆";
  btn.title = on ? "북마크 해제" : "북마크";
  btn.addEventListener("click", (e) => { e.preventDefault(); toggleBookmark(item, typeMeta, btn); });
  return btn;
}

function updateBookmarkCount(n) {
  $("bookmarkToggle").textContent = n ? `★ 북마크 (${n})` : "★ 북마크";
}

// ── 카드 렌더링 ─────────────────────────────────────────────────────
function buildCard(item, typeMeta) {
  const card = document.createElement("div");
  card.className = "card";
  if (typeMeta.value === "local") return buildLocalCard(item, card);

  if (typeMeta.thumb && item[typeMeta.thumb]) {
    const img = document.createElement("img");
    img.className = "thumb"; img.loading = "lazy"; img.alt = "";
    img.src = item[typeMeta.thumb];
    card.appendChild(img);
  } else if (typeMeta.ogThumb && item.link) {
    attachOgThumb(card, item.link);
  }

  card.appendChild(bookmarkBtn(item, typeMeta));

  const h = document.createElement("p");
  h.className = "card-title";
  if (item.link) {
    const a = document.createElement("a");
    a.href = item.link; a.target = "_blank"; a.rel = "noopener";
    a.textContent = clean(item.title);
    h.appendChild(a);
  } else {
    h.textContent = clean(item.title);
  }
  card.appendChild(h);

  if (item.description) {
    const d = document.createElement("p");
    d.className = "card-desc";
    d.textContent = clean(item.description);
    card.appendChild(d);
  }

  const sub = document.createElement("div");
  sub.className = "card-sub";
  for (const s of typeMeta.sub || []) {
    if (!item[s.key]) continue;
    if (s.blogger) {
      // B-3: 작성자 클릭 → 해당 블로거만 필터 (현재 결과 내)
      const link = document.createElement("a");
      link.className = "author-link";
      link.href = "#";
      link.textContent = `${s.label}: ${clean(item[s.key])}`;
      link.title = "이 블로거 글만 보기 (현재 결과 내)";
      link.addEventListener("click", (e) => {
        e.preventDefault();
        state.bloggerFilter = clean(item[s.key]);
        renderResults();
      });
      sub.appendChild(link);
      // A-3: "글 전체" → 작성자 모드(RSS)로 그 블로거 글 모아보기
      const blogId = parseBlogId(item.bloggerlink || "");
      if (blogId) {
        const all = document.createElement("a");
        all.className = "author-link author-all";
        all.href = "#";
        all.textContent = "↗ 글 전체";
        all.title = "이 블로거의 글 전체 보기";
        all.addEventListener("click", (e) => { e.preventDefault(); enterAuthorMode(blogId); });
        sub.appendChild(all);
      }
    } else {
      const span = document.createElement("span");
      span.textContent = `${s.label}: ${formatField(item[s.key], s.fmt)}`;
      sub.appendChild(span);
    }
  }
  if (sub.childNodes.length) card.appendChild(sub);
  return card;
}

function buildLocalCard(item, card) {
  card.appendChild(bookmarkBtn(item, SEARCH_TYPES.find((t) => t.value === "local")));
  const h = document.createElement("p");
  h.className = "card-title";
  const title = clean(item.title);
  const a = document.createElement("a");
  a.href = item.link || `https://map.naver.com/v5/search/${encodeURIComponent(title)}`;
  a.target = "_blank"; a.rel = "noopener";
  a.textContent = title;
  h.appendChild(a);
  card.appendChild(h);

  const sub = document.createElement("div");
  sub.className = "card-sub";
  const parts = [];
  if (item.category) parts.push({ cls: "tag", text: clean(item.category) });
  if (item.roadAddress || item.address) parts.push({ text: clean(item.roadAddress || item.address) });
  if (item.telephone) parts.push({ text: "☎ " + clean(item.telephone) });
  for (const p of parts) {
    const span = document.createElement("span");
    if (p.cls) span.className = p.cls;
    span.textContent = p.text;
    sub.appendChild(span);
  }
  card.appendChild(sub);
  return card;
}

function buildImageTile(item) {
  const a = document.createElement("a");
  a.className = "tile";
  a.href = item.link || item.thumbnail;
  a.target = "_blank"; a.rel = "noopener";
  a.title = clean(item.title);
  const img = document.createElement("img");
  img.loading = "lazy"; img.src = item.thumbnail; img.alt = clean(item.title);
  a.appendChild(img);
  return a;
}

// ── 필터 + 렌더 ─────────────────────────────────────────────────────
function getVisibleItems() {
  let items = state.items;
  const tm = state.typeMeta;

  // M-2 다중 키워드 AND 필터 (모든 키워드 포함)
  if (state.keywords.length) {
    const kws = state.keywords.map((k) => k.toLowerCase());
    items = items.filter((it) => {
      const t = itemText(it);
      return kws.every((k) => t.includes(k));
    });
  }
  // B-2 기간 필터
  if (state.period !== "all" && tm && tm.dateField) {
    const days = PERIOD_DAYS[state.period];
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    items = items.filter((it) => {
      const d = itemDate(it, tm);
      return d ? d >= cutoff : false;
    });
  }
  // B-3 블로거 필터
  if (state.bloggerFilter) {
    items = items.filter((it) => clean(it.bloggername) === state.bloggerFilter);
  }
  return items;
}

function renderBloggerChip() {
  const chip = $("bloggerChip");
  if (state.bloggerFilter) {
    chip.style.display = "inline-flex";
    chip.replaceChildren();
    const label = document.createElement("span");
    label.textContent = `블로거: ${state.bloggerFilter}`;
    const x = document.createElement("button");
    x.textContent = "✕";
    x.addEventListener("click", () => { state.bloggerFilter = null; renderResults(); });
    chip.appendChild(label);
    chip.appendChild(x);
  } else {
    chip.style.display = "none";
  }
}

function renderResults() {
  if (state.bookmarksView) return;
  const tm = state.typeMeta;
  if (!tm) return;
  renderBloggerChip();

  const andText = state.keywords.length ? ` · 모두 포함: ${state.keywords.join(", ")}` : "";
  const isAuthor = tm.author;
  const head = isAuthor ? `작성자 ${state.authorId}` : `전체 ${state.total.toLocaleString()}건`;
  const visible = getVisibleItems();
  const results = $("results");
  results.className = tm.image ? "results gallery" : "results";

  if (!visible.length) {
    setMeta(tm, `${head} · 표시 0건 (필터)${andText}`, false);
    showNoticeInResults(
      state.keywords.length
        ? "모든 키워드를 포함한 결과가 없습니다. 키워드를 줄여 보세요."
        : "조건에 맞는 결과가 없습니다. 기간/블로거 필터를 조정해 보세요."
    );
    setMoreVisible(canLoadMore());
    return;
  }

  const frag = document.createDocumentFragment();
  for (const item of visible) {
    frag.appendChild(tm.image ? buildImageTile(item) : buildCard(item, tm));
  }
  results.replaceChildren(frag);

  const filtered = visible.length !== state.items.length;
  setMeta(tm,
    `${head} · 표시 ${visible.length}건${filtered ? ` (필터, 수집 ${state.items.length})` : ""}${andText}`,
    true);
  setMoreVisible(canLoadMore());
}

function showNoticeInResults(text) {
  const div = document.createElement("div");
  div.className = "notice";
  div.textContent = text;
  $("results").replaceChildren(div);
}

// ── 더보기(페이징) ──────────────────────────────────────────────────
function setMoreVisible(show, loading) {
  const wrap = $("moreWrap");
  wrap.style.display = show ? "flex" : "none";
  const btn = $("moreBtn");
  btn.disabled = !!loading;
  btn.textContent = loading ? "불러오는 중…" : "더보기";
}

function canLoadMore() {
  if (state.bookmarksView) return false;
  if (state.typeMeta && state.typeMeta.author) return false; // RSS는 페이징 없음
  const next = state.items.length + 1;
  return state.items.length < state.total && next <= MAX_START;
}

// ── API 호출 ────────────────────────────────────────────────────────
async function fetchPage(append) {
  const start = append ? state.items.length + 1 : 1;
  const url = `https://openapi.naver.com/v1/search/${state.typeMeta.value}.json`
    + `?query=${encodeURIComponent(state.query)}`
    + `&display=${state.display}&start=${start}&sort=${state.sort}`;

  const resp = await fetch(url, {
    headers: {
      "X-Naver-Client-Id": state.creds.clientId,
      "X-Naver-Client-Secret": state.creds.clientSecret,
    },
  });
  if (!resp.ok) {
    const body = await resp.text();
    throw new Error(`HTTP ${resp.status} ${clean(body)}`);
  }
  const data = await resp.json();
  const items = data.items || [];
  state.total = Number(data.total || 0);
  state.items.push(...items);
  return items;
}

// ── 작성자(블로거) 기준 검색 — 블로그 RSS ───────────────────────────
// 입력에서 블로그ID 추출 (blog.naver.com/{id}, 전체 URL, 또는 순수 id)
function parseBlogId(input) {
  const s = (input || "").trim();
  const m = s.match(/blog\.naver\.com\/([A-Za-z0-9_-]+)/i);
  if (m) return m[1];
  return /^[A-Za-z0-9_-]+$/.test(s) ? s : null;
}

function rssText(el, tag) {
  const node = el.querySelector(tag);
  return node ? node.textContent.trim() : "";
}

async function fetchAuthorRss(blogId) {
  const resp = await fetch(`https://rss.blog.naver.com/${blogId}.xml`, { credentials: "omit" });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const xml = await resp.text();
  const doc = new DOMParser().parseFromString(xml, "text/xml");
  if (doc.querySelector("parsererror")) throw new Error("RSS 파싱 실패");
  return [...doc.querySelectorAll("item")].map((it) => ({
    title: rssText(it, "title"),
    link: rssText(it, "link").split("?")[0],
    description: rssText(it, "description"),
    pubDate: rssText(it, "pubDate"),
    bloggername: rssText(it, "author") || blogId,
    bloggerlink: `https://blog.naver.com/${blogId}`,
  }));
}

// 입력: "blogId" 또는 "blogId + 키워드 + 키워드" (첫 토큰=블로그ID, 나머지=AND 키워드)
async function performAuthorSearch(raw) {
  const parts = raw.split("+").map((s) => s.trim()).filter(Boolean);
  const idInput = parts.shift() || "";
  const blogId = parseBlogId(idInput);
  if (!blogId) {
    showNotice("블로그 ID 또는 <b>blog.naver.com/아이디</b> 주소를 입력하세요.<br>예: <b>zzeonbae100</b> 또는 <b>zzeonbae100 + 주식</b>", true);
    return;
  }

  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === "author");
  state.authorId = blogId;
  state.query = blogId; // CSV 파일명 등에 사용
  state.keywords = parts; // 작성자 모드에선 1개 이상이면 AND 필터 적용
  state.period = $("period").value;
  state.bloggerFilter = null;
  state.total = 0;
  state.items = [];

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, `작성자 ${blogId} 불러오는 중…`, false);
  setMoreVisible(false);
  showLoading(state.display);

  try {
    const items = await fetchAuthorRss(blogId);
    if (!items.length) {
      setMeta(state.typeMeta, "글 없음", false);
      showNotice("이 블로그에서 글을 찾지 못했습니다. 블로그 ID를 확인하세요.");
      return;
    }
    state.items = items;
    state.total = items.length;
    renderResults();
    saveHistory(raw);
  } catch (err) {
    showNotice(`작성자 글을 불러오지 못했습니다.<br><small>${clean(String(err.message || err))}</small><br>블로그 ID가 맞는지 확인하세요.`, true);
  } finally {
    btn.disabled = false;
  }
}

// 블로그 카드의 "글 전체" 버튼 → 작성자 모드 진입
function enterAuthorMode(blogId) {
  if (!blogId) return;
  stashCurrentResults();
  $("type").value = "author";
  $("query").value = blogId;
  updateModeHint();
  performSearch(); // renderedType 설정 + performAuthorSearch 디스패치
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ── 데이터랩 검색어트렌드 ───────────────────────────────────────────
function fmtDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// 기간 프리셋 → 시작/종료일 input 채우기
function applyTrendPreset() {
  const preset = $("trendPreset").value;
  if (preset === "custom") { $("startDate").disabled = false; $("endDate").disabled = false; return; }
  const end = new Date();
  const start = new Date();
  if (preset === "3m") start.setMonth(start.getMonth() - 3);
  else if (preset === "6m") start.setMonth(start.getMonth() - 6);
  else if (preset === "1y") start.setFullYear(start.getFullYear() - 1);
  else if (preset === "3y") start.setFullYear(start.getFullYear() - 3);
  $("startDate").value = fmtDate(start);
  $("endDate").value = fmtDate(end);
  $("startDate").disabled = true;
  $("endDate").disabled = true;
}

const SVGNS = "http://www.w3.org/2000/svg";
function svgEl(tag, attrs) {
  const el = document.createElementNS(SVGNS, tag);
  for (const k in attrs) el.setAttribute(k, attrs[k]);
  return el;
}

// 응답 results → 인라인 SVG 꺾은선 그래프
function buildTrendChart(results) {
  // 모든 그룹의 period 합집합 (정렬)
  const periodSet = new Set();
  for (const r of results) for (const d of r.data) periodSet.add(d.period);
  const periods = [...periodSet].sort();

  const W = 820, H = 380, L = 44, R = 16, T = 16, B = 52;
  const plotW = W - L - R, plotH = H - T - B;
  const xAt = (i) => periods.length <= 1 ? L + plotW / 2 : L + plotW * (i / (periods.length - 1));
  const yAt = (ratio) => T + plotH * (1 - ratio / 100);

  const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, class: "trend-chart", role: "img" });

  // y축 격자 + 라벨 (0,25,50,75,100)
  for (const v of [0, 25, 50, 75, 100]) {
    const y = yAt(v);
    svg.appendChild(svgEl("line", { x1: L, y1: y, x2: W - R, y2: y, class: "grid" }));
    const t = svgEl("text", { x: L - 8, y: y + 4, class: "axis", "text-anchor": "end" });
    t.textContent = String(v);
    svg.appendChild(t);
  }
  // x축 라벨 (최대 7개 균등)
  const step = Math.max(1, Math.ceil(periods.length / 7));
  for (let i = 0; i < periods.length; i += step) {
    const t = svgEl("text", { x: xAt(i), y: H - B + 18, class: "axis", "text-anchor": "middle" });
    t.textContent = periods[i];
    svg.appendChild(t);
  }

  // 그룹별 선
  results.forEach((r, gi) => {
    const color = TREND_COLORS[gi % TREND_COLORS.length];
    const map = {};
    for (const d of r.data) map[d.period] = d.ratio;
    let path = "", started = false;
    periods.forEach((p, i) => {
      if (map[p] == null) { started = false; return; }
      path += `${started ? "L" : "M"}${xAt(i).toFixed(1)} ${yAt(map[p]).toFixed(1)} `;
      started = true;
    });
    svg.appendChild(svgEl("path", { d: path.trim(), fill: "none", stroke: color, "stroke-width": "2" }));
    // 데이터 점 + 호버 값
    periods.forEach((p, i) => {
      if (map[p] == null) return;
      const c = svgEl("circle", { cx: xAt(i), cy: yAt(map[p]), r: "2.5", fill: color });
      const title = svgEl("title", {});
      title.textContent = `${r.title} · ${p} · ${map[p]}`;
      c.appendChild(title);
      svg.appendChild(c);
    });
  });
  return svg;
}

function renderTrendLegend(results) {
  const legend = document.createElement("div");
  legend.className = "trend-legend";
  results.forEach((r, gi) => {
    const item = document.createElement("span");
    item.className = "legend-item";
    const dot = document.createElement("span");
    dot.className = "legend-dot";
    dot.style.background = TREND_COLORS[gi % TREND_COLORS.length];
    item.appendChild(dot);
    const label = document.createElement("span");
    label.textContent = r.title;
    item.appendChild(label);
    legend.appendChild(item);
  });
  return legend;
}

function trendCsv(results) {
  const periodSet = new Set();
  for (const r of results) for (const d of r.data) periodSet.add(d.period);
  const periods = [...periodSet].sort();
  const maps = results.map((r) => { const m = {}; for (const d of r.data) m[d.period] = d.ratio; return m; });
  const header = ["period", ...results.map((r) => r.title)];
  const lines = [header.map(csvCell).join(",")];
  for (const p of periods) {
    lines.push([p, ...maps.map((m) => m[p] != null ? m[p] : "")].map(csvCell).join(","));
  }
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `naver_trend_${results.map((r) => r.title).join("-")}.csv`.replace(/[^0-9A-Za-z가-힣_.\-]+/g, "_");
  a.click();
  URL.revokeObjectURL(a.href);
}

// ── 연관검색어 (네이버 자동완성, 검색어트렌드에 통합) ────────────────
async function fetchRelated(query) {
  const url = `https://ac.search.naver.com/nx/ac?q=${encodeURIComponent(query)}&con=0&frm=nv&ans=2&r_format=json&st=100`;
  const data = await (await fetch(url)).json();
  const out = [];
  for (const g of (data.items || [])) for (const e of g) if (e && e[0]) out.push(e[0]);
  return [...new Set(out)];
}

function relatedCopyText() {
  return state.relatedData
    .map((g) => `[${g.keyword}] 연관검색어\n` + g.related.map((t, i) => `${i + 1}. ${t}`).join("\n"))
    .join("\n\n");
}

// 트렌드 그래프 아래에 입력 키워드들의 연관검색어를 표시
async function appendRelatedSection(keywords) {
  state.relatedData = [];
  const section = document.createElement("div");
  section.className = "rank-section";
  const head = document.createElement("div");
  head.className = "rank-head";
  const title = document.createElement("span");
  title.textContent = "연관검색어";
  const copyBtn = document.createElement("button");
  copyBtn.className = "ghost-btn"; copyBtn.textContent = "📋 복사";
  copyBtn.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(relatedCopyText()); const p = copyBtn.textContent; copyBtn.textContent = "복사됨 ✓"; setTimeout(() => { copyBtn.textContent = p; }, 1500); }
    catch (_) { copyBtn.textContent = "복사 실패"; }
  });
  head.append(title, copyBtn);
  section.appendChild(head);
  $("results").appendChild(section);

  for (const kw of keywords) {
    try {
      const list = await fetchRelated(kw);
      if (!list.length) continue;
      state.relatedData.push({ keyword: kw, related: list });
      const block = document.createElement("div");
      block.className = "related-block";
      const kwh = document.createElement("div");
      kwh.className = "related-kw"; kwh.textContent = kw;
      block.appendChild(kwh);
      const ul = document.createElement("ul");
      ul.className = "related-list";
      for (const term of list) {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = "https://search.naver.com/search.naver?query=" + encodeURIComponent(term);
        a.target = "_blank"; a.rel = "noopener";
        a.textContent = term;
        li.appendChild(a);
        ul.appendChild(li);
      }
      block.appendChild(ul);
      section.appendChild(block);
    } catch (_) { /* 무시 */ }
  }
  if (!state.relatedData.length) {
    const e = document.createElement("div");
    e.className = "rank-err";
    e.textContent = "연관검색어를 불러오지 못했습니다.";
    section.appendChild(e);
  }
}

// ── 최신 트렌드 (Google Trends 한국, 비공식 RSS) ────────────────────
function xmlNS(el, local) {
  const n = el.getElementsByTagNameNS("*", local);
  return n.length ? n[0].textContent.trim() : "";
}

function gtrendCopyText() {
  return "구글 최신 트렌드 (한국)\n" +
    state.gtrendData.map((t) => `${t.rank}. ${t.title}${t.traffic ? ` (${t.traffic})` : ""}`).join("\n");
}

function renderGTrend() {
  const ol = document.createElement("ol");
  ol.className = "gtrend-list";
  for (const t of state.gtrendData) {
    const li = document.createElement("li");
    const num = document.createElement("span");
    num.className = "rank-num"; num.textContent = t.rank;
    const main = document.createElement("div");
    main.className = "gt-main";
    const a = document.createElement("a");
    a.className = "gt-term";
    a.href = "https://search.naver.com/search.naver?query=" + encodeURIComponent(t.title);
    a.target = "_blank"; a.rel = "noopener";
    a.textContent = t.title;
    main.appendChild(a);
    if (t.traffic) {
      const sp = document.createElement("span");
      sp.className = "gt-traffic"; sp.textContent = t.traffic + " 검색";
      main.appendChild(sp);
    }
    if (t.news && t.news.title) {
      const n = document.createElement("a");
      n.className = "gt-news";
      n.href = t.news.url || "#"; n.target = "_blank"; n.rel = "noopener";
      n.textContent = `📰 ${t.news.title}${t.news.source ? " · " + t.news.source : ""}`;
      main.appendChild(n);
    }
    li.append(num, main);
    ol.appendChild(li);
  }
  $("results").className = "results";
  $("results").replaceChildren(ol);
}

async function performGTrend() {
  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === "gtrend");
  state.items = [];

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, "최신 트렌드 불러오는 중…", false);
  setMoreVisible(false);
  $("results").className = "results";
  $("results").replaceChildren();

  try {
    const xml = await (await fetch("https://trends.google.com/trending/rss?geo=KR")).text();
    if (xml[0] !== "<") throw new Error("응답 형식 오류(차단 가능)");
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    const items = [...doc.getElementsByTagName("item")];
    if (!items.length) { showNotice("최신 트렌드 데이터가 없습니다."); return; }

    state.gtrendData = items.map((it, i) => {
      const newsEl = it.getElementsByTagNameNS("*", "news_item")[0];
      return {
        rank: i + 1,
        title: xmlNS(it, "title"),
        traffic: xmlNS(it, "approx_traffic"),
        news: newsEl ? {
          title: xmlNS(newsEl, "news_item_title"),
          url: xmlNS(newsEl, "news_item_url"),
          source: xmlNS(newsEl, "news_item_source"),
        } : null,
      };
    });

    setMeta(state.typeMeta, `한국 · 오늘의 급상승 검색어 ${state.gtrendData.length}건 (Google Trends)`, false);
    const copyBtn = document.createElement("button");
    copyBtn.className = "ghost-btn"; copyBtn.textContent = "📋 복사";
    copyBtn.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(gtrendCopyText()); const p = copyBtn.textContent; copyBtn.textContent = "복사됨 ✓"; setTimeout(() => { copyBtn.textContent = p; }, 1500); }
      catch (_) { copyBtn.textContent = "복사 실패"; }
    });
    $("meta").appendChild(copyBtn);
    renderGTrend();
  } catch (err) {
    showNotice(`최신 트렌드를 불러오지 못했습니다.<br><small>${clean(String(err.message || err))}</small><br>(Google Trends 비공식 RSS — 일시적으로 막힐 수 있습니다)`, true);
  } finally {
    btn.disabled = false;
  }
}

// ── 주간 인기 트렌드 (상위 분야별 TOP3 → 통합·중복제거) ─────────────
// 분야 체크박스 (최초 1회 렌더, 전체 체크)
function renderWeeklyCats() {
  const box = $("weeklyCats");
  if (box.firstChild) return; // 이미 렌더됨
  TOP_CATEGORIES.forEach((cat, i) => {
    const label = document.createElement("label");
    label.className = "shop-cat";
    const cb = document.createElement("input");
    cb.type = "checkbox"; cb.value = String(i); cb.checked = true;
    const span = document.createElement("span");
    span.textContent = cat.name;
    label.append(cb, span);
    box.appendChild(label);
  });
}

function setWeeklyAll(checked) {
  $("weeklyCats").querySelectorAll("input").forEach((cb) => { cb.checked = checked; });
}

function weeklyCopyText() {
  const u = "통합 트렌드 (최근 1주, 분야 TOP3·중복 제거)\n" +
    state.weeklyUnified.map((e, i) => `${i + 1}. ${e.keyword} (${e.cats.join("·")})`).join("\n");
  const p = state.weeklyPerCat
    .map((c) => `[${c.name}]\n` + c.top3.map((k) => `${k.rank}. ${k.keyword}`).join("\n"))
    .join("\n\n");
  return u + "\n\n──────────\n\n" + p;
}

async function performWeekly() {
  const idxs = [...$("weeklyCats").querySelectorAll("input:checked")].map((c) => parseInt(c.value, 10));
  if (!idxs.length) { showNotice("분야를 1개 이상 선택하세요."); return; }
  const cats = idxs.map((i) => TOP_CATEGORIES[i]);

  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === "weekly");
  state.items = []; state.weeklyPerCat = []; state.weeklyUnified = [];

  const end = new Date();
  const start = new Date(); start.setDate(start.getDate() - 7);
  const endDate = fmtDate(end), startDate = fmtDate(start);
  const demo = getDemographics("shopping");

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, "주간 인기 트렌드 모으는 중…", false);
  setMoreVisible(false);
  $("results").className = "results";
  $("results").replaceChildren();

  const perCat = [];
  let done = 0;
  for (const cat of cats) {
    try {
      const data = await rankRequestRetry({
        cid: cat.param, timeUnit: "date", startDate, endDate,
        age: demo.decades[0] || "", gender: demo.gender, device: demo.device, page: "1", count: "10",
      });
      const top3 = (data.ranks || []).slice(0, 3).map((r) => ({ rank: r.rank, keyword: r.keyword }));
      perCat.push({ name: cat.name, top3 });
    } catch (_) {
      perCat.push({ name: cat.name, top3: [] });
    }
    setMeta(state.typeMeta, `주간 인기 트렌드 모으는 중… (${++done}/${cats.length})`, false);
    await sleep(300); // 연속 호출 차단 방지
  }

  if (!perCat.some((c) => c.top3.length)) {
    showNotice("주간 인기 트렌드를 불러오지 못했습니다 (데이터랩 비공식 — 확장 새로고침 후 재시도).", true);
    btn.disabled = false;
    return;
  }

  // 통합: 각 분야 TOP3 키워드를 모아 중복 제거 (등장 분야 수 → 최고순위 순)
  const map = new Map();
  for (const c of perCat) {
    for (const k of c.top3) {
      const e = map.get(k.keyword) || { keyword: k.keyword, count: 0, cats: [], best: 99 };
      e.count++; e.cats.push(c.name); e.best = Math.min(e.best, k.rank);
      map.set(k.keyword, e);
    }
  }
  const unified = [...map.values()].sort((a, b) => b.count - a.count || a.best - b.best);

  state.weeklyPerCat = perCat;
  state.weeklyUnified = unified;

  setMeta(state.typeMeta, `최근 1주 ${startDate} ~ ${endDate} · 분야 ${perCat.length}개${demoLabel(demo)}`, false);
  const copyBtn = document.createElement("button");
  copyBtn.className = "ghost-btn"; copyBtn.textContent = "📋 복사";
  copyBtn.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(weeklyCopyText()); const p = copyBtn.textContent; copyBtn.textContent = "복사됨 ✓"; setTimeout(() => { copyBtn.textContent = p; }, 1500); }
    catch (_) { copyBtn.textContent = "복사 실패"; }
  });
  $("meta").appendChild(copyBtn);

  renderWeekly();
  saveHistory("주간 인기 트렌드");
  btn.disabled = false;
}

function renderWeekly() {
  const frag = document.createDocumentFragment();

  // 통합 트렌드
  const uSec = document.createElement("div");
  uSec.className = "rank-section";
  const uHead = document.createElement("div");
  uHead.className = "rank-head";
  uHead.textContent = `통합 트렌드 — 최근 1주 (분야 TOP3 · 중복 제거 · ${state.weeklyUnified.length}개)`;
  uSec.appendChild(uHead);
  const ol = document.createElement("ol");
  ol.className = "rank-list";
  state.weeklyUnified.forEach((e, i) => {
    const li = document.createElement("li");
    const num = document.createElement("span");
    num.className = "rank-num"; num.textContent = i + 1;
    const a = document.createElement("a");
    a.className = "rank-kw";
    a.href = "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(e.keyword);
    a.target = "_blank"; a.rel = "noopener";
    a.textContent = e.keyword;
    const cats = document.createElement("span");
    cats.className = "weekly-cats";
    cats.textContent = e.count > 1 ? `${e.count}개 분야` : e.cats[0];
    li.append(num, a, cats);
    ol.appendChild(li);
  });
  uSec.appendChild(ol);
  frag.appendChild(uSec);

  // 분야별 TOP 3
  const pSec = document.createElement("div");
  pSec.className = "rank-section";
  const pHead = document.createElement("div");
  pHead.className = "rank-head";
  pHead.textContent = "분야별 TOP 3";
  pSec.appendChild(pHead);
  const row = document.createElement("div");
  row.className = "daily-columns";
  for (const c of state.weeklyPerCat) {
    const col = document.createElement("div");
    col.className = "daily-col";
    const dh = document.createElement("div");
    dh.className = "daily-date"; dh.textContent = c.name;
    col.appendChild(dh);
    const cl = document.createElement("ol");
    cl.className = "daily-list";
    for (const k of c.top3) {
      const li = document.createElement("li");
      const num = document.createElement("span");
      num.className = "rank-num"; num.textContent = k.rank;
      const a = document.createElement("a");
      a.className = "rank-kw";
      a.href = "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(k.keyword);
      a.target = "_blank"; a.rel = "noopener";
      a.textContent = k.keyword;
      li.append(num, a);
      cl.appendChild(li);
    }
    if (!c.top3.length) { const e = document.createElement("div"); e.className = "daily-empty"; e.textContent = "데이터 없음"; col.appendChild(e); }
    col.appendChild(cl);
    row.appendChild(col);
  }
  pSec.appendChild(row);
  frag.appendChild(pSec);

  $("results").className = "results";
  $("results").replaceChildren(frag);
}

async function performTrend() {
  const raw = $("query").value.trim();
  const groups = raw.split("+").map((s) => s.trim()).filter(Boolean).slice(0, 5)
    .map((g) => ({ groupName: g, keywords: [g] }));
  if (!groups.length) { showNotice("주제어를 입력하세요. 여러 개는 +로 구분합니다. 예: <b>한글 + 영어</b>"); return; }

  const startDate = $("startDate").value, endDate = $("endDate").value;
  const timeUnit = $("timeUnit").value;
  if (!startDate || !endDate) { showNotice("조회 기간을 지정하세요.", true); return; }
  if (startDate > endDate) { showNotice("시작일이 종료일보다 늦습니다.", true); return; }

  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === "trend");
  state.items = []; state.keywords = []; state.bloggerFilter = null;

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, "트렌드 조회 중…", false);
  setMoreVisible(false);
  $("results").className = "results";
  $("results").replaceChildren();

  const demo = getDemographics("search");
  const trendBody = { startDate, endDate, timeUnit, keywordGroups: groups };
  if (demo.device) trendBody.device = demo.device;
  if (demo.gender) trendBody.gender = demo.gender;
  if (demo.ages.length) trendBody.ages = demo.ages;

  try {
    const resp = await fetch("https://openapi.naver.com/v1/datalab/search", {
      method: "POST",
      headers: {
        "X-Naver-Client-Id": state.creds.clientId,
        "X-Naver-Client-Secret": state.creds.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(trendBody),
    });
    if (!resp.ok) {
      const body = await resp.text();
      showNotice(`요청 실패 (HTTP ${resp.status})<br><small>${clean(body)}</small>`, true);
      return;
    }
    const data = await resp.json();
    const results = (data.results || []).filter((r) => r.data && r.data.length);
    if (!results.length) { showNotice("해당 조건에 트렌드 데이터가 없습니다. 필터를 줄여 보세요."); return; }

    setMeta(state.typeMeta, `${startDate} ~ ${endDate} · ${unitLabel(timeUnit)} · 상대값(최대 100)${demoLabel(demo)}`, false);
    const csvBtn = document.createElement("button");
    csvBtn.className = "ghost-btn"; csvBtn.textContent = "⬇ CSV 저장";
    csvBtn.addEventListener("click", () => trendCsv(results));
    $("meta").appendChild(csvBtn);

    const wrap = document.createElement("div");
    wrap.className = "trend-wrap";
    wrap.appendChild(renderTrendLegend(results));
    wrap.appendChild(buildTrendChart(results));
    $("results").replaceChildren(wrap);
    saveHistory(raw);

    // 그래프 아래에 입력 키워드들의 연관검색어 표시
    appendRelatedSection(groups.map((g) => g.groupName));
  } catch (err) {
    showNotice(`네트워크 오류: ${clean(String(err.message || err))}`, true);
  } finally {
    btn.disabled = false;
  }
}

function unitLabel(u) { return u === "date" ? "일별" : u === "week" ? "주별" : "월별"; }

// ── 인구통계 필터 (데이터랩 공통: 기기/성별/연령) ───────────────────
// 연령: 화면은 10년 단위. 쇼핑인사이트는 그대로, 검색어트렌드는 세분 코드(1~11)로 변환.
const AGE_SEARCH_MAP = { "10": ["2"], "20": ["3", "4"], "30": ["5", "6"], "40": ["7", "8"], "50": ["9", "10"], "60": ["11"] };

// 체크박스 그룹 단일/다중 선택 규칙 처리
function handleDemoChange(input) {
  const g = input.dataset.g;
  const inputs = [...$("demoBar").querySelectorAll(`.demo[data-g="${g}"]`)];
  const allBox = inputs.find((i) => i.value === "");
  if (g === "device" || g === "gender") {
    // 단일 선택
    if (input.checked) inputs.forEach((i) => { if (i !== input) i.checked = false; });
  } else {
    // 연령: 전체 ↔ 개별 다중
    if (input.value === "" && input.checked) inputs.forEach((i) => { if (i.value !== "") i.checked = false; });
    else if (input.value !== "" && input.checked) allBox.checked = false;
  }
  if (!inputs.some((i) => i.checked)) allBox.checked = true; // 아무것도 없으면 전체
}

function getDemographics(mode) {
  const pick = (g) => [...$("demoBar").querySelectorAll(`.demo[data-g="${g}"]:checked`)].map((i) => i.value).filter(Boolean);
  const device = pick("device")[0] || "";
  const gender = pick("gender")[0] || "";
  const decades = pick("age");
  const ages = mode === "shopping" ? decades : decades.flatMap((d) => AGE_SEARCH_MAP[d] || []);
  return { device, gender, ages, decades };
}

// 적용된 필터를 메타에 표시할 라벨
function demoLabel(d) {
  const parts = [];
  if (d.device) parts.push(d.device === "pc" ? "PC" : "모바일");
  if (d.gender) parts.push(d.gender === "f" ? "여성" : "남성");
  if (d.decades.length) parts.push(d.decades.map((x) => x + "대").join("·"));
  return parts.length ? " · " + parts.join("·") : "";
}

// ── 데이터랩 쇼핑인사이트 (분야별) ──────────────────────────────────
function renderShopCats(list) {
  const box = $("shopCats");
  box.replaceChildren();
  list.forEach((cat, i) => {
    const label = document.createElement("label");
    label.className = "shop-cat";
    const cb = document.createElement("input");
    cb.type = "checkbox"; cb.value = String(i);
    cb.addEventListener("change", () => {
      if (box.querySelectorAll("input:checked").length > SHOP_MAX) cb.checked = false;
    });
    const span = document.createElement("span");
    span.textContent = cat.name;
    label.append(cb, span);
    box.appendChild(label);
  });
}

async function performShopping() {
  const idxs = [...$("shopCats").querySelectorAll("input:checked")].map((c) => parseInt(c.value, 10));
  if (!idxs.length) { showNotice("분야를 1개 이상 선택하세요. (‘분야 편집’에서 추가할 수 있습니다)"); return; }
  const category = idxs.slice(0, SHOP_MAX).map((i) => ({ name: state.shopCategories[i].name, param: [state.shopCategories[i].param] }));

  const startDate = $("startDate").value, endDate = $("endDate").value, timeUnit = $("timeUnit").value;
  if (!startDate || !endDate) { showNotice("조회 기간을 지정하세요.", true); return; }
  if (startDate > endDate) { showNotice("시작일이 종료일보다 늦습니다.", true); return; }

  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === "shopping");
  state.items = []; state.keywords = []; state.bloggerFilter = null;

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, "쇼핑인사이트 조회 중…", false);
  setMoreVisible(false);
  $("results").className = "results";
  $("results").replaceChildren();

  const demo = getDemographics("shopping");
  const shopBody = { startDate, endDate, timeUnit, category };
  if (demo.device) shopBody.device = demo.device;
  if (demo.gender) shopBody.gender = demo.gender;
  if (demo.ages.length) shopBody.ages = demo.ages;

  try {
    const resp = await fetch("https://openapi.naver.com/v1/datalab/shopping/categories", {
      method: "POST",
      headers: {
        "X-Naver-Client-Id": state.creds.clientId,
        "X-Naver-Client-Secret": state.creds.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(shopBody),
    });
    if (!resp.ok) {
      const body = await resp.text();
      showNotice(`요청 실패 (HTTP ${resp.status})<br><small>${clean(body)}</small><br>앱에 <b>데이터랩(쇼핑인사이트)</b> 권한이 있는지 확인하세요.`, true);
      return;
    }
    const data = await resp.json();
    const results = (data.results || []).filter((r) => r.data && r.data.length);
    if (!results.length) { showNotice("해당 조건에 데이터가 없습니다. 필터를 줄여 보세요."); return; }

    setMeta(state.typeMeta, `${startDate} ~ ${endDate} · ${unitLabel(timeUnit)} · 상대값(최대 100)${demoLabel(demo)}`, false);
    const csvBtn = document.createElement("button");
    csvBtn.className = "ghost-btn"; csvBtn.textContent = "⬇ CSV 저장";
    csvBtn.addEventListener("click", () => trendCsv(results));
    $("meta").appendChild(csvBtn);

    const wrap = document.createElement("div");
    wrap.className = "trend-wrap";
    wrap.appendChild(renderTrendLegend(results));
    wrap.appendChild(buildTrendChart(results));
    $("results").replaceChildren(wrap);

    // 분야 1개면 인기검색어를 그래프 아래에 함께 표시 (통합)
    if (idxs.length === 1) {
      const soloCat = state.shopCategories[idxs[0]];
      appendRankSection(soloCat, {
        timeUnit, startDate, endDate,
        age: demo.decades[0] || "", gender: demo.gender, device: demo.device,
      });
    }
  } catch (err) {
    showNotice(`네트워크 오류: ${clean(String(err.message || err))}`, true);
  } finally {
    btn.disabled = false;
  }
}

// ── 분야별 인기검색어 (datalab 비공식 엔드포인트) ──────────────────
// 데이터랩은 Referer가 datalab.naver.com이어야 응답한다 → manifest의
// declarative_net_request(rules.json)가 요청에 Referer를 주입한다.
const RANK_PAGE = 20;   // 엔드포인트는 페이지당 20개 고정 (count 무시)
const RANK_MAX = 500;   // TOP 500
const RANK_BATCH = 5;   // "더보기" 1회에 5페이지(=100개)

async function rankRequest(params) {
  const resp = await fetch("https://datalab.naver.com/shoppingInsight/getCategoryKeywordRank.naver", {
    method: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
    body: new URLSearchParams(params).toString(),
  });
  const text = await resp.text();
  if (text[0] !== "{") throw new Error("데이터랩이 응답을 거부했습니다(Referer/차단).");
  return JSON.parse(text);
}

async function rankFetch(page) {
  const c = state.rankCtx;
  return rankRequest({
    cid: c.cid, timeUnit: c.timeUnit, startDate: c.startDate, endDate: c.endDate,
    age: c.age, gender: c.gender, device: c.device, page: String(page), count: String(RANK_PAGE),
  });
}

// 연속 호출 차단(rate-limit) 대비: 실패 시 백오프 재시도
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function rankRequestRetry(params, attempts = 4) {
  for (let i = 0; i < attempts; i++) {
    try { return await rankRequest(params); }
    catch (e) { if (i === attempts - 1) throw e; await sleep(700 + i * 700); }
  }
}

// 일간 칼럼용: 종료일부터 거꾸로 최대 maxN일 (오래된 날짜가 왼쪽)
const WEEKDAY = ["일", "월", "화", "수", "목", "금", "토"];
function dayColumns(startDate, endDate, maxN) {
  const out = [];
  const start = new Date(startDate + "T00:00:00");
  const end = new Date(endDate + "T00:00:00");
  for (let i = 0; i < maxN; i++) {
    const d = new Date(end); d.setDate(d.getDate() - i);
    if (d < start) break;
    out.push(fmtDate(d));
  }
  return out.reverse();
}
function formatDayKR(s) {
  const dt = new Date(s + "T00:00:00");
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const day = String(dt.getDate()).padStart(2, "0");
  return `${dt.getFullYear()}.${m}.${day}.(${WEEKDAY[dt.getDay()]})`;
}
function dailyCopyText() {
  return state.dailyData
    .map((d) => `[${d.date}]\n` + d.ranks.map((r) => `${r.rank}. ${r.keyword}`).join("\n"))
    .join("\n\n");
}
function buildDailyCol(day, ranks) {
  const col = document.createElement("div");
  col.className = "daily-col";
  const dh = document.createElement("div");
  dh.className = "daily-date"; dh.textContent = formatDayKR(day);
  col.appendChild(dh);
  const ol = document.createElement("ol");
  ol.className = "daily-list";
  for (const r of ranks) {
    const li = document.createElement("li");
    const num = document.createElement("span");
    num.className = "rank-num"; num.textContent = r.rank;
    const a = document.createElement("a");
    a.className = "rank-kw";
    a.href = "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(r.keyword);
    a.target = "_blank"; a.rel = "noopener";
    a.textContent = r.keyword;
    li.append(num, a);
    ol.appendChild(li);
  }
  if (!ranks.length) { const e = document.createElement("div"); e.className = "daily-empty"; e.textContent = "데이터 없음"; col.appendChild(e); }
  col.appendChild(ol);
  return col;
}

// 다음 한 페이지(20개) 로드 → 이번 페이지 개수 반환
async function fetchRankPage() {
  const page = Math.floor(state.rankItems.length / RANK_PAGE) + 1;
  const data = await rankFetch(page);
  const ranks = data.ranks || [];
  state.rankItems.push(...ranks);
  return ranks.length;
}

// 여러 페이지 연속 로드 → 더 받을 게 있는지(hasMore) 반환
async function fetchRankBatch(pages) {
  let last = RANK_PAGE;
  for (let i = 0; i < pages && state.rankItems.length < RANK_MAX && last >= RANK_PAGE; i++) {
    last = await fetchRankPage();
  }
  return state.rankItems.length < RANK_MAX && last >= RANK_PAGE;
}

function fillRankList(ol) {
  ol.replaceChildren();
  for (const r of state.rankItems) {
    const li = document.createElement("li");
    const num = document.createElement("span");
    num.className = "rank-num"; num.textContent = r.rank;
    const a = document.createElement("a");
    a.className = "rank-kw";
    a.href = "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(r.keyword);
    a.target = "_blank"; a.rel = "noopener";
    a.textContent = r.keyword;
    li.append(num, a);
    ol.appendChild(li);
  }
}

// 클립보드 복사용 텍스트 (Claude 등 분석에 붙여넣기)
function rankCopyText() {
  const c = state.rankCtx;
  const head = `[${c.path}] 인기검색어 TOP ${state.rankItems.length} (${c.startDate} ~ ${c.endDate})`;
  const lines = state.rankItems.map((r) => `${r.rank}. ${r.keyword}`);
  return head + "\n" + lines.join("\n");
}

function rankCsv() {
  const lines = ["rank,keyword"];
  for (const r of state.rankItems) lines.push(`${r.rank},${csvCell(r.keyword)}`);
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `naver_rank_${state.rankCtx.name || "category"}.csv`.replace(/[^0-9A-Za-z가-힣_.\-]+/g, "_");
  a.click();
  URL.revokeObjectURL(a.href);
}

// 쇼핑인사이트 그래프 아래에 그 분야의 인기검색어 섹션을 붙인다 (분야 1개일 때)
// 단위가 "일별"이면 날짜별 칼럼(최근 7일), 아니면 기간 합산 순위(더보기)
async function appendRankSection(cat, base) {
  state.rankCtx = { cid: cat.param, name: cat.name, path: cat.path || cat.name, ...base };
  state.rankItems = [];
  state.dailyData = [];
  const daily = base.timeUnit === "date";

  const section = document.createElement("div");
  section.className = "rank-section";
  const head = document.createElement("div");
  head.className = "rank-head";
  const title = document.createElement("span");
  title.textContent = daily ? `${cat.name} 일간 인기검색어` : `${cat.name} 인기검색어`;
  const copyBtn = document.createElement("button");
  copyBtn.className = "ghost-btn"; copyBtn.textContent = "📋 복사";
  copyBtn.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(daily ? dailyCopyText() : rankCopyText());
      const prev = copyBtn.textContent;
      copyBtn.textContent = "복사됨 ✓";
      setTimeout(() => { copyBtn.textContent = prev; }, 1500);
    } catch (_) { copyBtn.textContent = "복사 실패"; }
  });
  const btns = document.createElement("span");
  btns.className = "rank-actions";
  btns.appendChild(copyBtn);
  if (!daily) {
    const csvBtn = document.createElement("button");
    csvBtn.className = "ghost-btn"; csvBtn.textContent = "⬇ CSV";
    csvBtn.addEventListener("click", rankCsv);
    btns.appendChild(csvBtn);
  }
  head.append(title, btns);
  section.appendChild(head);
  $("results").appendChild(section);

  try {
    if (daily) {
      const row = document.createElement("div");
      row.className = "daily-columns";
      section.appendChild(row);
      const days = dayColumns(base.startDate, base.endDate, 7);
      for (const day of days) {
        let ranks = [];
        try {
          const data = await rankRequestRetry({
            cid: cat.param, timeUnit: "date", startDate: day, endDate: day,
            age: base.age, gender: base.gender, device: base.device, page: "1", count: "10",
          });
          ranks = (data.ranks || []).slice(0, 10);
        } catch (_) { /* 해당 날짜만 비움 */ }
        state.dailyData.push({ date: day, ranks });
        row.appendChild(buildDailyCol(day, ranks));
        await sleep(250);
      }
      if (!state.dailyData.some((d) => d.ranks.length)) title.textContent = `${cat.name} 일간 인기검색어 — 데이터 없음`;
    } else {
      const ol = document.createElement("ol"); ol.className = "rank-list";
      const moreWrap = document.createElement("div"); moreWrap.className = "rank-more"; moreWrap.style.display = "none";
      const moreBtn = document.createElement("button"); moreBtn.textContent = "더보기";
      moreWrap.appendChild(moreBtn);
      section.append(ol, moreWrap);
      const showMore = (has) => {
        moreWrap.style.display = has ? "flex" : "none";
        title.textContent = `${cat.name} 인기검색어 (${state.rankItems.length})`;
      };
      const has = await fetchRankBatch(RANK_BATCH);
      if (!state.rankItems.length) { title.textContent = `${cat.name} 인기검색어 — 데이터 없음`; return; }
      fillRankList(ol); showMore(has);
      moreBtn.addEventListener("click", async () => {
        moreBtn.disabled = true; moreBtn.textContent = "불러오는 중…";
        try { const more = await fetchRankBatch(RANK_BATCH); fillRankList(ol); showMore(more); } catch (_) { /* 무시 */ }
        moreBtn.disabled = false; moreBtn.textContent = "더보기";
      });
    }
  } catch (err) {
    const e = document.createElement("div"); e.className = "rank-err";
    e.textContent = "인기검색어를 불러오지 못했습니다 (데이터랩 비공식 — 확장 새로고침 후 재시도).";
    section.appendChild(e);
  }
}

async function performSearch() {
  state.renderedType = $("type").value; // 새 검색 = 이 종류의 결과로 갱신
  resultCache.delete(state.renderedType); // 옛 캐시 무효화
  // 주간 인기 트렌드: 상위 분야별 TOP3 집계
  if ($("type").value === "weekly") { performWeekly(); return; }
  // 최신 트렌드: 검색어 없이 구글 트렌드 RSS
  if ($("type").value === "gtrend") { performGTrend(); return; }
  // 쇼핑인사이트: 검색어 없이 분야 선택만으로 동작 (인기검색어 통합)
  if ($("type").value === "shopping") { performShopping(); return; }

  const raw = $("query").value.trim();
  if (!raw) { $("query").focus(); return; }

  // 작성자(블로그) 모드는 네이버 검색 API 대신 RSS 사용
  if ($("type").value === "author") { performAuthorSearch(raw); return; }
  // 검색어트렌드는 데이터랩 POST 사용
  if ($("type").value === "trend") { performTrend(); return; }

  // M-1: "+"로 키워드 분리 → 2개 이상이면 AND 모드
  const parts = raw.split("+").map((s) => s.trim()).filter(Boolean);
  state.keywords = parts.length >= 2 ? parts : [];
  state.query = state.keywords.length ? state.keywords.join(" ") : raw;

  state.bookmarksView = false;
  $("bookmarkToggle").classList.remove("active");
  state.typeMeta = SEARCH_TYPES.find((t) => t.value === $("type").value);
  state.display = parseInt($("display").value, 10) || 10;
  state.sort = $("sort").value;
  state.period = $("period").value;
  state.bloggerFilter = null;
  state.total = 0;
  state.items = [];

  const btn = $("searchForm").querySelector("button");
  btn.disabled = true;
  setMeta(state.typeMeta, "검색 중…", false);
  setMoreVisible(false);
  showLoading(state.display);

  try {
    const items = await fetchPage(false);
    if (!items.length) {
      setMeta(state.typeMeta, "결과 없음", false);
      showNotice("검색 결과가 없습니다.");
      return;
    }
    renderResults();
    saveHistory(raw);
  } catch (err) {
    showNotice(`요청 실패<br><small>${clean(String(err.message || err))}</small>`, true);
  } finally {
    btn.disabled = false;
  }
}

async function loadMore() {
  if (!canLoadMore()) { setMoreVisible(false); return; }
  setMoreVisible(true, true);
  try {
    await fetchPage(true);
    renderResults();
  } catch (err) {
    setMoreVisible(canLoadMore());
    setMeta(state.typeMeta, `더보기 실패: ${clean(String(err.message || err))}`, true);
  }
}

// ── CSV 저장 ────────────────────────────────────────────────────────
function csvCell(v) {
  const s = clean(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function exportCsv() {
  const rows = getVisibleItems();
  if (!rows.length) return;
  const cols = [];
  for (const item of rows) for (const k of Object.keys(item)) if (!cols.includes(k)) cols.push(k);
  const lines = [cols.join(",")];
  for (const item of rows) lines.push(cols.map((c) => csvCell(item[c])).join(","));
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const safe = state.query.replace(/[^0-9A-Za-z가-힣]+/g, "_").replace(/^_+|_+$/g, "") || "result";
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `naver_${state.typeMeta.value}_${safe}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ── 최근 검색어 ─────────────────────────────────────────────────────
function renderHistory(list) {
  const dl = $("history");
  dl.replaceChildren();
  for (const q of list || []) {
    const opt = document.createElement("option");
    opt.value = q;
    dl.appendChild(opt);
  }
}

function saveHistory(query) {
  chrome.storage.local.get([HISTORY_KEY], (data) => {
    let list = Array.isArray(data[HISTORY_KEY]) ? data[HISTORY_KEY] : [];
    list = [query, ...list.filter((q) => q !== query)].slice(0, HISTORY_MAX);
    chrome.storage.local.set({ [HISTORY_KEY]: list }, () => renderHistory(list));
  });
}

// ── 북마크 보기 ─────────────────────────────────────────────────────
function renderBookmarks() {
  chrome.storage.local.get([BOOKMARK_KEY], (data) => {
    const list = Array.isArray(data[BOOKMARK_KEY]) ? data[BOOKMARK_KEY] : [];
    setMoreVisible(false);
    $("bloggerChip").style.display = "none";
    setMeta(null, `★ 북마크 ${list.length}건`, false);
    $("results").className = "results";
    if (!list.length) { showNoticeInResults("저장된 북마크가 없습니다. 카드의 ☆를 눌러 저장하세요."); return; }

    const frag = document.createDocumentFragment();
    for (const b of list) {
      const tm = SEARCH_TYPES.find((t) => t.value === b.type) || { value: b.type, sub: [] };
      const card = document.createElement("div");
      card.className = "card";
      if (b.thumb) {
        const img = document.createElement("img");
        img.className = "thumb"; img.loading = "lazy"; img.alt = ""; img.src = b.thumb;
        img.onerror = () => img.remove();
        card.appendChild(img);
      }
      card.appendChild(bookmarkBtn({ link: b.link, title: b.title, description: b.description, bloggername: b.bloggername }, tm));
      const h = document.createElement("p");
      h.className = "card-title";
      const a = document.createElement("a");
      a.href = b.link; a.target = "_blank"; a.rel = "noopener"; a.textContent = b.title || b.link;
      h.appendChild(a);
      card.appendChild(h);
      if (b.description) {
        const d = document.createElement("p"); d.className = "card-desc"; d.textContent = b.description;
        card.appendChild(d);
      }
      const sub = document.createElement("div");
      sub.className = "card-sub";
      const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = tm.label || b.type;
      sub.appendChild(tag);
      if (b.bloggername) { const s = document.createElement("span"); s.textContent = b.bloggername; sub.appendChild(s); }
      card.appendChild(sub);
      frag.appendChild(card);
    }
    $("results").replaceChildren(frag);
  });
}

function toggleBookmarksView() {
  state.bookmarksView = !state.bookmarksView;
  $("bookmarkToggle").classList.toggle("active", state.bookmarksView);
  if (state.bookmarksView) renderBookmarks();
  else if (state.items.length) renderResults();
  else { $("results").replaceChildren(); $("meta").replaceChildren(); }
}

// ── 전체 캡처 (결과 영역 → 클립보드 이미지) ─────────────────────────
function captureResults() {
  const target = $("results");
  if (!target.firstChild) { alert("캡처할 결과가 없습니다. 먼저 검색하세요."); return; }
  if (typeof html2canvas !== "function") { alert("캡처 라이브러리를 불러오지 못했습니다."); return; }
  if (!navigator.clipboard || !window.ClipboardItem) { alert("이 브라우저는 이미지 클립보드 복사를 지원하지 않습니다."); return; }

  const link = $("captureBtn");
  const prev = "🖼 캡처";
  link.textContent = "복사 중…";

  const bg = getComputedStyle(document.body).backgroundColor || "#ffffff";
  // html2canvas 결과 blob을 Promise로 전달 → 사용자 제스처 만료 없이 클립보드 쓰기
  const blobPromise = html2canvas(target, { backgroundColor: bg, useCORS: true, allowTaint: false, scale: 2, logging: false })
    .then((canvas) => new Promise((res, rej) => canvas.toBlob((b) => b ? res(b) : rej(new Error("이미지 생성 실패")), "image/png")));

  navigator.clipboard.write([new ClipboardItem({ "image/png": blobPromise })])
    .then(() => {
      link.textContent = "복사됨 ✓";
      setTimeout(() => { link.textContent = prev; }, 1500);
    })
    .catch((err) => {
      link.textContent = prev;
      alert("클립보드 복사 실패: " + (err && err.message ? err.message : err));
    });
}

// ── 종류별 결과 캐시 (탭 전환 시 재검색 없이 복원) ──────────────────
// 노드를 "이동"해 보관 → 이벤트 리스너·링크가 그대로 유지됨
const resultCache = new Map();

function stashCurrentResults() {
  const t = state.renderedType;
  if (!t) return;
  if (!$("results").firstChild && !$("meta").firstChild) return;
  const metaFrag = document.createDocumentFragment();
  while ($("meta").firstChild) metaFrag.appendChild($("meta").firstChild);
  const resFrag = document.createDocumentFragment();
  while ($("results").firstChild) resFrag.appendChild($("results").firstChild);
  resultCache.set(t, {
    metaFrag, resFrag,
    resClass: $("results").className,
    moreShown: $("moreWrap").style.display !== "none",
  });
}

function restoreResults(t) {
  const c = resultCache.get(t);
  if (!c) {
    $("meta").replaceChildren();
    $("results").replaceChildren();
    $("results").className = "results";
    setMoreVisible(false);
    return false;
  }
  $("meta").replaceChildren(c.metaFrag);
  $("results").replaceChildren(c.resFrag);
  $("results").className = c.resClass;
  setMoreVisible(c.moreShown);
  return true;
}

function onTypeChange() {
  if (state.bookmarksView) { // 북마크 보기 중이면 캐시 건드리지 않음
    updateModeHint();
    return;
  }
  stashCurrentResults();        // 현재 화면을 이전 종류로 보관
  updateModeHint();             // 컨트롤 전환
  const t = $("type").value;
  const restored = restoreResults(t);
  state.renderedType = restored ? t : null;
}

// 검색 종류에 따라 검색창 안내·컨트롤 표시 조정
function updateModeHint() {
  const v = $("type").value;
  const isAuthor = v === "author", isTrend = v === "trend";
  const isShopping = v === "shopping", isGtrend = v === "gtrend", isWeekly = v === "weekly";
  const isShopCat = isShopping;                // 분야 선택 사용
  const isDatalab = isTrend || isShopping;     // 데이터랩 계열(기간/단위·인구통계 공유)
  const noQuery = isShopCat || isGtrend || isWeekly; // 검색어 입력 불필요

  $("query").placeholder = isTrend
    ? "주제어를 +로 구분 (최대 5): 한글 + 영어"
    : isAuthor
      ? "블로그 ID 또는 URL (키워드 결합: 아이디 + 키워드)"
      : "검색어 입력 (여러 단어는 +로 구분 = 모두 포함)";
  $("query").style.display = noQuery ? "none" : "";
  $("sort").disabled = isAuthor || isDatalab || isGtrend || isWeekly;

  document.querySelector(".filter-bar").style.display = (isDatalab || isGtrend || isWeekly) ? "none" : "flex";
  $("trendBar").style.display = isDatalab ? "flex" : "none";          // 기간/단위 공유
  $("demoBar").style.display = (isDatalab || isWeekly) ? "flex" : "none"; // 인구통계 필터(주간도 사용)
  $("shopCatBar").style.display = isShopCat ? "flex" : "none";        // 분야 선택
  $("weeklyCatBar").style.display = isWeekly ? "flex" : "none";       // 주간 분야 선택
  $("display").style.display = (isDatalab || isGtrend || isWeekly) ? "none" : "";

  if (isWeekly) renderWeeklyCats();

  document.querySelector(".shop-cat-label").textContent = "분야 (최대 3, 1개면 인기검색어도):";

  if (isDatalab && !$("startDate").value) applyTrendPreset();
  if (isShopCat) renderShopCats(state.shopCategories);
}

// ── 초기화 ──────────────────────────────────────────────────────────
function init() {
  initTypeSelect();
  $("openOptions").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("captureBtn").addEventListener("click", (e) => { e.preventDefault(); captureResults(); });
  $("bookmarkToggle").addEventListener("click", (e) => { e.preventDefault(); toggleBookmarksView(); });
  $("moreBtn").addEventListener("click", loadMore);
  $("type").addEventListener("change", onTypeChange);
  $("trendPreset").addEventListener("change", applyTrendPreset);
  $("startDate").addEventListener("input", () => { $("trendPreset").value = "custom"; });
  $("endDate").addEventListener("input", () => { $("trendPreset").value = "custom"; });
  $("shopCatSettings").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("weeklyAll").addEventListener("click", (e) => { e.preventDefault(); setWeeklyAll(true); });
  $("weeklyNone").addEventListener("click", (e) => { e.preventDefault(); setWeeklyAll(false); });
  $("demoBar").addEventListener("change", (e) => { if (e.target.classList.contains("demo")) handleDemoChange(e.target); });
  updateModeHint();

  // 필터 변경 시 즉시 재렌더 (B-2/B-3). 정렬은 API 재호출이 필요해 안내.
  $("period").addEventListener("change", () => { state.period = $("period").value; if (state.items.length) renderResults(); });
  $("sort").addEventListener("change", () => {
    state.sort = $("sort").value;
    // 정렬은 API 재호출이 필요 → 이전 검색이 있으면 자동 재검색
    if (state.query && !state.bookmarksView && state.creds && state.creds.clientId) performSearch();
  });

  chrome.storage.local.get(["clientId", "clientSecret", "display", HISTORY_KEY, BOOKMARK_KEY, "shoppingCategories"], (data) => {
    state.creds = { clientId: data.clientId, clientSecret: data.clientSecret };
    if (data.display) $("display").value = String(data.display);
    renderHistory(data[HISTORY_KEY]);
    const bms = Array.isArray(data[BOOKMARK_KEY]) ? data[BOOKMARK_KEY] : [];
    state.bookmarkLinks = new Set(bms.map((b) => b.link));
    updateBookmarkCount(bms.length);
    state.shopCategories = Array.isArray(data.shoppingCategories) && data.shoppingCategories.length
      ? data.shoppingCategories : DEFAULT_SHOP_CATEGORIES;

    $("searchForm").addEventListener("submit", (e) => {
      e.preventDefault();
      if (!state.creds.clientId || !state.creds.clientSecret) {
        showNotice(
          "먼저 인증정보를 등록하세요.<br>" +
          '<a id="toOptions">설정 열기 →</a> 에서 Client ID / Secret을 입력하면 검색할 수 있습니다.'
        );
        return;
      }
      performSearch();
    });
  });
}

init();
