const $ = (id) => document.getElementById(id);

// 쇼핑인사이트 기본 상위 분야(코드) — "기본 상위분야로 채우기"에 사용
const DEFAULT_CATEGORIES = [
  { name: "패션의류", param: "50000000", path: "패션의류" },
  { name: "패션잡화", param: "50000001", path: "패션잡화" },
  { name: "화장품/미용", param: "50000002", path: "화장품/미용" },
  { name: "디지털/가전", param: "50000003", path: "디지털/가전" },
  { name: "가구/인테리어", param: "50000004", path: "가구/인테리어" },
  { name: "출산/육아", param: "50000005", path: "출산/육아" },
  { name: "식품", param: "50000006", path: "식품" },
  { name: "스포츠/레저", param: "50000007", path: "스포츠/레저" },
  { name: "생활/건강", param: "50000008", path: "생활/건강" },
  { name: "여가/생활편의", param: "50000009", path: "여가/생활편의" },
];

let CATALOG = [];   // 내장 전체 분야 목록 (categories.json)
let myCats = [];    // 사용자가 추가한 분야 [{name, param, path}]

// ── 내 목록 ─────────────────────────────────────────────────────────
function persistCats() {
  chrome.storage.local.set({ shoppingCategories: myCats });
}

function renderMyCats() {
  const box = $("myCats");
  box.replaceChildren();
  if (!myCats.length) {
    const e = document.createElement("div");
    e.className = "empty";
    e.textContent = "추가된 분야가 없습니다. 아래에서 검색해 추가하세요.";
    box.appendChild(e);
    return;
  }
  myCats.forEach((cat, i) => {
    const row = document.createElement("div");
    row.className = "my-cat";
    const path = document.createElement("span");
    path.className = "cat-path"; path.textContent = cat.path || cat.name;
    const code = document.createElement("span");
    code.className = "cat-code"; code.textContent = cat.param;
    const del = document.createElement("button");
    del.type = "button"; del.className = "del"; del.textContent = "삭제";
    del.addEventListener("click", () => { myCats.splice(i, 1); persistCats(); renderMyCats(); renderResults($("catSearch").value); });
    row.append(path, code, del);
    box.appendChild(row);
  });
}

function hasCat(param) { return myCats.some((c) => String(c.param) === String(param)); }

function addCat(node) {
  if (hasCat(node.cid != null ? node.cid : node.param)) return;
  myCats.push({ name: node.name, param: String(node.cid != null ? node.cid : node.param), path: node.path || node.name });
  persistCats();
  renderMyCats();
}

// ── 검색(picker) ────────────────────────────────────────────────────
function renderResults(query) {
  const box = $("catResults");
  const q = query.trim().toLowerCase();
  if (!q) { box.style.display = "none"; box.replaceChildren(); return; }
  const matches = CATALOG.filter((c) =>
    c.name.toLowerCase().includes(q) || (c.path && c.path.toLowerCase().includes(q))
  ).slice(0, 40);

  box.replaceChildren();
  if (!matches.length) {
    const e = document.createElement("div");
    e.className = "pick-row"; e.textContent = "검색 결과가 없습니다.";
    box.appendChild(e);
  } else {
    for (const c of matches) {
      const row = document.createElement("div");
      row.className = "pick-row";
      const path = document.createElement("span");
      path.className = "p-path"; path.textContent = c.path || c.name;
      const code = document.createElement("span");
      code.className = "p-code"; code.textContent = c.cid;
      row.append(path, code);
      if (hasCat(c.cid)) {
        const added = document.createElement("span");
        added.className = "added"; added.textContent = "추가됨 ✓";
        row.appendChild(added);
      } else {
        row.addEventListener("click", () => addCat(c));
      }
      box.appendChild(row);
    }
  }
  box.style.display = "block";
}

// ── 초기 로드 ───────────────────────────────────────────────────────
chrome.storage.local.get(["clientId", "clientSecret", "display", "shoppingCategories"], (data) => {
  if (data.clientId) $("clientId").value = data.clientId;
  if (data.clientSecret) $("clientSecret").value = data.clientSecret;
  if (data.display) $("display").value = data.display;
  myCats = Array.isArray(data.shoppingCategories) ? data.shoppingCategories.slice() : [];
  renderMyCats();
});

// 내장 카탈로그 로드
fetch("categories.json")
  .then((r) => r.json())
  .then((list) => { CATALOG = list; })
  .catch(() => { CATALOG = []; });

$("catSearch").addEventListener("input", (e) => renderResults(e.target.value));
$("resetCat").addEventListener("click", () => {
  for (const c of DEFAULT_CATEGORIES) if (!hasCat(c.param)) myCats.push({ ...c });
  persistCats(); renderMyCats(); renderResults($("catSearch").value);
});
$("clearCat").addEventListener("click", () => { myCats = []; persistCats(); renderMyCats(); renderResults($("catSearch").value); });

// 인증정보·기본개수 저장 (분야는 추가/삭제 시 자동 저장됨)
$("save").addEventListener("click", () => {
  const clientId = $("clientId").value.trim();
  const clientSecret = $("clientSecret").value.trim();
  let display = parseInt($("display").value, 10);
  if (Number.isNaN(display) || display < 1) display = 10;
  if (display > 100) display = 100;
  chrome.storage.local.set({ clientId, clientSecret, display }, () => {
    const status = $("status");
    status.classList.add("show");
    setTimeout(() => status.classList.remove("show"), 1800);
  });
});
