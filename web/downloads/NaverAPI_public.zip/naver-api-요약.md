# 네이버 오픈API 핵심 요약

> 출처
> - 오픈API 공통 가이드: https://developers.naver.com/docs/common/openapiguide/
> - 이용 요금제(플랜): https://developers.naver.com/products/intro/plan/plan.md
>
> 정리일: 2026-06-05. 요금제 표는 문서에서 직접 확인한 값. 공통 가이드 상세 본문은
> JS 렌더링으로 자동 추출이 제한되어 문서 목차 + 네이버 표준 규약으로 정리함.

## 1. 이용 요금제 — 무료 호출 한도

네이버 오픈API는 전부 무료이며 별도 유료 플랜이 없다. 대신 API별 일일 호출 한도가 있다.

| API | 설명 | 호출 제한 |
|---|---|---|
| 검색 | 블로그·이미지·웹·뉴스·백과사전·책·카페·지식iN 등 | 25,000회/일 |
| 네이버 로그인 | 외부 사이트 네이버 로그인 구현 | 없음 |
| 회원 프로필 조회 | 이름·이메일·휴대폰·별명·성별·생일·연령대 등 | 없음 |
| CLOVA Face Recognition | 얼굴 윤곽/부위/표정/유명인 닮음도 | 1,000건/일 |
| 데이터랩(검색어트렌드) | 통합검색어 트렌드 | 1,000회/일 |
| 데이터랩(쇼핑인사이트) | 분야별 쇼핑 트렌드 | 1,000회/일 |
| 캡차(이미지) | 보안 이미지 생성·검증 | 1,000회/일 |
| 캘린더 | 사용자 캘린더 일정 추가 | 5,000회/일 |
| 카페 — 가입하기 | 특정 카페 가입 | 50회/일 |
| 카페 — 글쓰기 | 가입 게시판에 글 작성 | 200회/일 |
| 공유하기 | 블로그·카페 공유 | 없음 |

- 검색 API(25,000회/일)가 가장 넉넉, 카페 가입(50)·글쓰기(200)이 가장 빡빡.
- 한도 초과 시 그날 추가 호출은 거부됨(증액은 별도 문의).

## 2. API 공통 가이드 — 핵심 규약

문서 최종 수정일: 2021-08-27.

### 인증 방식 (2종류)
- 로그인 방식: 사용자 정보가 필요한 API(회원 프로필, 캘린더, 카페 등) → OAuth 2.0 access token 필요
- 비로그인 방식: 사용자 무관 API(검색, 데이터랩, 파파고 등) → Client ID/Secret 헤더만으로 호출

### 애플리케이션 등록 절차
1. 네이버 개발자센터에서 애플리케이션 등록
2. 사용할 API 선택 + (로그인 방식이면) 서비스 URL·Callback URL 등록
3. Client ID / Client Secret 발급·확인
4. 내 애플리케이션 관리: 기본정보 / API 설정 / 멤버 관리 / 통계 보기 / 삭제

### 호출 규약
- 모든 호출은 HTTPS 사용.
- 비로그인 방식 호출 헤더:
  ```
  X-Naver-Client-Id:     {Client ID}
  X-Naver-Client-Secret: {Client Secret}
  ```
- 로그인 방식 호출 헤더:
  ```
  Authorization: Bearer {access_token}
  ```
  (access token은 OAuth 2.0 인증 절차로 별도 발급)

### 오류 처리
- 응답에 HTTP 상태 코드 + errorCode / errorMessage 포함.
- 공통 가이드의 "주요 오류 코드", "오류 메시지 형식" 섹션에서 코드별 의미 확인
  (인증 실패, 헤더 누락, 호출 한도 초과 등).

> 주의: 헤더 이름·인증 방식은 네이버 표준 규약이라 정확하나, 개별 오류 코드 값과
> 각 API의 정확한 엔드포인트·파라미터는 해당 API 상세 문서에서 다시 확인할 것.

## 3. 블로그 검색 API 상세

> 출처: https://developers.naver.com/docs/serviceapi/search/blog/blog.md (직접 확인)

**"블로그"로 가능한 것 = 블로그 *검색* 1가지뿐.**
네이버 오픈API 목록에 블로그 글쓰기/조회/관리 API는 없다. 블로그는 검색 API의
한 분야(blog)로만 제공되며, 비로그인 방식(Client ID/Secret 헤더)으로 호출한다.
하루 호출 한도는 검색 API 공통 25,000회/일.

### 요청
- URL: `GET https://openapi.naver.com/v1/search/blog.json` (XML은 `blog.xml`)
- 프로토콜: HTTPS, 메서드: GET
- 헤더: `X-Naver-Client-Id`, `X-Naver-Client-Secret`

### 파라미터 (쿼리 스트링)
| 파라미터 | 타입 | 필수 | 설명 |
|---|---|---|---|
| query | String | Y | 검색어 (UTF-8 인코딩) |
| display | Integer | N | 한 번에 표시할 결과 수 (기본 10, 최대 100) |
| start | Integer | N | 검색 시작 위치 (기본 1, 최대 1000) → 페이징 |
| sort | String | N | 정렬: `sim`(정확도순, 기본) / `date`(날짜순) |

→ 최대 노출 가능 건수: start(1000) + display(100) 한계상 **사실상 상위 1000건**까지.

### 응답 필드 (JSON)
| 필드 | 설명 |
|---|---|
| lastBuildDate | 검색 결과 생성 시각 |
| total | 총 검색 결과 수 |
| start / display | 시작 위치 / 표시 개수 |
| items[].title | 블로그 글 제목 (`<b>` 태그로 검색어 강조 포함) |
| items[].link | 블로그 글 URL |
| items[].description | 본문 요약 (검색어 강조 포함) |
| items[].bloggername | 블로그 이름 |
| items[].bloggerlink | 블로거 블로그 주소 |
| items[].postdate | 글 작성일 (yyyyMMdd) |

> 주의: title/description에 `<b>` 등 HTML 태그가 섞여 오므로 제거 후 사용.
> 블로그 검색 응답에는 **썸네일(이미지) 필드가 없다** → 필요하면 글 페이지의
> og:image를 별도로 가져와야 함(현재 확장 구현 방식).

### 오류 코드 (블로그 검색 관련)
- Invalid display value: display가 1~100 범위 밖
- Invalid start value: start가 1~1000 범위 밖
- (공통) 인증 실패/헤더 누락/호출 한도 초과 등은 공통 가이드 참조

### 확장 가능 포인트 (이 API 범위 내에서)
- `sort` 토글(정확도/최신순) UI 노출
- `start` 반복 호출로 페이징(더보기)
- `postdate`·`bloggername` 기반 **클라이언트 측** 날짜 필터/블로거 그룹핑
  (API 자체에는 날짜 범위·블로거 필터 파라미터가 없음)

## 4. 데이터랩 검색어트렌드 API 상세

> 출처: https://developers.naver.com/docs/serviceapi/datalab/search/search.md (직접 확인)

주제어 그룹으로 묶은 검색어의 **네이버 통합검색 검색 추이(시계열)** 를 JSON으로 반환.
검색 API(GET)와 달리 **POST + JSON 본문**을 사용한다. 비로그인 방식, 한도 **1,000회/일**.

### 요청
- URL: `POST https://openapi.naver.com/v1/datalab/search`
- 헤더: `X-Naver-Client-Id`, `X-Naver-Client-Secret`, `Content-Type: application/json`

### 본문 파라미터 (JSON)
| 파라미터 | 필수 | 설명 |
|---|---|---|
| startDate | Y | 시작일 yyyy-mm-dd (2016-01-01부터) |
| endDate | Y | 종료일 yyyy-mm-dd |
| timeUnit | Y | 구간 단위: `date`(일) / `week`(주) / `month`(월) |
| keywordGroups | Y | 주제어 그룹 배열 (**최대 5개**) |
| keywordGroups[].groupName | Y | 주제어(그룹 대표 이름) |
| keywordGroups[].keywords | Y | 검색어 배열 (**최대 20개**) |
| device | N | `""`(전체) / `pc` / `mo` |
| gender | N | `""` / `m` / `f` |
| ages | N | 연령대 배열 (예: ["1","2",…]) |

### 응답 (JSON)
- 최상위: `startDate`, `endDate`, `timeUnit`
- `results[]`: `{ title(주제어), keywords[], data: [{ period(yyyy-mm-dd), ratio }] }`
- **ratio는 절대 검색량이 아니라 조회 기간 내 상대값**(최댓값이 100인 비율).

### 메모
- 카드가 아닌 **꺾은선 그래프**로 시각화해야 의미 있음 (그룹별 1개 선, 최대 5선).
- 별도 형제 API: **쇼핑인사이트**(`/v1/datalab/shopping/*`) — §5 참고.

## 5. 데이터랩 쇼핑인사이트 API 상세

> 출처: https://developers.naver.com/docs/serviceapi/datalab/shopping/shopping.md (직접 확인)

네이버 통합검색 쇼핑 영역·네이버쇼핑에서의 **검색 클릭 추이**를 분야별로 반환.
검색어트렌드와 **별도 권한**(앱에 "데이터랩(쇼핑인사이트)" 추가 필요). 한도 1,000회/일.

### 분야별 트렌드 (이번 구현 대상)
- URL: `POST https://openapi.naver.com/v1/datalab/shopping/categories`
- 헤더: 검색어트렌드와 동일(+`Content-Type: application/json`)
- 본문:
  | 파라미터 | 필수 | 설명 |
  |---|---|---|
  | startDate / endDate | Y | yyyy-mm-dd (2017-08 이후 데이터 풍부) |
  | timeUnit | Y | date / week / month |
  | category | Y | `[{name, param:[분야코드,…]}]` **최대 3개 쌍** |
- **분야 코드(cat_id):** 네이버쇼핑에서 카테고리 선택 시 URL의 `cat_id` 값.
- 응답: `results[].title(분야명)`, `results[].category(코드들)`, `results[].data[{period, ratio}]` (ratio=상대값 최대 100).

### 상위 분야 코드(기본 리스트)
| 코드 | 분야 | 코드 | 분야 |
|---|---|---|---|
| 50000000 | 패션의류 | 50000005 | 출산/육아 |
| 50000001 | 패션잡화 | 50000006 | 식품 |
| 50000002 | 화장품/미용 | 50000007 | 스포츠/레저 |
| 50000003 | 디지털/가전 | 50000008 | 생활/건강 |
| 50000004 | 가구/인테리어 | 50000009 | 여가/생활편의 |

### 형제 엔드포인트 (범위 밖, 추후)
- `/shopping/category/device`(기기별), `/category/gender`(성별), `/category/age`(연령별),
  `/category/keywords`(분야 내 키워드별).
