# YouTube Data API v3 핵심 요약

> 출처(필독)
> - 레퍼런스: https://developers.google.com/youtube/v3/docs
> - search.list: https://developers.google.com/youtube/v3/docs/search/list
> - videos.list: https://developers.google.com/youtube/v3/docs/videos/list
> - 시작하기·할당량: https://developers.google.com/youtube/v3/getting-started
>
> 정리일: 2026-06-05. 정확한 파라미터/할당량은 위 공식 문서에서 재확인할 것.

## 1. 인증 / 호출 기본

- Base: `https://www.googleapis.com/youtube/v3/`
- **공개 데이터**(검색·인기·공개 통계): URL 쿼리에 `key={API_KEY}` 만 추가하면 호출 가능.
- **사용자별 데이터**(내 구독·시청기록 등): OAuth 2.0 필요 (이번 범위 밖).
- 메서드: 읽기는 GET. CORS 허용 → 브라우저/확장에서 직접 호출 가능.
- API Key 발급: Google Cloud Console → "YouTube Data API v3" 사용 설정 → 사용자 인증 정보 → API 키.
  (브라우저 노출 대비 HTTP 리퍼러/확장 ID 제한 권장)

## 2. 할당량 (Quota)

- 기본 **10,000 units/일** (프로젝트 단위).
- **search.list = 100 units** (비쌈) → 하루 약 100회 검색.
- 읽기 목록 호출(videos/channels/playlists/playlistItems/commentThreads/videoCategories.list) = **각 1 unit**.
- 절약 전략: search로 ID만 받고 → `videos.list`로 통계를 **한 번에(최대 50개)** 보강. 결과 캐시.

## 3. 주요 엔드포인트

### 3.1 search.list — 검색 (100u)
`GET search?part=snippet&key=...`
| 파라미터 | 설명 |
|---|---|
| q | 검색어 (연산자: `"구문"`, `-제외`, `a|b`) |
| type | `video` / `channel` / `playlist` (콤마 조합 가능) |
| order | `relevance`(기본)/`date`/`viewCount`/`rating`/`title`/`videoCount`(채널) |
| maxResults | 0~50 (기본 5) |
| pageToken | 다음/이전 페이지 토큰 (응답의 nextPageToken) |
| regionCode | 지역 (예: KR) |
| relevanceLanguage | 언어 (예: ko) |
| publishedAfter / publishedBefore | RFC3339 시각 (기간 필터) |
| videoDuration | `any`/`short`(<4분)/`medium`/`long`(>20분) (type=video) |
| channelId | 특정 채널 내 검색 |

- 응답: `items[].id.videoId|channelId|playlistId`, `items[].snippet`(title, channelTitle, publishedAt, thumbnails…), `nextPageToken`, `pageInfo`.
- **주의:** search 응답에는 조회수 등 통계가 없음 → videos.list로 보강 필요.

### 3.2 videos.list — 영상 상세 / 인기 동영상 (1u)
`GET videos?part=snippet,statistics,contentDetails&key=...`
- **ID로 조회:** `id=콤마목록`(최대 50) → 통계 보강용.
- **인기 동영상(트렌딩):** `chart=mostPopular&regionCode=KR&videoCategoryId=..&maxResults=50`.
- 응답 필드: `statistics.viewCount/likeCount/commentCount`, `contentDetails.duration`(ISO8601 `PT#M#S`).

### 3.3 channels.list — 채널 (1u)
`GET channels?part=snippet,statistics,contentDetails&id=..|forHandle=@핸들&key=...`
- `statistics.subscriberCount/videoCount/viewCount`.
- `contentDetails.relatedPlaylists.uploads` → 그 채널 업로드 재생목록 ID.

### 3.4 videoCategories.list — 카테고리 (1u)
`GET videoCategories?part=snippet&regionCode=KR&key=...` → 인기 동영상 카테고리 필터용.

### 3.5 commentThreads.list — 댓글 (1u)
`GET commentThreads?part=snippet&videoId=..&order=relevance|time&maxResults=..&key=...`

### 3.6 playlists / playlistItems (각 1u)
- `playlists?part=snippet,contentDetails&id=..` / `playlistItems?part=snippet&playlistId=..`.

## 4. 메모 (확장 구현 시)
- 길이 변환: ISO8601 `PT1H2M3S` → `1:02:03` 포맷 함수 필요.
- 조회수 등은 문자열 → 숫자 변환·천단위 콤마.
- likeCount는 비공개일 수 있음 → 없으면 생략.
- 인기 동영상은 search(100u)가 아니라 videos.list(1u)라 **저렴** → 트렌딩 대시보드에 적합.
