# PRD — YouTube 검색 크롬 확장프로그램

| 항목 | 내용 |
|---|---|
| 문서 상태 | 초안 (v1.0) |
| 작성일 | 2026-06-05 |
| 작성 | 전석환 |
| 관련 산출물 | `extension/` (구현 예정), `docs/90.reference/youtube-api-요약.md` |
| 참고 | NaverAPI 프로젝트(동일 방식)의 PRD 구조를 따른다 |

---

## 1. 배경 (Background)

NaverAPI 프로젝트에서 만든 "네이버 검색 크롬 확장"과 **동일한 방식**으로,
이번엔 **YouTube Data API**를 이용하는 크롬 확장을 만든다.

확장 아이콘만 누르면 검색 페이지가 열리고, 검색 종류(동영상·채널·재생목록·인기 동영상)를
골라 검색하면 결과가 카드로 표시되는 도구. 별도 서버나 빌드 없이 크롬에서 바로 동작.

**핵심 기술 전제:** YouTube Data API v3(`googleapis.com`)는 **API Key**만으로 공개 데이터
호출이 가능하고 CORS도 허용되므로, 크롬 확장(`host_permissions`)에서 **백엔드 없이 직접 호출**할 수 있다.

## 2. 목표 / 비목표 (Goals / Non-Goals)

**목표**
- 확장 아이콘 클릭 → 새 탭으로 검색 페이지가 열린다
- 검색창 + 검색 종류 선택 + 정렬/필터 + 검색 버튼
- YouTube API를 직접 호출해 결과를 카드(썸네일·제목·채널·게시일·조회수·길이)로 표시
- 옵션 페이지에서 API Key 입력 → `chrome.storage`에 저장
- 인기 동영상(트렌딩), 채널/댓글, 내보내기(복사·CSV·캡처) 등 확장 기능
- **관심 분야(My Topics): 카테고리·키워드 세트·관심 채널·지역/언어를 미리 설정 → 트렌딩·검색·전용 대시보드에 반영**

**비목표 (이번 범위 밖)**
- OAuth가 필요한 사용자별 데이터(내 구독·시청기록·좋아요 목록)
- 영상 업로드·댓글 작성 등 쓰기 작업
- 크롬 웹스토어 배포(개발자 모드 "압축해제 로드"로 사용)

## 3. 사용자 시나리오 (User Flow)

1. 최초 1회: 옵션 페이지에서 YouTube Data API Key 입력·저장
2. 툴바 아이콘 클릭 → 새 탭에 검색 페이지 열림
3. 종류=동영상, 검색어 입력, 정렬(관련성/최신/조회수) 선택 → 검색
4. 결과 카드(썸네일·제목·채널·조회수·길이) 표시, 카드 클릭 → YouTube로 이동
5. "더보기"로 다음 페이지, 결과를 복사/CSV/캡처로 내보내 Claude 분석

## 4. 요구사항 (Requirements)

### 4.1 기능 요구사항
| ID | 요구사항 |
|---|---|
| F-1 | 아이콘 클릭 시 새 탭으로 검색 페이지를 연다 |
| F-2 | 검색 종류(동영상·채널·재생목록·인기 동영상)를 선택할 수 있다 |
| F-3 | 검색어·정렬·결과 개수·필터를 지정해 검색한다 |
| F-4 | 결과를 카드로 표시하고 통계(조회수·좋아요·길이)를 보강한다 |
| F-5 | 옵션 페이지에서 API Key를 저장·로드한다 |
| F-6 | 할당량/키 오류를 사용자에게 안내한다 |
| F-7 | nextPageToken으로 더보기(페이징)를 지원한다 |
| F-8 | 관심 분야(카테고리·키워드 세트·관심 채널·지역/언어)를 등록·관리한다 |
| F-9 | 활성 분야를 트렌딩·검색 기본값·전용 대시보드에 반영한다 |

### 4.2 비기능 요구사항
| ID | 요구사항 |
|---|---|
| N-1 | 별도 서버 없이 브라우저에서 직접 API 호출 (host_permissions) |
| N-2 | API Key는 코드에 하드코딩하지 않고 chrome.storage에 저장 |
| N-3 | 응답 텍스트는 textContent로 삽입 (XSS 방지) |
| N-4 | 할당량 절약: search(100u) 후 videos.list(1u)로 통계 일괄 보강, 캐시 활용 |

## 5. 설계 결정 (Decisions, NaverAPI와 동일 기조)

| 항목 | 결정 | 비고 |
|---|---|---|
| UI 형태 | 아이콘 클릭 → 새 탭 전체 페이지 | NaverAPI와 동일 |
| 인증정보 | 옵션 페이지 API Key 입력 → chrome.storage.local | OAuth 미사용(공개 데이터) |
| 결과 표시 | 카드/리스트 (썸네일 포함) | |
| 내보내기 | 복사(텍스트)·CSV·캡처(클립보드 이미지) | NaverAPI에서 검증된 방식 |
| 지역 | 기본 regionCode=KR (변경 가능) | |

## 6. 기술 구조 (Architecture)

```
extension/                 (구현 예정 — 본 PRD는 설계만)
  manifest.json   ← Manifest V3 (host_permissions: https://*.googleapis.com/*)
  background.js   ← 아이콘 클릭 시 검색 탭 생성
  search.html/.css/.js  ← 검색 UI, API 호출, 카드 렌더링
  options.html/.js      ← API Key 설정
  icons/
```

**API 기본** (자세한 내용: `docs/90.reference/youtube-api-요약.md`)
- Base: `https://www.googleapis.com/youtube/v3/`
- 검색: `GET search?part=snippet&q=..&type=video&order=..&maxResults=..&regionCode=KR&key=API_KEY`
- 통계 보강: `GET videos?part=snippet,statistics,contentDetails&id=콤마목록&key=` (조회수·좋아요·길이)
- 인기 동영상: `GET videos?part=snippet,statistics&chart=mostPopular&regionCode=KR&videoCategoryId=..`
- 페이징: 응답의 `nextPageToken`을 다음 요청 `pageToken`에 전달

## 7. 검증 (Acceptance / Test)
1. `chrome://extensions` → 개발자 모드 → "압축해제 확장 로드"로 `extension/` 로드
2. 옵션에서 API Key 저장
3. 아이콘 클릭 → 새 탭 검색 페이지 표시
4. "lofi" + 동영상 → 카드(썸네일·채널·조회수) 표시
5. 종류=인기 동영상 → 트렌딩 목록 표시
6. 콘솔에 CORS 오류 없이 200 응답, 할당량 오류 시 안내 표시
7. API Key 미등록 상태에서 검색 시 안내 메시지 표시

## 8. 리스크 / 메모
- **할당량**: 기본 10,000 units/일. search.list가 **100u**라 하루 ~100회 검색 한계 → 통계는 videos.list(1u)로 묶고 캐시 적극 활용.
- API Key가 브라우저에 노출되므로 Google Cloud에서 **HTTP 리퍼러/확장 ID 제한** 권장(개인용 전제).
- 일부 통계(좋아요)는 비공개일 수 있음 → 없으면 생략.

---

## 8.5 기능별 상세 계획 (Planned Features)

### A. 동영상 검색 (Core)
- search.list(type=video) → videoId 목록 → videos.list로 통계 보강 → 카드.
- 카드: 썸네일, 제목, 채널명, 게시일(상대시간), 조회수, 길이(ISO8601→mm:ss), 설명 일부.
- 정렬: relevance / date / viewCount / rating.

### B. 검색 종류
- 동영상(video) / 채널(channel) / 재생목록(playlist) / **인기 동영상(mostPopular)**.
- 채널: 구독자·영상수·총조회수. 재생목록: 항목 수·썸네일.

### C. 필터
- 기간 publishedAfter/Before (1주/1개월/1년/전체).
- 영상 길이 videoDuration (short<4m / medium / long>20m).
- 지역 regionCode, 언어 relevanceLanguage (기본 KR).

### D. 인기 동영상(트렌딩)
- videos.list chart=mostPopular + regionCode=KR + videoCategoryId(카테고리별).
- 카테고리 목록: videoCategories.list. (NaverAPI의 "인기검색어/주간 트렌드"에 대응)

### E. 채널 / 댓글
- 채널 상세(channels.list), 영상의 댓글(commentThreads.list, order=relevance/time).

### G. 관심 분야 (My Topics) ★

> "내가 원하는 분야를 미리 설정해두고, 트렌딩·검색·전용 대시보드에 모두 반영한다."
> 모든 단위가 API Key만으로 구현 가능 (OAuth 불필요).

**G-1. 분야 단위 (4종, 옵션 페이지에서 등록·관리)**
- **카테고리**: `videoCategories.list`(regionCode 기준)로 목록을 받아 관심 항목(음악·게임·뉴스 등)을 체크 저장.
- **키워드 세트**: 이름(예: "AI 코딩") + 키워드 묶음("LLM", "claude code"…)을 저장. 검색어 `q`로 사용.
- **관심 채널**: 채널명/핸들로 찾아(`search`/`channels.list`) channelId 저장. 그 채널의 업로드(`uploads` 재생목록)만 모아보기.
- **지역·언어 기본값**: regionCode / relevanceLanguage를 분야별 기본값으로 저장(전역 기본 KR·ko).

**G-2. 저장 구조** (`chrome.storage.local`의 `myTopics` 배열)
```
{ id, name, emoji,
  categoryIds: [..],            // videoCategoryId 목록
  keywordSets: [{name, terms:[..]}],
  channelIds: [..],
  regionCode: "KR", relevanceLanguage: "ko",
  isDefault: false }
```

**G-3. 반영 위치 (3곳)**
- **트렌딩(인기)**: `videos.list chart=mostPopular` 를 분야의 `categoryIds`별로 묶어 표시(분야 채널 최신 업로드도 함께). 저렴(1u).
- **검색 기본값**: 검색 페이지 진입 시 활성 분야의 regionCode·language·키워드 세트를 기본 필터로 자동 적용. 분야 드롭다운으로 전환.
- **전용 대시보드("내 분야" 탭)**: 활성 분야의 카테고리별 인기 + 키워드별 최신 + 관심 채널 최신 업로드를 한 화면에 카드로 모아보기.

**G-4. 할당량 메모**: 트렌딩/대시보드는 videos.list·playlistItems(각 1u) 위주라 저렴. 키워드 세트 검색만 search(100u)이므로 캐시·수동 새로고침으로 절약.

### F. 내보내기 / UX
- 카드·다크모드·로딩·배지(NaverAPI에서 검증).
- 📋 복사(텍스트), CSV 저장, 🖼 캡처(클립보드 이미지, html2canvas).
- 최근 검색어, 북마크, 종류 전환 시 결과 캐시.

---

## 9. TODO (작업 목록)

> 진행 상태: [x] 완료 · [ ] 미완료. (2026-06-05 일괄 갱신)

**1. 기본 구축**
- 1.1 [x] 워크스페이스/PRD 작성 및 확정
- 1.2 [x] extension/ 1차 구현 (manifest·background·search·options·icons)
- 1.3 [x] 크롬 로드 및 실제 동작 테스트
- 1.4 [x] 옵션 페이지: API Key 입력·저장, 키/할당량 오류 안내 (키 테스트 포함)

**2. 동영상 검색 (Core)**
- 2.1 [x] search.list(type=video) 호출 + nextPageToken 더보기
- 2.2 [x] videos.list로 통계 보강(조회수·좋아요·길이) — 1회 호출로 묶기
- 2.3 [x] 카드 렌더(썸네일·제목·채널·게시일·조회수·길이)
- 2.4 [x] 정렬 토글(관련성/최신/조회수/평점)

**3. 검색 종류**
- 3.1 [x] 채널 검색(channel) + 채널 상세(구독자·영상수·총조회수)
- 3.2 [x] 재생목록 검색(playlist)
- 3.3 [x] 종류 전환 시 컨트롤·결과 캐시 (api.js 5분 캐시)

**4. 필터**
- 4.1 [x] 기간 필터(publishedAfter)
- 4.2 [x] 영상 길이 필터(videoDuration)
- 4.3 [x] 지역/언어(regionCode·relevanceLanguage)

**5. 인기 동영상(트렌딩)**
- 5.1 [x] videos.list chart=mostPopular(regionCode=KR) 인기 동영상
- 5.2 [x] 카테고리 목록(videoCategories.list) + 카테고리별 인기
- 5.3 [x] 카테고리 칩 전환 + 내 분야 대시보드

**5.5 관심 분야 (My Topics) ★**
- 5.5.1 [x] 옵션: 카테고리 선택(videoCategories.list 체크 저장)
- 5.5.2 [x] 옵션: 키워드 세트 등록(이름 + 키워드 묶음)
- 5.5.3 [x] 옵션: 관심 채널 등록(검색→channelId 저장)
- 5.5.4 [x] 분야별 지역/언어 기본값 저장(chrome.storage `myTopics`)
- 5.5.5 [x] 트렌딩에 분야 카테고리 반영(★ 강조)
- 5.5.6 [x] 검색 진입 시 활성 분야 기본값 자동 적용 + 분야 칩 전환
- 5.5.7 [x] "내 분야" 전용 대시보드(북마크·관심채널·키워드·카테고리, 섹션별 더보기, 조건 필터)
- 5.5.8 [x] 복수 분야 활성 허용 + 내 분야 탭엔 활성 분야만 표시
- 5.5.9 [x] 검색 결과 영상 → 분야 등록(채널 추가 / 영상 북마크) 메뉴

**6. 채널 / 댓글**
- 6.1 [x] 채널 상세 모달(통계·최근 업로드)
- 6.2 [x] 영상 댓글 보기(commentThreads, 관련성/최신 정렬 + 더보기)

**7. UI/UX**
- 7.1 [x] 다크모드·로딩(스피너)·종류 배지
- 7.2 [x] 빈 결과/오류 메시지·상단바 sticky
- 7.3 [x] 최근 검색어(칩·지우기)·북마크

**8. 내보내기**
- 8.1 [x] 📋 복사(결과 텍스트)
- 8.2 [x] CSV 저장
- 8.3 [ ] 🖼 캡처(결과 영역 → 이미지) — html2canvas 필요(외부 라이브러리 도입 보류 중)

**9. 할당량/안정성**
- 9.1 [x] 할당량 절약(통계 일괄 보강·5분 캐시·타임아웃), 초과 시 안내
- 9.2 [x] API Key 제한 가이드 문서화 (`docs/90.reference/API키-제한-가이드.md`)

---

## 10. 변경 이력 (Changelog)

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-06-05 | v1.0 | 최초 PRD 작성 (NaverAPI 방식 적용, YouTube Data API 기반 설계) |
| 2026-06-05 | v1.1 | 관심 분야(My Topics) 기능 추가 — 카테고리·키워드 세트·관심 채널·지역/언어를 트렌딩·검색·전용 대시보드에 반영 (F-8/F-9, §8.5-G, TODO 5.5) |
| 2026-06-05 | v1.2 | extension/ 전체 구현 완료. 복수 활성 분야, 내 분야 섹션별 더보기·조건필터, 영상→분야 등록(채널추가/북마크), 채널 상세·댓글 모달, 최근 검색어, 키 제한 가이드 문서. TODO 일괄 갱신(8.3 캡처만 보류) |
