// 월 환산 유틸
// 플랫폼마다 다른 가격 단위(1박/1주/1개월)를 "한 달 기준 가격"으로 통일한다.

import type { PriceUnit, SourcePrice } from "../types";

/** 한 달을 며칠로 볼지 (365 / 12 의 평균값) */
export const DAYS_PER_MONTH = 30.4;
const DAYS_PER_WEEK = 7;

/** 단위 가격을 한 달 기준 가격으로 환산한다 (정수 KRW로 반올림). */
export function toMonthlyPrice(amount: number, unit: PriceUnit): number {
  switch (unit) {
    case "night":
      return Math.round(amount * DAYS_PER_MONTH);
    case "week":
      return Math.round((amount / DAYS_PER_WEEK) * DAYS_PER_MONTH);
    case "month":
      return Math.round(amount);
  }
}

/** SourcePrice 를 월 환산가로 변환한다. */
export function monthlyPriceOf(price: SourcePrice): number {
  return toMonthlyPrice(price.amount, price.unit);
}

/** price 필드를 가진 객체에 monthlyPrice 를 채워 반환한다. */
export function withMonthlyPrice<T extends { price: SourcePrice }>(
  source: T,
): T & { monthlyPrice: number } {
  return { ...source, monthlyPrice: monthlyPriceOf(source.price) };
}

/** 한 달 기준 가격을 "1,520,000원/월" 형태 문자열로 만든다. */
export function formatMonthlyPrice(monthlyPrice: number): string {
  return `${monthlyPrice.toLocaleString("ko-KR")}원/월`;
}
