// 카카오 로컬 REST API 지오코딩 래퍼
// 주소/장소명 문자열 → 좌표(GeoLocation). 서버에서만 호출 (KAKAO_REST_KEY 사용).

import type { GeoLocation } from "../types";

const ADDRESS_URL = "https://dapi.kakao.com/v2/local/search/address.json";
const KEYWORD_URL = "https://dapi.kakao.com/v2/local/search/keyword.json";

interface KakaoDoc {
  x: string; // 경도(lng)
  y: string; // 위도(lat)
  address_name?: string;
  region_2depth_name?: string; // 키워드 검색 결과의 시/구
  address?: { region_2depth_name?: string } | null;
  road_address?: { region_2depth_name?: string } | null;
}

function headers(restKey: string): HeadersInit {
  return { Authorization: `KakaoAK ${restKey}` };
}

function toLocation(query: string, doc: KakaoDoc): GeoLocation {
  return {
    address: query,
    lat: Number(doc.y),
    lng: Number(doc.x),
    region:
      doc.road_address?.region_2depth_name ??
      doc.address?.region_2depth_name ??
      doc.region_2depth_name,
  };
}

async function searchAddress(query: string, restKey: string): Promise<GeoLocation | null> {
  const res = await fetch(`${ADDRESS_URL}?query=${encodeURIComponent(query)}`, {
    headers: headers(restKey),
  });
  if (!res.ok) throw new Error(`카카오 주소검색 실패: ${res.status} ${res.statusText}`);
  const data = (await res.json()) as { documents: KakaoDoc[] };
  const doc = data.documents?.[0];
  return doc ? toLocation(query, doc) : null;
}

async function searchKeyword(query: string, restKey: string): Promise<GeoLocation | null> {
  const res = await fetch(`${KEYWORD_URL}?query=${encodeURIComponent(query)}`, {
    headers: headers(restKey),
  });
  if (!res.ok) throw new Error(`카카오 키워드검색 실패: ${res.status} ${res.statusText}`);
  const data = (await res.json()) as { documents: KakaoDoc[] };
  const doc = data.documents?.[0];
  return doc ? toLocation(query, doc) : null;
}

/**
 * 주소(또는 장소명)를 좌표로 변환한다.
 * 1) 주소 검색 → 2) 실패 시 키워드(장소) 검색 폴백. 둘 다 실패하면 null.
 */
export async function geocode(
  query: string,
  restKey: string | undefined = process.env.KAKAO_REST_KEY,
): Promise<GeoLocation | null> {
  if (!restKey) throw new Error("KAKAO_REST_KEY 가 설정되지 않았습니다 (web/.env 확인).");
  const trimmed = query.trim();
  if (!trimmed) return null;
  return (await searchAddress(trimmed, restKey)) ?? (await searchKeyword(trimmed, restKey));
}
