// 에어비앤비(월 단위) 어댑터 — https://www.airbnb.co.kr (DOM 스크래핑)
// 월 단위(monthly stays) 검색 결과에서 카드의 "/월" 가격을 그대로 월(month) 단가로 사용.
// 카드에는 정확한 좌표/주소가 없어, 검색 지역(AIRBNB_REGIONS)별로 돌며 그 지역명을
// 주소로 써서 카카오 지오코딩한다(동 단위 정밀도는 낮음 — 1단계 한계로 명시).

import { chromium, type Page } from "playwright";
import type { CrawlAdapter, CrawlContext, RawListing } from "../types";

export const BASE_URL = "https://www.airbnb.co.kr";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

// 수집 대상 지역 (검색어 = 지오코딩 주소). 쉼표구분 환경변수로 덮어쓰기 가능.
const REGIONS = (process.env.AIRBNB_REGIONS ?? "서울,부산,제주").split(",").map((s) => s.trim());
// 월 시작일(미래 날짜) — 월 단위 검색 활성화에 필요
const MONTH_START = process.env.AIRBNB_MONTH_START ?? "2026-07-01";
// 상세 페이지에서 좌표를 가져올 매물 수 상한(지역당). 0이면 상세조회 끔(지역중심 좌표).
const DETAIL_LIMIT = Number(process.env.AIRBNB_DETAIL_LIMIT ?? 20);

interface ScrapedCard {
  id: string;
  name: string;
  region: string;
  monthly: number;
  img: string;
}

/** 상세 페이지 HTML 에서 정확한 좌표를 추출한다(실패 시 null). */
async function fetchCoords(
  page: Page,
  id: string,
): Promise<{ lat: number; lng: number } | null> {
  try {
    await page.goto(`${BASE_URL}/rooms/${id}`, {
      waitUntil: "domcontentloaded",
      timeout: 45000,
    });
    await page.waitForTimeout(1500);
    const coords = (await page.evaluate(`
      (() => {
        const html = document.documentElement.innerHTML;
        const la = html.match(/"lat"\\s*:\\s*(-?\\d+\\.\\d+)/);
        const ln = html.match(/"lng"\\s*:\\s*(-?\\d+\\.\\d+)/);
        if (la && ln) return { lat: Number(la[1]), lng: Number(ln[1]) };
        return null;
      })()
    `)) as { lat: number; lng: number } | null;
    return coords;
  } catch {
    return null;
  }
}

function searchUrl(region: string): string {
  const q = encodeURIComponent(region);
  return (
    `${BASE_URL}/s/${q}/homes` +
    `?flexible_trip_lengths%5B%5D=one_month` +
    `&monthly_start_date=${MONTH_START}` +
    `&monthly_length=1&search_type=filter_change`
  );
}

async function scrapeRegion(page: Page, region: string): Promise<ScrapedCard[]> {
  await page.goto(searchUrl(region), { waitUntil: "domcontentloaded", timeout: 60000 });
  await page
    .waitForSelector('[itemprop="itemListElement"]', { timeout: 25000 })
    .catch(() => {});
  await page.waitForTimeout(3000);

  // 함수 정의 없는 평탄 표현식(esbuild __name 주입 회피)
  return (await page.evaluate(`
    (() => {
      const cards = Array.from(document.querySelectorAll('[itemprop="itemListElement"]'));
      const out = [];
      for (const c of cards) {
        const a = c.querySelector('a[href*="/rooms/"]');
        const m = a && (a.getAttribute('href')||'').match(/rooms\\/(\\d+)/);
        if (!m) continue;
        const nameEl = c.querySelector('[data-testid="listing-card-name"]');
        const name = (nameEl && nameEl.textContent) || '';
        const imgEl = c.querySelector('img');
        const img = (imgEl && imgEl.getAttribute('src')) || '';
        // 가격: '₩숫자' 리프 노드들 중 마지막(할인가). '/월' 포함 카드만.
        const leafs = Array.from(c.querySelectorAll('span,div')).filter(s => s.children.length===0);
        const won = leafs.map(s => (s.textContent||'').trim()).filter(t => /^₩[\\d,]+$/.test(t));
        const hasMonthly = leafs.some(s => (s.textContent||'').indexOf('/월') >= 0);
        if (!hasMonthly || won.length === 0) continue;
        const monthly = Number(won[won.length-1].replace(/[^0-9]/g,'')) || 0;
        out.push({ id: m[1], name: name.trim(), region: '${region}', monthly, img });
      }
      return out;
    })()
  `)) as ScrapedCard[];
}

export const airbnbAdapter: CrawlAdapter = {
  platform: "airbnb",
  async fetch(ctx: CrawlContext): Promise<RawListing[]> {
    const browser = await chromium.launch({ headless: true });
    try {
      const page = await browser.newPage({ userAgent: UA, locale: "ko-KR" } as never);
      const seen = new Set<string>();
      const raws: RawListing[] = [];

      for (const region of REGIONS) {
        await ctx.throttle();
        ctx.log(`에어비앤비: '${region}' 검색`);
        let cards: ScrapedCard[] = [];
        try {
          cards = await scrapeRegion(page, region);
        } catch (e) {
          ctx.log(`에어비앤비: '${region}' 실패 — ${(e as Error).message}`);
          continue;
        }
        ctx.log(`에어비앤비: '${region}' 카드 ${cards.length}건`);

        const fresh = cards.filter((c) => c.monthly && !seen.has(c.id));
        let detailed = 0;
        for (const c of fresh) {
          seen.add(c.id);
          // 상세에서 정확한 좌표 추출(상한까지). 실패하면 지역명 지오코딩으로 폴백.
          let lat: number | undefined;
          let lng: number | undefined;
          if (detailed < DETAIL_LIMIT) {
            await ctx.throttle();
            const co = await fetchCoords(page, c.id);
            if (co) {
              lat = co.lat;
              lng = co.lng;
            }
            detailed++;
          }
          raws.push({
            platformId: c.id,
            title: c.name || `${region} 숙소`,
            url: `${BASE_URL}/rooms/${c.id}`,
            address: region, // 좌표 미확보 시 지역명으로 지오코딩(정밀도 낮음)
            lat,
            lng,
            region,
            price: { amount: c.monthly, unit: "month" },
            images: c.img ? [c.img] : [],
          });
        }
        ctx.log(`에어비앤비: '${region}' 좌표 ${detailed}건 상세조회`);
      }
      ctx.log(`에어비앤비: 총 ${raws.length}건`);
      return raws;
    } finally {
      await browser.close();
    }
  },
};
