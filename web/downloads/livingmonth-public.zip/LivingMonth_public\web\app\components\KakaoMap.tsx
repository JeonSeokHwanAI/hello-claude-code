"use client";

import { useEffect, useRef, useState } from "react";
import type { Listing } from "@/lib/types";
import { formatMonthlyPrice } from "@/lib/price";

declare global {
  interface Window {
    kakao: any;
  }
}

/** 지도 영역(bbox): 경도/위도 최소·최대 */
export interface Bounds {
  minLng: number;
  minLat: number;
  maxLng: number;
  maxLat: number;
}

interface KakaoMapProps {
  listings: Listing[];
  /** 선택된 매물 id (지도 중심 이동) */
  selectedId?: string;
  onMarkerClick?: (id: string) => void;
  /** 지도 이동·확대 시 현재 영역(bbox) 통지 */
  onBoundsChange?: (bounds: Bounds) => void;
}

const SEOUL_CENTER = { lat: 37.5665, lng: 126.978 };

// 클러스터 마커 스타일 — 기존 연한 초록·하늘색 배경 느낌은 유지하고,
// 글자색만 검정 + 흰 외곽선으로 연한 배경에서도 숫자가 또렷하게 보이도록 한다.
// (styles 를 지정하면 카카오 기본 배경이 사라지므로 배경색을 직접 지정한다.)
const CLUSTER_BG = ["#9fe0f0", "#9fe0a8", "#8fd0e8"]; // 소/중/대 (하늘·초록 계열)
const CLUSTER_STYLES: Record<string, string>[] = [40, 50, 60].map((size, i) => ({
  width: `${size}px`,
  height: `${size}px`,
  background: CLUSTER_BG[i],
  borderRadius: "50%",
  textAlign: "center",
  lineHeight: `${size}px`,
  fontSize: `${Math.round(size * 0.32)}px`,
  fontWeight: "700",
  color: "#111",
  textShadow: "0 0 2px #fff, 0 0 2px #fff",
  border: "2px solid rgba(255,255,255,0.95)",
  boxShadow: "0 1px 4px rgba(0,0,0,0.25)",
}));

export default function KakaoMap({
  listings,
  selectedId,
  onMarkerClick,
  onBoundsChange,
}: KakaoMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<any>(null);
  const clusterer = useRef<any>(null);
  // 말풍선은 전체에서 1개만 공유 — 동시에 여러 개가 떠 닫히지 않는 문제 방지
  const infoWindow = useRef<any>(null);
  // 콜백이 항상 최신값을 보도록 ref 로 보관
  const clickCb = useRef(onMarkerClick);
  clickCb.current = onMarkerClick;
  const boundsCb = useRef(onBoundsChange);
  boundsCb.current = onBoundsChange;

  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  // SDK 로드 + 지도/클러스터러 생성
  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_KAKAO_JS_KEY;
    if (!key) {
      setError("NEXT_PUBLIC_KAKAO_JS_KEY 가 설정되지 않았습니다.");
      return;
    }

    const init = () => {
      window.kakao.maps.load(() => {
        if (!mapRef.current) return;
        const map = new window.kakao.maps.Map(mapRef.current, {
          center: new window.kakao.maps.LatLng(SEOUL_CENTER.lat, SEOUL_CENTER.lng),
          level: 8,
        });
        mapObj.current = map;
        clusterer.current = new window.kakao.maps.MarkerClusterer({
          map,
          averageCenter: true,
          minLevel: 6,
          gridSize: 80,
          styles: CLUSTER_STYLES,
        });

        const emitBounds = () => {
          const b = map.getBounds();
          const sw = b.getSouthWest();
          const ne = b.getNorthEast();
          boundsCb.current?.({
            minLng: sw.getLng(),
            minLat: sw.getLat(),
            maxLng: ne.getLng(),
            maxLat: ne.getLat(),
          });
        };
        window.kakao.maps.event.addListener(map, "idle", emitBounds);
        // 빈 지도를 클릭하면 열려 있던 말풍선을 닫는다
        window.kakao.maps.event.addListener(map, "click", () =>
          infoWindow.current?.close(),
        );
        infoWindow.current = new window.kakao.maps.InfoWindow({ removable: false });
        emitBounds();
        setReady(true);
      });
    };

    if (window.kakao && window.kakao.maps) {
      init();
      return;
    }

    const existing = document.getElementById("kakao-maps-sdk") as HTMLScriptElement | null;
    if (existing) {
      existing.addEventListener("load", init);
      return () => existing.removeEventListener("load", init);
    }

    const script = document.createElement("script");
    script.id = "kakao-maps-sdk";
    script.async = true;
    // clusterer 라이브러리 포함 로드
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${key}&autoload=false&libraries=clusterer`;
    script.addEventListener("load", init);
    script.addEventListener("error", () =>
      setError("카카오 지도 SDK 로드 실패 (네트워크 또는 도메인 등록 확인)."),
    );
    document.head.appendChild(script);

    const t = setTimeout(() => {
      if (!mapObj.current) {
        setError(
          "지도를 불러오지 못했습니다. 카카오 콘솔에 도메인(http://localhost:3000) 등록이 필요할 수 있습니다.",
        );
      }
    }, 4000);
    return () => clearTimeout(t);
  }, []);

  // 매물 → 마커/클러스터 갱신
  useEffect(() => {
    if (!ready || !mapObj.current || !clusterer.current) return;
    const kakao = window.kakao;
    clusterer.current.clear();
    infoWindow.current?.close();

    const markers = listings.map((l) => {
      const marker = new kakao.maps.Marker({
        position: new kakao.maps.LatLng(l.location.lat, l.location.lng),
      });
      const thumb = l.images[0]
        ? `<img src="${l.images[0]}" alt="" style="width:100%;height:100px;object-fit:cover;display:block;border-radius:6px 6px 0 0;" />`
        : "";
      const content = `<div style="width:180px;font-size:12px;overflow:hidden;border-radius:6px;">${thumb}<div style="padding:6px 10px;"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${l.title}</div><b style="color:#2563eb;">${formatMonthlyPrice(l.monthlyPrice)}</b></div></div>`;
      const openInfo = () => {
        infoWindow.current.setContent(content);
        infoWindow.current.open(mapObj.current, marker);
      };
      kakao.maps.event.addListener(marker, "mouseover", openInfo);
      kakao.maps.event.addListener(marker, "mouseout", () => infoWindow.current.close());
      kakao.maps.event.addListener(marker, "click", () => {
        infoWindow.current.close(); // 클릭 시 말풍선 닫고 상세로
        clickCb.current?.(l.id);
      });
      return marker;
    });

    clusterer.current.addMarkers(markers);
  }, [ready, listings]);

  // 선택 매물로 중심 이동
  useEffect(() => {
    if (!ready || !mapObj.current || !selectedId) return;
    const target = listings.find((l) => l.id === selectedId);
    if (target) {
      mapObj.current.panTo(
        new window.kakao.maps.LatLng(target.location.lat, target.location.lng),
      );
    }
  }, [ready, selectedId, listings]);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <div ref={mapRef} style={{ width: "100%", height: "100%" }} />
      {error && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "1.5rem",
            textAlign: "center",
            color: "#666",
            background: "#f4f4f5",
            fontSize: 14,
            lineHeight: 1.6,
          }}
        >
          <div>🗺️ {error}</div>
          <div style={{ fontSize: 12, marginTop: 8 }}>(왼쪽 목록은 정상 동작합니다)</div>
        </div>
      )}
    </div>
  );
}
