---
name: setup
description: LivingMonth 공개본을 새 PC에서 설치·실행한다. node_modules·.next 등 재생성물이 빠진 슬림 배포본을 받아 npm install → .env 설정 → (선택)크롤링 → dev 서버까지 동일하게 세팅한다. "설치", "셋업", "처음 실행", "환경 구성", "install" 요청 시 사용.
---

# LivingMonth 설치 스킬

이 배포본은 **재생성 가능한 파일(node_modules, .next, next-env.d.ts)이 제거된 슬림 버전**입니다.
아래 절차로 어느 PC에서든 동일한 개발 환경을 만든다.

## 전제 확인

1. **Node.js 20.12+ 설치 여부** 확인. 없으면 https://nodejs.org 에서 LTS 설치 안내.
   ```
   node -v
   npm -v
   ```
2. 작업 위치는 항상 **`web/` 폴더**. (앱·의존성·.env 는 전부 web/ 안)

## 설치 절차 (순서대로)

### 1단계 — 의존성 설치
`web/` 에서 실행. `package-lock.json` 이 있으므로 버전이 그대로 재현된다.
```
cd web
npm install
```

### 2단계 — 카카오 키 설정
`web/.env.example` 을 복사해 `web/.env` 를 만들고 키 2개를 채운다.
- `NEXT_PUBLIC_KAKAO_JS_KEY` — 카카오맵 JavaScript 키 (지도)
- `KAKAO_REST_KEY` — 카카오 REST API 키 (지오코딩)
- 키 발급: https://developers.kakao.com (무료, 카드 불필요)
- ⚠️ 지도가 `domain mismatched` 로 안 뜨면 카카오 콘솔 → [플랫폼] → Web 사이트 도메인에
  `http://localhost:3000` 등록.

복사 명령:
- PowerShell: `Copy-Item .env.example .env`
- bash: `cp .env.example .env`

그 후 사용자에게 키 입력을 요청하거나, 사용자가 키를 주면 `.env` 에 기록한다.
**키는 절대 코드/문서/커밋에 하드코딩하지 않는다. `.env` 에만 둔다.**

### 3단계 — 매물 데이터 확인
- 배포본에는 **샘플 매물(`web/data/*.json`, 약 88건)**이 포함되어 있어 키만 넣으면 바로 동작한다.
- 최신 데이터로 갱신하려면(키 필요, 수 분 소요):
  ```
  npm run crawl
  ```
  - 크롤러는 Playwright 브라우저가 필요할 수 있다. 미설치 시:
    `npx playwright install chromium`
  - 옵션 환경변수: `SAMSAMM2_MAX_PAGES`, `MRMENTION_MAX_SCROLL`, `AIRBNB_REGIONS`, `AIRBNB_DETAIL_LIMIT`, `CRAWL_DELAY_MS`

### 4단계 — 개발 서버 실행
```
npm run dev
```
→ http://localhost:3000 에서 목록·검색·지도·상세 확인.

## 검증 (설치가 제대로 됐는지)
```
npm run build      # 프로덕션 빌드 통과 확인
npm test           # 단위 테스트 (월환산·정규화) 통과 확인
```

## 자주 쓰는 명령 (모두 web/ 에서)

| 명령 | 설명 |
|---|---|
| `npm install` | 의존성 설치 (최초 1회) |
| `npm run dev` | 개발 서버 (localhost:3000) |
| `npm run build` | 프로덕션 빌드 |
| `npm run crawl` | 매물 크롤링 → data/<platform>.json |
| `npm test` | 단위 테스트 |

## 문제 해결
- **`'next' 인식 불가`** → `npm install` 이 끝나기 전에 build/dev 를 돌린 경우. install 완료 후 재시도.
- **지도가 회색 + 안내문** → 카카오 콘솔 도메인 등록 필요(2단계 참고). 목록·검색·상세는 정상.
- **크롤 시 브라우저 오류** → `npx playwright install chromium`.
