// 월 환산 유틸 단위 테스트 — node:test 내장 러너 + tsx
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  DAYS_PER_MONTH,
  toMonthlyPrice,
  monthlyPriceOf,
  withMonthlyPrice,
  formatMonthlyPrice,
} from "./index";

test("toMonthlyPrice: 월 단위는 그대로(반올림)", () => {
  assert.equal(toMonthlyPrice(1_000_000, "month"), 1_000_000);
  assert.equal(toMonthlyPrice(1_000_000.4, "month"), 1_000_000);
});

test("toMonthlyPrice: 1박 단위는 ×30.4", () => {
  assert.equal(toMonthlyPrice(50_000, "night"), Math.round(50_000 * DAYS_PER_MONTH));
  assert.equal(toMonthlyPrice(50_000, "night"), 1_520_000);
});

test("toMonthlyPrice: 1주 단위는 ÷7×30.4", () => {
  assert.equal(toMonthlyPrice(300_000, "week"), Math.round((300_000 / 7) * DAYS_PER_MONTH));
  assert.equal(toMonthlyPrice(300_000, "week"), 1_302_857);
});

test("toMonthlyPrice: 0원은 0원", () => {
  assert.equal(toMonthlyPrice(0, "week"), 0);
});

test("monthlyPriceOf: SourcePrice 를 환산", () => {
  assert.equal(monthlyPriceOf({ amount: 360_000, unit: "week", currency: "KRW" }), 1_563_429);
});

test("withMonthlyPrice: monthlyPrice 필드를 덧붙이고 원본 보존", () => {
  const src = { price: { amount: 200_000, unit: "week" as const, currency: "KRW" }, title: "x" };
  const out = withMonthlyPrice(src);
  assert.equal(out.title, "x");
  assert.equal(out.monthlyPrice, monthlyPriceOf(src.price));
});

test("formatMonthlyPrice: 천단위 콤마 + 원/월", () => {
  assert.equal(formatMonthlyPrice(1_520_000), "1,520,000원/월");
  assert.equal(formatMonthlyPrice(0), "0원/월");
});
