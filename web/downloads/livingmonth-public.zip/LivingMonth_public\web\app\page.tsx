"use client";

import { useCallback, useEffect, useState } from "react";
import type { Listing } from "@/lib/types";
import KakaoMap, { type Bounds } from "./components/KakaoMap";
import ListingList from "./components/ListingList";
import ListingDetail from "./components/ListingDetail";
import SearchForm, { DEFAULT_FILTERS, type SearchFilters } from "./components/SearchForm";

function buildQuery(f: SearchFilters): string {
  const sp = new URLSearchParams();
  if (f.region.trim()) sp.set("region", f.region.trim());
  if (f.minPrice.trim()) sp.set("minPrice", f.minPrice.trim());
  if (f.maxPrice.trim()) sp.set("maxPrice", f.maxPrice.trim());
  if (f.platforms.length > 0) sp.set("platform", f.platforms.join(","));
  sp.set("sort", f.sort);
  return sp.toString();
}

export default function Home() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<SearchFilters>(DEFAULT_FILTERS);
  const [selectedId, setSelectedId] = useState<string | undefined>();
  const [bounds, setBounds] = useState<Bounds | null>(null);

  // 검색 조건이 바뀌면 매물 다시 로드
  useEffect(() => {
    setLoading(true);
    fetch(`/api/listings?${buildQuery(filters)}`)
      .then((r) => r.json())
      .then((d) => setListings(d.listings ?? []))
      .catch(() => setListings([]))
      .finally(() => setLoading(false));
  }, [filters]);

  // 지도 영역(bbox) 안의 매물만 목록에 노출 (지도와 목록 동기화)
  const visible = bounds
    ? listings.filter(
        (l) =>
          l.location.lng >= bounds.minLng &&
          l.location.lng <= bounds.maxLng &&
          l.location.lat >= bounds.minLat &&
          l.location.lat <= bounds.maxLat,
      )
    : listings;

  const selected = listings.find((l) => l.id === selectedId);
  const handleBoundsChange = useCallback((b: Bounds) => setBounds(b), []);

  return (
    <main style={{ display: "flex", width: "100vw", height: "100vh", overflow: "hidden" }}>
      {/* 왼쪽: 검색 + 목록 (상세 열리면 패널 위에 오버레이) */}
      <aside
        style={{
          position: "relative",
          width: 380,
          minWidth: 380,
          height: "100%",
          overflowY: "auto",
          borderRight: "1px solid #ddd",
          background: "#fafafa",
        }}
      >
        <header style={{ padding: "16px 16px 0", background: "#fff" }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>LivingMonth</h1>
          <p style={{ margin: "4px 0 0", fontSize: 12, color: "#374151" }}>
            한 달 기준 가격으로 비교하는 한달살기 매물
          </p>
        </header>

        <div style={{ background: "#fff", borderBottom: "1px solid #ddd" }}>
          <SearchForm value={filters} onChange={setFilters} />
        </div>

        <div style={{ padding: "8px 16px", fontSize: 12, color: "#374151" }}>
          {loading
            ? "불러오는 중…"
            : `지도 영역 내 ${visible.length}건 / 전체 ${listings.length}건`}
        </div>

        {!loading && visible.length === 0 ? (
          <p style={{ padding: 16, color: "#374151", fontSize: 13 }}>
            조건에 맞는 매물이 없습니다. 검색 조건이나 지도 위치를 바꿔보세요.
          </p>
        ) : (
          <ListingList listings={visible} selectedId={selectedId} onSelect={setSelectedId} />
        )}

        {selected && (
          <ListingDetail listing={selected} onClose={() => setSelectedId(undefined)} />
        )}
      </aside>

      {/* 오른쪽: 지도 */}
      <section style={{ flex: 1, height: "100%" }}>
        <KakaoMap
          listings={visible}
          selectedId={selectedId}
          onMarkerClick={setSelectedId}
          onBoundsChange={handleBoundsChange}
        />
      </section>
    </main>
  );
}
