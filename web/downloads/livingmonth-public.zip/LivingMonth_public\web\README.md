# LivingMonth (web)

여러 한달살기 플랫폼의 매물을 모아 카카오맵 위에서 **"한 달 기준 가격"으로 비교**하는 메타검색 서비스 (Next.js 앱).

> 이 폴더(`web/`)가 실제 앱입니다. 모든 명령은 이 폴더에서 실행합니다.
> 문서·기획은 상위 `../docs/` 에 있습니다.

## 요구 사항

- Node.js 20.12+ (개발은 22.x 기준)
- 카카오 개발자 키 2종 — https://developers.kakao.com
  - **JavaScript 키** → 지도 SDK (브라우저)
  - **REST API 키** → 로컬 API 지오코딩 (서버)

## 설치 & 실행

```bash
npm install

# 환경변수 설정: .env.example 을 복사해 키 입력
#   NEXT_PUBLIC_KAKAO_JS_KEY=...   (지도)
#   KAKAO_REST_KEY=...             (지오코딩)

npm run dev      # 개발 서버 http://localhost:3000
```

> ⚠️ **지도가 안 뜨면**: 카카오 콘솔 → [앱] → [플랫폼] → Web 사이트 도메인에
> `http://localhost:3000` 을 등록해야 합니다. (미등록 시 지도는 회색 안내문, 목록·검색은 정상)

## 데이터 수집 (크롤링)

```bash
npm run crawl
```

- 어댑터를 순회하며 매물을 수집 → 정규화(좌표·월환산) → `data/<platform>.json` 저장.
- 현재 **삼삼엠투**는 내부 API로 실제 동작(좌표 직접 제공). 미스터멘션·에어비앤비는 스캐폴드(미구현), 네이버는 1단계 제외.
- 옵션 환경변수:
  - `SAMSAMM2_MAX_PAGES` (기본 4) — 수집 페이지 수
  - `CRAWL_DELAY_MS` (기본 1000) — 요청 간 지연(ms)

## 테스트

```bash
npm test         # node:test + tsx, lib/**/*.test.ts
```

월 환산(1박/1주/1개월)·정규화(좌표 직접경로/필드 보존)를 검증합니다.

## 주요 명령

| 명령 | 설명 |
|---|---|
| `npm run dev` | 개발 서버 |
| `npm run build` | 프로덕션 빌드 |
| `npm run lint` | ESLint |
| `npm run crawl` | 매물 크롤링 → `data/` |
| `npm test` | 단위 테스트 |

## 구조

```
web/
  app/
    page.tsx                  # 메인: 검색 + 목록 + 지도
    api/listings/route.ts     # GET /api/listings (platform·price·region·bbox·sort)
    components/
      SearchForm.tsx          # 지역·가격·플랫폼·정렬 필터
      KakaoMap.tsx            # 카카오맵 + 마커 클러스터 + 영역검색(bbox)
      ListingList.tsx         # 매물 목록(썸네일·월가격)
      ListingDetail.tsx       # 상세(사진 갤러리·추가비용·딥링크)
  lib/
    types.ts                  # 공통 매물 모델(Listing/SourcePrice/...)
    price/                    # 월 환산 유틸 (+ 테스트)
    geocode/                  # 카카오 로컬 API 지오코딩
    storage.ts                # data/<platform>.json 읽기/쓰기
    crawler/
      types.ts                # CrawlAdapter / RawListing
      normalize.ts            # raw → 지오코딩/월환산 → Listing (+ 테스트)
      runner.ts               # 어댑터 실행·중복제거·저장
      adapters/               # 플랫폼별 어댑터 (samsamm2 구현)
  scripts/crawl.ts            # npm run crawl 진입점
  data/                       # 수집 결과 JSON (gitignore 권장)
```

## API: `GET /api/listings`

| 파라미터 | 예 | 설명 |
|---|---|---|
| `platform` | `samsamm2,airbnb` | 플랫폼 필터(콤마 구분) |
| `minPrice` / `maxPrice` | `1000000` | 월 환산가 범위 |
| `region` | `강남` | 지역 부분일치 |
| `bbox` | `minLng,minLat,maxLng,maxLat` | 지도 영역 |
| `sort` | `price`\|`area`\|`latest` | 정렬(기본 price) |
| `limit` | `50` | 최대 건수 |

응답: `{ total, count, listings: Listing[] }`
