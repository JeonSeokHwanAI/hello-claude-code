// 원시 매물(RawListing) → 공통 매물(Listing) 정규화
// 좌표를 채우고(직접 제공 시 그대로, 없으면 지오코딩), 가격을 월 기준으로 환산한다.

import type { GeoLocation, Listing, Platform } from "../types";
import { makeListingId } from "../types";
import { monthlyPriceOf } from "../price";
import { geocode } from "../geocode";
import type { RawListing } from "./types";

interface NormalizeOptions {
  /** 지오코딩(네트워크) 직전에 호출되는 지연 함수 */
  throttle?: () => Promise<void>;
}

/**
 * 원시 매물을 공통 매물로 정규화한다.
 * 좌표가 raw 에 있으면 그대로 쓰고, 없으면 지오코딩한다.
 * 좌표를 끝내 구하지 못하면 null 을 반환해 보류한다.
 */
export async function normalize(
  platform: Platform,
  raw: RawListing,
  fetchedAt: string,
  opts: NormalizeOptions = {},
): Promise<Listing | null> {
  let location: GeoLocation | null;
  if (raw.lat != null && raw.lng != null) {
    location = { address: raw.address, lat: raw.lat, lng: raw.lng, region: raw.region };
  } else {
    if (opts.throttle) await opts.throttle();
    location = await geocode(raw.address);
    if (location && raw.region) location.region = raw.region;
  }
  if (!location) return null;

  const price = {
    amount: raw.price.amount,
    unit: raw.price.unit,
    currency: raw.price.currency ?? "KRW",
  };

  return {
    id: makeListingId(platform, raw.platformId),
    platform,
    platformId: raw.platformId,
    title: raw.title,
    url: raw.url,
    location,
    price,
    monthlyPrice: monthlyPriceOf(price),
    extraCosts: raw.extraCosts,
    images: raw.images ?? [],
    amenities: raw.amenities,
    areaM2: raw.areaM2,
    rooms: raw.rooms,
    minStayDays: raw.minStayDays,
    fetchedAt,
  };
}
