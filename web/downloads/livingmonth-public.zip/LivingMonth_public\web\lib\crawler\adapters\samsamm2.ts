// 삼삼엠투 (33m²) 어댑터 — 내부 JSON API 사용
// 목록 API: GET https://web.33m2.co.kr/v1/rooms?page=&size=  → data.rooms.content[]
// 좌표(lat/lng)를 API가 직접 제공하므로 지오코딩 불필요.
// 삼삼엠투는 '주 단위' 단기임대 모델(1주~12주) → usingFee 를 주(week) 단가로 본다.

import type { CrawlAdapter, CrawlContext, RawListing } from "../types";

export const BASE_URL = "https://33m2.co.kr";
const API = "https://web.33m2.co.kr/v1/rooms";
const WEB_ORIGIN = "https://web.33m2.co.kr";
const IMG_CDN = "https://d1pviohoskiraj.cloudfront.net";
const PYEONG_TO_M2 = 3.3058;

/** picMain(예: "room/xxx.png") → CDN 절대 URL */
function imageUrl(picMain: string | undefined, size = "720x480"): string | undefined {
  if (!picMain) return undefined;
  return `${IMG_CDN}/${picMain}?b=samsamm2&d=${size}`;
}

const PAGE_SIZE = 50;
const MAX_PAGES = Number(process.env.SAMSAMM2_MAX_PAGES ?? 4);

const API_HEADERS: Record<string, string> = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
  Origin: WEB_ORIGIN,
  Referer: WEB_ORIGIN + "/",
  Accept: "application/json",
};

interface Room {
  rid: number;
  roomName: string;
  state?: string;
  province?: string;
  town?: string;
  picMain?: string;
  addrLot?: string;
  addrStreet?: string;
  propertyType?: string;
  usingFee?: number;
  mgmtFee?: number;
  pyeongSize?: number;
  roomCnt?: number;
  lat?: number;
  lng?: number;
}

interface ApiResponse {
  code?: string;
  data?: { rooms?: { content?: Room[] } };
}

function toRaw(r: Room): RawListing | null {
  if (r.usingFee == null) return null;
  const address =
    r.addrLot ??
    r.addrStreet ??
    [r.state, r.province, r.town].filter(Boolean).join(" ").trim();
  return {
    platformId: String(r.rid),
    title: r.roomName,
    url: `${WEB_ORIGIN}/guest/room/${r.rid}`,
    address,
    lat: r.lat,
    lng: r.lng,
    region: r.province ?? r.town,
    images: imageUrl(r.picMain) ? [imageUrl(r.picMain)!] : [],
    // 삼삼엠투 usingFee = 주당 이용료
    price: { amount: r.usingFee, unit: "week" },
    extraCosts: r.mgmtFee ? { maintenanceFee: r.mgmtFee } : undefined,
    areaM2: r.pyeongSize ? Math.round(r.pyeongSize * PYEONG_TO_M2) : undefined,
    rooms: r.roomCnt,
  };
}

export const samsamm2Adapter: CrawlAdapter = {
  platform: "samsamm2",
  async fetch(ctx: CrawlContext): Promise<RawListing[]> {
    const out: RawListing[] = [];
    for (let page = 1; page <= MAX_PAGES; page++) {
      await ctx.throttle();
      const res = await fetch(`${API}?page=${page}&size=${PAGE_SIZE}`, {
        headers: API_HEADERS,
      });
      if (!res.ok) {
        ctx.log(`삼삼엠투: page ${page} HTTP ${res.status} → 중단`);
        break;
      }
      const json = (await res.json()) as ApiResponse;
      const rooms = json.data?.rooms?.content ?? [];
      if (rooms.length === 0) break;
      for (const r of rooms) {
        const raw = toRaw(r);
        if (raw) out.push(raw);
      }
      ctx.log(`삼삼엠투: page ${page} → ${rooms.length}건 (누적 ${out.length})`);
      if (rooms.length < PAGE_SIZE) break;
    }
    return out;
  },
};
