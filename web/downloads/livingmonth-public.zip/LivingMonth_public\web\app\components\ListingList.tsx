"use client";

import type { Listing } from "@/lib/types";
import { PLATFORM_LABELS } from "@/lib/types";
import { formatMonthlyPrice } from "@/lib/price";

interface ListingListProps {
  listings: Listing[];
  selectedId?: string;
  onSelect?: (id: string) => void;
}

export default function ListingList({ listings, selectedId, onSelect }: ListingListProps) {
  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
      {listings.map((l) => {
        const selected = l.id === selectedId;
        return (
          <li
            key={l.id}
            onClick={() => onSelect?.(l.id)}
            style={{
              display: "flex",
              gap: 12,
              padding: "12px 16px",
              borderBottom: "1px solid #eee",
              cursor: "pointer",
              background: selected ? "#eef4ff" : "#fff",
            }}
          >
            {/* 썸네일 */}
            {l.images[0] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={l.images[0]}
                alt=""
                style={{
                  width: 84,
                  height: 84,
                  objectFit: "cover",
                  borderRadius: 8,
                  flexShrink: 0,
                  background: "#f0f0f0",
                }}
              />
            ) : (
              <div
                style={{
                  width: 84,
                  height: 84,
                  borderRadius: 8,
                  flexShrink: 0,
                  background: "#f0f0f0",
                }}
              />
            )}

            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                <span
                  style={{
                    fontWeight: 600,
                    fontSize: 14,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {l.title}
                </span>
                <span
                  style={{
                    fontSize: 11,
                    color: "#4b5563",
                    whiteSpace: "nowrap",
                    alignSelf: "flex-start",
                  }}
                >
                  {PLATFORM_LABELS[l.platform]}
                </span>
              </div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#2563eb", marginTop: 4 }}>
                {formatMonthlyPrice(l.monthlyPrice)}
              </div>
              <div style={{ fontSize: 12, color: "#374151", marginTop: 2 }}>
                {l.location.region ?? l.location.address}
                {l.areaM2 ? ` · ${l.areaM2}㎡` : ""}
                {l.rooms ? ` · 방 ${l.rooms}` : ""}
              </div>
              <a
                href={l.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                style={{ fontSize: 12, color: "#2563eb", textDecoration: "none" }}
              >
                원문 보기 ↗
              </a>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
