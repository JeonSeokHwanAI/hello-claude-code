// 전체 어댑터 목록 (러너가 순회)

import type { CrawlAdapter } from "../types";
import { samsamm2Adapter } from "./samsamm2";
import { mrmentionAdapter } from "./mrmention";
import { airbnbAdapter } from "./airbnb";
import { naverAdapter } from "./naver";

export const ALL_ADAPTERS: CrawlAdapter[] = [
  samsamm2Adapter,
  mrmentionAdapter,
  airbnbAdapter,
  naverAdapter,
];

export { samsamm2Adapter, mrmentionAdapter, airbnbAdapter, naverAdapter };
