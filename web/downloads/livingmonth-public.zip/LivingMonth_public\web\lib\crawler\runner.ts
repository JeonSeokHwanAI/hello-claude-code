// 크롤 러너
// 어댑터를 실행 → 원시 매물을 정규화(지오코딩·월환산) → 중복 제거 → JSON 저장.

import type { Listing } from "../types";
import { writeListings } from "../storage";
import { normalize } from "./normalize";
import type { CrawlAdapter, CrawlContext } from "./types";

/** 단일 어댑터를 실행해 정규화·저장하고, 저장된 매물을 반환한다. */
export async function runAdapter(
  adapter: CrawlAdapter,
  ctx: CrawlContext,
): Promise<Listing[]> {
  ctx.log(`${adapter.platform}: 수집 시작`);
  const raws = await adapter.fetch(ctx);
  ctx.log(`${adapter.platform}: 원시 ${raws.length}건 수집, 정규화 시작`);

  const fetchedAt = new Date().toISOString();
  const seen = new Set<string>();
  const listings: Listing[] = [];

  for (const raw of raws) {
    // 지연은 normalize 내부에서 지오코딩이 실제로 필요할 때만 적용된다
    // (어댑터는 자체 요청 사이에 ctx.throttle 로 매너 지연을 둔다).
    const listing = await normalize(adapter.platform, raw, fetchedAt, {
      throttle: ctx.throttle,
    });
    if (!listing) {
      ctx.log(`지오코딩 실패로 보류: ${raw.title}`);
      continue;
    }
    if (seen.has(listing.id)) continue;
    seen.add(listing.id);
    listings.push(listing);
  }

  await writeListings(adapter.platform, listings);
  ctx.log(`${adapter.platform}: ${listings.length}건 저장 (data/${adapter.platform}.json)`);
  return listings;
}

/** 여러 어댑터를 순차 실행한다. */
export async function runAll(
  adapters: CrawlAdapter[],
  ctx: CrawlContext,
): Promise<Listing[]> {
  const all: Listing[] = [];
  for (const adapter of adapters) {
    try {
      all.push(...(await runAdapter(adapter, ctx)));
    } catch (err) {
      ctx.log(`${adapter.platform}: 실패 — ${(err as Error).message}`);
    }
  }
  return all;
}
