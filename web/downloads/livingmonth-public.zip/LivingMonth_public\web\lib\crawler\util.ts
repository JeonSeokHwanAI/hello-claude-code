// 크롤러 보조 유틸 (로깅·지연)

/** ms 만큼 대기 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 접두어가 붙은 콘솔 로거 */
export function createLogger(prefix: string): (msg: string) => void {
  return (msg: string) => console.log(`[${prefix}] ${msg}`);
}

/** 호출 시마다 delayMs 만큼 쉬는 throttle 함수 (요청 간 매너 지연) */
export function makeThrottle(delayMs: number): () => Promise<void> {
  return () => sleep(delayMs);
}
