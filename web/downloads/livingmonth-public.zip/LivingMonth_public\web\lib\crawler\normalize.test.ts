// 정규화(normalize) 단위 테스트
// 좌표가 raw 에 있는 경로는 geocode 를 호출하지 않으므로 카카오 키 없이 검증 가능.
import { test } from "node:test";
import assert from "node:assert/strict";
import { normalize } from "./normalize";
import type { RawListing } from "./types";

const FETCHED = "2026-05-29T00:00:00.000Z";

function rawWithCoords(over: Partial<RawListing> = {}): RawListing {
  return {
    platformId: "1",
    title: "테스트 매물",
    url: "https://example.com/1",
    address: "서울 강남구 테헤란로 1",
    lat: 37.5,
    lng: 127.03,
    region: "강남구",
    price: { amount: 350_000, unit: "week" },
    ...over,
  };
}

test("좌표가 있으면 그대로 쓰고 월환산을 채운다", async () => {
  const out = await normalize("samsamm2", rawWithCoords(), FETCHED);
  assert.ok(out);
  assert.equal(out.id, "samsamm2:1");
  assert.equal(out.location.lat, 37.5);
  assert.equal(out.location.lng, 127.03);
  assert.equal(out.location.region, "강남구");
  assert.equal(out.price.currency, "KRW"); // currency 생략 시 기본값
  assert.equal(out.monthlyPrice, 1_520_000); // 350000/7*30.4 반올림
  assert.equal(out.fetchedAt, FETCHED);
});

test("images 미지정 시 빈 배열로 정규화", async () => {
  const out = await normalize("samsamm2", rawWithCoords({ images: undefined }), FETCHED);
  assert.ok(out);
  assert.deepEqual(out.images, []);
});

test("extraCosts/areaM2/rooms 등 선택 필드를 보존", async () => {
  const out = await normalize(
    "samsamm2",
    rawWithCoords({ extraCosts: { maintenanceFee: 90_000 }, areaM2: 46, rooms: 1 }),
    FETCHED,
  );
  assert.ok(out);
  assert.deepEqual(out.extraCosts, { maintenanceFee: 90_000 });
  assert.equal(out.areaM2, 46);
  assert.equal(out.rooms, 1);
});

test("lat 만 있고 lng 가 없으면 좌표 직접경로를 타지 않는다(보류 또는 지오코딩)", async () => {
  // lng 누락 → geocode 경로. 키가 없으면 throw 하므로, throttle 로 호출 여부만 확인.
  let geocodeAttempted = false;
  const raw = rawWithCoords({ lat: 37.5, lng: undefined });
  await normalize("samsamm2", raw, FETCHED, {
    throttle: async () => {
      geocodeAttempted = true;
    },
  }).catch(() => {
    /* 키 없으면 geocode 가 throw — 경로 진입 자체가 검증 대상 */
  });
  assert.equal(geocodeAttempted, true);
});
