// JSON 파일 저장 유틸 (서버 전용)
// 크롤링한 매물을 플랫폼별 JSON 파일(<web>/data/<platform>.json)로 읽고 쓴다.
// node:fs 를 쓰므로 서버 컴포넌트·라우트 핸들러·스크립트에서만 사용한다.

import { promises as fs } from "node:fs";
import path from "node:path";
import type { Listing, Platform } from "./types";
import { PLATFORMS } from "./types";

/** 저장 위치: <web>/data (npm 명령은 web/ 에서 실행하므로 cwd 기준) */
const DATA_DIR = path.join(process.cwd(), "data");

function fileFor(platform: Platform): string {
  return path.join(DATA_DIR, `${platform}.json`);
}

async function ensureDataDir(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

/** 특정 플랫폼의 매물 목록을 읽는다. 파일이 없으면 빈 배열. */
export async function readListings(platform: Platform): Promise<Listing[]> {
  try {
    const raw = await fs.readFile(fileFor(platform), "utf-8");
    return JSON.parse(raw) as Listing[];
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw err;
  }
}

/** 특정 플랫폼의 매물 목록을 저장한다 (전체 덮어쓰기). */
export async function writeListings(
  platform: Platform,
  listings: Listing[],
): Promise<void> {
  await ensureDataDir();
  await fs.writeFile(fileFor(platform), JSON.stringify(listings, null, 2), "utf-8");
}

/** 모든 플랫폼의 매물을 합쳐서 읽는다 (지도·비교 화면용). */
export async function readAllListings(): Promise<Listing[]> {
  const lists = await Promise.all(PLATFORMS.map(readListings));
  return lists.flat();
}
