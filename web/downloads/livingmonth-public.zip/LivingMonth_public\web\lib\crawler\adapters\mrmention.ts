// 미스터멘션 어댑터 — https://www.mrmention.co.kr/v2/search (DOM 스크래핑)
// robots.txt 는 메인 도메인의 /api/ 만 막고, 검색 결과 페이지(/v2/search)는 허용.
// 카드에 6박/14박/29박 가격이 표기되며, "29박 = 한 달" 가격을 그대로 월(month) 단가로 쓴다.
// 좌표가 없어 주소는 카카오 지오코딩으로 변환(normalize 단계).

import { chromium } from "playwright";
import type { CrawlAdapter, CrawlContext, RawListing } from "../types";

export const BASE_URL = "https://www.mrmention.co.kr";
const SEARCH_URL = `${BASE_URL}/v2/search`;
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

const MAX_SCROLL = Number(process.env.MRMENTION_MAX_SCROLL ?? 4);

// 카드에서 뽑아오는 원시 형태 (브라우저 컨텍스트에서 평탄 표현식으로 추출)
interface ScrapedCard {
  id: string;
  title: string;
  area: string; // "서울 서대문구 신촌동"
  monthly: number; // 29박 가격(할인가 우선)
  img: string;
}

export const mrmentionAdapter: CrawlAdapter = {
  platform: "mrmention",
  async fetch(ctx: CrawlContext): Promise<RawListing[]> {
    const browser = await chromium.launch({ headless: true });
    try {
      const page = await browser.newPage({ userAgent: UA, locale: "ko-KR" } as never);
      ctx.log("미스터멘션: 검색 페이지 로드");
      await page.goto(SEARCH_URL, { waitUntil: "domcontentloaded", timeout: 45000 });
      // 매물 카드가 렌더될 때까지 대기 (광고/트래킹 때문에 networkidle 은 불안정)
      await page
        .waitForSelector('a[href*="/v2/accommodation/"]', { timeout: 20000 })
        .catch(() => ctx.log("미스터멘션: 카드 셀렉터 대기 타임아웃(계속 진행)"));
      await page.waitForTimeout(1500);

      // 무한 스크롤로 추가 매물 로드
      for (let i = 0; i < MAX_SCROLL; i++) {
        await page.mouse.wheel(0, 4000);
        await ctx.throttle();
      }

      // 카드별 필드 추출 — 함수 정의 없는 평탄 표현식(esbuild __name 주입 회피)
      const cards = (await page.evaluate(`
        (() => {
          const anchors = Array.from(document.querySelectorAll('a[href*="/v2/accommodation/"]'));
          const seen = new Set();
          const out = [];
          for (const a of anchors) {
            const m = (a.getAttribute('href')||'').match(/accommodation\\/(\\d+)/);
            if (!m) continue;
            const id = m[1];
            if (seen.has(id)) continue;
            seen.add(id);
            const card = a.closest('li') || a.closest('div');
            if (!card) continue;
            const areaEl = card.querySelector('[class*="AccommodationCard_area"]');
            // 주의: room_thum(썸네일/뱃지)과 구분 — 제목은 room_tit
            const titleEl = card.querySelector('[class*="AccommodationCard_room_tit"]');
            const area = (areaEl && areaEl.textContent) || '';
            const title = (titleEl && titleEl.textContent) || '';
            const imgEl = card.querySelector('img');
            const img = (imgEl && imgEl.getAttribute('src')) || '';
            // 29박 블록의 최종 가격(<b>) 찾기: Price_day 텍스트가 '29박'인 컨테이너
            let monthly = 0;
            const days = card.querySelectorAll('[class*="Price_day"]');
            for (const d of days) {
              if ((d.textContent||'').indexOf('29박') >= 0) {
                const box = d.parentElement;
                const b = box && box.querySelector('b');
                const s = box && box.querySelector('s');
                const pick = (b && b.textContent) || (s && s.textContent) || '';
                monthly = Number(pick.replace(/[^0-9]/g,'')) || 0;
                break;
              }
            }
            out.push({ id, title: title.trim(), area: area.trim().replace(/\\s+/g,' '), monthly, img });
          }
          return out;
        })()
      `)) as ScrapedCard[];

      ctx.log(`미스터멘션: 카드 ${cards.length}건 추출`);

      const raws: RawListing[] = [];
      for (const c of cards) {
        if (!c.monthly || !c.area) continue; // 29박가/주소 없으면 스킵
        raws.push({
          platformId: c.id,
          title: c.title || c.area,
          url: `${BASE_URL}/v2/accommodation/${c.id}`,
          address: c.area, // 지오코딩 입력
          region: c.area.split(" ")[1], // 시/구 추정
          price: { amount: c.monthly, unit: "month" }, // 29박 ≈ 한 달
          images: c.img ? [c.img] : [],
        });
      }
      ctx.log(`미스터멘션: 유효 매물 ${raws.length}건`);
      return raws;
    } finally {
      await browser.close();
    }
  },
};
