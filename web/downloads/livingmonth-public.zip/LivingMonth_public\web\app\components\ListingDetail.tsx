"use client";

import type { Listing } from "@/lib/types";
import { PLATFORM_LABELS } from "@/lib/types";
import { formatMonthlyPrice } from "@/lib/price";

interface ListingDetailProps {
  listing: Listing;
  onClose: () => void;
}

const EXTRA_LABELS: Record<string, string> = {
  cleaningFee: "청소비",
  deposit: "보증금",
  utilities: "공과금",
  maintenanceFee: "관리비",
};

export default function ListingDetail({ listing, onClose }: ListingDetailProps) {
  const extras = Object.entries(listing.extraCosts ?? {}).filter(([, v]) => v != null);

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: "#fff",
        zIndex: 10,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "12px 16px",
          borderBottom: "1px solid #eee",
        }}
      >
        <button
          onClick={onClose}
          style={{
            border: "none",
            background: "transparent",
            fontSize: 18,
            cursor: "pointer",
          }}
          aria-label="뒤로"
        >
          ←
        </button>
        <strong style={{ fontSize: 14 }}>{PLATFORM_LABELS[listing.platform]}</strong>
      </div>

      <div style={{ overflowY: "auto", padding: 16 }}>
        {/* 사진 갤러리 */}
        {listing.images.length > 0 ? (
          <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
            {listing.images.map((src, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                key={i}
                src={src}
                alt={`${listing.title} 사진 ${i + 1}`}
                style={{ height: 140, borderRadius: 8, flexShrink: 0 }}
              />
            ))}
          </div>
        ) : (
          <div
            style={{
              height: 120,
              background: "#f4f4f5",
              borderRadius: 8,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#6b7280",
              fontSize: 13,
              marginBottom: 12,
            }}
          >
            사진 없음
          </div>
        )}

        <h2 style={{ margin: "0 0 6px", fontSize: 18 }}>{listing.title}</h2>
        <div style={{ fontSize: 22, fontWeight: 800, color: "#2563eb" }}>
          {formatMonthlyPrice(listing.monthlyPrice)}
        </div>
        <p style={{ fontSize: 12, color: "#4b5563", margin: "2px 0 14px" }}>
          원가격 {listing.price.amount.toLocaleString("ko-KR")}원/
          {listing.price.unit === "night" ? "박" : listing.price.unit === "week" ? "주" : "월"}{" "}
          기준 환산
        </p>

        <dl style={{ display: "grid", gridTemplateColumns: "80px 1fr", rowGap: 8, fontSize: 13 }}>
          <dt style={{ color: "#4b5563" }}>주소</dt>
          <dd style={{ margin: 0 }}>{listing.location.address}</dd>
          {listing.areaM2 != null && (
            <>
              <dt style={{ color: "#4b5563" }}>면적</dt>
              <dd style={{ margin: 0 }}>{listing.areaM2}㎡</dd>
            </>
          )}
          {listing.rooms != null && (
            <>
              <dt style={{ color: "#4b5563" }}>방</dt>
              <dd style={{ margin: 0 }}>{listing.rooms}개</dd>
            </>
          )}
        </dl>

        {/* 추가비용 */}
        {extras.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <h3 style={{ fontSize: 13, color: "#374151", margin: "0 0 6px" }}>추가비용</h3>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, fontSize: 13 }}>
              {extras.map(([k, v]) => (
                <li key={k} style={{ display: "flex", justifyContent: "space-between", padding: "3px 0" }}>
                  <span style={{ color: "#4b5563" }}>{EXTRA_LABELS[k] ?? k}</span>
                  <span>{Number(v).toLocaleString("ko-KR")}원</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {listing.amenities && listing.amenities.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <h3 style={{ fontSize: 13, color: "#374151", margin: "0 0 6px" }}>편의시설</h3>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {listing.amenities.map((a) => (
                <span
                  key={a}
                  style={{
                    fontSize: 12,
                    background: "#f0f0f0",
                    borderRadius: 4,
                    padding: "2px 8px",
                  }}
                >
                  {a}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      <div style={{ padding: 16, borderTop: "1px solid #eee" }}>
        <a
          href={listing.url}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "block",
            textAlign: "center",
            padding: "12px",
            background: "#2563eb",
            color: "#fff",
            borderRadius: 8,
            textDecoration: "none",
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          {PLATFORM_LABELS[listing.platform]}에서 예약하기 ↗
        </a>
      </div>
    </div>
  );
}
