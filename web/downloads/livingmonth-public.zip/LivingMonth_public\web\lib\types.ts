// 공통 매물 데이터 모델 (PRD 2.4 "정규화 매물" 스케치 기준)
// 4개 플랫폼(삼삼엠투·미스터멘션·에어비앤비·네이버 단기임대)의 매물을 하나의 형태로
// 정규화해, 카카오맵 위에서 "한 달 기준 가격"으로 비교하기 위한 타입 정의.

/** 매물을 가져온 원 플랫폼 (PRD: source) */
export type Platform = "samsamm2" | "mrmention" | "airbnb" | "naver";

/** 지원 플랫폼 목록 (순회·기본값의 단일 출처) */
export const PLATFORMS: Platform[] = ["samsamm2", "mrmention", "airbnb", "naver"];

/** 플랫폼 표시 이름 (한글) */
export const PLATFORM_LABELS: Record<Platform, string> = {
  samsamm2: "삼삼엠투",
  mrmention: "미스터멘션",
  airbnb: "에어비앤비",
  naver: "네이버 단기임대",
};

/** 원 플랫폼이 표기하는 가격의 기준 단위 (1박 / 1주 / 1개월). PRD: priceUnitOriginal */
export type PriceUnit = "night" | "week" | "month";

/** 좌표 + 주소 (카카오맵 표시·지오코딩 결과) */
export interface GeoLocation {
  /** 주소 원문 (도로명/지번) */
  address: string;
  /** 위도 */
  lat: number;
  /** 경도 */
  lng: number;
  /** 시/구/동 등 상위 지역 (지역 필터용) */
  region?: string;
}

/** 원 플랫폼에 표기된 가격 (월 환산 전) */
export interface SourcePrice {
  /** 금액 */
  amount: number;
  /** 기준 단위 (PRD: priceUnitOriginal) */
  unit: PriceUnit;
  /** 통화 코드 (1단계 KRW 고정) */
  currency: string;
}

/** 월세와 별도로 표기하는 주요 추가비용 (FR-4). 추출 가능한 범위에서 채운다. */
export interface ExtraCosts {
  /** 청소비 */
  cleaningFee?: number;
  /** 보증금 */
  deposit?: number;
  /** 공과금 */
  utilities?: number;
  /** 관리비 */
  maintenanceFee?: number;
}

/** 여러 플랫폼 매물을 통합한 공통 매물 타입 */
export interface Listing {
  /** 전역 고유 ID = `${platform}:${platformId}` */
  id: string;
  /** 원 플랫폼 (PRD: source) */
  platform: Platform;
  /** 원 플랫폼 내 매물 ID */
  platformId: string;
  /** 매물 제목 */
  title: string;
  /** 원 플랫폼 상세 페이지 링크 (예약·결제는 이 딥링크로 연결. PRD: sourceUrl) */
  url: string;

  /** 위치 (지도 표시·필터) */
  location: GeoLocation;
  /** 원 가격 (정규화 전) */
  price: SourcePrice;
  /** ★ 한 달 기준 환산 월세 (KRW). 플랫폼 간 비교의 기준값. */
  monthlyPrice: number;
  /** 월세 외 추가비용 (각각 표기, FR-4) */
  extraCosts?: ExtraCosts;

  /** 내부 사진 갤러리 URL 목록 (FR-3). images[0] 을 대표 이미지로 사용. */
  images: string[];
  /** 편의시설 목록 */
  amenities?: string[];
  /** 면적 (㎡, PRD: area) */
  areaM2?: number;
  /** 방 개수 */
  rooms?: number;
  /** 최소 숙박일 */
  minStayDays?: number;

  /** 수집 시각 (ISO 8601, PRD: collectedAt) */
  fetchedAt: string;
}

/** 전역 고유 ID 생성: `${platform}:${platformId}` */
export function makeListingId(platform: Platform, platformId: string): string {
  return `${platform}:${platformId}`;
}

/** 대표 이미지(썸네일) — images 의 첫 장. 없으면 undefined. */
export function thumbnailOf(listing: Listing): string | undefined {
  return listing.images[0];
}
