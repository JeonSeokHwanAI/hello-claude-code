// 크롤러 공통 타입
// 각 플랫폼 어댑터는 CrawlAdapter 를 구현해 RawListing 배열을 반환한다.
// RawListing(원시) → 정규화(지오코딩·월환산) → Listing(공통 모델) 으로 변환된다.

import type { Page } from "playwright";
import type { ExtraCosts, Platform, PriceUnit } from "../types";

/** 어댑터가 추출한 원시 매물 (좌표·월환산 전) */
export interface RawListing {
  /** 원 플랫폼 내 매물 ID */
  platformId: string;
  /** 매물 제목 */
  title: string;
  /** 원 플랫폼 상세 페이지 링크 */
  url: string;
  /** 지오코딩 입력용 주소/장소명 */
  address: string;
  /** 좌표 (플랫폼이 직접 제공 시). 있으면 지오코딩을 생략한다. */
  lat?: number;
  lng?: number;
  /** 지역(시/구/동) — 좌표 직접 제공 시 region 채움용 */
  region?: string;
  /** 원 가격 (currency 생략 시 KRW) */
  price: { amount: number; unit: PriceUnit; currency?: string };
  /** 사진 URL 목록 */
  images?: string[];
  /** 편의시설 */
  amenities?: string[];
  /** 면적(㎡) */
  areaM2?: number;
  /** 방 개수 */
  rooms?: number;
  /** 최소 숙박일 */
  minStayDays?: number;
  /** 추가비용(청소비·보증금·공과금·관리비) */
  extraCosts?: ExtraCosts;
}

/** 어댑터 실행 컨텍스트 (러너가 주입) */
export interface CrawlContext {
  /** 진행 로그 출력 */
  log: (msg: string) => void;
  /** 요청 사이 지연 (매너 크롤링) */
  throttle: () => Promise<void>;
  /** Playwright 페이지 (브라우저 기동 시 주입; 미기동 시 undefined) */
  page?: Page;
}

/** 플랫폼별 크롤러 어댑터 */
export interface CrawlAdapter {
  /** 대상 플랫폼 */
  platform: Platform;
  /** 원 플랫폼에서 매물을 수집해 RawListing 배열로 반환 */
  fetch(ctx: CrawlContext): Promise<RawListing[]>;
}
