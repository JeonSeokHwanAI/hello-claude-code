// GET /api/listings — 매물 검색 API
// 쿼리 파라미터:
//   platform : 콤마구분 플랫폼 필터 (samsamm2,mrmention,airbnb,naver)
//   minPrice / maxPrice : 한 달 기준 가격(monthlyPrice) 범위
//   region   : 지역 문자열 부분일치 (location.region / address)
//   bbox     : 지도 영역 "minLng,minLat,maxLng,maxLat" 내 매물만
//   sort     : "price"(기본, 월가격 오름차순) | "area"(면적 내림차순) | "latest"(수집 최신순)
//   limit    : 최대 건수

import { NextResponse, type NextRequest } from "next/server";
import { readAllListings } from "@/lib/storage";
import { PLATFORMS, type Listing, type Platform } from "@/lib/types";

// 매 요청마다 JSON 파일을 새로 읽도록 정적 최적화 비활성화
export const dynamic = "force-dynamic";

function parseNumber(value: string | null): number | null {
  if (value == null || value.trim() === "") return null;
  const n = Number(value);
  return Number.isNaN(n) ? null : n;
}

export async function GET(req: NextRequest): Promise<NextResponse> {
  const sp = req.nextUrl.searchParams;
  let listings: Listing[] = await readAllListings();

  // 플랫폼 필터
  const platforms = sp
    .get("platform")
    ?.split(",")
    .map((p) => p.trim())
    .filter((p): p is Platform => (PLATFORMS as string[]).includes(p));
  if (platforms && platforms.length > 0) {
    listings = listings.filter((l) => platforms.includes(l.platform));
  }

  // 가격(월 환산) 범위
  const minPrice = parseNumber(sp.get("minPrice"));
  const maxPrice = parseNumber(sp.get("maxPrice"));
  if (minPrice != null) listings = listings.filter((l) => l.monthlyPrice >= minPrice);
  if (maxPrice != null) listings = listings.filter((l) => l.monthlyPrice <= maxPrice);

  // 지역 부분일치
  const region = sp.get("region")?.trim();
  if (region) {
    listings = listings.filter(
      (l) => l.location.region?.includes(region) || l.location.address.includes(region),
    );
  }

  // 지도 영역(bbox) 필터: minLng,minLat,maxLng,maxLat
  const bbox = sp.get("bbox");
  if (bbox) {
    const parts = bbox.split(",").map(Number);
    if (parts.length === 4 && parts.every((n) => !Number.isNaN(n))) {
      const [minLng, minLat, maxLng, maxLat] = parts;
      listings = listings.filter(
        (l) =>
          l.location.lng >= minLng &&
          l.location.lng <= maxLng &&
          l.location.lat >= minLat &&
          l.location.lat <= maxLat,
      );
    }
  }

  // 정렬
  const sort = sp.get("sort") ?? "price";
  listings.sort((a, b) => {
    if (sort === "area") return (b.areaM2 ?? 0) - (a.areaM2 ?? 0);
    if (sort === "latest") return b.fetchedAt.localeCompare(a.fetchedAt);
    return a.monthlyPrice - b.monthlyPrice; // price(기본)
  });

  const total = listings.length;
  const limit = parseNumber(sp.get("limit"));
  if (limit != null) listings = listings.slice(0, limit);

  return NextResponse.json({ total, count: listings.length, listings });
}
