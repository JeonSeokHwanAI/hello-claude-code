# LivingMonth 진행 상황

> 이 파일은 진행 기록용입니다. (CLAUDE.md에는 넣지 않습니다.)

## 최종 업데이트: 2026-05-29

- ✅ **PRD 완성** — `docs/20.working/LivingMonth-PRD.md` (1.개요~5.사용자환경설정).
- ✅ **4.1 프로젝트 셋업 완료** — Next.js 16 + React 19 + TypeScript + Tailwind v4.
- ✅ **폴더 재구성** — Next.js 앱 일체를 `web/`로 이동. root에는 문서 워크스페이스(`docs/`·`CLAUDE.md`·`.claude/`)만. npm 명령은 `web/`에서 실행.
- ✅ **카카오 키** — `web/.env`에 `NEXT_PUBLIC_KAKAO_JS_KEY`(지도), `KAKAO_REST_KEY`(지오코딩) 저장.
- ✅ **지도 미리보기 화면** — `web/app/components/KakaoMap.tsx`, `web/app/page.tsx` (강남역 중심 + 마커).
- ✅ **4.2 데이터 모델 & 저장 완료** (PRD 2.4·FR-4 기준)
  - `web/lib/types.ts` — 공통 매물 타입 `Listing`(+ `SourcePrice`/`GeoLocation`/`ExtraCosts`/`images[]`/`amenities[]`), `Platform`·`PLATFORMS`·`PLATFORM_LABELS`, `makeListingId()`·`thumbnailOf()`.
  - `web/lib/price/index.ts` — 월 환산 유틸(`toMonthlyPrice`/`monthlyPriceOf`/`withMonthlyPrice`/`formatMonthlyPrice`, `DAYS_PER_MONTH=30.4`).
  - `web/lib/storage.ts` — 플랫폼별 JSON 저장(`web/data/<platform>.json`).
- ✅ **4.3 크롤러 프레임워크 완료 / 어댑터 스캐폴드** (`tsc --noEmit` 통과, `npm run crawl` 동작)
  - `web/lib/geocode/index.ts` — 카카오 로컬 API 지오코딩(`geocode()`: 주소→실패시 키워드 폴백).
  - `web/lib/crawler/` — `types.ts`(CrawlAdapter/RawListing/CrawlContext), `normalize.ts`(raw→지오코딩→월환산→Listing), `runner.ts`(`runAdapter`/`runAll`: 정규화·중복제거·저장), `util.ts`(로거·throttle).
  - `web/lib/crawler/adapters/` — **삼삼엠투: 내부 API(`/v1/rooms`) 실구현 완료(실측 50건, 좌표 직접 사용, 주→월 환산).** 미스터멘션·에어비앤비·네이버는 스캐폴드(`[]` 반환).
  - `web/scripts/crawl.ts` + `npm run crawl`(tsx). 의존성 `tsx`·`playwright` 추가(브라우저 바이너리는 미설치).
  - 주의: tsx는 CJS 출력이라 스크립트의 top-level await 금지 → `main()` async 래퍼 사용.
- ⏳ **블로커**: 카카오 JS SDK 사이트 도메인 `http://localhost:3000` 등록 미완료 → 지도 `401 domain mismatched`.
- ✅ Playwright Chromium 설치 완료. 정찰 결과: 미스터멘션 robots는 `/api/` 금지(→DOM), 네이버 부동산은 안티봇/ToS 민감(→보류 검토).
- ✅ **삼삼엠투 어댑터 실구현** — 내부 API(`web.33m2.co.kr/v1/rooms`), 좌표 직접 사용, 주→월 환산, 실측 50건.
- ✅ **결정**: 네이버 1단계 제외(스캐폴드 유지). 미스터멘션·에어비앤비는 후순위.
- ✅ **4.4 API 완료** — `web/app/api/listings/route.ts`: `GET /api/listings` (platform·minPrice/maxPrice·region·sort·limit + bbox). dev 서버 실응답 검증.
- ✅ **4.5 프론트 완료** — `web/app/page.tsx` + 컴포넌트: `SearchForm`(지역·가격·플랫폼·정렬), `KakaoMap`(MarkerClusterer·idle→bbox 동기화·마커↔목록 양방향), `ListingList`, `ListingDetail`(사진갤러리·추가비용·딥링크). tsc·build 통과. 삼삼엠투 50건 표시.
- ✅ **삼삼엠투 이미지 연동** — CDN(`d1pviohoskiraj.cloudfront.net`) 호스트 확정, 어댑터가 `images` 채움. 말풍선·목록 썸네일·상세 갤러리에 표시.
- ✅ **UI 다듬기** — 클러스터 숫자 가독성(검정+흰 외곽선), 보조 텍스트 진한 회색, 다크모드 흰글씨 묻힘 수정, 말풍선 공용 1개로 정리(클릭/지도클릭 시 닫힘).
- ✅ **4.6 마무리** — `npm test`(node:test+tsx, 11건 통과: 월환산·정규화), `web/README.md` 작성. `tsc`/`build`/`test` 전부 PASS. `data/*.json` gitignore 추가.
- ✅ **네이버 API 재정찰** — 내부 API(`/api/articles`, `/api/articles/clusters`) 존재하나 인증토큰 필수·429 rate limit·단기임대 필터 부재·ToS 민감 → 1단계 제외 유지 확정.
- ✅ **미스터멘션 어댑터 실구현** — DOM 스크래핑(`/v2/search`, 카드 셀렉터 `AccommodationCard_room_tit`/`_area`), 29박→월 가격, 카카오 지오코딩, CDN 이미지. 실측 20건.
- ✅ **에어비앤비 어댑터 실구현** — DOM 스크래핑(월 단위 검색, `[data-testid=listing-card-name]`/`/월` 가격), 상세페이지 HTML에서 정확 좌표(`"lat"/"lng"`) 추출(지역당 `AIRBNB_DETAIL_LIMIT`건). 실측 18건(서울).
- ✅ **4개 출처 통합 크롤** — `npm run crawl` 88건(삼삼엠투50·미스터멘션20·에어비앤비18·네이버0). API가 플랫폼별 합산 반환 확인. tsc·test(11) 통과.
- 주의: Playwright `page.evaluate`에 함수 전달 시 tsx/esbuild가 `__name` 주입 → 브라우저서 ReferenceError. **문자열 평탄 표현식 `(() => {...})()`** 으로 우회.
- ⬜ **다음 단계**: 어댑터 수집량 확대(페이지네이션·지역 확장), 미스터멘션/에어비앤비 좌표·면적 보강, 카카오 도메인 등록.
- ❗ **남은 블로커**: 카카오 콘솔 도메인(`http://localhost:3000`) 등록 — 등록 전엔 지도 회색+안내문, 목록·검색·상세는 정상.
