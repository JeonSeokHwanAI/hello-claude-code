"use client";

import { useState } from "react";
import { PLATFORMS, PLATFORM_LABELS, type Platform } from "@/lib/types";

export interface SearchFilters {
  region: string;
  minPrice: string;
  maxPrice: string;
  platforms: Platform[];
  sort: "price" | "area" | "latest";
}

export const DEFAULT_FILTERS: SearchFilters = {
  region: "",
  minPrice: "",
  maxPrice: "",
  platforms: [...PLATFORMS],
  sort: "price",
};

interface SearchFormProps {
  value: SearchFilters;
  onChange: (next: SearchFilters) => void;
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "6px 8px",
  border: "1px solid #9ca3af",
  borderRadius: 6,
  fontSize: 13,
  color: "#111827",
  boxSizing: "border-box",
};

export default function SearchForm({ value, onChange }: SearchFormProps) {
  const [draft, setDraft] = useState(value);

  function togglePlatform(p: Platform) {
    const has = draft.platforms.includes(p);
    setDraft({
      ...draft,
      platforms: has ? draft.platforms.filter((x) => x !== p) : [...draft.platforms, p],
    });
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onChange(draft);
      }}
      style={{ padding: 16, display: "flex", flexDirection: "column", gap: 10 }}
    >
      <input
        style={inputStyle}
        placeholder="지역 (예: 강남, 부산)"
        value={draft.region}
        onChange={(e) => setDraft({ ...draft, region: e.target.value })}
      />

      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <input
          style={inputStyle}
          type="number"
          placeholder="최소 월가격"
          value={draft.minPrice}
          onChange={(e) => setDraft({ ...draft, minPrice: e.target.value })}
        />
        <span style={{ color: "#374151" }}>~</span>
        <input
          style={inputStyle}
          type="number"
          placeholder="최대 월가격"
          value={draft.maxPrice}
          onChange={(e) => setDraft({ ...draft, maxPrice: e.target.value })}
        />
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {PLATFORMS.map((p) => (
          <label
            key={p}
            style={{ fontSize: 12, color: "#374151", display: "flex", gap: 4, alignItems: "center" }}
          >
            <input
              type="checkbox"
              checked={draft.platforms.includes(p)}
              onChange={() => togglePlatform(p)}
            />
            {PLATFORM_LABELS[p]}
          </label>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <select
          style={{ ...inputStyle, width: "auto", flex: 1 }}
          value={draft.sort}
          onChange={(e) =>
            setDraft({ ...draft, sort: e.target.value as SearchFilters["sort"] })
          }
        >
          <option value="price">월가격 낮은순</option>
          <option value="area">면적 넓은순</option>
          <option value="latest">최신 수집순</option>
        </select>
        <button
          type="submit"
          style={{
            padding: "6px 16px",
            background: "#2563eb",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            fontSize: 13,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          검색
        </button>
      </div>
    </form>
  );
}
