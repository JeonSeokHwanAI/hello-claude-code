# LivingMonth (공개 배포본 · 슬림)

여러 한달살기 플랫폼(삼삼엠투·미스터멘션·에어비앤비)의 매물을 모아,
카카오맵 위에서 **"한 달 기준 가격"으로 비교**하는 메타검색 서비스.

> **슬림 배포본**입니다. 설치로 다시 만들 수 있는 파일은 제외했습니다.
> 제외: `web/node_modules`, `web/.next`, `web/next-env.d.ts`, 비밀키(`web/.env`)
> 포함: 전체 소스코드, 설정, 샘플 매물 데이터(`web/data/*.json`), 문서(`docs/`), 설치 스킬

## 빠른 시작

이 폴더를 Claude Code 로 열고 **`/setup`** 스킬을 호출하면 설치를 안내합니다.
수동으로 하려면:

```bash
cd web
npm install                       # 의존성 설치 (node_modules 재생성)
cp .env.example .env              # 카카오 키 입력 (PowerShell: Copy-Item)
npm run dev                       # http://localhost:3000
```

- 카카오 키 발급: https://developers.kakao.com
- 지도가 안 뜨면 콘솔에 도메인 `http://localhost:3000` 등록.

## 폴더 구조

```
LivingMonth_public/
  CLAUDE.md                          # 프로젝트 가이드
  docs/                              # 기획/PRD/진행 기록
  .claude/skills/setup/              # 설치 자동화 스킬
  web/                               # Next.js 앱 (소스만, 재생성물 제외)
    app/  lib/  scripts/  public/  data/
    package.json  package-lock.json  .env.example  ...
```

## 명령 요약 (web/ 에서)

| 명령 | 설명 |
|---|---|
| `npm install` | 의존성 설치 |
| `npm run dev` | 개발 서버 |
| `npm run build` | 프로덕션 빌드 |
| `npm run crawl` | 매물 크롤링 |
| `npm test` | 단위 테스트 |

자세한 설치 절차는 [.claude/skills/setup/SKILL.md](.claude/skills/setup/SKILL.md) 참고.
