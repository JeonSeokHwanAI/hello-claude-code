// 크롤 실행 진입점 — `npm run crawl`
// 모든 어댑터를 순차 실행해 매물을 수집·정규화·저장한다.
// web/.env 의 KAKAO_REST_KEY 를 사용한다 (지오코딩).

import { ALL_ADAPTERS } from "../lib/crawler/adapters";
import { runAll } from "../lib/crawler/runner";
import { createLogger, makeThrottle } from "../lib/crawler/util";

// web/.env 로드 (cwd = web). Node 20.12+/22 의 내장 로더 사용.
(process as NodeJS.Process & { loadEnvFile?: (path?: string) => void }).loadEnvFile?.();

const log = createLogger("crawl");
const delayMs = Number(process.env.CRAWL_DELAY_MS ?? 1000);

async function main(): Promise<void> {
  const listings = await runAll(ALL_ADAPTERS, {
    log,
    throttle: makeThrottle(delayMs),
  });
  log(`완료: 총 ${listings.length}건`);
}

void main();
