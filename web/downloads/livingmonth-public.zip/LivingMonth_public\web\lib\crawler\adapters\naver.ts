// 네이버 부동산 단기임대 어댑터 — https://new.land.naver.com
// ⚠️ 라이브 셀렉터 미구현(스캐폴드). 구현 시 robots.txt·이용약관 확인 + 요청 간 throttle 준수.
// TODO: ctx.page 로 목록/상세 DOM 파싱, 또는 비공개 내부 JSON API 활용(우선).

import type { CrawlAdapter, CrawlContext, RawListing } from "../types";

export const BASE_URL = "https://new.land.naver.com";

export const naverAdapter: CrawlAdapter = {
  platform: "naver",
  async fetch(ctx: CrawlContext): Promise<RawListing[]> {
    ctx.log("네이버 단기임대: 라이브 셀렉터 미구현 (스캐폴드)");
    return [];
  },
};
