# LivingMonth

여러 한달살기 플랫폼(삼삼엠투·미스터멘션·에어비앤비·네이버 단기임대)의 매물을 모아, 카카오맵 위에서 **"한 달 기준 가격"으로 비교**해주는 메타검색 서비스. 매물을 직접 중개하지 않고 비교·탐색에 집중하며, 예약·결제는 원 플랫폼으로 연결만 한다.

## 폴더 구조 (★ 가장 중요)

- **root = 문서 워크스페이스**: `docs/`, `CLAUDE.md`, `.claude/`, `README.md`만 둔다.
- **`web/` = 실제 코드(Next.js 앱)**: 앱·설정·의존성·`.env`는 전부 `web/` 안에 있다.

```
LivingMonth/
  CLAUDE.md
  README.md
  .claude/
  docs/
    10.input/      ← 외부에서 받은 원본 자료 (수정하지 않음)
    20.working/    ← 작업 중인 초안·중간 산출물 (진행 기록 PROGRESS.md 포함)
    30.output/     ← 최종 결과물 (공유·배포용)
    90.reference/  ← 참고 문서·링크·캡처
  web/             ← Next.js 앱 (npm·dev 서버는 모두 여기서 실행)
    app/  lib/  public/  data/
    package.json  next.config.ts  tsconfig.json  .env  ...
```

## ⚠️ 파일 생성 규칙 (Claude가 반드시 지킬 것)

- **root에는 새 파일/폴더를 만들지 않는다.** 코드·설정·의존성·생성물은 전부 `web/` 안에서 처리한다.
  - `npm install`·`npm run *`·스캐폴딩 등 **모든 명령은 `web/`에서 실행**한다 (root에서 실행 금지 — root에 `node_modules`/`package.json` 등이 생기지 않게).
  - 새 코드 파일은 `web/app`, `web/lib` 등 적절한 하위에 둔다.
- **문서만 root의 `docs/` 체계에 둔다.** (성격에 맞는 `10/20/30/90` 폴더 선택)

## 작업 위치

- **개발 정본: `E:\WorkSpace\LivingMonth` (로컬 NTFS)** — 코드 실행은 `E:\WorkSpace\LivingMonth\web`.

## 기술 스택

- Next.js(App Router)+TS / Tailwind v4 / 카카오맵 JS SDK / 카카오 로컬 REST API(지오코딩) / Playwright(크롤링) / JSON 파일 저장(`web/data/`).

## 작업 규칙 (Claude가 따라야 할 규칙)

### PRD 작성 규칙
- **워크플로우**: 사용자가 질문하면 **Plan Mode**로 답한다(바로 파일을 수정하지 않음). 답변한 뒤 **PRD에 저장할지 사용자에게 물어본다.**
- **단일 문서**: PRD 관련 정보는 모두 **PRD 하나의 문서**에 넣는다. 별도 파일로 분리하지 않는다.
- **PRD 구성(필수 항목)**:
  1. PRD 개요
  2. 요구사항
  3. 기술적 요소
  4. 사용자 환경설정
  5. Todo list (체크박스 `- [ ]` 형식)

### Skill 구성 규칙
- 사용자가 생성한 Skill은 반드시 `.claude/skills/{스킬명}/SKILL.md` 형태로 만든다.
  (스킬명 폴더를 만들고 그 아래에 `SKILL.md`를 둔다 — `.claude/skills/SKILL.md` 처럼 평탄하게 두지 않는다)
- Skill에서 사용하는 스크립트는 `.claude/skills/{스킬명}/scripts/` 아래에 둔다.
- Skill이 참고하는 문서·예시·데이터 파일은 `.claude/skills/{스킬명}/references/` 아래에 둔다.

## 자주 쓰는 명령

> 작업 디렉터리: `E:\WorkSpace\LivingMonth\web`

- `npm run dev` — 개발 서버 (http://localhost:3000)
- `npm run build` — 프로덕션 빌드
- `npm run lint` — ESLint

---
이 문서는 Claude가 매 대화 시작 시 자동으로 읽는다.
