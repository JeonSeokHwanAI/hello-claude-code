# 시안 서버 — 시안 페이지를 띄우고, [저장] 누른 값을 파일로 받아 적는다.
#   실행:  python docs/30.output/_시안서버.py
#   주소:  http://localhost:8731/시안-8-1-웹-로그인명단.html
#   받은 값: docs/30.output/선택-8-1.json
import json, os, sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 8731


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def do_POST(self):
        if not self.path.startswith('/save'):
            self.send_error(404)
            return
        n = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(n).decode('utf-8')
        try:
            data = json.loads(body)
        except ValueError:
            self.send_error(400)
            return
        name = data.get('round', '8-1')
        out = os.path.join(HERE, '선택-%s.json' % name)
        with open(out, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print('[saved] %s' % out)
        for k, v in data.items():
            print('   %s = %s' % (k, v))
        sys.stdout.flush()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(b'{"ok":true}')

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    print('mockup server on http://localhost:%d/' % PORT)
    sys.stdout.flush()
    ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
