---
name: make-brand-asset
description: Interactively interview the user and then generate a brand-new landing page or one of six marketing artifact types (Instagram Card News deck / Templates 4종 / Karrot Promo / Gallery card stack / A4 print guidebook / Device mockup) by following the templates in LANDING_PROMPT.md. Drives a Q&A flow using AskUserQuestion to gather domain, brand, palette, and copy inputs, then writes a self-contained flat folder whose save location is determined by the host workspace's CLAUDE.md output rules (never hardcoded in the skill). Use when the user wants to start a new brand asset from scratch ("새 랜딩 만들어줘", "카드뉴스 시리즈 시작", "다른 도메인용 브랜드 자산 만들기"), or when they reference LANDING_PROMPT.md and want it applied to a real project.
---

# make-brand-asset

[LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md)에 정의된 7개 골격(랜딩 1 + 마케팅 6)을 **질의응답 인터뷰**로 채워, 해당 골격에 맞는 자기완결적 폴더를 생성하는 스킬입니다.

## When to invoke

- 사용자가 "새 랜딩 만들어줘", "이 도메인용 카드뉴스", "가이드북 만들고 싶다" 등 **새 아티팩트** 생성을 요청할 때
- "LANDING_PROMPT 써서…", "그 프롬프트로…" 등 [LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md)를 명시적으로 참조할 때
- 본 스킬은 도메인부터 새로 정하거나 7개 유형(랜딩·카드뉴스·템플릿·당근·갤러리·PDF·목업) 어느 것이든 **새로 생성**하는 데 쓴다. (워크스페이스에 `make-card-news` 같은 템플릿 재사용 전용 스킬이 따로 있다면, 기존 템플릿 재사용은 그쪽이 더 특화됨.)

## Inputs

원칙적으로 **사용자에게 직접 질문해서** 채웁니다 — 미리 인자로 주지 않아도 됨. 한 번에 모든 걸 묻지 말고 **단계별로** `AskUserQuestion`을 호출.

## Process

### STEP 0 — 사전 컨텍스트 로드

먼저 다음 두 파일을 Read로 로드:

1. [LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md) — 7개 유형의 골격·검증 체크리스트
2. [CLAUDE.md](../../../CLAUDE.md) — 폴더 구조·라운드트립 무결성·핸드오프 절차

### STEP 0.5 — **랜딩 선행 게이트 (필수)**

**부속 마케팅 자산(B~F)은 랜딩이 시각 토큰의 원천이라 랜딩 없이 만들면 팔레트·톤·SVG 무드가 따로 놀게 됩니다.** 따라서:

1. **랜딩이 이미 있는지** 먼저 확인 (CLAUDE.md의 산출물 폴더를 Glob로 탐색):
   - `docs/20.working/*-landing/app.jsx` 또는 `docs/30.output/*-landing/app.jsx` 류의 폴더가 있고
   - 그 안에 `TWEAK_DEFAULTS`와 `PALETTES`가 정의되어 있는지 Read로 확인. (탐색 위치는 CLAUDE.md 산출물 규칙을 따름.)

2. **랜딩이 없는데** 사용자가 유형 B~F(부속 자산)를 요청한 경우 — `AskUserQuestion`으로 다음을 물어 **랜딩 생성을 먼저 권유**:

   ```
   질문: "이 프로젝트에는 아직 랜딩 페이지가 없습니다.
          부속 마케팅 자산은 랜딩의 팔레트·톤을 그대로 가져다 써야
          시각 일관성이 유지됩니다. 어떻게 할까요?"
   header: "Landing 선행"
   options:
     1. 랜딩부터 만들고 이어서 요청한 자산 생성 (권장)
     2. 그래도 부속 자산만 먼저 만들기 (임시 팔레트 사용)
     3. 작업 취소
   ```

3. 사용자가 **옵션 1(권장)**을 고르면:
   - 먼저 유형 A(랜딩)의 인터뷰부터 진행해 랜딩을 완성.
   - 완료 후 자동으로 원래 요청한 부속 자산 인터뷰로 이어감. 이때 컬러 무드·팔레트 키는 **방금 만든 랜딩의 값을 기본으로 채워** 사용자가 매번 다시 입력하지 않아도 되게 함.

4. 사용자가 **옵션 2**를 고르면:
   - 그 자산만 만들되, 사후 안내에서 "랜딩을 만들 때 같은 팔레트로 묶을 수 있도록 [LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md)의 유형 A를 참고하세요"라고 한 줄 알림.

5. 사용자가 **옵션 3**을 고르면 — 작업 종료.

> **예외**: 사용자가 처음부터 유형 A(랜딩)를 요청했다면 이 게이트는 건너뜀.

### STEP 1 — 유형 선택 (Q1)

`AskUserQuestion` 한 번으로 어떤 유형을 만들지 확정.

```
질문: "어떤 자산을 만드시겠어요?"
header: "Asset type"
options (4개씩 두 번에 나눠야 7개를 다 못 보임 — 한 번에 4개):
  1. 랜딩 페이지 (React 무빌드, 11섹션)
  2. Instagram 카드뉴스 데크 (1080×1080, 5~7장)
  3. 갤러리 카드 스택 (시안 보드, N장 그리드)
  4. A4 인쇄 가이드북 (PDF용)
```

만약 사용자가 "기타"로 다른 유형(B Templates, C Karrot, F 디바이스 목업)을 골랐다면 후속 질문으로 다시 선택.

### STEP 2 — 도메인 인터뷰 (유형별 분기)

**유형별로 묻는 항목이 다름.** 매 질문은 `multiSelect: false`, 옵션은 "추천안 2~3개 + 기타" 형식으로 제시해 사용자가 빠르게 고를 수 있게 함. "기타"를 고르면 자유 입력으로 받음.

**질문 묶기 규칙:**
- **유형 A (랜딩)**: 한 메시지에 **반드시 질문 1개**만. 답변을 받은 뒤 다음 질문으로 진행. 묶어 묻지 말 것.
- **유형 B~F**: 관련 항목 2~3개까지 한 메시지에 묶어도 됨(사용자 피로도 ↑ 방지 위해 최대 3개).
- **모든 질문 본문에 실제 예시 2~3개**를 함께 제시 — 사용자가 무엇을 어떤 톤·길이로 답하면 되는지 보고 따라 쓸 수 있게. 옵션 description 또는 질문 본문 어디든 OK.

#### 모든 유형 공통 — Q2 브랜드 기본

```
질문 1: "브랜드(또는 프로젝트) 이름과 한 줄 카테고리는?"
  → AskUserQuestion options: 사용자가 직접 입력하도록 "Other" 유도
질문 2: "타깃 고객을 한 문장으로?"
질문 3: "톤은?" (따뜻함 / 똑똑함 / 유쾌함 / 권위감)
질문 4: "컬러 무드?" (각 옵션에 preview로 색 3개 미리보기 제공)
  - Warm pink + sage     (예: #E8C9C0 / #5A6B52 / #FAF6F0)
  - Cobalt + cream       (예: #2A5BD7 / #F5F1E8 / #1A1F2E)
  - Forest + amber       (예: #2F5D3A / #D9A441 / #FBF6EC)
  - Mono ink + accent    (예: #111111 / #FF6B35 / #F5F5F5)
```

#### 유형 A: 랜딩 페이지 — **반드시 한 번에 하나씩** 질문

> 랜딩은 11개 섹션을 카피·이미지·CTA로 가득 채우는 작업이라, 한꺼번에 4개씩 묶어 물으면 사용자가 대충 답하게 되고 결국 자리표시자("○○", "[ ... ]")로 가득 찬 빈약한 결과물이 나옵니다. 따라서 **랜딩(유형 A) 인터뷰만큼은 `AskUserQuestion`을 한 질문씩 호출**합니다 — 같은 메시지에 여러 질문 묶기 금지. 또한 매 질문에는 사용자가 빈칸 채우기처럼 답할 수 있도록 **실제 예시 2~3개를 옵션이나 질문 본문에 함께** 보여줍니다.
>
> 답이 짧거나 모호하면(예: "그냥 좋게", "알아서") **그 자리에서 한 번 더 구체화 질문**을 던집니다. 자유 입력이 필요할 땐 옵션에 추천안 2~3개를 미리 채워 "Other"로 직접 쓰게 유도 — 빈 입력창만 던지지 말 것.

다음 순서대로 **한 번에 한 질문씩** 진행합니다. 각 질문의 옵션·예시는 도메인(Q2에서 받은 카테고리)에 맞춰 즉석에서 살짝 각색해도 좋지만, 예시 개수는 줄이지 마세요.

**A-1. 핵심 약속 (헤드라인 씨앗) 한 문장**
- 질문 본문에 다음과 같은 예시를 보여줄 것:
  - 산전 요가: "김해 1:1 화상으로, 임신 28주에도 안전한 요가"
  - 1:1 영어 과외: "현직 미국 변호사와 주 2회, 3개월 만에 비즈니스 이메일 자력 작성"
  - 수제 디저트 구독: "보존료 없이 매주 금요일 도착하는, 4종 계절 디저트"
- 옵션: ["위 예시처럼 짧고 구체적으로", "내가 직접 쓸게요 (Other로 입력)"]

**A-2. 차별점 3가지** — 한 번에 3개 모두 받되, 예시로 톤을 잡아줌
- 본문 예시:
  ```
  산전 요가 예:
   1) 김해 1:1 화상 — 이동·대기 0, 산모 컨디션에 맞춘 그 날의 시퀀스
   2) 3년차 산전·산후 전문 강사 — RYT200 + 산전요가 지도자 자격
   3) 평일 야간·주말 슬롯 — 남편 퇴근 후 함께 상담 가능
  ```
- 옵션: 도메인 카테고리에 맞춘 추천안 1세트(3개) + "직접 쓸게요"

**A-3. 상품/플랜 구조** — 트랙·요금제·메뉴
- 본문 예시 (도메인별):
  - 코칭/레슨: "1회 체험 3.3만 / 4주 12회 28만 / 12주 36회 75만"
  - SaaS: "Free · Pro 19$/월 · Team 49$/월·사용자"
  - 디저트 구독: "4종 9.8만/월 · 6종 13.8만/월 · 단건 2.8만"
- 옵션: ["3트랙 구성", "2트랙 구성", "단일 상품 + 옵션", "직접 입력"]
- 사용자가 트랙 수를 고르면 **A-3b**로 각 트랙의 이름·가격·메타 3셀을 채우게 함

**A-4. 권위·신뢰 근거** — 정량으로
- 본문 예시:
  - "RYT200 + 산전요가 전문가 자격 / 누적 회원 230명 / 평균 만족도 4.9/5"
  - "미국 CA 변호사 면허 2014 / WSJ·한경 기고 5회 / 1:1 수강생 누적 84명"
- 옵션: ["자격·수상 위주", "숫자(누적·평점) 위주", "미디어 노출 위주", "직접 입력"]

**A-5. CTA 행동** — 헤더와 Apply 폼이 같이 사용
- 옵션 (각 옵션 description에 어떤 도메인에 어울리는지 한 줄):
  - "무료 체험 신청" — 레슨·코칭·SaaS
  - "상담 신청" — B2B·고가 서비스
  - "사전 예약" — 모집 시즌·런칭 전
  - "다운로드 / 가이드 받기" — 리드 수집형
  - "직접 입력"

**A-6. Instructor / About 섹션을 "사람" vs "회사"**
- 옵션:
  - "사람 (1인 강사·전문가 프로필)" — 자격·경력·임팩트 숫자 3개
  - "회사 (팀·연혁·미션)" — 팀 사진 placeholder + 연혁 타임라인
- description에 어떤 카피·SVG가 채워질지 한 줄로 미리 알림.

**A-7. 섹션별 보강 입력** (선택, 시간 여유 시) — 한 질문씩
- "타깃 고객의 가장 큰 망설임 3가지는?" → PainPoints 4카드의 씨앗 (예: "임신 중 운동이 무서워요 / 대면 수업은 부담돼요 / 산후에 시간이 없어요")
- "FAQ에 반드시 들어가야 할 질문 3개는?" (예: "환불 정책은? / 출산 직후 가능한가요? / 결제는 어떻게 하나요?")
- "Testimonials 4개의 톤은?" — 회원 가상 닉네임 + 한 줄 후기 씨앗

> A-7은 사용자가 "이건 알아서 채워줘"라고 하면 합리적 placeholder("○○ 회원님" 등)로 채우고 STEP 3 요약에서 알림.

#### 유형 B/C/D: 인스타 데크 (카드뉴스·템플릿·당근·갤러리)

```
- 주제 한 줄 (예: "어버이날, 엄마에게도" / "6월 모집")
- 카드 수 (3 / 5 / 7 / 사용자 지정)
- 슬라이드 구성 자동 추천(예: Cover→Intro→Principle×3→CTA) 후 OK/수정 확인
- 핸들 / 워터마크 텍스트 (예: @yourbrand.kh)
- 사용할 PALETTES 키 (기존 랜딩이 있으면 같은 키 권장)
```

#### 유형 E: A4 인쇄 가이드북

```
- 책 제목 / 부제
- 챕터 구성 (자유 입력. 예: "표지 1p + 인트로 2p + 4주 챕터 각 6p + 부록 2p")
- 인쇄용 색감 (paper-warm / paper-cool / pure-white)
- 표지에 큰 일러스트가 필요한지 (Y/N)
```

#### 유형 F: 디바이스 목업

```
- 디바이스 (iPhone 15 Pro / Galaxy S24 / iPad / 데스크톱 브라우저)
- 화면 종류 (Instagram 프로필 / 카톡 채널 / 앱 홈 / 웹사이트 미리보기)
- 표시 콘텐츠 (핸들·게시물 컷 수·바이오 등 자유 입력)
```

### STEP 3 — 입력 요약 확인

수집한 모든 응답을 한 화면에 정리해 보여주고 마지막 확인:

```
질문: "이대로 생성할까요?"
options:
  1. 네, 만들어 주세요
  2. 일부 수정 (어떤 항목인지 자유 입력)
```

수정을 고르면 해당 항목만 다시 질문.

### STEP 4 — 파일 생성

[LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md)의 해당 유형 골격을 **그대로 따라** 파일을 작성.

> **출력 경로는 절대 스킬에 하드코딩하지 말 것.** 매번 [CLAUDE.md](../../../CLAUDE.md)의 **"산출물 저장 규칙"**을 Read해서 저장 위치를 결정한다 (워크스페이스마다 폴더 규칙이 다름). LANDING_PROMPT.md에 나오는 `landing/`·`marketing/` 같은 경로는 Claude Design 독립 저장소 기준 예시일 뿐이며, **이 워크스페이스에서는 CLAUDE.md가 우선**한다.

CLAUDE.md 규칙에 따라 결과물은 **자기완결 평탄 폴더 1개**(`<kebab-name>-<유형>/`)로 만들고, 작업 중에는 `docs/20.working/`·확정 시 `docs/30.output/`에 둔다(현 워크스페이스 기준 — CLAUDE.md를 따름). 유형별 폴더명·파일 구성:

| 유형 | 폴더명 | 파일 |
|---|---|---|
| A 랜딩 | `<kebab-name>-landing/` | `index.html`, `app.jsx`, `tweaks-panel.jsx`, `styles.css` |
| B 카드뉴스 | `<kebab-name>-card-news/` | `<YYYY-MM-DD>_<topic>_Card News.html` + `deck-stage.js` (사본) |
| C Karrot | `<kebab-name>-karrot/` | `Karrot Promo Cards.html` + `deck-stage.js` |
| D 갤러리 | `<kebab-name>-gallery/` | `<Series>.html` |
| E PDF | `<kebab-name>-guidebook/` | `<Title>.html` |
| F 목업 | `<kebab-name>-mockup/` | `<Device> <Screen>.html` |

**`deck-stage.js`가 필요한 유형(B·C·일부 D)**: 같은 워크스페이스에 기존 데크 폴더가 있으면 그 폴더의 `deck-stage.js`를 Read해 새 폴더에 **동일 사본**으로 Write(없으면 새로 작성). 절대 다른 폴더의 사본을 import·참조하지 말 것 — 각 결과물 폴더는 평탄·자기완결([CLAUDE.md](../../../CLAUDE.md)의 산출물 저장 규칙).

**기존 자산을 참고할 때**: 같은 유형의 기존 결과물 폴더(CLAUDE.md 산출물 경로에서 Glob로 탐색)를 한 번 훑어 시각 디테일·SVG 패턴을 차용 — 단, **카피·색·핸들은 새 인터뷰 값으로 완전히 교체**.

### STEP 5 — 검증

생성 후 [LANDING_PROMPT.md](../../../docs/90.reference/LANDING_PROMPT.md)의 해당 유형 "[검증 체크리스트]"를 한 줄씩 자체 점검. 통과 못 하는 항목이 있으면 수정 후 다시 검증.

랜딩(A)이라면 특히:
- `TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{...}/*EDITMODE-END*/` 마커가 `app.jsx` 상단에 동일한 형태로 존재
- `PALETTES`와 `TweakColor` 옵션 배열이 1:1 동기화
- 11개 섹션이 순서대로 존재

### STEP 6 — 사후 안내

생성된 파일 경로(CLAUDE.md 규칙에 따른 실제 저장 위치) + 다음 단계 옵션을 한 문장씩 안내:

1. **미리보기**: `python -m http.server 8000` → `http://localhost:8000/<결과물 폴더 경로>/`
2. **PDF 출력**: 가이드북·인쇄물이면 브라우저 `Ctrl+P` → "PDF로 저장"(여백 0·배경 그래픽 ON). 또는 헤드리스 Chromium `--print-to-pdf`로 렌더 검증.
3. **PNG/GIF/MP4 변환**: 카드·데크 자산이면 워크스페이스에 해당 변환 스킬(html-to-png / make-gif / make-mp4 등)이 있을 때 그걸 사용. 없으면 헤드리스 Chromium `--screenshot`로 PNG 캡처.
4. **확정 시 승격**: 작업이 끝나 공유·배포 단계면 결과물 폴더를 `docs/20.working/`에서 `docs/30.output/`로 이동(CLAUDE.md 산출물 저장 규칙).

연관 후속 자산 제안도 한 줄로:
- 랜딩을 만들었다면 "같은 팔레트로 카드뉴스 5장도 만들어 드릴까요?"
- 카드뉴스를 만들었다면 "MP4 슬라이드쇼로 묶어 드릴까요?"

## Brand-agnostic 원칙

- 본 스킬은 **특정 브랜드 전용이 아님**. `LANDING_PROMPT.md`가 도메인 변수를 분리해뒀으므로, 인터뷰로 받은 새 브랜드 정보를 그대로 주입.
- 단, 같은 워크스페이스에 기존 랜딩 자산(CLAUDE.md 산출물 경로의 `*-landing/`)이 있을 때 사용자가 "같은 톤으로" 또는 별도 지시 없이 자산을 추가하라고 하면 — 그 랜딩 `app.jsx`의 `TWEAK_DEFAULTS.palette` 기본 키와 `PALETTES` 값을 그대로 채택.
- 사용자가 명시적으로 다른 도메인(예: "세무사 사무소", "베이커리")을 말하면, 기존 자산은 **시각 참고만** 하고 카피·SVG 일러스트·색은 **새 도메인에 맞춰 새로** 만듦.

## AskUserQuestion 사용 패턴

- **랜딩(유형 A) 인터뷰는 한 번에 정확히 1개 질문**. 답을 받고 다음을 묻기 — 묶지 말 것.
- 그 외 유형은 **한 번에 1~3개 질문**. 4개 넘으면 사용자 피로도 ↑.
- **모든 질문에 실제 예시 2~3개 포함**. 옵션 label·description 또는 질문 본문 어디에 넣어도 OK. 예시는 도메인에 맞는 구체적·정량 문장으로(추상어 금지).
- 각 옵션은 짧고(1~5단어) 상호배타적으로.
- 컬러 무드 질문에서는 `preview` 필드에 색 스와치를 ASCII로 그려 사용자가 보고 고를 수 있게:
  ```
  preview: "■■■  #E8C9C0\n■■■  #5A6B52\n■■■  #FAF6F0"
  ```
- 사용자가 "Other"를 고르면 자유 입력값을 그대로 변수로 사용.
- 인터뷰 도중 사용자가 "그냥 알아서 해줘"라고 하면 — 합리적 기본값으로 채우고 STEP 3 요약에서 한 번 더 확인 받음.

## 출력 후 절대 하지 말 것

- 다른 아티팩트 폴더의 파일을 import / link / symlink — 폴더 라운드트립이 깨짐.
- `package.json`, lock 파일, 번들러 설정 추가.
- 외부 이미지 CDN 사용 (Google Fonts만 허용).
- 기존 아티팩트의 파일을 동의 없이 수정 — 본 스킬은 **신규 생성** 전용.

## Example flow

```
사용자: "새 카드뉴스 시작해줘. 베이커리 신메뉴 알리는 거."

Skill:
  Q1: 어떤 자산? → [카드뉴스 데크] 선택
  Q2: 브랜드명? → "수요일베이커리"
  Q3: 톤? → 따뜻함
  Q4: 컬러 무드? → cream + caramel (preview로 색 스와치 표시)
  Q5: 카드 수? → 5장
  Q6: 슬라이드 구성 추천 (Cover→Hook→메뉴3종→CTA) — OK?
  Q7: 핸들? → @wednesdaybakery
  Q8: 요약 확인 → "네 만들어주세요"

→ (CLAUDE.md 산출물 규칙 확인 후) docs/20.working/wednesday-bakery-card-news/ 폴더 생성
  - 2026-05-19_신메뉴 5종_Card News.html
  - deck-stage.js (사본)

→ 사후 안내: 미리보기 명령 + PNG/PDF 변환 안내 + (확정 시 30.output 승격)
```
