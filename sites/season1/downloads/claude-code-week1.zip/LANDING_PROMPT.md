# Claude Design 공용 랜딩 프롬프트

도메인만 갈아끼우면 `landing/`과 동일한 품질·구조의 한국어 랜딩 아티팩트가 나오는 Claude Design 프롬프트입니다. `landing/` 아티팩트를 역설계해 "기술 골격(고정)"과 "도메인 입력(가변)"을 분리했습니다.

## 사용법

1. 아래 코드 블록을 그대로 복사해 Claude Design에 붙여넣기.
2. `[도메인]` 블록의 각 항목을 자기 비즈니스에 맞게 채움.
3. 생성된 폴더는 [marketing/](marketing/) 아래 케밥케이스(예: `marketing/tax-office-landing/`)로 보관 — 이때 [CLAUDE.md](CLAUDE.md)의 "새 핸드오프 번들을 받았을 때" 절차를 따름.

부속 자산(Instagram 카드, 가이드북 등)을 같은 무드로 이어 만들 때는 이 프롬프트로 랜딩을 먼저 만든 뒤, "위 `PALETTES.<키>`와 동일한 색·톤으로…" 처럼 후속 프롬프트를 이어가면 일관성이 유지됩니다.

---

```
당신은 단일 페이지 한국어 랜딩을 만드는 Claude Design 디자이너입니다.
아래 [기술 골격]은 그대로 따르고, [도메인]·[브랜드]·[제안] 블록만 사용자가
넣은 값으로 채워 자기완결적인 아티팩트 하나를 생성하세요.

═══════════════════════════════════════════
[도메인] — 사용자가 채움
═══════════════════════════════════════════
- 카테고리:          (예: SaaS 협업툴 / 1:1 영어 과외 / 수제 디저트 구독)
- 타깃 고객:         (한 문장)
- 핵심 약속:         (한 문장, 헤드라인의 씨앗)
- 차별점 3가지:      (각 한 줄)
- 상품/플랜 구조:    (트랙·요금제·메뉴 등 자유 형식)
- 권위/신뢰 근거:    (자격·수상·누적 사용자·미디어 등)
- 톤:                (예: 따뜻하고 차분 / 똑똑하고 시원시원 / 유쾌)
- 컬러 무드:         (예: dusty pink+sage / cobalt+cream / forest+amber)
- CTA 행동:          (무료 체험 / 상담 신청 / 사전 예약 …)

═══════════════════════════════════════════
[기술 골격] — 반드시 준수
═══════════════════════════════════════════

▶ 산출물
폴더 하나 안에 평탄(flat)하게 4개 파일만:
  index.html       (22줄 셸; React 18 UMD + Babel Standalone CDN)
  app.jsx          (모든 섹션·SVG·트윅 패널)
  tweaks-panel.jsx (재사용 트윅 셸; 호스트 postMessage 처리)
  styles.css       (정적 스타일, 색은 CSS 변수로만 참조)

▶ 절대 금지
- 빌드 도구·package.json·번들러·lock 파일
- 외부 이미지·폰트(Google Fonts만 허용)·아이콘 라이브러리
- 폴더 중첩, ../ 상위 참조, symlink
- TypeScript, JSX 외 트랜스파일 필요한 문법

▶ app.jsx 최상단은 정확히 이 형태
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "palette": "<key1>",
    "headlineWeight": 700,
    "showSticky": true,
    ...추가키
  }/*EDITMODE-END*/;
  // 마커는 호스트가 트윅값을 코드에 다시 쓸 때 파싱하는 경계 — 절대 제거 금지.

▶ 팔레트 시스템
  const PALETTES = {
    key1: { ivory, pinkSoft, pink, pinkDeep, sage, sageSoft, ink, muted },
    key2: { ... },
    key3: { ... }
  };
  // 도메인 무드에 맞춰 3종 제공. 키 이름은 의미 있게(예: forest/dawn/dusk).
  // styles.css는 --c-<키>로만 색을 참조. App에서 useEffect로
  // document.documentElement.style.setProperty('--c-<키>', value) 주입.

▶ 트윅 패널 (window.* 전역 사용)
  window.useTweaks, window.TweaksPanel, window.TweakSection,
  window.TweakColor, window.TweakRadio, window.TweakToggle, window.TweakSlider
  // tweaks-panel.jsx가 노출. 최소 3개 트윅: 팔레트 / 헤드라인 굵기 / sticky CTA.

▶ 일러스트
  도메인에 맞는 인라인 SVG 컴포넌트 4~6개. props로 {size, c} 받아
  stroke를 c.sage, 강조는 c.pinkDeep(이름은 팔레트 키 그대로)로 처리.
  사진은 placeholder div(stripes + label)로 비워두기.

▶ 타이포
  serif(헤딩) + sans(본문) 페어. Noto Serif KR + Noto Sans KR 기본.
  도메인이 다르면 적절히 교체(예: 영문 중심이면 Fraunces + Inter).

═══════════════════════════════════════════
[섹션 순서] — 11개, 순서·역할 고정. 카피만 도메인화.
═══════════════════════════════════════════

01 Hero
   nav(브랜드 + 4링크 + CTA) / 좌:헤드라인+서브+CTA 2개+trust row 3칸
   / 우:대표 SVG 카드(라이브감 있는 windowed 컨테이너) + float 카드 2개
02 PainPoints      "이런 분께 추천" 4카드(번호 + 2줄)
03 Differentiators 3카드(아이콘+제목+본문). 차별점 3가지 그대로.
04 Programs        2~4개 트랙/플랜 카드(태그·제목·메타 3셀)
05 HowItWorks      sage 배경 반전. 4스텝 + 마무리 안내.
06 Instructor/About 사진placeholder + 자격/경력/임팩트 숫자 3개
07 Testimonials    4리뷰(이름·상태·본문) - 가상 회원으로 표시(○○ 회원님)
08 FAQ             6항목, 단일 오픈 아코디언, 좌측 사이드에 채널문의 링크
09 Pricing         3~4 플랜, 가장 인기 highlight + "추천" 배지
10 Apply           폼(이름·연락처·상태select·시간대radio) + 클라이언트 검증
                   + 성공 화면. 백엔드 미연결, setSubmitted(true)로만 전환.
                   푸터에 "개인정보는 상담 목적으로만…30일 파기" 고지.
11 Footer          ink 배경. 브랜드·연락·사업자정보(placeholder OK)·copyright

+ StickyCTA       scrollY > 600에서 노출, 트윅으로 ON/OFF

═══════════════════════════════════════════
[카피 원칙]
═══════════════════════════════════════════
- 헤드라인은 줄바꿈으로 호흡(<br/>), 핵심 명사구는 <em>으로 강조.
- 본문은 짧고 단정한 한국어. 과장 형용사 자제, 구체 숫자(주차·분·회·%) 선호.
- CTA 동사는 "신청하기 / 시작하기" 등 행동형, 명사형 피함.
- 신뢰 문구는 자격·연차·인원·평점 형태로 정량화.
- placeholder가 필요한 위치는 ○○ / 0000 / [ ... ] 로 명시해 두기.

═══════════════════════════════════════════
[검증 체크리스트] — 생성 후 자체 점검
═══════════════════════════════════════════
□ 4개 파일이 폴더 안에 평탄하게 있는가
□ EDITMODE-BEGIN/END 마커가 app.jsx 상단에 그대로 있는가
□ PALETTES와 TweakColor 옵션 배열이 1:1로 동기화되어 있는가
□ styles.css가 색을 --c-<키>로만 참조하고 하드코딩이 없는가
□ 외부 이미지·번들러·lock 파일이 없는가
□ 11개 섹션이 모두 존재하고 순서가 맞는가
□ 폼이 클라이언트 검증 + 성공 화면을 갖고 백엔드를 호출하지 않는가
□ 모바일(<768px)에서도 nav·hero·grid가 깨지지 않는가
```

---

# 부속 마케팅 아티팩트 프롬프트

[marketing/](marketing/)의 10개 아티팩트를 분석해 6개 유형으로 정리했습니다. 모두 위 랜딩과 같은 무빌드·Google Fonts CDN·단일 폴더 평탄 구조 규칙을 따릅니다. 랜딩을 먼저 만든 뒤 같은 `PALETTES` 키를 그대로 인용하면 시각 일관성이 유지됩니다.

## 유형 한눈에

| # | 유형 | 캔버스 | 의존성 | 변환 산출물 |
|---|---|---|---|---|
| A | Instagram Card News (deck) | 1080×1080 | deck-stage.js | PNG/GIF/MP4 |
| B | Instagram Templates 4종 | 1080×1080 | deck-stage.js | PNG |
| C | Karrot Promo Cards (deck) | 1080×1080 | deck-stage.js | PNG |
| D | 갤러리 카드 스택 | 1080×1080 (scale-fit) | 없음 | PNG/GIF |
| E | A4 인쇄 가이드북 | 210×297mm | 없음 (@media print) | PDF |
| F | 단일 페이지 디바이스 목업 | 자유 | 없음 | 스크린샷 |

## 공통 전제 (모든 유형)

```
- 무빌드. package.json·번들러·lock 파일 금지.
- 폴더 안에 평탄하게: 메인 HTML 한 개 + (deck면 deck-stage.js 사본 한 개).
  deck-stage.js는 marketing/ 안 4개 deck 폴더에 사본이 있다 — 절대 공유시키지 말 것.
- 외부 의존성은 Google Fonts CDN만.
- 타이포: Noto Serif KR(헤딩) + Noto Sans KR(본문). 영문은 Inter/Fraunces.
- 색은 랜딩 PALETTES와 같은 키 이름(ivory/pinkSoft/pink/pinkDeep/sage/sageSoft/ink/muted)을
  사용해 후속 자산을 만들 때 색 토큰을 그대로 가져갈 수 있게 한다.
- 인라인 SVG만 사용. 외부 이미지·아이콘 라이브러리 금지.
- 한국어 카피, 시각적 placeholder는 ○○ / 0000 / [ ... ].
```

---

## A. Instagram Card News (deck)

5~7장 정사각 슬라이드. 한 주제(예: "어버이날, 엄마에게도")를 단편처럼 풀어냄.

```
deck-stage.js 웹 컴포넌트를 사용하는 1080×1080 슬라이드덱을 만드세요.

[입력]
- 주제: (예: 어버이날, 엄마에게도)
- 슬라이드 구성: 01 Cover → 02 Intro → 03~05 Principle 1~3 → 06 Summary → 07 CTA
- 톤/색: 랜딩의 <팔레트 키>를 그대로 사용 (없으면 dusty)
- CTA 행동: (예: 무료 체험 신청 / DM / 프로필 링크)

[기술 골격]
- 파일: <YYYY-MM-DD>_<주제>_instagram Card News.html + deck-stage.js (사본)
- <deck-stage> 안에 각 슬라이드는 <section class="slide" style="width:1080px;height:1080px">
- 1920×1080이 아닌 1080×1080 캔버스 — CSS의 design canvas 크기를 정사각으로 설정
- 색은 인라인 <style> 안 CSS 변수(--c-ivory 등)로만 참조
- 일러스트: lotus mark + 슬라이드별 인라인 SVG 보조 도형(원·잎·화살표 등)
- 발표자 노트는 선택 — 필요하면 <script type="application/json" id="speaker-notes">
- @media print 없음(스크린 전용). PNG export는 html-to-png 스킬이 처리.

[카피 원칙]
- Cover는 큰 명사구 + 부제 한 줄. 본문 슬라이드는 80자 이하.
- 핵심 단어 1~2개만 sage 또는 pinkDeep로 강조.
- 마지막 CTA 슬라이드에 "넘겨보기" 화살표 + 행동 동사.
```

---

## B. Instagram Templates 4종 (deck)

재사용 가능한 4개 템플릿(교육형 / 후기형 / 브랜드형 / 전환형)을 하나의 파일에 카드 3장씩 묶어 쇼케이스로 제시.

```
4개 템플릿을 12장 슬라이드(3장×4템플릿)로 한 파일에 묶은 데크를 만드세요.

[템플릿 정의]
T1 교육형 (Education)
  - Cover: 큰 숫자(예: "01") + 주제
  - Content: 일러스트 + 본문 + 3줄 팁
  - CTA: "FREE TRIAL" 박스 + DM 안내
T2 후기형 (Testimonial)
  - Cover: 회원 아바타(원형 placeholder) + 호칭
  - Quote: 큰 따옴표 + 본문 + ★★★★★ 5점
  - CTA: "YOUR TURN" + 신청 링크
T3 브랜드형 (Brand)
  - Quote Light: ivory 배경 + serif 큰 인용
  - Quote Dark: ink 배경 + ivory 텍스트로 같은 인용을 반전
  (브랜드 인용은 카드 2장이 한 세트)
T4 전환형 (Conversion)
  - Cover: ⏰ deadline + 한정 인원(예: "선착순 5명")
  - Benefits: 3줄 가치 나열
  - CTA: "APPLY NOW" + 마감일

[공통 요소]
- 좌상단: .tpl-label (T1/T2/T3/T4)
- 좌하단: .logo-mark (lotus)
- 우상단: .page-ind ("01/03")
- 우하단: .handle (@goyoyoga.kh 등)

[기술 골격]
- 파일: Instagram Templates.html + deck-stage.js (사본)
- 1080×1080. dark 슬라이드는 lotus stroke를 sage→ivory로 동적 변경.
```

---

## C. Karrot Promo Cards (deck)

당근마켓 동네생활 톤. 5장 정사각 슬라이드. 핵심은 친근함 + 오렌지 액센트.

```
1080×1080 슬라이드 5장의 당근마켓 동네 홍보 데크를 만드세요.

[슬라이드]
01 Hero Copy   "김해 ○○동 이웃님, 안녕하세요" — 친근한 인사 + 큰 카피
02~04 Content  서비스 소개 / 가격 / 방식 (한 슬라이드 한 메시지)
05 CTA         "동네생활에서 알려드리기" + 채널 안내

[Karrot 특화 요소]
- .karrot-tag: 좌하단 오렌지(#FF6F0F) 배경 둥근 태그 "당근"
- .corner-tag: 좌상단 브랜드 로고 미니 (랜딩 lotus 그대로)
- 배경: pinkSoft 그라디언트 + leaf SVG (opacity 0.4)
- 본문은 반말 살짝 섞인 동네말 톤("들러보세요" "보러오세요")

[기술 골격]
- 파일: Karrot Promo Cards.html + deck-stage.js (사본)
```

---

## D. 갤러리 카드 스택 (단일 페이지)

여러 카드를 한 페이지에서 한눈에 보여주는 "에디터용 시안 보드". deck-stage.js를 쓰지 않음. 산출 카드는 1080×1080이지만 CSS `transform: scale()`로 갤러리 안에 축소 배치. 이 유형이 가장 자주 등장합니다 (명상 커버 / 신년 캠페인 / 계절 프로그램).

```
1080×1080 카드 N장을 그리드로 늘어놓은 단일 페이지 시안 보드를 만드세요.

[입력]
- 시리즈명: (예: Meditation / New Year / Seasonal Summer)
- 카드 수: 3~15장. 필요시 여러 세트로 묶음(.set-head로 구분).
- 카드당 역할: Cover / Why / Program / Benefit / CTA 등 시리즈마다 다름.

[페이지 구조]
- .gallery-head: 페이지 타이틀 + 시리즈 메타(좌측 sage 세로선)
- .set-head: 세트 구분자(예: "Set 1 · 산후 회복") - 여러 세트면 반복
- .grid: display:grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
- .frame: 그림자·라운드가 있는 카드 외곽 chrome (export 시엔 제거됨)
- .card: 실제 1080×1080 디자인 캔버스. transform-origin: top left;
         transform: scale(<frame width> / 1080);
         그리고 .frame이 카드 비율을 유지하도록 aspect-ratio: 1/1.

[디자인]
- 카드별 그라디언트·일러스트·메타라벨을 다르게 주되 팔레트는 통일.
- 시리즈별 분기는 .set-head.<variant>로 색만 바꿈 (예: summer→#6B8A7A, winter→#B07868).

[변환]
- html-to-png 스킬이 .card만 풀블리드로 뽑아 1080×1080 PNG로 export.
- 따라서 .frame chrome(라운드·그림자·세트 헤드)은 카드 안에 들어가면 안 됨.
- 재생성 소스(_render/)는 archive/exports/<artifact>/ 아래에 별도 사본으로 둠.
```

---

## E. A4 인쇄 가이드북 (PDF용)

산후 챌린지 키트, 임산부 요가 가이드북 같은 장문 자료. html-to-pdf 스킬로 출력.

```
A4(210×297mm) 인쇄용 단일 HTML 가이드북을 만드세요.

[입력]
- 책 제목 / 부제
- 챕터 구성과 페이지 수 (예: 표지 1p + 인트로 2p + 4주 챕터 각 6p + 부록 2p)
- 톤: 따뜻하고 안내적. 의학·자격 근거가 들어가면 정량 표기.

[기술 골격]
- 파일: <Title>.html 단 하나. 외부 이미지 없음.
- @page { size: A4; margin: 0; }
- 각 페이지는 .page { width: 210mm; height: 297mm; padding: 22~24mm;
                       page-break-after: always; }
- 표지 .page.cover는 padding 제거 + radial-gradient 풀블리드.
- 본문 페이지: .running(상단 러닝 헤더, 도서명) + .folio(하단 페이지 번호).
- 타이포: h1.display 36pt serif / h2.chapter 22pt / .lead 13pt / 본문 11pt 1.65 라인.
- 구분: .divider--ornament (· · ·), .pills(태그), justified 정렬.
- @media print 블록에서 화면용 그림자·라운드를 제거.

[검증]
□ Chromium에서 Ctrl+P "PDF 저장"으로 페이지가 의도대로 잘리는가
□ .page-break-after가 모든 페이지에 걸려 있는가
□ 표지에 페이지 번호가 안 찍히는가 (:not(.cover) .folio)
```

---

## F. 단일 페이지 디바이스 목업 (스크린샷용)

Instagram 프로필 미리보기 같은 "디바이스 안에 화면을 그린" 단일 페이지.

```
iPhone/안드로이드 프레임 안에 화면 한 컷을 그린 단일 HTML을 만드세요.

[입력]
- 디바이스: iPhone 14 Pro / Galaxy S24 등
- 화면 종류: Instagram 프로필 / 카톡채널 / 앱 홈 등
- 표시할 콘텐츠: 브랜드 핸들, 게시물 9컷(또는 6컷) placeholder, 하이라이트, 바이오

[기술 골격]
- 파일: <Device> <Screen>.html 한 개.
- 디바이스 프레임은 인라인 SVG + CSS로 그림 (notch, 스피커, 둥근 모서리, 그림자).
- 상태바·하단 인디케이터까지 정확히 (시간 9:41, 신호·배터리).
- 콘텐츠는 진짜 앱과 똑같은 비율·간격으로 — 픽셀퍼펙트가 목적.
- 게시물 placeholder는 인라인 SVG 그라디언트 박스 9개.
- 반응형 X — 디바이스 한 모델 기준 고정 크기.

[용도]
- 클라이언트 보고용 스크린샷. PNG export는 단순히 Chromium 전체 페이지 캡처.
```

---

## 유형 선택 가이드

| 만들고 싶은 것 | 유형 |
|---|---|
| 한 주제로 5~7장 인스타 카드뉴스 | **A** Card News |
| 4종 템플릿을 한 번에 쇼케이스 | **B** Templates |
| 당근마켓 동네생활 홍보 | **C** Karrot |
| 명상 커버, 시즌 카드, 캠페인 다중 카드 모음 | **D** 갤러리 |
| 가이드북·워크북·인쇄 배포물 | **E** A4 PDF |
| 인스타 프로필 미리보기, 앱 화면 시안 | **F** 디바이스 목업 |

각 유형의 산출물을 PNG/GIF/MP4/PDF로 떨어뜨릴 때는 [CLAUDE.md](CLAUDE.md)의 "Export → PNG / GIF" 절차와 [.claude/skills/](.claude/skills/)의 5개 스킬(html-to-png, make-gif, make-mp4, html-to-pdf, make-card-news)을 그대로 사용하세요.
