---
name: image-to-pdf
description: 이미지 파일(JPG/PNG/WebP/BMP/TIFF 등)을 하나의 PDF로 묶거나 각각 PDF로 변환한다. 사용자가 "이미지를 PDF로", "스캔본 합쳐서 PDF", "사진들 PDF로 묶어줘" 같은 요청을 할 때 사용한다.
---

# image-to-pdf

여러 이미지를 한 PDF로 합치거나, 각 이미지를 개별 PDF로 변환한다.

## 사용 시점

- "이 폴더 이미지들 한 PDF로 묶어줘"
- "스캔 이미지들 합쳐서 PDF 만들어줘"
- "PNG들을 페이지별 PDF로 변환"

## 사전 준비

Pillow가 필요하다. 없으면 먼저 설치:

```powershell
pip install pillow
```

## 사용법

### 1) 여러 이미지를 하나의 PDF로 합치기 (기본)

```powershell
python .claude/skills/image-to-pdf/scripts/images_to_pdf.py `
  --output docs/30.output/merged.pdf `
  docs/10.input/scan1.jpg docs/10.input/scan2.jpg docs/10.input/scan3.jpg
```

폴더 통째로 (정렬 순서대로):

```powershell
python .claude/skills/image-to-pdf/scripts/images_to_pdf.py `
  --output docs/30.output/merged.pdf `
  --from-dir docs/10.input
```

### 2) 각 이미지를 개별 PDF로 변환

```powershell
python .claude/skills/image-to-pdf/scripts/images_to_pdf.py `
  --split `
  --output-dir docs/30.output `
  --from-dir docs/10.input
```

## 옵션

- `--output PATH` : 합쳐서 만들 PDF 경로 (기본 모드)
- `--split` + `--output-dir DIR` : 이미지 1장당 PDF 1개를 `DIR`에 생성
- `--from-dir DIR` : 폴더 내 이미지 자동 수집 (파일명 정렬)
- `--sort {name,mtime}` : 정렬 기준 (기본 `name`)
- `--ext jpg,png,webp,bmp,tif,tiff` : 수집할 확장자 (기본값 = 좌측 목록)
- 위치 인자 : 개별 이미지 경로들 (여러 개 가능)

## 동작 규칙

- RGBA/팔레트 이미지는 RGB로 변환 후 저장 (PDF는 알파 미지원).
- EXIF 회전 정보를 반영해 정방향으로 저장한다.
- 출력 폴더가 없으면 자동 생성한다.
- 입력 이미지가 0장이면 에러로 종료한다.
