"""Convert images to PDF (merge into one, or split into one PDF per image)."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from PIL import Image, ImageOps

DEFAULT_EXTS = ("jpg", "jpeg", "png", "webp", "bmp", "tif", "tiff")


def collect_from_dir(dir_path: Path, exts: tuple[str, ...], sort: str) -> list[Path]:
    files = [p for p in dir_path.iterdir() if p.is_file() and p.suffix.lower().lstrip(".") in exts]
    if sort == "mtime":
        files.sort(key=lambda p: p.stat().st_mtime)
    else:
        files.sort(key=lambda p: p.name.lower())
    return files


def load_image(path: Path) -> Image.Image:
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGB")
    elif img.mode != "RGB":
        img = img.convert("RGB")
    return img


def merge_to_pdf(images: list[Path], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    first, *rest = [load_image(p) for p in images]
    first.save(output, "PDF", save_all=True, append_images=rest)
    print(f"[OK] merged {len(images)} image(s) -> {output}")


def split_to_pdfs(images: list[Path], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    for p in images:
        target = out_dir / (p.stem + ".pdf")
        load_image(p).save(target, "PDF")
        print(f"[OK] {p.name} -> {target}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Convert images to PDF.")
    ap.add_argument("images", nargs="*", type=Path, help="image files")
    ap.add_argument("--from-dir", type=Path, help="collect images from this directory")
    ap.add_argument("--ext", default=",".join(DEFAULT_EXTS), help="comma-separated extensions when using --from-dir")
    ap.add_argument("--sort", choices=("name", "mtime"), default="name")
    ap.add_argument("--output", type=Path, help="merged PDF output path")
    ap.add_argument("--split", action="store_true", help="produce one PDF per image")
    ap.add_argument("--output-dir", type=Path, help="output directory when using --split")
    args = ap.parse_args()

    images: list[Path] = list(args.images)
    if args.from_dir:
        exts = tuple(e.strip().lower().lstrip(".") for e in args.ext.split(",") if e.strip())
        images.extend(collect_from_dir(args.from_dir, exts, args.sort))

    if not images:
        print("error: no input images", file=sys.stderr)
        return 2

    if args.split:
        if not args.output_dir:
            print("error: --split requires --output-dir", file=sys.stderr)
            return 2
        split_to_pdfs(images, args.output_dir)
    else:
        if not args.output:
            print("error: --output is required (or use --split)", file=sys.stderr)
            return 2
        merge_to_pdf(images, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
